# M R S brand kit

Put this whole `brand` folder inside your site's `public/` folder, so files are served at `/brand/...`.

```
brand/
  svg/      logo and mark (dark, light, mono), app icon, maskable icon, favicon, Camellia flower and avatars, watermark tile
  icons/    favicon.svg, favicon.ico (16/32/48), favicon PNGs, apple-touch-icon (180), icon-192/512, maskable-192/512, Camellia avatars, site.webmanifest
  social/   og-image.png (1200x630)
  docs/     head-tags.html (paste into <head>), this README
```

## Rules
- Every logo file is outlined paths only. There is no live text, no font, no image and no script inside the SVG files.
- Use `mrs-lockup-on-dark.svg` on the dark navy background and `mrs-lockup-on-light.svg` on light backgrounds. Use the mono files for one-colour print, stamps and watermarks.
- Minimum sizes: lockup 80 px wide on screen (or 25 mm in print); mark alone 16 px; below 24 px use `mrs-favicon.svg`, which has heavier strokes.
- Clear space: keep at least the height of one node circle free on all sides.
- Never recolour, stretch, rotate, outline, add shadows to, or place the logo on a busy photo. Camellia's flower is Camellia's own mark; do not use it as the company logo.
- Colours: navy #0B1220, ink #E6EDF7, cyan #22D3EE (on dark). On light backgrounds the cyan becomes #0891B2 for graphics. Do not use #0891B2 for small text (contrast 3.7:1 on white); use #0E7490 or darker for text.
- Camellia pink set: #EC4899, #F472B6, #F9A8D4, #FBCFE8 with #FBBF24 stamen dots.

## Checks already run on these files
- Lint: no text, tspan, image, script, style, foreignObject, href, filter, mask, clipPath or gradient elements; each file under 5 KB.
- Rendering parity: Chromium and librsvg produce matching pixels (under 0.1% differing) for the lockup, app icon, favicon, maskable icon and Camellia avatar.
- Maskable icon: zero non-background pixels outside the 80% safe circle (radius 204.8 of 512).
- Contrast: ink on navy 15.9:1; cyan on navy 10.4:1; ink on light 17.6:1; #0891B2 on white 3.7:1 (graphics only).
- The wordmark is Space Grotesk Bold (SIL Open Font License) converted to outlines.
