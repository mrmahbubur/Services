/**
 * Type declarations for the pre-built bundle (bundle/mrs-core.mjs).
 * The TypeScript source in server/mrs-core/ is the canonical, editable form;
 * this bundle is the same code compiled to one plain-JavaScript file.
 */
import type { Express } from 'express';

export interface Store {
  readonly kind: string;
  readonly durable: boolean;
}
export declare class MemoryStore implements Store {
  readonly kind: string;
  readonly durable: boolean;
}
export declare class FileStore implements Store {
  readonly kind: string;
  readonly durable: boolean;
  constructor(dir: string);
}
export declare class FirestoreStore implements Store {
  readonly kind: string;
  readonly durable: boolean;
  /** `db` is a Firestore handle from firebase-admin: getFirestore(app) or getFirestore(app, databaseId). */
  constructor(db: unknown, prefix?: string);
}

export interface InstallOptions {
  /** Where everything is kept. Use FirestoreStore in production. */
  store?: Store;
  /** Defaults to process.env. */
  env?: Record<string, string | undefined>;
  /** Optional hook for sending e-mail to clients. */
  sendEmail?: (to: string, subject: string, text: string) => Promise<void>;
}

export interface TickResult {
  jobsRun: number;
  paymentsChecked: number;
  paymentsVerified: number;
  paymentsEscalated: number;
  ordersAdvanced: number;
  binance: string;
  tookMs: number;
}

export interface Installed {
  core: unknown;
  tick: (budgetMs?: number) => Promise<TickResult>;
}

/** Call BEFORE app.use(express.json()) and before any existing /api routes. */
export declare function installMrsCore(app: Express, options?: InstallOptions): Installed;
export declare function hashSecret(plain: string): string;
