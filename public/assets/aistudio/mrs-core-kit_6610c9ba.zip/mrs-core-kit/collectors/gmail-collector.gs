/**
 * M R S — Gmail collector (Google Apps Script).
 *
 * WHAT IT DOES
 *   Runs inside YOUR Google account. Once a minute it looks for new e-mail from
 *   Payoneer, Skrill and Binance, and hands those messages to your website, signed
 *   with a secret only you and the site know. The site decides whether a message is
 *   a genuine "money received" notice; this script decides nothing.
 *
 * WHAT IT CAN SEE
 *   Only messages matching QUERY below (mail from those three senders). It never
 *   reads the rest of your mailbox, never sends mail, never deletes anything.
 *
 * SET-UP (once)
 *   1. script.google.com -> New project -> paste this file.
 *   2. Project Settings -> Script properties -> add:
 *        MRS_SITE           https://mrs-services.ai.studio
 *        MRS_INGEST_SECRET  (the same value as the site's MRS_INGEST_SECRET secret)
 *        MRS_CRON_SECRET    (only if the site has a separate MRS_CRON_SECRET)
 *   3. Run the function `setup` once and approve the permissions it asks for.
 *   4. Run `selfTest`. The log must end with "site answered 200".
 *
 * NOT YET RUN AGAINST A REAL MAILBOX: this was tested against a model of Apps
 * Script's services, not Google's own. Do step 4, then one real small payment.
 */

var QUERY = 'from:(payoneer.com OR skrill.com OR binance.com)';
var MAX_PER_RUN = 20;
var REMEMBER = 400; // ids of messages already handed over

/** Run once. Creates the two timers. */
function setup() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('run').timeBased().everyMinutes(1).create(); // mail + quick housekeeping
  ScriptApp.newTrigger('work').timeBased().everyMinutes(5).create(); // lets Camellia's queued jobs run
  Logger.log('Timers created: run (every minute), work (every 5 minutes).');
}

/** Every minute: hand new provider mail to the site. Also serves as the "I am alive" signal. */
function run() {
  var props = PropertiesService.getScriptProperties();
  var cfg = config_(props);
  var done = (props.getProperty('DONE') || '').split(',').filter(String);
  var doneSet = {};
  done.forEach(function (id) {
    doneSet[id] = true;
  });

  // Only threads with mail newer than the last successful run (minus 10 minutes of overlap).
  var since = Number(props.getProperty('SINCE') || 0) || Math.floor(Date.now() / 1000) - 2 * 86400;
  var startedAt = Math.floor(Date.now() / 1000);
  var threads = GmailApp.search(QUERY + ' after:' + (since - 600), 0, 30);

  var batch = [];
  for (var i = 0; i < threads.length && batch.length < MAX_PER_RUN; i++) {
    var messages = threads[i].getMessages();
    for (var j = 0; j < messages.length && batch.length < MAX_PER_RUN; j++) {
      var m = messages[j];
      var id = m.getId();
      if (doneSet[id]) continue;
      if (m.getDate().getTime() / 1000 < since - 600) continue;
      batch.push({
        id: id,
        authResults: firstAuthenticationResults_(m.getRawContent()),
        from: m.getFrom(),
        subject: m.getSubject(),
        body: String(m.getPlainBody() || '').slice(0, 10000),
        date: m.getDate().toISOString(),
      });
    }
  }

  var res = post_(cfg, '/api/ingest/email', { messages: batch }, cfg.ingestSecret);
  if (res.code !== 200) {
    Logger.log('Site refused the batch (' + res.code + '): ' + res.text.slice(0, 200) + ' - will try again next minute.');
    return; // nothing is marked done, so nothing is lost
  }
  batch.forEach(function (b) {
    done.push(b.id);
  });
  props.setProperty('DONE', done.slice(-REMEMBER).join(','));
  // Only move the window forward when everything found was handed over.
  if (batch.length < MAX_PER_RUN) props.setProperty('SINCE', String(startedAt));
  if (batch.length > 0) Logger.log('Handed over ' + batch.length + ' message(s): ' + res.text.slice(0, 300));

  tick_(cfg, '?jobs=0&budget=8000');
}

/** Every 5 minutes: let queued work run. Returns at once when there is nothing to do. */
function work() {
  tick_(config_(PropertiesService.getScriptProperties()), '?budget=240000');
}

/** Run by hand after set-up: checks the secret and the connection without touching your mail. */
function selfTest() {
  var cfg = config_(PropertiesService.getScriptProperties());
  var res = post_(cfg, '/api/ingest/email', { messages: [] }, cfg.ingestSecret);
  Logger.log('site answered ' + res.code + (res.code === 200 ? '' : ': ' + res.text.slice(0, 300)));
  if (res.code === 401) Logger.log('The secret here and MRS_INGEST_SECRET on the site are different.');
  if (res.code === 503) Logger.log('MRS_INGEST_SECRET is not set on the site.');
}

// ---------------------------------------------------------------- helpers

function config_(props) {
  var site = String(props.getProperty('MRS_SITE') || '').replace(/\/+$/, '');
  var ingestSecret = props.getProperty('MRS_INGEST_SECRET') || '';
  if (!/^https:\/\//.test(site)) throw new Error('Set MRS_SITE (https://...) in Script properties.');
  if (ingestSecret.length < 24) throw new Error('Set MRS_INGEST_SECRET (24+ characters) in Script properties.');
  return { site: site, ingestSecret: ingestSecret, cronSecret: props.getProperty('MRS_CRON_SECRET') || ingestSecret };
}

/**
 * The value of the FIRST "Authentication-Results" header: the one Gmail itself
 * added when it received the message. A sender can add look-alike headers of the
 * same name, but only underneath Gmail's. ("ARC-Authentication-Results" is a
 * different header and is not used.)
 */
function firstAuthenticationResults_(raw) {
  var text = String(raw || '').slice(0, 60000);
  var end = text.search(/\r?\n\r?\n/);
  var head = (end >= 0 ? text.slice(0, end) : text).replace(/\r?\n[ \t]+/g, ' '); // unfold continuation lines
  var lines = head.split(/\r?\n/);
  for (var i = 0; i < lines.length; i++) {
    var match = /^Authentication-Results:\s*(.*)$/i.exec(lines[i]);
    if (match) return match[1].slice(0, 3500);
  }
  return '';
}

/** JSON with every non-ASCII character escaped, so the bytes signed are exactly the bytes sent. */
function asciiJson_(value) {
  return JSON.stringify(value).replace(/[\u007f-\uffff]/g, function (c) {
    return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
  });
}

function hex_(bytes) {
  var out = '';
  for (var i = 0; i < bytes.length; i++) out += ('0' + ((bytes[i] + 256) % 256).toString(16)).slice(-2); // Apps Script bytes are -128..127
  return out;
}

/** X-Signature = hex HMAC-SHA256(secret, body + timestamp). Same scheme as the SMS bridge. */
function post_(cfg, path, payload, secret) {
  var body = asciiJson_(payload);
  var ts = String(Math.floor(Date.now() / 1000));
  var signature = hex_(Utilities.computeHmacSha256Signature(body + ts, secret, Utilities.Charset.UTF_8));
  var res = UrlFetchApp.fetch(cfg.site + path, {
    method: 'post',
    contentType: 'application/json',
    payload: body,
    headers: { 'X-Timestamp': ts, 'X-Signature': signature },
    muteHttpExceptions: true,
    followRedirects: false,
  });
  return { code: res.getResponseCode(), text: String(res.getContentText() || '') };
}

function tick_(cfg, queryString) {
  try {
    var res = UrlFetchApp.fetch(cfg.site + '/api/cron/tick' + queryString, {
      method: 'post',
      contentType: 'application/json',
      payload: '{}',
      headers: { Authorization: 'Bearer ' + cfg.cronSecret },
      muteHttpExceptions: true,
      followRedirects: false,
    });
    if (res.getResponseCode() !== 200) Logger.log('tick answered ' + res.getResponseCode());
  } catch (e) {
    Logger.log('tick failed: ' + e); // never let housekeeping stop the mail hand-over
  }
}
