#!/usr/bin/env node
/**
 * M R S — provider poller (Binance Pay history; optionally Skrill account history).
 *
 * WHY THIS RUNS ON YOUR OWN MACHINE
 *   Binance refuses API calls from United States addresses, and Google Cloud (where
 *   the site runs) is commonly treated as one. Skrill's query interface only answers
 *   to an IP address you have listed in advance. So this small script runs on a
 *   computer or phone of yours, reads your own account's incoming payments with a
 *   READ-ONLY key, and reports them to your site, signed with a shared secret.
 *
 * NEEDS   Node.js 18 or newer. No packages to install.
 *
 * SET-UP
 *   Create a file named  poller.env  next to this script (keep it private):
 *
 *     MRS_SITE=https://mrs-services.ai.studio
 *     MRS_INGEST_SECRET=<same value as the site's MRS_INGEST_SECRET>
 *     BINANCE_API_KEY=<Binance API key with ONLY "Enable Reading" ticked>
 *     BINANCE_API_SECRET=<its secret>
 *     # optional, only if your Skrill account has Settings > Developer Settings:
 *     # SKRILL_EMAIL=you@example.com
 *     # SKRILL_MQI_PASSWORD=<the separate API/MQI password, not your login password>
 *
 *   Check it once:      node poller.mjs --once
 *   Then keep it going: node poller.mjs
 *
 * SAFETY
 *   The Binance key must be read-only: no trading, no withdrawals. With a read-only
 *   key this script cannot move money even if the file is stolen.
 *
 * NOT YET RUN AGAINST THE REAL BINANCE OR SKRILL: no account was available when this
 * was written. It follows their published API references and was tested against a
 * stand-in server. Run it with --once and read what it prints.
 */
import { createHash, createHmac } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));

/** Reads KEY=value lines; real environment variables win. */
export function loadEnv(file, base = process.env) {
  const env = {};
  if (existsSync(file)) {
    for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
      if (m && !line.trim().startsWith('#')) env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
  return { ...env, ...Object.fromEntries(Object.entries(base).filter(([, v]) => typeof v === 'string' && v !== '')) };
}

/** Headers that prove the request comes from the holder of the secret. */
export function signedHeaders(secret, body, nowMs = Date.now()) {
  const ts = String(Math.floor(nowMs / 1000));
  return { 'Content-Type': 'application/json', 'X-Timestamp': ts, 'X-Signature': createHmac('sha256', secret).update(body).update(ts).digest('hex') };
}

export async function report(cfg, payload, fetchFn = fetch) {
  const body = JSON.stringify(payload);
  const res = await fetchFn(`${cfg.site}/api/ingest/provider`, { method: 'POST', headers: signedHeaders(cfg.ingestSecret, body), body, signal: AbortSignal.timeout(20_000) });
  const text = await res.text();
  if (res.status === 401) throw new Error('the site refused the signature: MRS_INGEST_SECRET here and on the site differ, or this computer\'s clock is wrong');
  if (res.status === 503) throw new Error('MRS_INGEST_SECRET is not set on the site');
  if (!res.ok) throw new Error(`the site answered ${res.status}: ${text.slice(0, 200)}`);
  return JSON.parse(text);
}

/** Binance Pay history since `startTime` (ms). Returns the rows exactly as Binance gives them. */
export async function binanceHistory(cfg, startTime, fetchFn = fetch, clockOffsetMs = 0) {
  const params = new URLSearchParams({ startTime: String(Math.max(0, Math.floor(startTime))), limit: '100', recvWindow: '10000', timestamp: String(Date.now() + clockOffsetMs) });
  const signature = createHmac('sha256', cfg.binanceSecret).update(params.toString()).digest('hex');
  const res = await fetchFn(`${cfg.binanceBase}/sapi/v1/pay/transactions?${params.toString()}&signature=${signature}`, { headers: { 'X-MBX-APIKEY': cfg.binanceKey }, signal: AbortSignal.timeout(15_000) });
  const text = await res.text();
  if (res.status === 451 || /restricted location/i.test(text)) throw Object.assign(new Error('Binance refuses requests from this network location. Run the poller from a network in a supported country.'), { code: 'restricted_location' });
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`Binance answered HTTP ${res.status} with a body that is not JSON`);
  }
  if (Number(json.code) === -1021) throw Object.assign(new Error('this computer\'s clock differs from Binance\'s'), { code: 'clock_skew' });
  if (Number(json.code) === -2015 || Number(json.code) === -2014) throw Object.assign(new Error('Binance rejected the API key: wrong key, "Enable Reading" not ticked, or this IP address is not on the key\'s allow-list'), { code: 'bad_key' });
  if (!res.ok || (json.code !== undefined && String(json.code) !== '000000')) throw new Error(`Binance error ${json.code ?? res.status}: ${json.message ?? json.msg ?? 'unknown'}`);
  return Array.isArray(json.data) ? json.data : [];
}

export async function binanceServerOffset(cfg, fetchFn = fetch) {
  const res = await fetchFn(`${cfg.binanceBase}/api/v3/time`, { signal: AbortSignal.timeout(8000) });
  const json = await res.json();
  return typeof json.serverTime === 'number' ? json.serverTime - Date.now() : 0;
}

/** Skrill account history as CSV text, from `sinceMs`. */
export async function skrillHistory(cfg, sinceMs, fetchFn = fetch) {
  const d = new Date(sinceMs);
  const start = `${String(d.getUTCDate()).padStart(2, '0')}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${d.getUTCFullYear()}`;
  const params = new URLSearchParams({ email: cfg.skrillEmail, password: createHash('md5').update(cfg.skrillPassword).digest('hex'), action: 'history', start_date: start });
  const res = await fetchFn(`${cfg.skrillBase}/app/query.pl?${params.toString()}`, { signal: AbortSignal.timeout(20_000) });
  const text = await res.text();
  if (!res.ok || /^\d{3}\s/.test(text.trim())) throw new Error(`Skrill answered: ${text.trim().slice(0, 120) || res.status} (is this IP address listed under Developer Settings, and is the MQI enabled?)`);
  return text;
}

export function readConfig(env) {
  const cfg = {
    site: String(env.MRS_SITE ?? '').replace(/\/+$/, ''),
    ingestSecret: env.MRS_INGEST_SECRET ?? '',
    binanceKey: env.BINANCE_API_KEY ?? '',
    binanceSecret: env.BINANCE_API_SECRET ?? '',
    binanceBase: String(env.BINANCE_BASE_URL ?? 'https://api.binance.com').replace(/\/+$/, ''),
    skrillEmail: env.SKRILL_EMAIL ?? '',
    skrillPassword: env.SKRILL_MQI_PASSWORD ?? '',
    skrillBase: String(env.SKRILL_BASE_URL ?? 'https://www.skrill.com').replace(/\/+$/, ''),
    everySeconds: Math.max(30, Number(env.POLL_SECONDS ?? 60) || 60),
  };
  const problems = [];
  if (!/^https?:\/\//.test(cfg.site)) problems.push('MRS_SITE must be the address of your site (https://...)');
  if (cfg.ingestSecret.length < 24) problems.push('MRS_INGEST_SECRET must be set (24+ characters, same as on the site)');
  if (!cfg.binanceKey !== !cfg.binanceSecret) problems.push('set both BINANCE_API_KEY and BINANCE_API_SECRET, or neither');
  if (!cfg.skrillEmail !== !cfg.skrillPassword) problems.push('set both SKRILL_EMAIL and SKRILL_MQI_PASSWORD, or neither');
  if (!cfg.binanceKey && !cfg.skrillEmail) problems.push('nothing to poll: set the Binance keys and/or the Skrill details');
  return { cfg, problems };
}

/**
 * One round. `state` is { binanceCursor, skrillCursor, skrillLastRun, clockOffsetMs } and is updated in place.
 * Returns what happened, as short lines.
 */
export async function pollOnce(cfg, state, fetchFn = fetch) {
  const lines = [];
  const now = Date.now();

  if (cfg.binanceKey) {
    try {
      let rows;
      try {
        rows = await binanceHistory(cfg, (state.binanceCursor ?? now - 24 * 3600_000) - 15 * 60_000, fetchFn, state.clockOffsetMs ?? 0);
      } catch (err) {
        if (err.code !== 'clock_skew') throw err;
        state.clockOffsetMs = await binanceServerOffset(cfg, fetchFn);
        rows = await binanceHistory(cfg, (state.binanceCursor ?? now - 24 * 3600_000) - 15 * 60_000, fetchFn, state.clockOffsetMs);
      }
      const incoming = rows.filter((r) => !String(r.amount ?? '').trim().startsWith('-'));
      const out = await report(cfg, { provider: 'binance', rows: incoming }, fetchFn); // an empty list is the "I am alive" signal
      state.binanceCursor = now;
      lines.push(`binance: ${rows.length} row(s) read, ${incoming.length} incoming, site recorded ${out.counts?.new ?? 0} new`);
    } catch (err) {
      lines.push(`binance: ${err.message}`);
      await report(cfg, { provider: 'binance', error: String(err.message).slice(0, 180) }, fetchFn).catch(() => undefined); // so the admin screen shows why
    }
  }

  if (cfg.skrillEmail && now - (state.skrillLastRun ?? 0) >= 5 * 60_000) {
    state.skrillLastRun = now;
    try {
      const csv = await skrillHistory(cfg, (state.skrillCursor ?? now - 2 * 86_400_000) - 86_400_000, fetchFn);
      const out = await report(cfg, { provider: 'skrill', csv }, fetchFn);
      state.skrillCursor = now;
      lines.push(`skrill: history read, site recorded ${out.counts?.new ?? 0} new`);
    } catch (err) {
      lines.push(`skrill: ${err.message}`);
      await report(cfg, { provider: 'skrill', error: String(err.message).slice(0, 180) }, fetchFn).catch(() => undefined);
    }
  }
  return lines;
}

async function main() {
  const { cfg, problems } = readConfig(loadEnv(join(HERE, 'poller.env')));
  if (problems.length > 0) {
    console.error('Cannot start:\n' + problems.map((p) => `  - ${p}`).join('\n'));
    process.exit(2);
  }
  const stateFile = join(HERE, 'poller-state.json');
  const state = existsSync(stateFile) ? JSON.parse(readFileSync(stateFile, 'utf8')) : {};
  const once = process.argv.includes('--once');
  console.log(`M R S poller -> ${cfg.site}  (Binance: ${cfg.binanceKey ? 'on' : 'off'}, Skrill: ${cfg.skrillEmail ? 'on' : 'off'}, every ${cfg.everySeconds}s)`);
  for (;;) {
    let lines;
    try {
      lines = await pollOnce(cfg, state);
    } catch (err) {
      lines = [`could not reach the site: ${err.message}`];
    }
    writeFileSync(stateFile, JSON.stringify(state));
    for (const l of lines) console.log(`${new Date().toISOString()}  ${l}`);
    if (once) break;
    await new Promise((r) => setTimeout(r, cfg.everySeconds * 1000));
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((err) => {
    console.error(err.message);
    process.exit(1);
  });
}
