# Going live

Do this after INTEGRATION.md. It connects each payment method to its source of truth and
then proves each one with a real, small payment. Until a method has passed its test here,
treat it as "the owner confirms by hand".

Everything in this file needs your accounts and your phone, so none of it could be done
or tested from my side.

## A. Connect the sources

### 1. bKash and Nagad: your phone forwards the operators' SMS

The SIM for `01810853282` receives an SMS for every bKash and Nagad movement. An Android
app on that phone forwards incoming SMS to the site.

- **App**: any SMS-to-webhook forwarder that can sign its requests or send a fixed
  header. The server speaks the format of the open-source *SMS Gateway for Android*
  (`docs.sms-gate.app`, "Webhooks"): event `sms:received`, headers `X-Signature` and
  `X-Timestamp`. I have not run that app; follow its own guide for the exact screens.
- **Webhook address**: `https://mrs-services.ai.studio/api/ingest/sms`
- **Signing key**: set the app's webhook signing key to the value of your
  `MRS_SMS_SIGNING_KEY` secret.
- A forwarder that cannot sign: set `MRS_SMS_BEARER_TOKEN` on the site (32+ random
  characters) and have the app send the header `Authorization: Bearer <that value>`,
  with a JSON body `{ "sender": "...", "message": "..." }`.
- Keep the phone charged, online, and the app excluded from battery saving.

**Privacy, plainly.** Most forwarders send *every* SMS the phone receives, not only
bKash and Nagad. The server keeps only operator transaction messages; everything else,
including one-time codes, is dropped without being stored or logged (tested). The other
messages still travel to your server on the way to being dropped. If the app can filter
by sender, forward only `bKash`, `16247`, `NAGAD` and `16167`. Best is a spare phone that
holds only this SIM.

If your operator shows a different sender name, add it with the site secrets
`MRS_SMS_SENDERS_BKASH` / `MRS_SMS_SENDERS_NAGAD` (comma-separated). Never add an
ordinary phone number there: a sender ID that anyone can text from proves nothing.

### 2. Payoneer and Skrill (and Binance as a backup): Gmail collector

1. Make sure Payoneer, Skrill and Binance send their notices to the Gmail account you
   will use, **directly** (not auto-forwarded from another mailbox: forwarding breaks the
   proof that the message is genuine).
2. Go to `script.google.com`, create a project, paste `collectors/gmail-collector.gs`.
3. Project Settings → Script properties: `MRS_SITE` = `https://mrs-services.ai.studio`,
   `MRS_INGEST_SECRET` = the same value as on the site.
4. Run `setup` once and approve the permissions. Run `selfTest`; the log must end with
   `site answered 200`.

The script reads only mail from those three senders, and also calls the site's tick every
minute (see INTEGRATION.md, step 8).

### 3. Binance: read-only key and the poller

1. Binance → API Management → create a key. Tick **only "Enable Reading"**. No trading,
   no withdrawals. With a read-only key nothing can be moved even if the key leaks.
2. On a computer that stays on (or the same Android phone, with Termux and Node.js),
   copy `collectors/poller.mjs`, create `poller.env` next to it as described at the top
   of that file, then run `node poller.mjs --once`.
3. Expected: `binance: N row(s) read, …`. If it says Binance refuses the network
   location, that machine cannot be used; try another network. Then run `node
   poller.mjs` and leave it running.

Why not on the site itself: Binance refuses API calls from Google Cloud addresses. You
may try anyway by setting `BINANCE_API_KEY` and `BINANCE_API_SECRET` as site secrets;
the self-test will say whether Binance accepted or refused.

### 4. Alerts to your phone (optional, recommended)

Telegram → BotFather → `/newbot` → copy the token into `TELEGRAM_BOT_TOKEN`. Send your new
bot any message, open `https://api.telegram.org/bot<token>/getUpdates`, copy the number
at `chat.id` into `TELEGRAM_CHAT_ID`. Without this, everything that needs you is still
listed in the admin console; you just are not pinged.

## B. Prove each method with real money

Small amounts are enough: a part payment is recorded like any other.

### Before anything: the self-test

Admin → Self-test (or the command in INTEGRATION.md). Fix whatever it lists except the
bridges, which turn green as you go.

### bKash

1. **Read test, no money.** Open a real *"You have received Tk …"* SMS from bKash on your
   phone. Admin → Test a message → kind SMS, sender `bKash`, paste the text. It must show
   `outcome: credit` with the right amount, transaction ID and balance.
   If it does not, stop and send me that SMS with the digits changed; the reader needs
   adjusting to your operator's wording.
2. **Confirm your balance once.** Admin → Wallet balance → enter the balance your bKash
   app shows.
3. **Live test.** Place a test order for the CV service. From another bKash number, Send
   Money **Tk 10** to `01810853282` and type the order's `PAY-…` reference in the
   Reference field. Within about a minute, without anyone typing anything on the site,
   the order thread must show *"Payment confirmed: Tk 10.00 received … still due"*.
4. **Claim test.** Send another Tk 10 **without** a reference, then enter its transaction
   ID on the pay page. It must go from "waiting for the provider's record" to verified.
5. **Forgery test.** From the other phone, send an ordinary SMS to `01810853282` that
   copies a bKash message. Nothing may be recorded.

### Nagad

Same five steps, sender `NAGAD`.

### Binance

1. From another Binance account, Pay → Send **1 USDT** to UID `38927942`.
2. The poller prints `… 1 incoming, site recorded 1 new`; Admin → Payments shows the
   record under ledger entries.
3. On the pay page of a test order, choose Binance and enter the **Order ID from the
   payer's receipt**. Expected: verified.
   This step answers a question I could not: whether that Order ID is the same string as
   the ID Binance's API reports. If the payment stays "waiting", send me both strings
   (the one on the receipt and the one in the ledger entry); the comparison needs a
   one-line change.

### Payoneer and Skrill

These cannot be rehearsed for free, so use the first real payment on each.

1. When the provider's e-mail arrives, look at Admin → Payments → ledger entries within
   two minutes.
2. If a record appeared with the right amount: the notice was read. If the customer's
   claim then verified by itself, that method is automatic for you.
3. If nothing appeared, look at Admin → *Unread messages from providers*. Confirm the
   payment by hand (**Received**), and send me the e-mail's subject and text with names
   and figures changed. The reader was written without a real sample and is deliberately
   strict.

Either way the customer is not left waiting: you get the alert and confirm in one tap.

### Camellia

1. Self-test with the live model call: `ai_model` must say the model answered.
2. Place a CV order with your **own** CV and a real job posting. Admin → Work → the draft
   appears for review within a few minutes.
3. Read the draft and its checks before releasing. This is the first time real model
   output meets the checks. In particular: does the "No new names, tools or
   organisations" check flag ordinary words? If it does often, tell me which; the word
   list needs tuning.
4. Only after several good drafts, consider switching on auto-release for that service.

## C. Day to day

Open the admin overview. **Needs you** lists, in order of urgency:

| It says | Do |
|---|---|
| Quotes | read the order, set the price |
| Payments | open the provider's app; **Received** or **Not received** |
| Drafts | read, then **Release** or **Send back** with a note |
| Hands-on tasks | do the work with the customer; **Hands-on step done** with notes |
| Failed jobs | read the reason; **Run again**, or do it by hand and upload |

Made a mistake, or sent money back? **Reverse** the payment. The invoice loses the
credit, locked files lock again, and the payment comes back to your queue: confirm it
again with the right amount, or mark it not received. A reversed payment never verifies
itself again, and after a refund that transaction cannot pay for another order.

Alerts worth acting on at once:

| Alert | Meaning | Do |
|---|---|---|
| "balance does not add up" | an SMS reported a balance that does not follow from the last | open the wallet app. Balance matches → confirm it. Does not match → do **not** approve; someone may be texting your phone fake messages |
| "The SMS phone is not reporting" | payments are waiting and the phone is silent | check power, network, the forwarder app |
| "A payment e-mail failed authentication" | an e-mail claimed to be a payment notice and is not from the provider | nothing; it was ignored. It is a scam attempt |
| "The bank SMS disagrees with a recorded payment" | you confirmed a payment by hand, and the operator's SMS then showed a different amount | check the app; **Reverse**, then confirm again with the real amount |
| "Failed admin sign-in" | a wrong admin password was entered | if it was not you, change the password and use *sign out everywhere* |

## D. Settings worth a decision

- **Automatic limits** (`autoVerifyLimitsUsd`): SMS and e-mail $50, API $500 by default.
  Above the limit you confirm by hand. Raise them only after section B has passed.
- **Kill switch**: stops all automatic settlement at once.
- **Reference-only payments** (`autoMatchByReference`): on by default. Tell customers to
  write the `PAY-…` reference on the transfer; it is the smoothest path for them.
- **Rate** (`usdToBdt`): 100 by default, as on the site today. It is frozen on each
  invoice when the invoice is issued.
