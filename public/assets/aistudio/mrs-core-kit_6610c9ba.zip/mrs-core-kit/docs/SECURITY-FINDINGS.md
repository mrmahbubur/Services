# What I found on the live site

Checked against `https://mrs-services.ai.studio` on 2026-11-11 (04:46 UTC), page script
`/assets/index-rscqN_Hx.js`. Everything below was read from what the site serves to any
visitor. I sent no request that changes data.

These are listed first because they decide what "real" has to mean. Items 1–3 can be
used by a stranger today.

## 1. The admin API answers anyone

| Request, with no login | Answer |
|---|---|
| `GET /api/admin/payments?queue=all` | 200, JSON: payment queue, ledger, settings |
| `GET /api/admin/payment-registry` | 200, JSON |
| `GET /api/admin/accountant-pack` | 200, JSON: income export |

The admin page calls the routes that *change* things the same way, with no credentials:
`POST /api/admin/payments/:id/verify`, `.../owner-confirm`, `.../reject`,
`POST /api/admin/ledger`, `PUT /api/admin/payment-settings`. I did not call those,
because that would alter your data. Since the page sends nothing that could identify the
owner, the server cannot be checking anything. Treat them as open: anyone can mark a
payment "received".

**Fixed by:** every `/api/admin/*` route requires a server-side admin session
(`security/auth.ts`); with no password configured the admin API is closed, not open.

## 2. The admin password is published in the page

The page's script contains the check itself:

```
e === "mrs2026admin" || e === "admin"
```

and "being logged in" is `localStorage.mrs_admin_session = "true"`, a value any visitor
can set in their own browser. So the password protects nothing, and both values are now
public.

**Fixed by:** the password is checked on the server and never sent to the browser.
`config.ts` refuses those two values if they are ever configured again.

## 3. The secret that authenticates "bank SMS" is public

The page's script contains `mrs_bridge_secret_998124` and `mrs_live_bridge_secret_2026`.
The open admin endpoint in item 1 also returns a field `settings.smsSecret`, and its
value is one of those two. That secret is what tells the server "this SMS really came
from the owner's phone". With it, anyone can post a made-up *"You have received Tk
1,500…"* message and have a payment verified automatically. There is also a
`/api/admin/simulator/run` route on the live server whose purpose is to manufacture a
verified payment.

**Fixed by:** collectors sign each request with a secret that exists only in server
settings (`security/hmac.ts`); stale and replayed requests are refused; the simulator is
removed (it answers 410); both published secrets are refused as configuration.

## 4. Orders never leave the customer's browser

The page saves orders, clients, invoices, messages and deliverables with
`localStorage.setItem("mrs_orders", …)` and similar. It contains no request that sends an
order to the server (the only server calls are the payment, chat, admin and health
routes), and its Firestore connection is used for a single connectivity check.

What that means in practice:

- When a customer places an order on their phone, **you do not receive it.** It exists
  on that phone only.
- The customer's "portal" is the same: clear the browser or switch device and it is gone.
- The Client ID + PIN check runs in the browser, against data in the browser, with a
  fixed salt (`_mrs_salt_2026`) that is in the public script.
- The server has no order or invoice to verify a payment against. The live payment
  queue is empty.

**Fixed by:** orders, invoices, clients, messages and files are stored on the server
(`orders/service.ts`); the browser shows what the server returns.

## 5. The "work" is a fixed template

- The "AI draft" for the CV service is a hard-coded text about a fictional *"Software
  Engineer & Technical Architect … Senior Solutions Developer | Digital Core Ltd."* with
  invented figures. It is the same for every customer and does not read their CV.
- Camellia's replies in the portal are fixed sentences chosen by keyword after a
  1.2-second delay (`"ATS Optimizer analysis underway…"`).
- "Mark complete" attaches a placeholder file containing the service name.

No model is called for any of this. A paying customer would receive someone else's
made-up career.

**Fixed by:** the fulfilment pipeline (`fulfilment/`), which works from the customer's
own material and blocks delivery when a check fails.

## 6. The payment panel reports checks that did not run

The customer's "Payment Review Status" panel prints **PASS / SIGNED / VALIDATED** for
*Transaction ID Validation*, *Locked Invoice Amount Match (0.00 deviation)*,
*Cryptographic Proof Integrity* and *Official Registry Destination*. These are fixed
labels in the page. They appear for any transaction ID, including one that does not
exist.

**Fixed by:** `GET /api/payments/:id/status` returns `checkResults`, each with a real
status. The page must display those (see FRONTEND-CHANGES.md).

## 7. Data does not appear to survive a restart

The server reported an uptime of under five minutes when checked, the admin page labels
its storage "Firestore / In-Memory", and the payment queue held 0 payments and 2 ledger
rows. That pattern is what an in-memory store reseeded on each start looks like. I
cannot see the server code, so this is an inference.

**Fixed by:** `FirestoreStore`. The readiness check and the admin self-test report
plainly when storage is not durable.

## 8. Smaller things

- The script contains a string shaped like a Telegram bot token (it includes the words
  `demo-token`). If it was ever a real token, revoke it in BotFather.
- Ratings, review counts, order counts and three named reviews are constants in the
  script, not computed from orders. If they are not true figures, remove them.
- The home page mentions "Cards & Wise" and "Bank Transfer"; the five real methods are
  bKash, Nagad, Binance, Payoneer and Skrill.
- On a failed payment submission the page silently saves the claim in the browser and
  shows success. The customer believes it was sent.
- Camellia is presented as "M R S Team · Service Coordinator". She is software. In this
  kit she says so when asked; the page should label her as an AI assistant.

## What to do now

1. Until the server side of this kit is installed, do not trust any "verified" status
   on the site. Confirm each payment in the bKash / Nagad / Binance / Payoneer / Skrill
   app yourself.
2. Install the kit (INTEGRATION.md). Choose a **new** admin password and new secrets.
   The published ones must never be reused.
3. After installing, repeat the first table in this file. All three must answer 401.
