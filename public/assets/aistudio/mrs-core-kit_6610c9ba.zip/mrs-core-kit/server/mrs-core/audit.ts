/**
 * mrs-core — tamper-evident audit log.
 *
 * Every money or delivery decision appends an entry whose hash covers the previous
 * entry's hash. Editing or deleting any past entry breaks the chain, and
 * verifyAuditChain() says where. Entries are written in the SAME transaction as the
 * change they describe, so there is never a change without its record.
 */
import type { AuditEntry } from './types.ts';
import type { Store, Tx } from './store/store.ts';
import { C } from './store/store.ts';
import { canonicalJson, nowIso, sha256Hex } from './util.ts';

const HEAD_ID = 'auditHead';
const GENESIS = '0'.repeat(64);

export interface AuditHead {
  seq: number;
  hash: string;
}

export interface AuditInput {
  actor: string; // 'auto' | 'owner' | 'client:<id>' | 'collector:<name>' | 'camellia'
  action: string; // e.g. payment.verified
  target: string; // e.g. the payment id
  detail: string;
}

function entryHash(e: Omit<AuditEntry, 'hash'>): string {
  return sha256Hex(canonicalJson({ seq: e.seq, at: e.at, actor: e.actor, action: e.action, target: e.target, detail: e.detail, prevHash: e.prevHash }));
}

/** Call at the START of a transaction (before any write). */
export async function readAuditHead(t: Tx): Promise<AuditHead> {
  return (await t.get<AuditHead>(C.meta, HEAD_ID)) ?? { seq: 0, hash: GENESIS };
}

/** Buffers audit entries into the transaction. `head` must come from readAuditHead(t). */
export function writeAudit(t: Tx, head: AuditHead, inputs: AuditInput[]): void {
  let { seq, hash } = head;
  const at = nowIso();
  for (const input of inputs) {
    seq += 1;
    const base: Omit<AuditEntry, 'hash'> = {
      id: `AUD-${String(seq).padStart(8, '0')}`,
      seq,
      at,
      actor: input.actor,
      action: input.action,
      target: input.target,
      detail: input.detail.slice(0, 600),
      prevHash: hash,
    };
    hash = entryHash(base);
    t.put(C.audit, base.id, { ...base, hash });
  }
  if (inputs.length > 0) t.put(C.meta, HEAD_ID, { seq, hash });
}

/** One-off audit entry in its own transaction. */
export async function audit(store: Store, input: AuditInput): Promise<void> {
  await store.tx(async (t) => {
    const head = await readAuditHead(t);
    writeAudit(t, head, [input]);
  });
}

export async function listAudit(store: Store, limit = 200): Promise<AuditEntry[]> {
  const all = await store.list<AuditEntry>(C.audit, [], 5000);
  return all.sort((a, b) => b.seq - a.seq).slice(0, limit);
}

export interface ChainCheck {
  ok: boolean;
  entries: number;
  /** First sequence number at which the chain is broken. */
  brokenAt?: number;
  reason?: string;
}

export async function verifyAuditChain(store: Store): Promise<ChainCheck> {
  const all = (await store.list<AuditEntry>(C.audit, [], 100_000)).sort((a, b) => a.seq - b.seq);
  let prev = GENESIS;
  let expectedSeq = 1;
  for (const e of all) {
    if (e.seq !== expectedSeq) return { ok: false, entries: all.length, brokenAt: expectedSeq, reason: 'missing entry' };
    if (e.prevHash !== prev) return { ok: false, entries: all.length, brokenAt: e.seq, reason: 'previous-hash mismatch' };
    const { hash, ...rest } = e;
    if (entryHash(rest) !== hash) return { ok: false, entries: all.length, brokenAt: e.seq, reason: 'entry was modified' };
    prev = hash;
    expectedSeq += 1;
  }
  const head = await store.get<AuditHead>(C.meta, HEAD_ID);
  if (all.length > 0 && (!head || head.hash !== prev || head.seq !== all.length)) {
    return { ok: false, entries: all.length, brokenAt: all.length, reason: 'log tail was removed or head is stale' };
  }
  return { ok: true, entries: all.length };
}
