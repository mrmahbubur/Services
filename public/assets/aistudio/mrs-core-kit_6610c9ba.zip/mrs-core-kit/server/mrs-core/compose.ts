/**
 * mrs-core — assembles the shared context (store, secrets, notifier, model) and wires
 * the modules to each other. Used by installMrsCore() and by the tests.
 */
import type { Secrets } from './config.ts';
import { loadSecrets } from './config.ts';
import type { Core, ModelClient } from './core.ts';
import type { FetchFn, Notifier } from './notify.ts';
import { createNotifier } from './notify.ts';
import { installEngine } from './fulfilment/engine.ts';
import { registerAllWorkers } from './fulfilment/workers/index.ts';
import { addMessage, onInvoiceChanged } from './orders/service.ts';
import { senderRulesFromEnv } from './payments/parsers/sms.ts';
import type { SenderRules } from './payments/parsers/sms.ts';
import type { Store } from './store/store.ts';
import { C, MemoryStore } from './store/store.ts';
import type { Order } from './types.ts';

export interface BuildOptions {
  /** Where everything is kept. Use FirestoreStore in production. */
  store?: Store;
  secrets?: Secrets;
  env?: Record<string, string | undefined>;
  notifier?: Notifier;
  fetchFn?: FetchFn;
  model?: ModelClient;
  senderRules?: SenderRules;
  balanceAutoHeal?: number;
  sendEmail?: (to: string, subject: string, text: string) => Promise<void>;
  log?: Core['log'];
}

const NO_MODEL: ModelClient = {
  name: 'none',
  available: false,
  generate: async () => {
    throw new Error('no model configured');
  },
};

function defaultLog(level: 'info' | 'warn' | 'error', message: string, extra?: Record<string, unknown>): void {
  const line = JSON.stringify({ severity: level.toUpperCase(), component: 'mrs-core', message, ...(extra ?? {}) });
  if (level === 'error') console.error(line);
  else console.log(line);
}

export function buildCore(opts: BuildOptions = {}): Core {
  const env = opts.env ?? process.env;
  const secrets = opts.secrets ?? loadSecrets(env);
  const store = opts.store ?? new MemoryStore();
  const fetchFn: FetchFn = opts.fetchFn ?? ((input, init) => fetch(input, init));
  const autoHeal = Number(env.MRS_BALANCE_AUTOHEAL ?? '0');

  const core: Core = {
    store,
    secrets,
    notifier: opts.notifier ?? createNotifier(store, secrets, fetchFn),
    fetchFn,
    model: opts.model ?? NO_MODEL,
    senderRules: opts.senderRules ?? senderRulesFromEnv(env),
    balanceAutoHeal: opts.balanceAutoHeal ?? (Number.isInteger(autoHeal) && autoHeal >= 0 && autoHeal <= 20 ? autoHeal : 0),
    ...(opts.sendEmail ? { sendEmail: opts.sendEmail } : {}),
    log: opts.log ?? defaultLog,
    hooks: {},
  };

  installEngine();
  registerAllWorkers();
  core.hooks.invoiceChanged = (invoiceId) => onInvoiceChanged(core, invoiceId);
  core.hooks.orderMessage = async (orderId, text) => {
    const order = await store.get<Order>(C.orders, orderId);
    if (order) await addMessage(core, order, 'system', 'M R S', text);
  };
  return core;
}
