/**
 * mrs-core — configuration.
 *
 * Secrets come from environment variables (AI Studio: Settings -> Secrets). Nothing
 * secret is ever placed in a file that the browser can download, and nothing here
 * has a default that would let the system run "open": a missing secret switches the
 * feature that needs it OFF.
 *
 *   MRS_SESSION_SECRET      32+ random chars. Signs admin and client sessions.
 *   MRS_ADMIN_PASSWORD      12+ chars. (Or MRS_ADMIN_PASSWORD_HASH from tools/hash-password.mjs)
 *   MRS_SMS_SIGNING_KEY     Signing key shown in the Android SMS gateway app.
 *   MRS_SMS_BEARER_TOKEN    Optional, for forwarder apps that cannot sign requests.
 *   MRS_INGEST_SECRET       Shared secret for the Gmail and Binance/Skrill collectors.
 *   MRS_CRON_SECRET         Secret for POST /api/cron/tick (defaults to MRS_INGEST_SECRET).
 *   GEMINI_API_KEY          Already provided by AI Studio.
 *   MRS_GEMINI_MODEL        Optional. Default: gemini-flash-latest.
 *   MRS_PAGESPEED_API_KEY   Optional. PageSpeed Insights key for website audits.
 *   BINANCE_API_KEY / BINANCE_API_SECRET   Only if this server may call Binance directly.
 *   TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID  Optional owner alerts.
 *   MRS_PUBLIC_BASE_URL     e.g. https://mrs-services.ai.studio
 */
import type { Currency, EvidenceSource, Method, PaymentSettings } from './types.ts';
import { canonicalJson, sha256Hex } from './util.ts';

export interface PaymentMethodDef {
  /** Registry id - the same ids the frontend already uses. */
  id: string;
  method: Method;
  label: string;
  region: 'local' | 'international';
  currency: Currency;
  /** The receiving account. Money must arrive here and nowhere else. */
  accountId: string;
  holderName: string;
  identifiers: { type: string; label: string; value: string; copy: boolean }[];
  txnTypeRequired: string;
  /** Asset symbols accepted on crypto rails (1:1 with USD). */
  acceptedAssets?: string[];
  /** Evidence channels that can confirm money on this rail, strongest first. */
  evidence: EvidenceSource[];
  /** Loose shape of a transaction id on this rail (after normalisation). */
  trxIdPattern: RegExp;
  trxIdHint: string;
  instructions: string[];
}

/**
 * OFFICIAL PAYMENT REGISTRY - the only accounts the business is paid on.
 * The browser must display these from GET /api/payment-methods, never from its own copy.
 */
export const PAYMENT_METHODS: PaymentMethodDef[] = [
  {
    id: 'bkash-personal',
    method: 'bkash',
    label: 'bKash (Personal)',
    region: 'local',
    currency: 'BDT',
    accountId: '01810853282',
    holderName: 'Md. Mahbubur Rahman',
    identifiers: [{ type: 'msisdn', label: 'bKash number', value: '01810853282', copy: true }],
    txnTypeRequired: 'Send Money',
    evidence: ['sms', 'statement', 'manual'],
    trxIdPattern: /^[A-Z0-9]{8,12}$/,
    trxIdHint: '10 letters and digits, e.g. DK593YKJET',
    instructions: [
      'Open bKash (app or *247#) and choose Send Money.',
      'Send to 01810853282.',
      'Enter the exact amount in Taka shown on your invoice.',
      'Type your payment reference (PAY-....) in the Reference field, then confirm.',
    ],
  },
  {
    id: 'nagad-personal',
    method: 'nagad',
    label: 'Nagad (Personal)',
    region: 'local',
    currency: 'BDT',
    accountId: '01810853282',
    holderName: 'Md. Mahbubur Rahman',
    identifiers: [{ type: 'msisdn', label: 'Nagad number', value: '01810853282', copy: true }],
    txnTypeRequired: 'Send Money',
    evidence: ['sms', 'statement', 'manual'],
    trxIdPattern: /^[A-Z0-9]{6,12}$/,
    trxIdHint: '8 letters and digits, e.g. 72AB3890',
    instructions: [
      'Open Nagad (app or *167#) and choose Send Money.',
      'Send to 01810853282.',
      'Enter the exact amount in Taka shown on your invoice.',
      'Type your payment reference (PAY-....) in the Reference field, then confirm.',
    ],
  },
  {
    id: 'binance-pay',
    method: 'binance_pay',
    label: 'Binance (Pay / internal transfer)',
    region: 'international',
    currency: 'USD',
    accountId: '38927942',
    holderName: 'Md. Mahbubur Rahman',
    identifiers: [
      { type: 'binance_uid', label: 'Binance UID', value: '38927942', copy: true },
      { type: 'binance_id', label: 'Binance ID', value: 'mrxshahn', copy: true },
    ],
    txnTypeRequired: 'Binance Pay - Send (internal, no network fee)',
    acceptedAssets: ['USDT', 'USDC'],
    evidence: ['api', 'email', 'statement', 'manual'],
    trxIdPattern: /^[A-Z0-9]{8,40}$/,
    trxIdHint: 'the Order ID on your Binance Pay receipt',
    instructions: [
      'Open Binance, then Pay, then Send.',
      'Recipient: Binance UID 38927942 (or Binance ID mrxshahn).',
      'Send the exact invoice amount in USDT.',
      'Copy the Order ID from the receipt and enter it here.',
    ],
  },
  {
    id: 'payoneer',
    method: 'payoneer',
    label: 'Payoneer (USD)',
    region: 'international',
    currency: 'USD',
    accountId: '108003450',
    holderName: 'Md. Mahbubur Rahman',
    identifiers: [{ type: 'customer_id', label: 'Payoneer Customer ID', value: '108003450', copy: true }],
    txnTypeRequired: 'Payoneer-to-Payoneer payment',
    evidence: ['email', 'statement', 'manual'],
    trxIdPattern: /^[A-Z0-9]{5,40}$/,
    trxIdHint: 'the payment / transaction ID on your Payoneer confirmation',
    instructions: [
      'In Payoneer choose Pay, then pay a Payoneer recipient.',
      'Recipient Customer ID: 108003450.',
      'Send the exact invoice amount in USD and put your payment reference in the note.',
      'Enter the payment ID from your confirmation here.',
    ],
  },
  {
    id: 'skrill',
    method: 'skrill',
    label: 'Skrill (USD)',
    region: 'international',
    currency: 'USD',
    accountId: '407108385',
    holderName: 'Md. Mahbubur Rahman',
    identifiers: [{ type: 'customer_id', label: 'Skrill Customer ID', value: '407108385', copy: true }],
    txnTypeRequired: 'Skrill-to-Skrill transfer',
    evidence: ['api', 'email', 'statement', 'manual'],
    trxIdPattern: /^[A-Z0-9]{5,40}$/,
    trxIdHint: 'the Transaction ID on your Skrill receipt',
    instructions: [
      'In Skrill choose Send, then Skrill to Skrill.',
      'Recipient Customer ID: 407108385.',
      'Send the exact invoice amount in USD and put your payment reference in the message.',
      'Enter the Transaction ID from your receipt here.',
    ],
  },
];

export function methodDef(method: Method): PaymentMethodDef {
  const def = PAYMENT_METHODS.find((m) => m.method === method);
  if (!def) throw new Error(`unknown payment method ${method}`);
  return def;
}

/** Accepts a registry id ("bkash-personal"), a method ("bkash") or the legacy frontend values. */
export function resolveMethod(input: { methodId?: unknown; method?: unknown }): Method | null {
  const candidates = [input.methodId, input.method]
    .filter((v): v is string => typeof v === 'string')
    .map((v) => v.trim().toLowerCase());
  for (const c of candidates) {
    const byId = PAYMENT_METHODS.find((m) => m.id === c || m.method === c);
    if (byId) return byId.method;
    if (c.includes('bkash')) return 'bkash';
    if (c.includes('nagad')) return 'nagad';
    if (c.includes('binance')) return 'binance_pay';
    if (c.includes('payoneer')) return 'payoneer';
    if (c.includes('skrill')) return 'skrill';
  }
  return null;
}

export const USD_METHODS: Method[] = PAYMENT_METHODS.filter((m) => m.currency === 'USD').map((m) => m.method);

/** What the browser is allowed to see of the registry, plus a hash to detect tampering. */
export function publicRegistry(): {
  registry_version: number;
  business: string;
  methods: Record<string, unknown>[];
  updated_at: string;
  integrity_hash: string;
} {
  const methods = PAYMENT_METHODS.map((m) => ({
    method_id: m.id,
    method: m.method,
    label: m.label,
    region: m.region,
    currency: m.currency,
    identifiers: m.identifiers,
    txn_type_required: m.txnTypeRequired,
    accepted_assets: m.acceptedAssets ?? [],
    status: 'active',
    holder_name: m.holderName,
    instructions: m.instructions,
    trx_id_hint: m.trxIdHint,
    ...(m.accountId === '01810853282' && m.method === 'nagad'
      ? { shared_identifier_with: 'bkash-personal', shared_identifier_ack: true }
      : {}),
  }));
  return {
    registry_version: 3,
    business: 'M R S - Professional Automation & Digital Services',
    methods,
    updated_at: '2026-11-11',
    integrity_hash: sha256Hex(canonicalJson(methods)),
  };
}

/** Same keys and defaults as the existing admin settings tab. */
export const DEFAULT_SETTINGS: PaymentSettings = {
  ledgerWaitWindowHours: 6,
  reviewWindowDays: 7,
  intentExpiryHours: 48,
  slaHours: 4,
  amountToleranceBps: 100,
  amountToleranceFixedMinor: 0,
  timeToleranceMinutes: 15,
  autoVerifyLimitsUsd: { sms: 50, email: 50, api: 500, chain: 500, statement: 999999, manual: 999999 },
  riskThresholdAuto: 30,
  riskThresholdReview: 60,
  minConfirmations: { trc20: 19, bep20: 15, erc20: 12, btc: 2 },
  stepUpAmountUsd: 200,
  smsStaleHours: 6,
  maxSubmissionsPerInvoice: 5,
  autoVerifySources: { sms: true, email: true, api: true, chain: true, statement: true, manual: true },
  killSwitch: false,
  autoMatchByReference: true,
  usdToBdt: 100,
};

export interface Secrets {
  sessionSecret: string;
  adminPassword: string;
  adminPasswordHash: string;
  smsSigningKey: string;
  smsBearerToken: string;
  ingestSecret: string;
  cronSecret: string;
  geminiApiKey: string;
  geminiModel: string;
  pagespeedApiKey: string;
  binanceApiKey: string;
  binanceApiSecret: string;
  telegramBotToken: string;
  telegramChatId: string;
  publicBaseUrl: string;
  production: boolean;
}

/** Passwords that were visible in the public JavaScript bundle. They can never be used again. */
const BURNED_PASSWORDS = new Set(['admin', 'mrs2026admin', 'password', '123456', 'mrs_bridge_secret_998124', 'mrs_live_bridge_secret_2026']);

export function loadSecrets(env: Record<string, string | undefined> = process.env): Secrets {
  const get = (k: string): string => (env[k] ?? '').trim();
  const ingestSecret = get('MRS_INGEST_SECRET');
  return {
    sessionSecret: get('MRS_SESSION_SECRET'),
    adminPassword: get('MRS_ADMIN_PASSWORD'),
    adminPasswordHash: get('MRS_ADMIN_PASSWORD_HASH'),
    smsSigningKey: get('MRS_SMS_SIGNING_KEY'),
    smsBearerToken: get('MRS_SMS_BEARER_TOKEN'),
    ingestSecret,
    cronSecret: get('MRS_CRON_SECRET') || ingestSecret,
    geminiApiKey: get('GEMINI_API_KEY') || get('API_KEY'),
    geminiModel: get('MRS_GEMINI_MODEL') || 'gemini-flash-latest',
    pagespeedApiKey: get('MRS_PAGESPEED_API_KEY'),
    binanceApiKey: get('BINANCE_API_KEY'),
    binanceApiSecret: get('BINANCE_API_SECRET'),
    telegramBotToken: get('TELEGRAM_BOT_TOKEN'),
    telegramChatId: get('TELEGRAM_CHAT_ID'),
    publicBaseUrl: (get('MRS_PUBLIC_BASE_URL') || 'https://mrs-services.ai.studio').replace(/\/+$/, ''),
    production: get('NODE_ENV') === 'production',
  };
}

export interface ConfigProblem {
  level: 'error' | 'warn';
  key: string;
  message: string;
}

/** Explains, in plain words, what is switched off and why. Shown by the admin self-test. */
export function checkSecrets(s: Secrets): ConfigProblem[] {
  const out: ConfigProblem[] = [];
  const weak = (v: string, min: number): boolean => v.length < min || BURNED_PASSWORDS.has(v);

  if (weak(s.sessionSecret, 32)) {
    out.push({ level: 'error', key: 'MRS_SESSION_SECRET', message: 'Missing or shorter than 32 characters. Admin and client sign-in are disabled.' });
  }
  if (!s.adminPasswordHash && weak(s.adminPassword, 12)) {
    out.push({ level: 'error', key: 'MRS_ADMIN_PASSWORD', message: 'Missing, shorter than 12 characters, or a password that was exposed in the old public code. Admin sign-in is disabled.' });
  }
  if (weak(s.smsSigningKey, 16) && weak(s.smsBearerToken, 24)) {
    out.push({ level: 'warn', key: 'MRS_SMS_SIGNING_KEY', message: 'Not set. bKash / Nagad SMS cannot be received, so those payments wait for the owner.' });
  }
  if (weak(s.ingestSecret, 24)) {
    out.push({ level: 'warn', key: 'MRS_INGEST_SECRET', message: 'Not set. The Gmail and Binance/Skrill collectors cannot report, so Binance, Payoneer and Skrill payments wait for the owner.' });
  }
  if (!s.geminiApiKey) {
    out.push({ level: 'warn', key: 'GEMINI_API_KEY', message: 'Not set. Camellia cannot produce drafts; every order becomes an owner task.' });
  }
  if (!s.telegramBotToken || !s.telegramChatId) {
    out.push({ level: 'warn', key: 'TELEGRAM_BOT_TOKEN', message: 'Not set. Items needing the owner are only visible in the admin queue.' });
  }
  return out;
}
