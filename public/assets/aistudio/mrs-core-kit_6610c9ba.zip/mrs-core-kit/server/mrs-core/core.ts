/**
 * mrs-core — the shared context every module receives, plus settings and bridge health.
 */
import type { Secrets } from './config.ts';
import { DEFAULT_SETTINGS } from './config.ts';
import type { FetchFn, Notifier } from './notify.ts';
import type { SenderRules } from './payments/parsers/sms.ts';
import type { Store } from './store/store.ts';
import { C } from './store/store.ts';
import type { BridgeStatus, EvidenceSource, PaymentSettings } from './types.ts';
import { nowIso } from './util.ts';

/** Text-generation backend used by Camellia. See fulfilment/gemini.ts. */
export interface ModelPart {
  text?: string;
  inlineData?: { mimeType: string; data: string };
}
export interface ModelRequest {
  system: string;
  parts: ModelPart[];
  /** Gemini response schema (OBJECT / ARRAY / STRING ... in upper case). Omit for plain text. */
  schema?: Record<string, unknown>;
  maxOutputTokens?: number;
  temperature?: number;
}
export interface ModelClient {
  readonly name: string;
  readonly available: boolean;
  /** Returns the model's text. Throws ModelError on failure. */
  generate(req: ModelRequest): Promise<string>;
}

export interface Core {
  store: Store;
  secrets: Secrets;
  notifier: Notifier;
  fetchFn: FetchFn;
  model: ModelClient;
  senderRules: SenderRules;
  /** 0 = only the owner can re-trust a broken balance chain. */
  balanceAutoHeal: number;
  /** Optional e-mail hook supplied by the host app. */
  sendEmail?: (to: string, subject: string, text: string) => Promise<void>;
  /** Wired by index.ts so payments can tell orders what happened without importing them. */
  hooks: {
    /** An invoice's paid amount changed. Must be idempotent. */
    invoiceChanged?: (invoiceId: string) => Promise<void>;
    /** Put a line in the client's order thread. */
    orderMessage?: (orderId: string, text: string) => Promise<void>;
  };
  log: (level: 'info' | 'warn' | 'error', message: string, extra?: Record<string, unknown>) => void;
}

// ---------------------------------------------------------------- settings

const SETTINGS_ID = 'paymentSettings';
let cache: { at: number; value: PaymentSettings; store: Store } | null = null;

function num(v: unknown, fallback: number, min: number, max: number): number {
  const n = typeof v === 'number' ? v : Number.NaN;
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}

/** Accepts untrusted input and returns settings with every field present and in range. */
export function sanitizeSettings(input: unknown, base: PaymentSettings = DEFAULT_SETTINGS): PaymentSettings {
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const limitsIn = (i.autoVerifyLimitsUsd && typeof i.autoVerifyLimitsUsd === 'object' ? i.autoVerifyLimitsUsd : {}) as Record<string, unknown>;
  const sourcesIn = (i.autoVerifySources && typeof i.autoVerifySources === 'object' ? i.autoVerifySources : {}) as Record<string, unknown>;
  const sources: (EvidenceSource | 'chain')[] = ['sms', 'email', 'api', 'chain', 'statement', 'manual'];
  const limits = { ...base.autoVerifyLimitsUsd };
  const enabled = { ...base.autoVerifySources };
  for (const s of sources) {
    limits[s] = num(limitsIn[s], base.autoVerifyLimitsUsd[s], 0, 999_999);
    if (typeof sourcesIn[s] === 'boolean') enabled[s] = sourcesIn[s] as boolean;
  }
  return {
    ledgerWaitWindowHours: num(i.ledgerWaitWindowHours, base.ledgerWaitWindowHours, 0.25, 72),
    reviewWindowDays: num(i.reviewWindowDays, base.reviewWindowDays, 1, 60),
    intentExpiryHours: num(i.intentExpiryHours, base.intentExpiryHours, 1, 720),
    slaHours: num(i.slaHours, base.slaHours, 0.25, 72),
    amountToleranceBps: num(i.amountToleranceBps, base.amountToleranceBps, 0, 500),
    amountToleranceFixedMinor: num(i.amountToleranceFixedMinor, base.amountToleranceFixedMinor, 0, 500),
    timeToleranceMinutes: num(i.timeToleranceMinutes, base.timeToleranceMinutes, 0, 240),
    autoVerifyLimitsUsd: limits,
    riskThresholdAuto: num(i.riskThresholdAuto, base.riskThresholdAuto, 1, 100),
    riskThresholdReview: num(i.riskThresholdReview, base.riskThresholdReview, 1, 100),
    minConfirmations: base.minConfirmations,
    stepUpAmountUsd: num(i.stepUpAmountUsd, base.stepUpAmountUsd, 1, 999_999),
    smsStaleHours: num(i.smsStaleHours, base.smsStaleHours, 1, 168),
    maxSubmissionsPerInvoice: num(i.maxSubmissionsPerInvoice, base.maxSubmissionsPerInvoice, 1, 20),
    autoVerifySources: enabled,
    killSwitch: typeof i.killSwitch === 'boolean' ? i.killSwitch : base.killSwitch,
    autoMatchByReference: typeof i.autoMatchByReference === 'boolean' ? i.autoMatchByReference : base.autoMatchByReference,
    usdToBdt: num(i.usdToBdt, base.usdToBdt, 50, 500),
  };
}

export async function getSettings(store: Store): Promise<PaymentSettings> {
  if (cache && cache.store === store && Date.now() - cache.at < 5000) return cache.value;
  const stored = await store.get<PaymentSettings>(C.meta, SETTINGS_ID);
  const value = sanitizeSettings(stored ?? {}, DEFAULT_SETTINGS);
  cache = { at: Date.now(), value, store };
  return value;
}

export async function saveSettings(store: Store, input: unknown): Promise<PaymentSettings> {
  const current = await getSettings(store);
  const next = sanitizeSettings(input, current);
  await store.put(C.meta, SETTINGS_ID, next);
  cache = { at: Date.now(), value: next, store };
  return next;
}

// ---------------------------------------------------------------- bridge health

export type Bridge = 'sms' | 'email' | 'api';

interface BridgeRecord {
  lastSeenAt: string | null;
  messageCount: number;
  errorCount: number;
  lastError?: string;
}

export async function touchBridge(store: Store, bridge: Bridge, messages: number, error?: string): Promise<void> {
  const id = `bridge:${bridge}`;
  const prev = (await store.get<BridgeRecord>(C.meta, id)) ?? { lastSeenAt: null, messageCount: 0, errorCount: 0 };
  await store.put(C.meta, id, {
    lastSeenAt: nowIso(),
    messageCount: prev.messageCount + messages,
    errorCount: prev.errorCount + (error ? 1 : 0),
    ...(error ? { lastError: error.slice(0, 200) } : prev.lastError ? { lastError: prev.lastError } : {}),
  });
}

/**
 * `staleHours`: how long a bridge may stay silent before it is called stale. The SMS
 * phone and the pollers send a heartbeat, so silence means the bridge is down.
 */
export async function bridgeStatuses(store: Store, staleHours: number): Promise<Record<Bridge | 'chain', BridgeStatus>> {
  const out = {} as Record<Bridge | 'chain', BridgeStatus>;
  for (const bridge of ['sms', 'email', 'api'] as Bridge[]) {
    const rec = await store.get<BridgeRecord>(C.meta, `bridge:${bridge}`);
    let health: BridgeStatus['health'] = 'never_seen';
    if (rec?.lastSeenAt) {
      const ageHours = (Date.now() - new Date(rec.lastSeenAt).getTime()) / 3600_000;
      health = ageHours <= staleHours ? 'healthy' : 'stale';
    }
    out[bridge] = {
      source: bridge,
      lastSeenAt: rec?.lastSeenAt ?? null,
      health,
      messageCount: rec?.messageCount ?? 0,
      errorCount: rec?.errorCount ?? 0,
      ...(rec?.lastError ? { lastError: rec.lastError } : {}),
    };
  }
  out.chain = { ...out.api, source: 'chain' }; // the existing admin panel has a "chain" tile
  return out;
}
