/**
 * mrs-core — the fulfilment engine: takes a workable order to delivered files.
 *
 *   queued -> running -> waiting_inputs   Camellia needs something from the client
 *                     -> owner_review     work is done; the owner looks before release
 *                     -> owner_task       the owner has a hands-on step to do
 *                     -> released         files are in the client's portal
 *                     -> failed           could not be done automatically; owner told
 *
 * Nothing reaches a client until release(). By default the owner presses that
 * button; per service, the owner may let work that passes every check release
 * itself (settings.autoRelease).
 *
 * The engine holds no state in memory. Every step is saved, so it resumes after a
 * restart, and a lease stops two server instances running the same job.
 */
import type { Core } from '../core.ts';
import { readAuditHead, writeAudit } from '../audit.ts';
import type { ServiceDef } from '../orders/catalog.ts';
import { findService } from '../orders/catalog.ts';
import { addMessage, advance, registerEnsureJob, registerIntakeListener } from '../orders/service.ts';
import { fullyPaid } from '../payments/invoice.ts';
import { C } from '../store/store.ts';
import type { Deliverable, Invoice, Job, JobStep, Order, QaCheck } from '../types.ts';
import { HttpError, clampText, newId, nowIso, sha256Hex } from '../util.ts';
import { ModelError } from './gemini.ts';
import type { JobInputs } from './inputs.ts';
import { loadInputs } from './inputs.ts';
import { parseMarkdown } from './render/blocks.ts';
import { renderPdf } from './render/pdf.ts';
import { truncateForPreview } from './render/text.ts';

export interface OutFile {
  fileName: string;
  mime: string;
  bytes: Buffer;
  title: string;
  description: string;
  /** final = what the client ordered; report = supporting document (audit, QA, notes). */
  kind: 'final' | 'report';
}

export interface WorkerResult {
  files: OutFile[];
  qa: QaCheck[];
  /** Hands-on steps only the owner can do, in plain words. */
  ownerTasks: string[];
  /** Questions for the client. */
  questions: string[];
  /** True when the work cannot go on without the client's answers. */
  needsClient: boolean;
  /** Short account for the owner. */
  summary: string;
  /** Markdown of the main deliverable; its first part becomes the locked preview. */
  previewMarkdown?: string;
}

export interface WorkerCtx {
  core: Core;
  order: Order;
  service: ServiceDef;
  job: Job;
  inputs: JobInputs;
  phase: 'prepare' | 'finish';
  /** Revision requests and send-backs, oldest first. */
  feedback: string[];
  ownerNotes: string;
}

export type Worker = (ctx: WorkerCtx) => Promise<WorkerResult>;

const workers = new Map<string, Worker>();

/** Registers the worker for a `service.worker` key ("cv") or key family ("pack" for "pack:xyz"). */
export function registerWorker(key: string, worker: Worker): void {
  workers.set(key, worker);
}

function workerFor(service: ServiceDef): Worker | undefined {
  return workers.get(service.worker) ?? workers.get(service.worker.split(':')[0] ?? '');
}

// ---------------------------------------------------------------- settings

export interface FulfilmentSettings {
  /** serviceId -> release without the owner when every blocking check passes. */
  autoRelease: Record<string, boolean>;
}

export async function getFulfilmentSettings(core: Core): Promise<FulfilmentSettings> {
  const s = await core.store.get<FulfilmentSettings>(C.meta, 'fulfilmentSettings');
  return { autoRelease: s?.autoRelease ?? {} };
}

export async function saveFulfilmentSettings(core: Core, input: unknown): Promise<FulfilmentSettings> {
  const raw = (input && typeof input === 'object' ? (input as { autoRelease?: unknown }).autoRelease : null) as Record<string, unknown> | null;
  const autoRelease: Record<string, boolean> = {};
  for (const [serviceId, on] of Object.entries(raw ?? {})) {
    const service = findService(serviceId);
    // Only work Camellia completes on her own can release itself.
    if (service && service.mode === 'auto' && on === true) autoRelease[service.serviceId] = true;
  }
  const next = { autoRelease };
  await core.store.put(C.meta, 'fulfilmentSettings', next);
  return next;
}

// ---------------------------------------------------------------- job records

const LEASE_MS = 5 * 60_000;
const MAX_ATTEMPTS = 4;

async function saveJob(core: Core, job: Job): Promise<Job> {
  const next = { ...job, updatedAt: nowIso() };
  await core.store.put(C.jobs, job.id, next);
  return next;
}

/** Creates the job for an order that has become workable. Called by orders.advance(). */
export async function ensureJob(core: Core, order: Order): Promise<void> {
  if (order.jobId) return;
  const service = findService(order.serviceId);
  if (!service || service.mode === 'manual') return;
  const id = `JOB-${order.orderId.replace(/^ORD-/, '')}`;
  const now = nowIso();
  const job: Job = { id, orderId: order.orderId, serviceId: order.serviceId, mode: service.mode, state: 'queued', phase: 'prepare', attempts: 0, steps: [], qa: [], ownerTasks: [], questionsForClient: [], deliverableIds: [], feedback: [], createdAt: now, updatedAt: now };
  await core.store.tx(async (t) => {
    const fresh = await t.get<Order>(C.orders, order.orderId);
    if (!fresh || fresh.jobId) return;
    const existing = await t.get<Job>(C.jobs, id);
    if (!existing) t.put(C.jobs, id, job);
    t.put(C.orders, order.orderId, { ...fresh, jobId: id, updatedAt: now });
  });
}

/** New client input arrived: a job that was waiting for it can go again. */
async function onIntakeChanged(core: Core, orderId: string): Promise<void> {
  const order = await core.store.get<Order>(C.orders, orderId);
  const job = order?.jobId ? await core.store.get<Job>(C.jobs, order.jobId) : null;
  if (job && job.state === 'waiting_inputs') await saveJob(core, { ...job, state: 'queued', questionsForClient: [], notBefore: undefined });
}

/**
 * The client answered in the order thread while Camellia was waiting for them.
 * The answer is handed to the worker and the job goes again.
 */
export async function clientReplied(core: Core, orderId: string, text: string): Promise<boolean> {
  const order = await core.store.get<Order>(C.orders, orderId);
  const job = order?.jobId ? await core.store.get<Job>(C.jobs, order.jobId) : null;
  if (!job || job.state !== 'waiting_inputs') return false;
  await saveJob(core, { ...job, state: 'queued', attempts: 0, notBefore: undefined, questionsForClient: [], feedback: [...job.feedback, `Client answered: ${text.slice(0, 2000)}`].slice(-10) });
  return true;
}

export function installEngine(): void {
  registerEnsureJob(ensureJob);
  registerIntakeListener(onIntakeChanged);
}

// ---------------------------------------------------------------- deliverables

async function removeUnreleased(core: Core, job: Job, keepOwnerUploads: boolean): Promise<string[]> {
  const kept: string[] = [];
  for (const id of job.deliverableIds) {
    const d = await core.store.get<Deliverable>(C.deliverables, id);
    if (!d) continue;
    if (d.released || (keepOwnerUploads && d.producedBy === 'owner')) {
      kept.push(id);
      continue;
    }
    await core.store.deleteBlob(`deliv_${id}`);
    await core.store.delete(C.deliverables, id);
  }
  return kept;
}

async function storeFile(core: Core, order: Order, jobId: string | undefined, file: OutFile, producedBy: 'camellia' | 'owner', kind: Deliverable['kind'], released: boolean): Promise<Deliverable> {
  const id = newId('DLV');
  const safeName = file.fileName.replace(/[^\w.\- ()]/g, '_').slice(0, 100) || 'file';
  const d: Deliverable = { id, orderId: order.orderId, clientId: order.clientId, ...(jobId ? { jobId } : {}), title: file.title.slice(0, 120), description: file.description.slice(0, 400), fileName: safeName, mime: file.mime, size: file.bytes.length, sha256: sha256Hex(file.bytes), kind, released, producedBy, createdAt: nowIso() };
  await core.store.putBlob(`deliv_${id}`, file.bytes);
  await core.store.put(C.deliverables, id, d);
  return d;
}

export async function listDeliverables(core: Core, orderId: string): Promise<Deliverable[]> {
  return (await core.store.list<Deliverable>(C.deliverables, [['orderId', orderId]], 500)).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

// ---------------------------------------------------------------- running a job

async function lease(core: Core, jobId: string): Promise<Job | null> {
  return core.store.tx(async (t) => {
    const job = await t.get<Job>(C.jobs, jobId);
    if (!job) return null;
    const now = Date.now();
    const leased = job.lockedUntil !== undefined && Date.parse(job.lockedUntil) > now;
    const runnable = job.state === 'queued' || (job.state === 'running' && !leased);
    if (!runnable || leased) return null;
    if (job.notBefore && Date.parse(job.notBefore) > now) return null;
    const next: Job = { ...job, state: 'running', attempts: job.attempts + 1, lockedUntil: new Date(now + LEASE_MS).toISOString(), updatedAt: nowIso() };
    t.put(C.jobs, jobId, next);
    return next;
  });
}

function step(name: string, startedAt: string, status: JobStep['status'], detail?: string): JobStep {
  return { name, status, startedAt, finishedAt: nowIso(), ...(detail ? { detail: detail.slice(0, 300) } : {}) };
}

async function toOwnerTask(core: Core, job: Job, order: Order, tasks: string[], summary: string, steps: JobStep[]): Promise<Job> {
  const next = await saveJob(core, { ...job, state: 'owner_task', lockedUntil: undefined, ownerTasks: tasks, summary, steps: [...job.steps, ...steps].slice(-40) });
  await core.notifier.owner('action', `job:${job.id}`, 'An order needs your hands', `${order.orderId} - ${order.serviceName} for ${order.clientName}.\n${tasks.map((t) => `• ${t}`).join('\n')}`.slice(0, 900), '/admin');
  return next;
}

/** Runs one job as far as it can go right now. Returns the job as it was left. */
export async function runJob(core: Core, jobId: string): Promise<Job | null> {
  const job = await lease(core, jobId);
  if (!job) return core.store.get<Job>(C.jobs, jobId);
  const started = nowIso();

  const order = await core.store.get<Order>(C.orders, job.orderId);
  const service = order ? findService(order.serviceId) : undefined;
  if (!order || !service || order.state === 'cancelled') {
    return saveJob(core, { ...job, state: 'failed', lockedUntil: undefined, lastError: 'order no longer exists or was cancelled' });
  }

  if (order.noAiRequested) {
    return toOwnerTask(core, job, order, ['The client asked that no AI be used on this order. Do the work by hand and upload the files.'], 'No AI requested by the client.', [step('no_ai', started, 'skipped')]);
  }
  const worker = workerFor(service);
  if (!worker) {
    return toOwnerTask(core, job, order, [`No automatic worker exists for ${service.name}. Do the work by hand and upload the files.`], 'No worker registered.', [step('worker', started, 'skipped')]);
  }
  if (!core.model.available) {
    return toOwnerTask(core, job, order, ['The AI model is not configured (GEMINI_API_KEY), so Camellia cannot prepare this order. Do it by hand, or add the key and press "Run again".'], 'AI model not configured.', [step('model', started, 'skipped')]);
  }

  let result: WorkerResult;
  try {
    const inputs = await loadInputs(core, order);
    result = await worker({ core, order, service, job, inputs, phase: job.phase, feedback: job.feedback, ownerNotes: job.ownerNotes ?? '' });
  } catch (err) {
    const message = String((err as Error)?.message ?? err).slice(0, 300);
    // Temporary trouble (the model, or a lookup service such as Gravatar, PageSpeed or DNS,
    // is briefly unreachable) is retried later; anything else is handed to the owner.
    const retryable = (err as { retryable?: unknown })?.retryable === true;
    if (retryable && job.attempts < MAX_ATTEMPTS) {
      const quota = err instanceof ModelError && err.code === 'quota';
      const waitMs = quota ? 60 * 60_000 : Math.min(15 * 60_000, 30_000 * 2 ** job.attempts);
      return saveJob(core, { ...job, state: 'queued', lockedUntil: undefined, notBefore: new Date(Date.now() + waitMs).toISOString(), lastError: message, steps: [...job.steps, step('work', started, 'failed', message)].slice(-40) });
    }
    core.log('error', 'job failed', { jobId, error: message });
    const failed = await saveJob(core, { ...job, state: 'failed', lockedUntil: undefined, lastError: message, steps: [...job.steps, step('work', started, 'failed', message)].slice(-40) });
    await core.notifier.owner('action', `job:${job.id}`, 'Camellia could not finish an order', `${order.orderId} - ${order.serviceName} for ${order.clientName}.\nReason: ${message}\nOpen it in the admin console: run it again, or do it by hand.`, '/admin');
    return failed;
  }

  if (result.needsClient && result.questions.length > 0) {
    await addMessage(core, order, 'camellia', 'Camellia', `Before I can continue I need a few things from you:\n${result.questions.map((q) => `• ${q}`).join('\n')}\n\nReply here or update your order details. The turnaround clock is paused until then.`);
    return saveJob(core, { ...job, state: 'waiting_inputs', lockedUntil: undefined, questionsForClient: result.questions.slice(0, 12), qa: result.qa, summary: result.summary, steps: [...job.steps, step('work', started, 'ok', 'waiting for the client')].slice(-40) });
  }

  // Replace the previous draft's files with this run's. Files already delivered stay
  // visible until the new version is released, and are retired at that moment.
  const kept = await removeUnreleased(core, job, true);
  const retire: string[] = [...(job.retireIds ?? [])];
  for (const id of kept) {
    const d = await core.store.get<Deliverable>(C.deliverables, id);
    if (d && d.released && d.producedBy === 'camellia' && !retire.includes(id)) retire.push(id);
  }
  const ids = [...kept];
  for (const f of result.files) ids.push((await storeFile(core, order, job.id, f, 'camellia', f.kind, false)).id);
  if (result.previewMarkdown) await core.store.putBlob(`preview_${job.id}`, Buffer.from(result.previewMarkdown, 'utf8'));

  const blockers = result.qa.filter((q) => q.severity === 'block' && !q.passed);
  const handsOn = job.mode !== 'auto' && job.phase === 'prepare';
  const base: Job = {
    ...job,
    lockedUntil: undefined,
    lastError: undefined,
    notBefore: undefined,
    qa: result.qa.slice(0, 60),
    ownerTasks: result.ownerTasks.slice(0, 20),
    questionsForClient: result.questions.slice(0, 12),
    deliverableIds: ids,
    retireIds: retire,
    summary: result.summary.slice(0, 1500),
    model: core.model.name,
    steps: [...job.steps, step(job.phase === 'finish' ? 'finish' : 'work', started, 'ok', `${result.files.length} file(s), ${blockers.length} blocking check(s) failed`)].slice(-40),
  };

  if (handsOn) return toOwnerTask(core, base, order, result.ownerTasks.length > 0 ? result.ownerTasks : ['Review the prepared material, do the work, then mark it done.'], result.summary, []);

  const saved = await saveJob(core, { ...base, state: 'owner_review' });
  const settings = await getFulfilmentSettings(core);
  if (job.mode === 'auto' && blockers.length === 0 && settings.autoRelease[service.serviceId] && result.files.length > 0) {
    return release(core, job.id, 'auto', false);
  }
  await advance(core, order.orderId);
  await core.notifier.owner('action', `job:${job.id}`, blockers.length > 0 ? 'A draft failed its checks' : 'A draft is ready for your review', `${order.orderId} - ${order.serviceName} for ${order.clientName}.\n${result.summary.slice(0, 400)}${blockers.length > 0 ? `\nFailed: ${blockers.map((b) => b.label).join('; ')}` : ''}`, '/admin');
  return saved;
}

/** Runs queued jobs until the time budget is used. Called by the cron tick. */
export async function runDueJobs(core: Core, budgetMs: number): Promise<{ ran: number }> {
  const deadline = Date.now() + budgetMs;
  const due = [...(await core.store.list<Job>(C.jobs, [['state', 'queued']], 100)), ...(await core.store.list<Job>(C.jobs, [['state', 'running']], 100))].sort((a, b) => a.updatedAt.localeCompare(b.updatedAt));
  let ran = 0;
  for (const job of due) {
    if (Date.now() >= deadline) break;
    const before = job.attempts;
    const after = await runJob(core, job.id);
    if (after && after.attempts > before) ran += 1;
  }
  return { ran };
}

// ---------------------------------------------------------------- release

/**
 * Puts the job's files in the client's portal. `force` lets the owner release work
 * whose blocking checks failed; that decision is written to the audit log.
 */
export async function release(core: Core, jobId: string, actor: 'owner' | 'auto', force: boolean): Promise<Job> {
  const job = await core.store.get<Job>(C.jobs, jobId);
  if (!job) throw new HttpError(404, 'job_not_found', 'Job not found.');
  if (job.state === 'released') return job;
  if (job.state === 'running' || job.state === 'queued') throw new HttpError(409, 'job_busy', 'This job is still being worked on.');
  const order = await core.store.get<Order>(C.orders, job.orderId);
  const service = order ? findService(order.serviceId) : undefined;
  if (!order || !service) throw new HttpError(404, 'order_not_found', 'Order not found.');

  const retire = new Set(job.retireIds ?? []);
  const files = (await listDeliverables(core, order.orderId)).filter((d) => job.deliverableIds.includes(d.id) && d.kind !== 'preview' && !retire.has(d.id));
  if (files.length === 0) throw new HttpError(409, 'nothing_to_release', 'There are no files to deliver yet. Upload the finished work first.');
  const blockers = job.qa.filter((q) => q.severity === 'block' && !q.passed);
  if (blockers.length > 0 && !(actor === 'owner' && force)) {
    throw new HttpError(409, 'checks_failed', `Blocking checks failed: ${blockers.map((b) => b.label).join('; ')}. Fix the work, send it back, or release anyway.`, { failed: blockers });
  }

  const invoice = order.invoiceId ? await core.store.get<Invoice>(C.invoices, order.invoiceId) : null;
  const locked = service.lockableDeliverables && invoice !== null && !fullyPaid(invoice);
  const ids = job.deliverableIds.filter((id) => !retire.has(id));
  if (locked) {
    const md = (await core.store.getBlob(`preview_${job.id}`))?.toString('utf8');
    if (md) {
      const pdf = renderPdf(parseMarkdown(truncateForPreview(md)), { title: `${order.serviceName} - preview`, footer: `M R S · ${order.orderId} · preview`, watermark: 'PREVIEW' });
      const preview = await storeFile(core, order, job.id, { fileName: `${order.orderId}-preview.pdf`, mime: 'application/pdf', bytes: pdf.bytes, title: 'Preview', description: 'First part of your work. The full files unlock when payment is confirmed.', kind: 'final' }, 'camellia', 'preview', true);
      ids.push(preview.id);
    }
  }

  const released = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const fresh = await t.get<Job>(C.jobs, jobId);
    if (!fresh) throw new HttpError(404, 'job_not_found', 'Job not found.');
    if (fresh.state === 'released') return fresh;
    const docs: Deliverable[] = [];
    for (const f of files) {
      const d = await t.get<Deliverable>(C.deliverables, f.id);
      if (d) docs.push(d);
    }
    const old: Deliverable[] = [];
    for (const id of retire) {
      const d = await t.get<Deliverable>(C.deliverables, id);
      if (d) old.push(d);
    }
    for (const d of docs) t.put(C.deliverables, d.id, { ...d, released: true });
    for (const d of old) t.put(C.deliverables, d.id, { ...d, released: false }); // superseded by this delivery
    const next: Job = { ...fresh, state: 'released', lockedUntil: undefined, deliverableIds: ids, retireIds: [], updatedAt: nowIso() };
    t.put(C.jobs, jobId, next);
    writeAudit(t, head, [{ actor, action: 'job.released', target: jobId, detail: `${order.orderId}: ${docs.length} file(s)${blockers.length > 0 ? `; RELEASED WITH FAILED CHECKS: ${blockers.map((b) => b.id).join(',')}` : ''}${locked ? '; locked until paid' : ''}` }]);
    return next;
  });
  await advance(core, order.orderId);
  return released;
}

// ---------------------------------------------------------------- owner actions

/** The owner sends a draft back with instructions; Camellia does it again. */
export async function sendBack(core: Core, jobId: string, notesRaw: unknown): Promise<Job> {
  const notes = clampText(notesRaw, 2000);
  if (notes.length < 3) throw new HttpError(400, 'notes_required', 'Say what should change.');
  const job = await core.store.get<Job>(C.jobs, jobId);
  if (!job) throw new HttpError(404, 'job_not_found', 'Job not found.');
  if (job.state === 'released') throw new HttpError(409, 'already_released', 'Already delivered. Ask the client to request a revision, or upload a corrected file.');
  if (job.state === 'running') throw new HttpError(409, 'job_busy', 'This job is running.');
  return saveJob(core, { ...job, state: 'queued', attempts: 0, notBefore: undefined, feedback: [...job.feedback, `Owner: ${notes}`].slice(-10) });
}

/** Clears a failure or back-off so the job runs again now. */
export async function requeue(core: Core, jobId: string): Promise<Job> {
  const job = await core.store.get<Job>(C.jobs, jobId);
  if (!job) throw new HttpError(404, 'job_not_found', 'Job not found.');
  if (job.state === 'released') throw new HttpError(409, 'already_released', 'Already delivered.');
  return saveJob(core, { ...job, state: 'queued', attempts: 0, notBefore: undefined, lockedUntil: undefined });
}

/**
 * The owner finished the hands-on part (applied the fixes, held the session...).
 * Camellia then verifies / writes it up, and the result waits for release.
 */
export async function ownerDone(core: Core, jobId: string, notesRaw: unknown): Promise<Job> {
  const notes = clampText(notesRaw, 4000);
  const job = await core.store.get<Job>(C.jobs, jobId);
  if (!job) throw new HttpError(404, 'job_not_found', 'Job not found.');
  if (job.state !== 'owner_task') throw new HttpError(409, 'not_waiting_for_owner', 'This job is not waiting for a hands-on step.');
  if (notes.length < 10) throw new HttpError(400, 'notes_required', 'Describe briefly what you did; it goes into the client\'s report.');
  await saveJob(core, { ...job, state: 'queued', phase: 'finish', attempts: 0, notBefore: undefined, ownerNotes: notes });
  return (await runJob(core, jobId)) ?? job;
}

/** The owner adds a finished file to an order (the only route for manual services). */
export async function ownerUpload(core: Core, orderId: string, fileName: unknown, title: unknown, bytes: Buffer, externalUrl?: string): Promise<Deliverable> {
  const order = await core.store.get<Order>(C.orders, orderId);
  if (!order) throw new HttpError(404, 'order_not_found', 'Order not found.');
  if (order.state === 'cancelled') throw new HttpError(409, 'order_closed', 'This order was cancelled.');
  const name = clampText(fileName, 100) || 'file';
  const ext = (name.split('.').pop() ?? '').toLowerCase();
  if (['html', 'htm', 'svg', 'js', 'mjs', 'exe', 'bat', 'cmd', 'sh', 'scr', 'msi', 'com', 'vbs', 'ps1', 'jar', 'apk'].includes(ext) && !externalUrl) {
    throw new HttpError(415, 'bad_file_type', 'That file type is not delivered through the portal. Put it in a .zip.');
  }

  let jobId = order.jobId;
  if (!jobId) {
    jobId = `JOB-${order.orderId.replace(/^ORD-/, '')}`;
    const now = nowIso();
    const job: Job = { id: jobId, orderId, serviceId: order.serviceId, mode: 'manual', state: 'owner_task', phase: 'finish', attempts: 0, steps: [], qa: [], ownerTasks: [], questionsForClient: [], deliverableIds: [], feedback: [], createdAt: now, updatedAt: now };
    await core.store.put(C.jobs, jobId, job);
    await core.store.put(C.orders, orderId, { ...order, jobId, updatedAt: now });
  }
  const job = await core.store.get<Job>(C.jobs, jobId);
  if (!job) throw new HttpError(404, 'job_not_found', 'Job not found.');

  const file: OutFile = { fileName: name, mime: 'application/octet-stream', bytes, title: clampText(title, 120) || name, description: externalUrl ? 'Link to your files.' : 'Delivered by M R S.', kind: 'final' };
  const stored = await storeFile(core, order, jobId, file, 'owner', externalUrl ? 'link' : 'final', job.state === 'released');
  if (externalUrl) await core.store.put(C.deliverables, stored.id, { ...stored, externalUrl });
  await saveJob(core, { ...job, deliverableIds: [...job.deliverableIds, stored.id], state: job.state === 'failed' ? 'owner_task' : job.state });
  return stored;
}

// ---------------------------------------------------------------- client: revision

export async function requestRevision(core: Core, orderId: string, clientId: string, textRaw: unknown): Promise<Order> {
  const text = clampText(textRaw, 2000);
  if (text.length < 10) throw new HttpError(400, 'details_required', 'Please describe what should change.');
  const order = await core.store.get<Order>(C.orders, orderId);
  if (!order || order.clientId !== clientId) throw new HttpError(404, 'order_not_found', 'Order not found.');
  if (order.state !== 'delivered') throw new HttpError(409, 'not_delivered', 'A revision can be requested once the work is delivered.');
  if (order.revisionsUsed >= order.revisionsTotal) throw new HttpError(409, 'no_revisions_left', `The ${order.revisionsTotal} included revision(s) are used. Message us for a quote on further changes.`);
  const job = order.jobId ? await core.store.get<Job>(C.jobs, order.jobId) : null;
  if (!job) throw new HttpError(409, 'no_job', 'This order has no work record. Please message us.');

  await addMessage(core, order, 'client', order.clientName, `Revision request: ${text}`);
  const next: Order = { ...order, state: 'revision', status: 'In progress', revisionsUsed: order.revisionsUsed + 1, updatedAt: nowIso() };
  await core.store.put(C.orders, orderId, next);
  const feedback = [...job.feedback, `Client revision ${next.revisionsUsed}: ${text}`].slice(-10);
  if (job.mode === 'auto') await saveJob(core, { ...job, state: 'queued', phase: 'prepare', attempts: 0, notBefore: undefined, feedback });
  else {
    await saveJob(core, { ...job, state: 'owner_task', feedback, ownerTasks: [`Client asked for a revision: ${text}`] });
    await core.notifier.owner('action', `job:${job.id}`, 'A client asked for a revision', `${orderId} - ${order.serviceName}: ${text.slice(0, 400)}`, '/admin');
  }
  return next;
}
