/**
 * mrs-core — turning what the client supplied into something a worker can use.
 *
 * Text formats and Word / Excel files are read here, by code. PDFs and images are
 * handed to the model as files, because reading those is what the model is for.
 * Nothing is fetched from the internet on a client's say-so.
 */
import type { Core, ModelPart } from '../core.ts';
import { intakeBlobId } from '../orders/service.ts';
import type { Order } from '../types.ts';
import { docxToText } from './render/docx.ts';
import { parseDelimited } from './render/text.ts';
import { xlsxToRows } from './render/xlsx.ts';

export interface JobInputs {
  answers: Record<string, string>;
  details: string;
  /** Text read from uploaded files, by intake field key. */
  fileText: Record<string, string>;
  /** Uploaded files the model must read itself (PDF, images), by intake field key. */
  fileParts: Record<string, ModelPart[]>;
  /** Uploaded tables (csv / tsv / xlsx / json array of objects), by intake field key. */
  tables: Record<string, string[][]>;
  /** File names, by intake field key. */
  fileNames: Record<string, string[]>;
  /** Anything that could not be read, in plain words. */
  problems: string[];
}

const MAX_TEXT = 200_000;
const MAX_INLINE_BYTES = 4_500_000;

function jsonToTable(text: string): string[][] | null {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return null;
  }
  const list = Array.isArray(data) ? data : data && typeof data === 'object' ? Object.values(data as Record<string, unknown>).find(Array.isArray) : null;
  if (!Array.isArray(list) || list.length === 0 || !list.every((r) => r && typeof r === 'object' && !Array.isArray(r))) return null;
  const keys: string[] = [];
  for (const r of list as Record<string, unknown>[]) for (const k of Object.keys(r)) if (!keys.includes(k)) keys.push(k);
  const cell = (v: unknown): string => (v === null || v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v));
  return [keys, ...(list as Record<string, unknown>[]).map((r) => keys.map((k) => cell(r[k])))];
}

export async function loadInputs(core: Core, order: Order): Promise<JobInputs> {
  const inputs: JobInputs = { answers: { ...order.intake }, details: order.details, fileText: {}, fileParts: {}, tables: {}, fileNames: {}, problems: [] };

  for (const file of order.intakeFiles) {
    const key = file.id.split(':')[0] ?? 'file';
    const bytes = await core.store.getBlob(intakeBlobId(order.orderId, file));
    if (!bytes) {
      inputs.problems.push(`${file.fileName}: the uploaded file is no longer stored.`);
      continue;
    }
    inputs.fileNames[key] = [...(inputs.fileNames[key] ?? []), file.fileName];
    const ext = (file.fileName.split('.').pop() ?? '').toLowerCase();
    const addText = (text: string): void => {
      inputs.fileText[key] = [inputs.fileText[key], text.slice(0, MAX_TEXT)].filter(Boolean).join('\n\n');
    };
    try {
      if (ext === 'docx') addText(docxToText(bytes));
      else if (ext === 'xlsx') inputs.tables[key] = xlsxToRows(bytes);
      else if (ext === 'csv' || ext === 'tsv') {
        const text = bytes.toString('utf8');
        inputs.tables[key] = parseDelimited(text, ext === 'tsv' ? '\t' : undefined);
        addText(text);
      } else if (ext === 'json') {
        const text = bytes.toString('utf8');
        const table = jsonToTable(text);
        if (table) inputs.tables[key] = table;
        addText(text);
      } else if (ext === 'txt' || ext === 'md') addText(bytes.toString('utf8'));
      else if (ext === 'pdf' || ext === 'png' || ext === 'jpg' || ext === 'jpeg') {
        if (bytes.length > MAX_INLINE_BYTES) inputs.problems.push(`${file.fileName}: too large to be read automatically (over 4.5 MB).`);
        else inputs.fileParts[key] = [...(inputs.fileParts[key] ?? []), { inlineData: { mimeType: file.mime, data: bytes.toString('base64') } }];
      } else inputs.problems.push(`${file.fileName}: this file type cannot be read automatically.`);
    } catch (err) {
      inputs.problems.push(`${file.fileName}: could not be read (${String((err as Error)?.message ?? err).slice(0, 120)}).`);
    }
  }
  return inputs;
}

/** The client's text for a field: what they typed plus what was read from files. */
export function textOf(inputs: JobInputs, ...keys: string[]): string {
  const parts: string[] = [];
  for (const k of keys) {
    if (inputs.answers[k]?.trim()) parts.push(inputs.answers[k].trim());
    if (inputs.fileText[k]?.trim()) parts.push(inputs.fileText[k].trim());
  }
  return parts.join('\n\n');
}

export function partsOf(inputs: JobInputs, ...keys: string[]): ModelPart[] {
  return keys.flatMap((k) => inputs.fileParts[k] ?? []);
}
