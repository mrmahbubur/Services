/**
 * mrs-core — a small document model shared by the PDF and Word writers.
 *
 * Workers write Markdown (or build blocks directly); the same blocks become a .md,
 * a .docx and a .pdf, so the three files always say the same thing.
 */

export type Block =
  | { t: 'title'; text: string; sub?: string } // centred document title + optional line below it
  | { t: 'h'; level: 1 | 2 | 3; text: string }
  | { t: 'p'; text: string }
  | { t: 'li'; text: string; ordered?: boolean; n?: number; indent?: number }
  | { t: 'code'; text: string }
  | { t: 'table'; rows: string[][] }
  | { t: 'rule' }
  | { t: 'space' };

/** A run of text; `b` = bold. */
export interface Run {
  text: string;
  b: boolean;
}

/** Splits `**bold**` out of a line and drops other Markdown decoration. */
export function inlineRuns(text: string): Run[] {
  const cleaned = text
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '$1 ($2)')
    .replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1$2')
    .replace(/(^|[\s(])_([^_\s][^_]*?)_(?=[\s).,;:!?]|$)/g, '$1$2');
  const runs: Run[] = [];
  const re = /\*\*([^*]+)\*\*/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(cleaned)) !== null) {
    if (m.index > last) runs.push({ text: cleaned.slice(last, m.index), b: false });
    runs.push({ text: m[1] ?? '', b: true });
    last = m.index + m[0].length;
  }
  if (last < cleaned.length) runs.push({ text: cleaned.slice(last), b: false });
  return runs.filter((r) => r.text.length > 0);
}

export function plainText(text: string): string {
  return inlineRuns(text)
    .map((r) => r.text)
    .join('');
}

function splitTableRow(line: string): string[] {
  return line
    .trim()
    .replace(/^\|/, '')
    .replace(/\|$/, '')
    .split('|')
    .map((c) => c.trim());
}

/** Parses the Markdown subset the workers produce. Unknown syntax degrades to plain paragraphs. */
export function parseMarkdown(md: string): Block[] {
  const lines = md.replace(/\r/g, '').split('\n');
  const blocks: Block[] = [];
  let para: string[] = [];
  const flush = (): void => {
    if (para.length > 0) blocks.push({ t: 'p', text: para.join(' ') });
    para = [];
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i] ?? '';
    const trimmed = line.trim();

    if (/^```/.test(trimmed)) {
      flush();
      const code: string[] = [];
      i++;
      while (i < lines.length && !/^```/.test((lines[i] ?? '').trim())) {
        code.push(lines[i] ?? '');
        i++;
      }
      blocks.push({ t: 'code', text: code.join('\n') });
      continue;
    }
    if (trimmed === '') {
      flush();
      if (blocks.length > 0 && blocks[blocks.length - 1]?.t !== 'space') blocks.push({ t: 'space' });
      continue;
    }
    const heading = /^(#{1,6})\s+(.*)$/.exec(trimmed);
    if (heading) {
      flush();
      const level = Math.min(3, (heading[1] ?? '#').length) as 1 | 2 | 3;
      blocks.push({ t: 'h', level, text: plainText((heading[2] ?? '').replace(/\s+#+$/, '')) });
      continue;
    }
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      flush();
      blocks.push({ t: 'rule' });
      continue;
    }
    if (/^\|.*\|$/.test(trimmed)) {
      flush();
      const rows: string[][] = [];
      while (i < lines.length && /^\|.*\|$/.test((lines[i] ?? '').trim())) {
        const cells = splitTableRow(lines[i] ?? '');
        if (!cells.every((c) => /^:?-{2,}:?$/.test(c))) rows.push(cells);
        i++;
      }
      i--;
      if (rows.length > 0) blocks.push({ t: 'table', rows });
      continue;
    }
    const bullet = /^(\s*)[-*+•]\s+(.*)$/.exec(line);
    if (bullet) {
      flush();
      blocks.push({ t: 'li', text: bullet[2] ?? '', indent: Math.min(2, Math.floor((bullet[1] ?? '').length / 2)) });
      continue;
    }
    const numbered = /^(\s*)(\d{1,3})[.)]\s+(.*)$/.exec(line);
    if (numbered) {
      flush();
      blocks.push({ t: 'li', text: numbered[3] ?? '', ordered: true, n: Number(numbered[2]), indent: Math.min(2, Math.floor((numbered[1] ?? '').length / 2)) });
      continue;
    }
    para.push(trimmed.replace(/^>\s?/, ''));
  }
  flush();
  while (blocks.length > 0 && blocks[blocks.length - 1]?.t === 'space') blocks.pop();
  return blocks;
}

/** All visible text of a document, for checks that compare a deliverable with its source. */
export function blocksText(blocks: Block[]): string {
  const out: string[] = [];
  for (const b of blocks) {
    if (b.t === 'title') out.push(b.text, b.sub ?? '');
    else if (b.t === 'h' || b.t === 'p' || b.t === 'li') out.push(plainText(b.text));
    else if (b.t === 'code') out.push(b.text);
    else if (b.t === 'table') out.push(b.rows.map((r) => r.map(plainText).join(' | ')).join('\n'));
  }
  return out.filter(Boolean).join('\n');
}
