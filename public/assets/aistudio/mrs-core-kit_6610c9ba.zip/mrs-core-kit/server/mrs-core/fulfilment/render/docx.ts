/**
 * mrs-core — Word (.docx) writer and text reader (no dependencies).
 *
 * Writer: plain paragraphs, headings, bullets, tables and bold runs with standard
 * style names, which is what Word, Google Docs, LibreOffice and applicant-tracking
 * systems all read reliably. Any script (Bengali, Arabic, ...) is supported, because
 * Word picks the font.
 *
 * Reader: pulls the text out of a client's uploaded .docx.
 */
import type { Block } from './blocks.ts';
import { inlineRuns } from './blocks.ts';
import { listZip, readZipEntry, zip } from './zip.ts';

export function xmlEscape(text: string): string {
  return text
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '') // characters XML 1.0 forbids
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function run(text: string, bold: boolean, mono = false): string {
  if (!text) return '';
  const props = `${bold ? '<w:b/>' : ''}${mono ? '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/><w:sz w:val="18"/>' : ''}`;
  return `<w:r>${props ? `<w:rPr>${props}</w:rPr>` : ''}<w:t xml:space="preserve">${xmlEscape(text)}</w:t></w:r>`;
}

function runs(text: string): string {
  return inlineRuns(text)
    .map((r) => run(r.text, r.b))
    .join('');
}

function para(inner: string, opts: { style?: string; center?: boolean; indentLeft?: number; hanging?: number; after?: number; before?: number; keepNext?: boolean } = {}): string {
  const p: string[] = [];
  if (opts.style) p.push(`<w:pStyle w:val="${opts.style}"/>`);
  if (opts.keepNext) p.push('<w:keepNext/>');
  if (opts.before !== undefined || opts.after !== undefined) p.push(`<w:spacing${opts.before !== undefined ? ` w:before="${opts.before}"` : ''}${opts.after !== undefined ? ` w:after="${opts.after}"` : ''}/>`);
  if (opts.indentLeft !== undefined) p.push(`<w:ind w:left="${opts.indentLeft}"${opts.hanging ? ` w:hanging="${opts.hanging}"` : ''}/>`);
  if (opts.center) p.push('<w:jc w:val="center"/>');
  return `<w:p>${p.length ? `<w:pPr>${p.join('')}</w:pPr>` : ''}${inner}</w:p>`;
}

function table(rows: string[][]): string {
  const cols = Math.max(1, ...rows.map((r) => r.length));
  const w = Math.floor(9000 / cols);
  const border = (side: string): string => `<w:${side} w:val="single" w:sz="4" w:space="0" w:color="999999"/>`;
  const grid = Array.from({ length: cols }, () => `<w:gridCol w:w="${w}"/>`).join('');
  const body = rows
    .map((row, ri) => {
      const cells = Array.from({ length: cols }, (_, c) => {
        const text = row[c] ?? '';
        const inner = ri === 0 ? run(inlineRuns(text).map((r) => r.text).join(''), true) : runs(text);
        return `<w:tc><w:tcPr><w:tcW w:w="${w}" w:type="dxa"/></w:tcPr>${para(inner, { after: 40 })}</w:tc>`;
      }).join('');
      return `<w:tr>${cells}</w:tr>`;
    })
    .join('');
  return `<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:tblBorders>${['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(border).join('')}</w:tblBorders></w:tblPr><w:tblGrid>${grid}</w:tblGrid>${body}</w:tbl>`;
}

const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri" w:eastAsia="Calibri"/><w:sz w:val="21"/><w:szCs w:val="21"/><w:lang w:val="en-US"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="100" w:line="259" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="40"/><w:jc w:val="center"/></w:pPr><w:rPr><w:b/><w:sz w:val="36"/><w:szCs w:val="36"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="808080"/></w:pBdr><w:spacing w:before="200" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="140" w:after="40"/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style>
</w:styles>`;

const CONTENT_TYPES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`;

const ROOT_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`;

const DOC_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;

export function renderDocx(blocks: Block[], opts: { title: string; author?: string }): Buffer {
  const body: string[] = [];
  for (const b of blocks) {
    if (b.t === 'title') {
      body.push(para(run(b.text, false), { style: 'Title' }));
      if (b.sub) body.push(para(run(b.sub, false), { center: true, after: 160 }));
    } else if (b.t === 'h') body.push(para(run(b.text, false), { style: `Heading${b.level}` }));
    else if (b.t === 'p') body.push(para(runs(b.text)));
    else if (b.t === 'li') {
      const left = 360 + (b.indent ?? 0) * 360;
      const marker = b.ordered ? `${b.n ?? 1}.` : '\u2022';
      body.push(para(`${run(marker, false)}<w:r><w:tab/></w:r>${runs(b.text)}`, { indentLeft: left, hanging: 280, after: 40 }));
    } else if (b.t === 'code') {
      for (const line of b.text.split('\n')) body.push(para(run(line.replace(/\t/g, '    '), false, true), { indentLeft: 240, after: 0 }));
      body.push(para('', { after: 80 }));
    } else if (b.t === 'table') {
      body.push(table(b.rows), para('', { after: 60 }));
    } else if (b.t === 'rule') {
      body.push('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="808080"/></w:pBdr><w:spacing w:after="80"/></w:pPr></w:p>');
    }
    // 'space' needs nothing: paragraph spacing already separates blocks
  }

  const document = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body.join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1080" w:right="1080" w:bottom="1080" w:left="1080" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`;

  const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xmlEscape(opts.title.slice(0, 200))}</dc:title><dc:creator>${xmlEscape((opts.author ?? 'M R S').slice(0, 100))}</dc:creator></cp:coreProperties>`;

  return zip([
    { name: '[Content_Types].xml', data: CONTENT_TYPES },
    { name: '_rels/.rels', data: ROOT_RELS },
    { name: 'word/document.xml', data: document },
    { name: 'word/styles.xml', data: STYLES },
    { name: 'word/_rels/document.xml.rels', data: DOC_RELS },
    { name: 'docProps/core.xml', data: core },
  ]);
}

export function xmlUnescape(text: string): string {
  return text
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d: string) => String.fromCodePoint(Number(d)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h: string) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&amp;/g, '&');
}

const MAX_DOCX_XML = 30 * 1024 * 1024;

/** Text of a .docx: one line per paragraph, table cells separated by tabs. */
export function docxToText(buf: Buffer): string {
  const entries = listZip(buf);
  const main = entries.find((e) => e.name === 'word/document.xml');
  if (!main) throw new Error('not a Word document (word/document.xml missing)');
  const parts = [main, ...entries.filter((e) => /^word\/(header|footer)\d*\.xml$/.test(e.name))];
  const out: string[] = [];
  for (const part of parts) {
    const xml = readZipEntry(buf, part, MAX_DOCX_XML).toString('utf8');
    const text = xml
      .replace(/<w:tab\b[^>]*\/>/g, '\t')
      .replace(/<w:(br|cr)\b[^>]*\/>/g, '\n')
      .replace(/<\/w:p>\s*<\/w:tc>\s*<\/w:tr>/g, '\n') // last cell of a table row
      .replace(/<\/w:p>\s*<\/w:tc>/g, '\t') // cell boundary inside a row
      .replace(/<\/w:p>/g, '\n')
      .replace(/<w:instrText[\s\S]*?<\/w:instrText>/g, '')
      .replace(/<[^>]+>/g, '');
    out.push(xmlUnescape(text));
  }
  return out
    .join('\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}
