/**
 * mrs-core — PDF writer (no dependencies).
 *
 * Produces plain, single-column, real-text PDFs: exactly what applicant-tracking
 * systems and screen readers parse best. Uses the fonts built into every PDF reader
 * (Helvetica, Helvetica-Bold, Courier), so files are a few kilobytes.
 *
 * LIMIT: those built-in fonts cover Latin text only. Characters outside that range
 * (Bengali, Arabic, CJK, emoji) cannot be drawn; they are replaced by "?" and
 * counted in `unsupportedChars`, so the caller can warn and fall back to the .docx.
 */
import { deflateSync } from 'node:zlib';
import type { Block, Run } from './blocks.ts';
import { inlineRuns } from './blocks.ts';

// Adobe font metrics (1/1000 em) for characters 0x20-0x7E.
const HELVETICA = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];
const HELVETICA_BOLD = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584];

/** Widths of the WinAnsi specials (0x80-0x9F) that we emit: [regular, bold]. */
const SPECIAL_WIDTH: Record<number, [number, number]> = {
  0x80: [556, 556], // euro
  0x85: [1000, 1000], // ellipsis
  0x91: [222, 278],
  0x92: [222, 278],
  0x93: [333, 500],
  0x94: [333, 500],
  0x95: [350, 350], // bullet
  0x96: [556, 556], // en dash
  0x97: [1000, 1000], // em dash
  0x99: [1000, 1000], // trademark
};

const UNICODE_TO_WINANSI: Record<number, number | string> = {
  0x20ac: 0x80,
  0x2026: 0x85,
  0x2018: 0x91,
  0x2019: 0x92,
  0x201c: 0x93,
  0x201d: 0x94,
  0x2022: 0x95,
  0x25cf: 0x95,
  0x25aa: 0x95,
  0x2023: 0x95,
  0x00b7: 0x95,
  0x2013: 0x96,
  0x2014: 0x97,
  0x2122: 0x99,
  0x00a0: 0x20,
  0x2009: 0x20,
  0x200a: 0x20,
  0x202f: 0x20,
  0x2011: '-',
  0x2010: '-',
  0x2212: '-',
  0x2192: '->',
  0x2190: '<-',
  0x2264: '<=',
  0x2265: '>=',
  0x2260: '!=',
  0x2713: '+',
  0x2714: '+',
  0x200b: '',
  0xfeff: '',
};

export interface Encoded {
  /** One WinAnsi byte per element. */
  bytes: number[];
  unsupported: number;
}

/** Unicode text -> WinAnsi bytes. */
export function encodeWinAnsi(text: string): Encoded {
  const bytes: number[] = [];
  let unsupported = 0;
  for (const ch of text.normalize('NFC')) {
    const cp = ch.codePointAt(0) ?? 63;
    if (cp === 9) bytes.push(32, 32);
    else if (cp >= 0x20 && cp <= 0x7e) bytes.push(cp);
    else if (cp >= 0xa1 && cp <= 0xff) bytes.push(cp);
    else if (cp < 0x20 || cp === 0x7f) continue; // control characters are dropped
    else {
      const mapped = UNICODE_TO_WINANSI[cp];
      if (typeof mapped === 'number') bytes.push(mapped);
      else if (typeof mapped === 'string') for (const c of mapped) bytes.push(c.charCodeAt(0));
      else {
        bytes.push(63);
        unsupported += 1;
      }
    }
  }
  return { bytes, unsupported };
}

type FontKey = 'F1' | 'F2' | 'F3';

function byteWidth(b: number, font: FontKey): number {
  if (font === 'F3') return 600;
  const table = font === 'F2' ? HELVETICA_BOLD : HELVETICA;
  if (b >= 0x20 && b <= 0x7e) return table[b - 0x20] as number;
  const special = SPECIAL_WIDTH[b];
  if (special) return special[font === 'F2' ? 1 : 0];
  if (b >= 0xc0) {
    // accented Latin letters are as wide as their base letter
    const base = String.fromCharCode(b).normalize('NFD').charCodeAt(0);
    if (base >= 0x20 && base <= 0x7e) return table[base - 0x20] as number;
  }
  return 556;
}

/** Width of `text` in points at `size`. */
export function textWidth(text: string, font: FontKey, size: number): number {
  let w = 0;
  for (const b of encodeWinAnsi(text).bytes) w += byteWidth(b, font);
  return (w * size) / 1000;
}

function pdfString(bytes: number[]): string {
  let out = '(';
  for (const b of bytes) {
    if (b === 0x28 || b === 0x29 || b === 0x5c) out += '\\' + String.fromCharCode(b);
    else if (b < 0x20 || b > 0x7e) out += '\\' + b.toString(8).padStart(3, '0');
    else out += String.fromCharCode(b);
  }
  return out + ')';
}

const n2 = (v: number): string => (Math.round(v * 100) / 100).toString();

export interface PdfOptions {
  title: string;
  author?: string;
  /** Text shown at the bottom left of every page. */
  footer?: string;
  /** Large diagonal text behind the content of every page (e.g. PREVIEW). */
  watermark?: string;
  /** Page margin in points. Default 54 (0.75 inch). */
  margin?: number;
  /** Base font size. Default 10. */
  fontSize?: number;
}

export interface PdfResult {
  bytes: Buffer;
  pages: number;
  unsupportedChars: number;
}

interface Piece {
  text: string;
  font: FontKey;
}

const PAGE_W = 595.28; // A4
const PAGE_H = 841.89;

export function renderPdf(blocks: Block[], opts: PdfOptions): PdfResult {
  const margin = opts.margin ?? 54;
  const base = opts.fontSize ?? 10;
  const left = margin;
  const right = PAGE_W - margin;
  const top = PAGE_H - margin;
  const bottom = margin + 14;
  const width = right - left;

  const pages: string[][] = [[]];
  let y = top;
  let unsupported = 0;

  const page = (): string[] => pages[pages.length - 1] as string[];
  const newPage = (): void => {
    pages.push([]);
    y = top;
  };
  const need = (h: number): void => {
    if (y - h < bottom) newPage();
  };

  const drawPieces = (x: number, yy: number, pieces: Piece[], size: number): void => {
    if (pieces.length === 0) return;
    let ops = `BT ${n2(x)} ${n2(yy)} Td`;
    let current: FontKey | null = null;
    for (const p of pieces) {
      const enc = encodeWinAnsi(p.text);
      unsupported += enc.unsupported;
      if (enc.bytes.length === 0) continue;
      if (current !== p.font) {
        ops += ` /${p.font} ${n2(size)} Tf`;
        current = p.font;
      }
      ops += ` ${pdfString(enc.bytes)} Tj`;
    }
    page().push(ops + ' ET');
  };

  /** Breaks runs into lines no wider than maxWidth. */
  const wrap = (runs: Run[], size: number, maxWidth: number, mono = false): Piece[][] => {
    const lines: Piece[][] = [];
    let line: Piece[] = [];
    let lineW = 0;
    const push = (): void => {
      // trim the trailing space of a line
      const lastPiece = line[line.length - 1];
      if (lastPiece) lastPiece.text = lastPiece.text.replace(/\s+$/, '');
      lines.push(line);
      line = [];
      lineW = 0;
    };
    for (const run of runs) {
      const font: FontKey = mono ? 'F3' : run.b ? 'F2' : 'F1';
      const tokens = run.text.split(/(\s+)/).filter((t) => t.length > 0);
      for (let token of tokens) {
        const isSpace = /^\s+$/.test(token);
        if (isSpace) token = ' ';
        let w = textWidth(token, font, size);
        if (isSpace && line.length === 0) continue; // no leading space on a wrapped line
        if (lineW + w > maxWidth && line.length > 0 && !isSpace) push();
        // a single word wider than the line: split it by characters
        while (w > maxWidth) {
          let cut = token.length - 1;
          while (cut > 1 && textWidth(token.slice(0, cut), font, size) > maxWidth) cut--;
          line.push({ text: token.slice(0, cut), font });
          push();
          token = token.slice(cut);
          w = textWidth(token, font, size);
        }
        const lastPiece = line[line.length - 1];
        if (lastPiece && lastPiece.font === font) lastPiece.text += token;
        else line.push({ text: token, font });
        lineW += w;
      }
    }
    if (line.length > 0) push();
    return lines;
  };

  const paragraph = (runs: Run[], size: number, indent: number, leading: number, after: number, firstPrefix?: { text: string; x: number; font: FontKey }): void => {
    const lines = wrap(runs, size, width - indent);
    lines.forEach((ln, i) => {
      need(leading);
      y -= leading;
      if (i === 0 && firstPrefix) drawPieces(left + firstPrefix.x, y, [{ text: firstPrefix.text, font: firstPrefix.font }], size);
      drawPieces(left + indent, y, ln, size);
    });
    y -= after;
  };

  const hline = (yy: number, gray = 0.6, w = 0.6): void => {
    page().push(`q ${gray} G ${w} w ${n2(left)} ${n2(yy)} m ${n2(right)} ${n2(yy)} l S Q`);
  };

  for (const b of blocks) {
    if (b.t === 'title') {
      const size = base + 8;
      need(size + 20);
      y -= size;
      drawPieces(left + Math.max(0, (width - textWidth(b.text, 'F2', size)) / 2), y, [{ text: b.text, font: 'F2' }], size);
      if (b.sub) {
        const subSize = base - 0.5;
        for (const ln of wrap([{ text: b.sub, b: false }], subSize, width)) {
          y -= subSize + 4;
          const lw = ln.reduce((s, p) => s + textWidth(p.text, p.font, subSize), 0);
          drawPieces(left + Math.max(0, (width - lw) / 2), y, ln, subSize);
        }
      }
      y -= 8;
    } else if (b.t === 'h') {
      const size = b.level === 1 ? base + 5 : b.level === 2 ? base + 1.5 : base + 0.5;
      const before = b.level === 1 ? 10 : b.level === 2 ? 9 : 6;
      need(before + size + 30); // keep a heading with the text that follows it
      y -= before;
      paragraph([{ text: b.text, b: true }], size, 0, size + 3, 1);
      if (b.level === 2) {
        hline(y - 1.5);
        y -= 5;
      } else y -= 2;
    } else if (b.t === 'p') {
      paragraph(inlineRuns(b.text), base, 0, base + 3.5, 4);
    } else if (b.t === 'li') {
      const indentBase = 4 + (b.indent ?? 0) * 14;
      const marker = b.ordered ? `${b.n ?? 1}.` : '\u2022';
      const hang = b.ordered ? Math.max(14, textWidth(marker + ' ', 'F1', base) + 2) : 11;
      paragraph(inlineRuns(b.text), base, indentBase + hang, base + 3.5, 1.5, { text: marker, x: indentBase, font: 'F1' });
    } else if (b.t === 'code') {
      const size = base - 1.5;
      const maxChars = Math.max(20, Math.floor((width - 12) / ((600 * size) / 1000)));
      y -= 3;
      for (const raw of b.text.split('\n')) {
        const expanded = raw.replace(/\t/g, '    ');
        const chunks = expanded.length === 0 ? [''] : (expanded.match(new RegExp(`.{1,${maxChars}}`, 'g')) ?? ['']);
        for (const chunk of chunks) {
          need(size + 3);
          y -= size + 3;
          drawPieces(left + 8, y, [{ text: chunk, font: 'F3' }], size);
        }
      }
      y -= 6;
    } else if (b.t === 'table') {
      const cols = Math.max(1, ...b.rows.map((r) => r.length));
      const colW = width / cols;
      const size = base - 1;
      const leading = size + 3;
      b.rows.forEach((row, ri) => {
        const cells = Array.from({ length: cols }, (_, c) => wrap(ri === 0 ? [{ text: row[c] ?? '', b: true }] : inlineRuns(row[c] ?? ''), size, colW - 8));
        const rowLines = Math.max(1, ...cells.map((c) => c.length));
        need(rowLines * leading + 6);
        const rowTop = y;
        cells.forEach((cellLines, c) => {
          cellLines.forEach((ln, li) => drawPieces(left + c * colW + 3, rowTop - (li + 1) * leading, ln, size));
        });
        y = rowTop - rowLines * leading - 4;
        hline(y, ri === 0 ? 0.3 : 0.8, ri === 0 ? 0.8 : 0.4);
        y -= 1;
      });
      y -= 6;
    } else if (b.t === 'rule') {
      need(10);
      y -= 5;
      hline(y);
      y -= 5;
    } else if (b.t === 'space') {
      y -= 5;
    }
  }

  // ---- serialise
  const footerText = opts.footer ?? '';
  const objects: Buffer[] = [];
  const add = (body: string | Buffer): number => {
    objects.push(typeof body === 'string' ? Buffer.from(body, 'latin1') : body);
    return objects.length;
  };
  // 1 catalog, 2 pages (filled in below), 3-5 fonts, 6 info
  add('<< /Type /Catalog /Pages 2 0 R >>');
  add('');
  add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  add('<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>');
  const meta = (s: string): string => pdfString(encodeWinAnsi(s.slice(0, 200)).bytes);
  add(`<< /Title ${meta(opts.title)} /Author ${meta(opts.author ?? 'M R S')} /Producer (mrs-core) >>`);

  const kids: number[] = [];
  pages.forEach((ops, i) => {
    const pre: string[] = [];
    if (opts.watermark) {
      const wm = encodeWinAnsi(opts.watermark.slice(0, 40));
      pre.push(`q 0.9 g BT /F2 64 Tf 0.7071 0.7071 -0.7071 0.7071 ${n2(PAGE_W / 2 - 150)} ${n2(PAGE_H / 2 - 190)} Tm ${pdfString(wm.bytes)} Tj ET Q`);
    }
    const post: string[] = [];
    const pageLabel = `${i + 1} / ${pages.length}`;
    const fy = margin - 4;
    post.push(`q 0.45 g BT /F1 8 Tf ${n2(right - textWidth(pageLabel, 'F1', 8))} ${n2(fy)} Td ${pdfString(encodeWinAnsi(pageLabel).bytes)} Tj ET Q`);
    if (footerText) post.push(`q 0.45 g BT /F1 8 Tf ${n2(left)} ${n2(fy)} Td ${pdfString(encodeWinAnsi(footerText.slice(0, 110)).bytes)} Tj ET Q`);

    const stream = deflateSync(Buffer.from([...pre, '0 g', ...ops, ...post].join('\n'), 'latin1'));
    const contentId = add(Buffer.concat([Buffer.from(`<< /Length ${stream.length} /Filter /FlateDecode >>\nstream\n`, 'latin1'), stream, Buffer.from('\nendstream', 'latin1')]));
    const pageId = add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents ${contentId} 0 R >>`);
    kids.push(pageId);
  });
  objects[1] = Buffer.from(`<< /Type /Pages /Kids [${kids.map((k) => `${k} 0 R`).join(' ')}] /Count ${kids.length} >>`, 'latin1');

  const chunks: Buffer[] = [Buffer.from('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n', 'latin1')];
  const offsets: number[] = [];
  let pos = chunks[0]?.length ?? 0;
  objects.forEach((body, i) => {
    offsets.push(pos);
    const head = Buffer.from(`${i + 1} 0 obj\n`, 'latin1');
    const tail = Buffer.from('\nendobj\n', 'latin1');
    chunks.push(head, body, tail);
    pos += head.length + body.length + tail.length;
  });
  const xref = [`xref\n0 ${objects.length + 1}\n`, '0000000000 65535 f \n', ...offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`)].join('');
  chunks.push(Buffer.from(`${xref}trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info 6 0 R >>\nstartxref\n${pos}\n%%EOF\n`, 'latin1'));
  return { bytes: Buffer.concat(chunks), pages: pages.length, unsupportedChars: unsupported };
}
