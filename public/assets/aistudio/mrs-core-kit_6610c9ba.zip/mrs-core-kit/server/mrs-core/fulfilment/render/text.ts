/**
 * mrs-core — delimited text (CSV / TSV) reading and writing.
 */

const CANDIDATES = [',', ';', '\t', '|'] as const;

/** Guesses the delimiter from the first lines, ignoring anything inside quotes. */
export function sniffDelimiter(text: string): string {
  const sample = text.slice(0, 20_000).split(/\r?\n/).filter((l) => l.trim() !== '').slice(0, 25);
  let best = ',';
  let bestScore = -1;
  for (const d of CANDIDATES) {
    const counts = sample.map((line) => {
      let n = 0;
      let quoted = false;
      for (const ch of line) {
        if (ch === '"') quoted = !quoted;
        else if (ch === d && !quoted) n++;
      }
      return n;
    });
    const first = counts[0] ?? 0;
    if (first === 0) continue;
    const consistent = counts.filter((c) => c === first).length / counts.length;
    const score = consistent * 1000 + first;
    if (score > bestScore) {
      bestScore = score;
      best = d;
    }
  }
  return best;
}

/** RFC-4180 reader: quoted fields, doubled quotes, embedded delimiters and newlines. */
export function parseDelimited(text: string, delimiter?: string): string[][] {
  const src = text.replace(/^\uFEFF/, '');
  const d = delimiter ?? sniffDelimiter(src);
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  let cellStarted = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i] as string;
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"' && !cellStarted) {
      quoted = true;
      cellStarted = true;
    } else if (ch === d) {
      row.push(cell);
      cell = '';
      cellStarted = false;
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && src[i + 1] === '\n') i++;
      row.push(cell);
      cell = '';
      cellStarted = false;
      rows.push(row);
      row = [];
    } else {
      cell += ch;
      cellStarted = true;
    }
  }
  if (cell !== '' || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  // Blank lines inside the file are kept, so that "row 7" here is row 7 in the
  // client's own spreadsheet. Only blank lines at the very end are dropped.
  while (rows.length > 0 && (rows[rows.length - 1] as string[]).every((c) => c.trim() === '')) rows.pop();
  return rows;
}

export function csvCell(value: string): string {
  return /[",\n\r]/.test(value) || /^\s|\s$/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

export function toCsv(rows: string[][]): string {
  return rows.map((r) => r.map((c) => csvCell(c ?? '')).join(',')).join('\r\n') + '\r\n';
}

/** Plain text with the leading part kept and the rest replaced by a notice (for locked previews). */
export function truncateForPreview(markdown: string, fraction = 0.35, minLines = 12): string {
  const lines = markdown.split('\n');
  const keep = Math.min(lines.length, Math.max(minLines, Math.ceil(lines.length * fraction)));
  if (keep >= lines.length) return markdown;
  return [...lines.slice(0, keep), '', '---', '', `**Preview ends here.** The complete work (${lines.length - keep} more lines) unlocks as soon as your payment is confirmed.`].join('\n');
}
