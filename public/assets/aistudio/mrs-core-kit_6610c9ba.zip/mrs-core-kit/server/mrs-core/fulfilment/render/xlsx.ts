/**
 * mrs-core — Excel (.xlsx) writer and reader (no dependencies).
 *
 * Writer: every text cell is stored as an inline string, never as a formula, so a
 * value such as "=HYPERLINK(...)" in client data is shown as text and cannot run.
 *
 * Reader: first worksheet of a client's upload, as rows of strings.
 * LIMIT: Excel stores dates as day numbers; they are returned as those numbers and
 * the data worker converts them when a column is declared to be a date.
 */
import { xmlEscape, xmlUnescape } from './docx.ts';
import { listZip, readZipEntry, zip } from './zip.ts';

export type Cell = string | number | null;

export interface Sheet {
  name: string;
  rows: Cell[][];
  /** Make the first row bold and freeze it. */
  header?: boolean;
}

function colName(index: number): string {
  let n = index + 1;
  let s = '';
  while (n > 0) {
    const r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

function sheetXml(sheet: Sheet): string {
  const widths: number[] = [];
  const rowsXml = sheet.rows
    .map((row, r) => {
      const cells = row
        .map((value, c) => {
          const ref = `${colName(c)}${r + 1}`;
          const style = sheet.header && r === 0 ? ' s="1"' : '';
          if (value === null || value === '') return '';
          widths[c] = Math.min(60, Math.max(widths[c] ?? 8, String(value).length + 2));
          if (typeof value === 'number' && Number.isFinite(value)) return `<c r="${ref}"${style}><v>${value}</v></c>`;
          return `<c r="${ref}"${style} t="inlineStr"><is><t xml:space="preserve">${xmlEscape(String(value).slice(0, 32000))}</t></is></c>`;
        })
        .join('');
      return `<row r="${r + 1}">${cells}</row>`;
    })
    .join('');
  const cols = widths.length > 0 ? `<cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w ?? 8}" customWidth="1"/>`).join('')}</cols>` : '';
  const view = sheet.header ? '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' : '';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${view}${cols}<sheetData>${rowsXml}</sheetData></worksheet>`;
}

function safeSheetName(name: string, used: Set<string>): string {
  let base = name.replace(/[\\/?*[\]:]/g, ' ').trim().slice(0, 31) || 'Sheet';
  let n = 2;
  while (used.has(base.toLowerCase())) base = `${base.slice(0, 28)} ${n++}`;
  used.add(base.toLowerCase());
  return base;
}

export function renderXlsx(sheets: Sheet[]): Buffer {
  const used = new Set<string>();
  const names = sheets.map((s) => safeSheetName(s.name, used));
  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`;
  const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xmlEscape(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`;
  const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  return zip([
    { name: '[Content_Types].xml', data: contentTypes },
    { name: '_rels/.rels', data: rootRels },
    { name: 'xl/workbook.xml', data: workbook },
    { name: 'xl/_rels/workbook.xml.rels', data: workbookRels },
    { name: 'xl/styles.xml', data: styles },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s) })),
  ]);
}

function colIndex(ref: string): number {
  const letters = /^[A-Z]+/.exec(ref)?.[0] ?? 'A';
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

const MAX_SHEET_XML = 40 * 1024 * 1024;
const MAX_ROWS = 50_000;
const MAX_COLS = 200;

/** Rows of the first worksheet as strings. */
export function xlsxToRows(buf: Buffer): string[][] {
  const entries = listZip(buf);
  const sheetEntry = entries.filter((e) => /^xl\/worksheets\/sheet\d+\.xml$/.test(e.name)).sort((a, b) => Number(/\d+/.exec(a.name)?.[0]) - Number(/\d+/.exec(b.name)?.[0]))[0];
  if (!sheetEntry) throw new Error('not an Excel workbook (no worksheet found)');

  const shared: string[] = [];
  const sharedEntry = entries.find((e) => e.name === 'xl/sharedStrings.xml');
  if (sharedEntry) {
    const xml = readZipEntry(buf, sharedEntry, MAX_SHEET_XML).toString('utf8');
    const siRe = /<si\b[^>]*>([\s\S]*?)<\/si>/g;
    let m: RegExpExecArray | null;
    while ((m = siRe.exec(xml)) !== null) {
      const withoutPhonetic = (m[1] ?? '').replace(/<rPh\b[\s\S]*?<\/rPh>/g, '');
      const texts = [...withoutPhonetic.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((t) => xmlUnescape(t[1] ?? ''));
      shared.push(texts.join(''));
    }
  }

  const xml = readZipEntry(buf, sheetEntry, MAX_SHEET_XML).toString('utf8');
  const rows: string[][] = [];
  const rowRe = /<row\b([^>]*)>([\s\S]*?)<\/row>/g;
  let rm: RegExpExecArray | null;
  while ((rm = rowRe.exec(xml)) !== null && rows.length < MAX_ROWS) {
    // Excel omits blank rows from the file; put each row where its number says, so
    // that "row 7" here is row 7 in the client's own spreadsheet.
    const declared = Number(/\br="(\d+)"/.exec(rm[1] ?? '')?.[1]);
    if (Number.isInteger(declared) && declared > 0) while (rows.length < Math.min(declared - 1, MAX_ROWS)) rows.push([]);
    const row: string[] = [];
    const cellRe = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g;
    let cm: RegExpExecArray | null;
    let next = 0;
    while ((cm = cellRe.exec(rm[2] ?? '')) !== null) {
      const attrs = cm[1] ?? '';
      const inner = cm[2] ?? '';
      const ref = /\br="([A-Z]+\d+)"/.exec(attrs)?.[1];
      const type = /\bt="(\w+)"/.exec(attrs)?.[1] ?? 'n';
      const col = ref ? colIndex(ref) : next;
      if (col >= MAX_COLS) continue;
      let value = '';
      if (type === 'inlineStr') value = [...inner.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((t) => xmlUnescape(t[1] ?? '')).join('');
      else {
        const v = /<v\b[^>]*>([\s\S]*?)<\/v>/.exec(inner)?.[1] ?? '';
        if (type === 's') value = shared[Number(v)] ?? '';
        else if (type === 'b') value = v === '1' ? 'TRUE' : 'FALSE';
        else value = xmlUnescape(v);
      }
      while (row.length < col) row.push('');
      row[col] = value;
      next = col + 1;
    }
    rows.push(row);
  }
  while (rows.length > 0 && (rows[rows.length - 1] ?? []).every((c) => c === '')) rows.pop();
  return rows;
}

/** Excel day number -> YYYY-MM-DD (1900 date system), or null when out of range. */
export function excelSerialToIso(serial: number): string | null {
  if (!Number.isFinite(serial) || serial < 1 || serial > 2_958_465) return null;
  const ms = Math.round((serial - 25569) * 86_400_000); // 25569 = 1970-01-01
  return new Date(ms).toISOString().slice(0, 10);
}
