/**
 * mrs-core — tools shared by the workers.
 *
 * The important one is Grounding: a deliverable may only state facts that are in
 * what the client supplied. Models invent plausible numbers, tools and credentials;
 * these checks are done by code, on every run, and a failure blocks delivery.
 */
import type { QaCheck } from '../../types.ts';
import type { OutFile } from '../engine.ts';
import { UNTRUSTED_RULE } from '../gemini.ts';
import type { Block } from '../render/blocks.ts';
import { parseMarkdown } from '../render/blocks.ts';
import { renderDocx } from '../render/docx.ts';
import { renderPdf } from '../render/pdf.ts';

export const CAMELLIA_RULES = [
  'You are Camellia, the AI assistant that prepares client work for M R S, a small digital-services business. A person reviews your work before the client sees it.',
  UNTRUSTED_RULE,
  'Use only facts that appear in the material you are given. Never invent names, employers, dates, figures, credentials, tools, links or results. If something needed is not there, leave it out and list it as a question.',
  'Write plain, direct, professional English unless told otherwise. No filler, no marketing language, no emojis.',
  'Never write placeholders such as [Your Name], XX%, TBD or lorem ipsum.',
].join('\n');

export function check(id: string, label: string, passed: boolean, severity: 'block' | 'warn', detail: string): QaCheck {
  return { id, label, passed, severity, detail: detail.slice(0, 500) };
}

// ---------------------------------------------------------------- grounding

function fold(text: string): string {
  return text.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

/** Digits of a figure, without thousands separators or a trailing ".0": "1,200.50" -> "1200.5". */
function canonicalNumber(raw: string): string {
  let v = raw.replace(/,/g, '');
  if (v.includes('.')) v = v.replace(/0+$/, '').replace(/\.$/, '');
  return v.replace(/^0+(?=\d)/, '');
}

const NUMBER_RE = /\d[\d,]*(?:\.\d+)?/g;
const NUMBER_WORDS = ['two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'fifteen', 'twenty', 'thirty', 'forty', 'fifty', 'hundred', 'hundreds', 'thousand', 'thousands', 'million', 'millions', 'billion', 'dozen', 'dozens', 'double', 'doubled', 'triple', 'tripled', 'half', 'halved'];

/** Words that look like proper nouns but are ordinary sentence furniture. */
const COMMON_CAPS = new Set(['i', 'a', 'an', 'the', 'and', 'or', 'of', 'for', 'to', 'in', 'on', 'at', 'by', 'with', 'from', 'as', 'is', 'are', 'was', 'were', 'be', 'this', 'that', 'these', 'those', 'it', 'its', 'we', 'our', 'you', 'your', 'not', 'no', 'yes', 'if', 'then', 'when', 'while', 'after', 'before', 'during', 'per', 'via', 'using', 'used', 'use', 'new', 'key', 'core', 'summary', 'skills', 'experience', 'education', 'projects', 'certifications', 'languages', 'profile', 'professional', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december', 'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'sept', 'oct', 'nov', 'dec', 'present', 'current']);

export class Grounding {
  private squashed: string;
  private tokens: Set<string>;
  private numbers: Set<string>;
  private folded: string;

  constructor(...sources: string[]) {
    const text = sources.join('\n');
    this.folded = fold(text);
    this.squashed = this.folded.replace(/[^a-z0-9]/g, '');
    this.tokens = new Set(this.folded.split(/[^a-z0-9+#.]+/).map((t) => t.replace(/^\.+|\.+$/g, '')).filter(Boolean));
    this.numbers = new Set((text.match(NUMBER_RE) ?? []).map(canonicalNumber));
  }

  /** Is this term (a skill, tool, name) present in the source? Tolerates spacing / punctuation variants. */
  hasTerm(term: string): boolean {
    const f = fold(term).trim();
    if (!f) return true;
    const compact = f.replace(/[^a-z0-9+#]/g, '');
    if (compact.length <= 3 || /[+#]/.test(compact)) {
      // short or symbol-bearing terms (C, R, Go, C++, C#) must match a whole token
      return this.tokens.has(f.replace(/\s+/g, '')) || this.tokens.has(compact);
    }
    const alnum = f.replace(/[^a-z0-9]/g, '');
    if (alnum.length === 0) return true;
    if (this.squashed.includes(alnum)) return true;
    // plural of something the source has in the singular ("APIs" for "API")
    if (alnum.length > 4 && alnum.endsWith('s') && this.squashed.includes(alnum.slice(0, -1))) return true;
    // multi-word term: every significant word must be present
    const words = f.split(/[^a-z0-9+#.]+/).filter((w) => w.length > 2);
    return words.length > 1 && words.every((w) => this.tokens.has(w) || this.squashed.includes(w.replace(/[^a-z0-9]/g, '')));
  }

  hasNumber(raw: string): boolean {
    return this.numbers.has(canonicalNumber(raw));
  }

  /** Figures in `text` that are not in the source. */
  ungroundedNumbers(text: string): string[] {
    const out = new Set<string>();
    for (const m of text.match(NUMBER_RE) ?? []) if (!this.hasNumber(m)) out.add(m);
    return [...out];
  }

  /** Spelled-out quantities ("five years", "doubled") that are not in the source. */
  ungroundedNumberWords(text: string): string[] {
    const out = new Set<string>();
    for (const w of fold(text).split(/[^a-z]+/)) if (NUMBER_WORDS.includes(w) && !this.tokens.has(w)) out.add(w);
    return [...out];
  }

  /**
   * Capitalised or technical-looking terms in `text` that are not in the source:
   * product names, tools, organisations, acronyms. Sentence-initial ordinary words
   * are ignored.
   */
  ungroundedTerms(text: string): string[] {
    const out = new Set<string>();
    for (const sentence of text.split(/(?<=[.!?:;\n])\s+|\n+|[•·]/)) {
      const words = sentence.trim().split(/\s+/);
      words.forEach((raw, i) => {
        const w = raw.replace(/^[^A-Za-z0-9+#]+|[^A-Za-z0-9+#]+$/g, '');
        if (w.length < 2) return;
        const looksTechnical = /[A-Z].*[A-Z]|[a-z][A-Z]|[+#]|\d[A-Za-z]|[A-Za-z]\d|\.[a-z]{2}/.test(w);
        const capitalised = /^[A-Z][a-z]+$/.test(w);
        if (!looksTechnical && !(capitalised && i > 0)) return;
        if (COMMON_CAPS.has(w.toLowerCase())) return;
        if (!this.hasTerm(w)) out.add(w);
      });
    }
    return [...out];
  }
}

// ---------------------------------------------------------------- text checks

const PLACEHOLDER_RE = /\[(?:your|insert|add|company|name|date|number|x+|tbd|todo|placeholder|link|url)[^\]]{0,40}\]|\bX{2,}%?|\bTBD\b|\bTODO\b|lorem ipsum|<[a-z _-]{2,24}>|\{\{[^}]{1,40}\}\}/i;

export function findPlaceholders(text: string): string[] {
  const out: string[] = [];
  const re = new RegExp(PLACEHOLDER_RE.source, 'gi');
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null && out.length < 8) out.push(m[0]);
  return out;
}

export function fencesBalanced(md: string): boolean {
  return (md.match(/^```/gm) ?? []).length % 2 === 0;
}

export function urlsIn(text: string): string[] {
  return [...new Set((text.match(/\bhttps?:\/\/[^\s<>()\]"']+/gi) ?? []).map((u) => u.replace(/[.,;:!?]+$/, '')))];
}

export function wordCount(text: string): number {
  return (text.trim().match(/\S+/g) ?? []).length;
}

// ---------------------------------------------------------------- output files

export interface DocSet {
  files: OutFile[];
  pages: number;
  unsupportedChars: number;
}

/** One document as PDF + Word (+ Markdown), so the client gets a fixed and an editable copy. */
export function documentFiles(baseName: string, title: string, description: string, content: string | Block[], opts: { footer?: string; kind?: 'final' | 'report'; withMarkdown?: boolean; withDocx?: boolean } = {}): DocSet {
  const blocks = typeof content === 'string' ? parseMarkdown(content) : content;
  const kind = opts.kind ?? 'final';
  const pdf = renderPdf(blocks, { title, ...(opts.footer ? { footer: opts.footer } : {}) });
  const files: OutFile[] = [{ fileName: `${baseName}.pdf`, mime: 'application/pdf', bytes: pdf.bytes, title: `${title} (PDF)`, description, kind }];
  if (opts.withDocx !== false) {
    files.push({ fileName: `${baseName}.docx`, mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', bytes: renderDocx(blocks, { title }), title: `${title} (Word, editable)`, description, kind });
  }
  if (opts.withMarkdown && typeof content === 'string') {
    files.push({ fileName: `${baseName}.md`, mime: 'text/markdown', bytes: Buffer.from(content, 'utf8'), title: `${title} (Markdown)`, description, kind });
  }
  return { files, pages: pdf.pages, unsupportedChars: pdf.unsupportedChars };
}

export function pdfTextCheck(unsupportedChars: number): QaCheck {
  return check('pdf_characters', 'PDF can show every character', unsupportedChars === 0, 'warn', unsupportedChars === 0 ? 'All characters print in the PDF.' : `${unsupportedChars} character(s) are in a script the PDF font cannot print and appear as "?". The Word file is correct; deliver that, or re-export the PDF from Word.`);
}

export function safeBaseName(text: string, fallback: string): string {
  const v = text.normalize('NFKD').replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').slice(0, 50);
  return v || fallback;
}

/** Revision notes and send-backs, as one prompt section (or '' when there are none). */
export function feedbackSection(feedback: string[]): string {
  if (feedback.length === 0) return '';
  return `\n\nCHANGES REQUESTED ON EARLIER DRAFTS (apply all; the latest wins where they conflict):\n${feedback.map((f, i) => `${i + 1}. ${f}`).join('\n')}`;
}
