/**
 * mrs-core — S-MRS-06 Advanced ATS CV & Resume.
 *
 * How a fabricated CV is prevented, by construction and by check:
 *
 *  1. Facts (employers, job titles, dates, degrees, certifications, contact details)
 *     are EXTRACTED once from the client's CV. The rewrite step is never asked for
 *     them and cannot change them: the final document is assembled by code from the
 *     extracted facts plus the model's rewritten prose.
 *  2. The rewritten prose (summary, bullets, skills) is then checked by code against
 *     the client's own text. A figure, skill or named tool that is not in the CV
 *     blocks delivery - above all a keyword that appears in the job posting but not
 *     in the CV, which is the classic way an "ATS-optimised" CV ends up lying.
 *  3. The keyword report is counted by code. No invented "98% ATS score".
 */
import type { QaCheck } from '../../types.ts';
import type { WorkerCtx, WorkerResult } from '../engine.ts';
import { askJson, askText, quoteUntrusted } from '../gemini.ts';
import { partsOf, textOf } from '../inputs.ts';
import type { Block } from '../render/blocks.ts';
import { blocksText } from '../render/blocks.ts';
import { CAMELLIA_RULES, Grounding, check, documentFiles, feedbackSection, findPlaceholders, pdfTextCheck, safeBaseName, wordCount } from './common.ts';

interface CvFacts {
  name: string;
  headline: string | null;
  contact: { email: string | null; phone: string | null; location: string | null; links: string[] };
  summary: string | null;
  experience: { title: string; employer: string; location: string | null; start: string | null; end: string | null; bullets: string[] }[];
  education: { degree: string; institution: string; year: string | null; details: string | null }[];
  skills: string[];
  certifications: string[];
  projects: { name: string; description: string }[];
  languages: string[];
  unclear: string[];
}

interface Target {
  roleTitles: string[];
  keywords: { term: string; importance: 'must' | 'nice' }[];
}

interface Rewrite {
  headline: string;
  summary: string;
  skillGroups: { group: string; items: string[] }[];
  experience: { index: number; bullets: string[] }[];
  projects: { index: number; description: string }[];
  questionsForClient: string[];
}

const S = (extra: Record<string, unknown> = {}): Record<string, unknown> => ({ type: 'STRING', ...extra });
const NS = { type: 'STRING', nullable: true };
const LIST = (items: Record<string, unknown>): Record<string, unknown> => ({ type: 'ARRAY', items });

const FACTS_SCHEMA = {
  type: 'OBJECT',
  required: ['name', 'contact', 'experience', 'education', 'skills', 'certifications', 'projects', 'languages', 'unclear'],
  properties: {
    name: S(),
    headline: NS,
    contact: { type: 'OBJECT', required: ['links'], properties: { email: NS, phone: NS, location: NS, links: LIST(S()) } },
    summary: NS,
    experience: LIST({ type: 'OBJECT', required: ['title', 'employer', 'bullets'], properties: { title: S(), employer: S(), location: NS, start: NS, end: NS, bullets: LIST(S()) } }),
    education: LIST({ type: 'OBJECT', required: ['degree', 'institution'], properties: { degree: S(), institution: S(), year: NS, details: NS } }),
    skills: LIST(S()),
    certifications: LIST(S()),
    projects: LIST({ type: 'OBJECT', required: ['name', 'description'], properties: { name: S(), description: S() } }),
    languages: LIST(S()),
    unclear: LIST(S()),
  },
};

const TARGET_SCHEMA = {
  type: 'OBJECT',
  required: ['roleTitles', 'keywords'],
  properties: { roleTitles: LIST(S()), keywords: LIST({ type: 'OBJECT', required: ['term', 'importance'], properties: { term: S(), importance: S({ enum: ['must', 'nice'] }) } }) },
};

const REWRITE_SCHEMA = {
  type: 'OBJECT',
  required: ['headline', 'summary', 'skillGroups', 'experience', 'projects', 'questionsForClient'],
  properties: {
    headline: S(),
    summary: S(),
    skillGroups: LIST({ type: 'OBJECT', required: ['group', 'items'], properties: { group: S(), items: LIST(S()) } }),
    experience: LIST({ type: 'OBJECT', required: ['index', 'bullets'], properties: { index: { type: 'INTEGER' }, bullets: LIST(S()) } }),
    projects: LIST({ type: 'OBJECT', required: ['index', 'description'], properties: { index: { type: 'INTEGER' }, description: S() } }),
    questionsForClient: LIST(S()),
  },
};

const clean = (s: string | null | undefined): string => (s ?? '').replace(/\s+/g, ' ').trim();

function dateRange(start: string | null, end: string | null): string {
  const a = clean(start);
  const b = clean(end);
  return a && b ? `${a} – ${b}` : a || b;
}

/** The CV as blocks: facts verbatim from extraction, prose from the rewrite. */
function assemble(facts: CvFacts, rw: Rewrite): Block[] {
  const blocks: Block[] = [];
  const contact = [clean(facts.contact.location), clean(facts.contact.phone), clean(facts.contact.email), ...facts.contact.links.map(clean)].filter(Boolean).join(' · ');
  blocks.push({ t: 'title', text: clean(facts.name), ...(contact ? { sub: contact } : {}) });
  if (clean(rw.headline)) blocks.push({ t: 'p', text: `**${clean(rw.headline)}**` });

  if (clean(rw.summary)) blocks.push({ t: 'h', level: 2, text: 'Summary' }, { t: 'p', text: clean(rw.summary) });

  const groups = rw.skillGroups.map((g) => ({ group: clean(g.group), items: g.items.map(clean).filter(Boolean) })).filter((g) => g.items.length > 0);
  if (groups.length > 0) {
    blocks.push({ t: 'h', level: 2, text: 'Skills' });
    for (const g of groups) blocks.push({ t: 'p', text: g.group ? `**${g.group}:** ${g.items.join(', ')}` : g.items.join(', ') });
  }

  if (facts.experience.length > 0) {
    blocks.push({ t: 'h', level: 2, text: 'Experience' });
    facts.experience.forEach((job, i) => {
      const where = [clean(job.employer), clean(job.location)].filter(Boolean).join(', ');
      blocks.push({ t: 'h', level: 3, text: [clean(job.title), where].filter(Boolean).join(' — ') });
      const dates = dateRange(job.start, job.end);
      if (dates) blocks.push({ t: 'p', text: dates });
      const rewritten = rw.experience.find((e) => e.index === i)?.bullets.map(clean).filter(Boolean) ?? [];
      for (const b of rewritten.length > 0 ? rewritten : job.bullets.map(clean).filter(Boolean)) blocks.push({ t: 'li', text: b });
    });
  }

  if (facts.projects.length > 0) {
    blocks.push({ t: 'h', level: 2, text: 'Projects' });
    facts.projects.forEach((p, i) => {
      const text = clean(rw.projects.find((x) => x.index === i)?.description) || clean(p.description);
      blocks.push({ t: 'li', text: `**${clean(p.name)}:** ${text}` });
    });
  }

  if (facts.education.length > 0) {
    blocks.push({ t: 'h', level: 2, text: 'Education' });
    for (const e of facts.education) blocks.push({ t: 'li', text: [`**${clean(e.degree)}**`, clean(e.institution), clean(e.year), clean(e.details)].filter(Boolean).join(', ') });
  }
  if (facts.certifications.length > 0) {
    blocks.push({ t: 'h', level: 2, text: 'Certifications' });
    for (const c of facts.certifications) blocks.push({ t: 'li', text: clean(c) });
  }
  if (facts.languages.length > 0) blocks.push({ t: 'h', level: 2, text: 'Languages' }, { t: 'p', text: facts.languages.map(clean).filter(Boolean).join(', ') });
  return blocks;
}

function blocksToMarkdown(blocks: Block[]): string {
  const out: string[] = [];
  for (const b of blocks) {
    if (b.t === 'title') out.push(`# ${b.text}`, b.sub ?? '', '');
    else if (b.t === 'h') out.push('', `${'#'.repeat(b.level)} ${b.text}`, '');
    else if (b.t === 'p') out.push(b.text, '');
    else if (b.t === 'li') out.push(`- ${b.text}`);
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}

interface ProseCheck {
  checks: QaCheck[];
  /** Exact items the model must remove or rephrase. */
  violations: string[];
}

/** Code checks on everything the model wrote. `source` is the client's own CV text. */
export function checkProse(rw: Rewrite, facts: CvFacts, source: Grounding, posting: Grounding, target: Target): ProseCheck {
  const prose = [rw.headline, rw.summary, ...rw.experience.flatMap((e) => e.bullets), ...rw.projects.map((p) => p.description)].join('\n');
  const skills = rw.skillGroups.flatMap((g) => g.items).map(clean).filter(Boolean);
  const violations: string[] = [];

  const badNumbers = source.ungroundedNumbers(prose);
  const badWords = source.ungroundedNumberWords(prose);
  const badSkills = skills.filter((s) => !source.hasTerm(s));
  const newTerms = source.ungroundedTerms(prose);
  // A new term that the job posting asks for is keyword stuffing; any other new term is suspicious.
  const stuffed = newTerms.filter((t) => posting.hasTerm(t) || target.keywords.some((k) => k.term.toLowerCase().includes(t.toLowerCase())));
  const otherNew = newTerms.filter((t) => !stuffed.includes(t));
  const placeholders = findPlaceholders(prose + '\n' + skills.join('\n'));
  const badIndex = rw.experience.filter((e) => e.index < 0 || e.index >= facts.experience.length).map((e) => e.index);
  const longRoles = rw.experience.filter((e) => e.bullets.length > 7).length;
  const firstPerson = /\b(I|my|me|we|our)\b/.test(prose.replace(/\bI\/O\b/g, ''));

  for (const n of badNumbers) violations.push(`the figure "${n}" is not in the CV`);
  for (const w of badWords) violations.push(`the quantity word "${w}" is not in the CV`);
  for (const s of badSkills) violations.push(`the skill "${s}" is not in the CV`);
  for (const t of stuffed) violations.push(`"${t}" comes from the job posting but is not in the CV`);
  for (const t of otherNew) violations.push(`"${t}" is not in the CV`);
  for (const p of placeholders) violations.push(`placeholder text "${p}"`);

  const list = (items: string[]): string => items.slice(0, 8).join(', ') + (items.length > 8 ? ` (+${items.length - 8} more)` : '');
  const checks: QaCheck[] = [
    check('cv_figures', 'Every figure comes from the client\'s CV', badNumbers.length === 0 && badWords.length === 0, 'block', badNumbers.length + badWords.length === 0 ? 'No number or quantity was added.' : `Not in the CV: ${list([...badNumbers, ...badWords])}.`),
    check('cv_skills', 'Every listed skill is in the client\'s CV', badSkills.length === 0, 'block', badSkills.length === 0 ? 'All skills are the client\'s own.' : `Not in the CV: ${list(badSkills)}.`),
    check('cv_no_stuffing', 'No keyword taken from the job posting without basis', stuffed.length === 0, 'block', stuffed.length === 0 ? 'Nothing was copied from the posting into the CV.' : `In the posting but not in the CV: ${list(stuffed)}.`),
    check('cv_new_terms', 'No new names, tools or organisations', otherNew.length === 0, 'block', otherNew.length === 0 ? 'No new proper noun appears.' : `Not in the CV: ${list(otherNew)}. If one of these is an ordinary word, release anyway; otherwise send the draft back.`),
    check('cv_placeholders', 'No placeholder text', placeholders.length === 0, 'block', placeholders.length === 0 ? 'None found.' : `Found: ${list(placeholders)}.`),
    check('cv_structure', 'Bullets refer to real roles', badIndex.length === 0, 'block', badIndex.length === 0 ? 'Every rewritten role exists in the CV.' : `Unknown role numbers: ${badIndex.join(', ')}.`),
    check('cv_summary_length', 'Summary is concise', wordCount(rw.summary) <= 90, 'warn', `${wordCount(rw.summary)} words (aim for 90 or fewer).`),
    check('cv_bullets', 'No role has more than 7 bullets', longRoles === 0, 'warn', longRoles === 0 ? 'OK.' : `${longRoles} role(s) have more than 7 bullets.`),
    check('cv_voice', 'Written without "I / my / we"', !firstPerson, 'warn', firstPerson ? 'First-person pronouns found.' : 'OK.'),
  ];
  return { checks, violations };
}

/** Which posting keywords appear in a text - counted by code. */
function coverage(target: Target, g: Grounding): { matched: string[]; missing: string[] } {
  const seen = new Set<string>();
  const matched: string[] = [];
  const missing: string[] = [];
  for (const k of target.keywords) {
    const term = clean(k.term);
    const key = term.toLowerCase();
    if (!term || seen.has(key)) continue;
    seen.add(key);
    (g.hasTerm(term) ? matched : missing).push(k.importance === 'must' ? `${term} (required)` : term);
  }
  return { matched, missing };
}

export async function cvWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs } = ctx;
  const postings = textOf(inputs, 'job_postings');
  const notes = textOf(inputs, 'notes');
  let cvText = textOf(inputs, 'cv_text', 'cv_file');
  const scans = partsOf(inputs, 'cv_file');
  const qa: QaCheck[] = [];

  // A PDF or image CV has to be read by the model; say so, because code cannot cross-check it.
  let transcribed = false;
  if (cvText.length < 200 && scans.length > 0) {
    cvText = await askText(core, {
      system: `${CAMELLIA_RULES}\nTranscribe the attached CV exactly as written, top to bottom, as plain text. Keep every name, date, number and line. Do not correct, summarise, reorder or add anything.`,
      parts: [...scans, { text: 'Transcribe this CV.' }],
      maxOutputTokens: 8192,
      temperature: 0,
    });
    transcribed = true;
  }

  if (cvText.trim().length < 200) {
    return { files: [], qa, ownerTasks: [], needsClient: true, questions: ['Your current CV or career notes (upload a PDF / Word file, or paste the text). What we received was empty or too short to work from.'], summary: 'No usable CV was supplied.' };
  }
  if (postings.trim().length < 80) {
    return { files: [], qa, ownerTasks: [], needsClient: true, questions: ['The text of at least one job posting you are applying for (paste the text itself; links cannot be opened).'], summary: 'No job posting was supplied.' };
  }

  const facts = await askJson<CvFacts>(core, {
    system: `${CAMELLIA_RULES}\nExtract the facts of this CV into the structure. Copy names, titles, employers, dates, degrees and certifications exactly as written. Use null or an empty list where the CV says nothing. Put anything ambiguous or missing (for example a role without dates) in "unclear" as a short question for the candidate.`,
    parts: [{ text: quoteUntrusted('CV', cvText, 40_000) }],
    schema: FACTS_SCHEMA,
    temperature: 0,
  });
  if (!clean(facts.name) || (facts.experience.length === 0 && facts.education.length === 0)) {
    return { files: [], qa, ownerTasks: [], needsClient: true, questions: ['A CV that shows your name and at least your work history or education. We could not find these in what you sent.'], summary: 'CV has no name, experience or education.' };
  }

  const target = await askJson<Target>(core, {
    system: `${CAMELLIA_RULES}\nFrom these job postings list the role titles and the concrete skills, tools, qualifications and domain terms an applicant-tracking system would screen for. Mark each "must" (stated as required) or "nice". Use the postings' own wording. At most 30 keywords. Do not list soft generalities such as "team player".`,
    parts: [{ text: quoteUntrusted('JOB_POSTINGS', postings, 30_000) }],
    schema: TARGET_SCHEMA,
    temperature: 0,
  });

  const source = new Grounding(cvText);
  const posting = new Grounding(postings);
  const before = coverage(target, source);

  const rewritePrompt = (violations: string[]): string =>
    [
      'Rewrite the prose of this CV for the target roles.',
      '',
      `FACTS (already extracted; you cannot change them and must not repeat employers, titles or dates):\n${JSON.stringify(facts)}`,
      '',
      `TARGET ROLES: ${target.roleTitles.join('; ')}`,
      `KEYWORDS THE CANDIDATE'S CV ALREADY SUPPORTS (use these where they truthfully fit): ${before.matched.join(', ') || 'none'}`,
      `KEYWORDS NOT IN THE CV (do NOT use these; instead ask about them in questionsForClient): ${before.missing.join(', ') || 'none'}`,
      notes ? `\nCANDIDATE'S NOTES:\n${quoteUntrusted('NOTES', notes, 4000)}` : '',
      '',
      'Rules:',
      '- headline: the candidate\'s professional title in up to 10 words, from the CV.',
      '- summary: 2-4 sentences, no "I".',
      '- experience: for each role (index = position in FACTS.experience, starting at 0) 2-6 bullets. Start each with a strong verb. Keep every figure exactly as the CV states it. If the CV gives no figure, write the achievement without one.',
      '- skillGroups: group the candidate\'s existing skills (for example Languages, Frameworks, Tools). Only skills present in the CV.',
      '- projects: one line each (index = position in FACTS.projects).',
      '- questionsForClient: what the candidate should tell us to strengthen the CV (missing dates, results they can quantify, whether they have the missing keywords).',
      violations.length > 0 ? `\nYOUR PREVIOUS DRAFT BROKE THE RULES. Remove or rephrase each of these, without replacing it by anything else that is not in the CV:\n${violations.map((v) => `- ${v}`).join('\n')}` : '',
      feedbackSection(ctx.feedback),
    ].join('\n');

  let rewrite = await askJson<Rewrite>(core, { system: CAMELLIA_RULES, parts: [{ text: rewritePrompt([]) }], schema: REWRITE_SCHEMA, temperature: 0.3 });
  let prose = checkProse(rewrite, facts, source, posting, target);
  let repaired = false;
  if (prose.violations.length > 0) {
    // One automatic correction, telling the model exactly what was unsupported.
    rewrite = await askJson<Rewrite>(core, { system: CAMELLIA_RULES, parts: [{ text: rewritePrompt(prose.violations.slice(0, 25)) }], schema: REWRITE_SCHEMA, temperature: 0.1 });
    prose = checkProse(rewrite, facts, source, posting, target);
    repaired = true;
  }
  qa.push(...prose.checks);

  const blocks = assemble(facts, rewrite);
  const finalText = blocksText(blocks);
  const after = coverage(target, new Grounding(finalText));
  const base = safeBaseName(`${facts.name}-CV`, 'CV');
  const cv = documentFiles(base, `${clean(facts.name)} - CV`, 'ATS-ready CV: single column, real text, standard headings.', blocks, { footer: clean(facts.name) });
  qa.push(pdfTextCheck(cv.unsupportedChars));
  qa.push(check('cv_length', 'Fits on two pages', cv.pages <= 2, 'warn', `${cv.pages} page(s).`));
  qa.push(check('cv_source', 'CV text was read by code', !transcribed, 'warn', transcribed ? 'The CV arrived as a PDF or image and was transcribed by the AI model. Compare names, dates and figures with the original before releasing.' : 'Read directly from the client\'s text / Word file.'));
  qa.push(check('cv_roles_kept', 'No role was dropped', true, 'block', `${facts.experience.length} role(s), ${facts.education.length} education entr(ies), ${facts.certifications.length} certification(s) carried over verbatim.`));

  const questions = [...new Set([...facts.unclear, ...rewrite.questionsForClient].map(clean).filter(Boolean))].slice(0, 12);
  const report = [
    `# Keyword and changes report`,
    '',
    `Prepared for ${clean(facts.name)} · order ${order.orderId}`,
    '',
    '## Target roles',
    '',
    ...(target.roleTitles.length > 0 ? target.roleTitles.map((r) => `- ${clean(r)}`) : ['- (none named in the postings)']),
    '',
    '## Keywords from the job postings',
    '',
    `Counted by matching each keyword against the text of your CV. ${after.matched.length} of ${after.matched.length + after.missing.length} appear in the new CV (${before.matched.length} appeared in the original).`,
    '',
    '### In your CV',
    '',
    ...(after.matched.length > 0 ? after.matched.map((k) => `- ${k}`) : ['- none']),
    '',
    '### Not in your CV',
    '',
    'These were not added, because your CV does not show them. If you do have this experience, tell us where and we will add it truthfully.',
    '',
    ...(after.missing.length > 0 ? after.missing.map((k) => `- ${k}`) : ['- none']),
    '',
    '## What was changed',
    '',
    '- Layout: one column, standard section headings, real text (no tables, images or text boxes), which applicant-tracking systems read reliably.',
    '- Summary and bullets were rewritten for the target roles. Employers, job titles, dates, education and certifications are exactly as in your original.',
    '- No figure, skill or tool was added that is not in your original CV.',
    '',
    '## Questions for you',
    '',
    ...(questions.length > 0 ? questions.map((q) => `- ${q}`) : ['- none']),
    '',
  ].join('\n');
  const reportFiles = documentFiles(`${base}-keyword-report`, 'Keyword and changes report', 'Which posting keywords your CV covers, what changed, and what to tell us.', report, { kind: 'report', withDocx: false });

  const blockers = qa.filter((q) => q.severity === 'block' && !q.passed);
  return {
    files: [...cv.files, ...reportFiles.files],
    qa,
    ownerTasks: [],
    questions,
    needsClient: false,
    summary: `CV for ${clean(facts.name)}: ${facts.experience.length} role(s); posting keywords covered ${after.matched.length}/${after.matched.length + after.missing.length}${repaired ? '; one automatic correction was needed' : ''}${blockers.length > 0 ? `; ${blockers.length} blocking check(s) still fail` : '; all blocking checks pass'}.`,
    previewMarkdown: blocksToMarkdown(blocks),
  };
}
