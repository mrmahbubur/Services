/**
 * mrs-core — S-MRS-11 Data Entry.
 *
 * The model never touches the client's data. It reads the header and a few sample
 * rows and proposes a PLAN (which source column feeds which target column, and
 * which fixed rules to apply). Code validates that plan and applies it to every
 * row, so the result is reproducible and no row can be invented, lost or reworded.
 *
 * Every row is accounted for:   source rows = output rows + duplicates + empty rows
 * Cells that break a rule are kept as they are and listed in an Issues sheet -
 * they are never silently "fixed".
 *
 * Scans and photos are different: the model has to transcribe them. That result is
 * always marked as needing a person to compare it with the source.
 */
import type { QaCheck } from '../../types.ts';
import type { OutFile, WorkerCtx, WorkerResult } from '../engine.ts';
import { askJson, quoteUntrusted } from '../gemini.ts';
import { partsOf, textOf } from '../inputs.ts';
import { parseDelimited, toCsv } from '../render/text.ts';
import { excelSerialToIso, renderXlsx } from '../render/xlsx.ts';
import type { Cell } from '../render/xlsx.ts';
import { CAMELLIA_RULES, check, documentFiles, feedbackSection, safeBaseName } from './common.ts';

export const TRANSFORMS = ['trim', 'collapse_spaces', 'upper', 'lower', 'title', 'digits_only', 'remove_currency'] as const;
export type Transform = (typeof TRANSFORMS)[number];
export type ColumnType = 'text' | 'number' | 'date' | 'email' | 'phone_bd';
export type DateOrder = 'DMY' | 'MDY' | 'YMD';

export interface PlanColumn {
  name: string;
  from: string[];
  join?: string | null;
  transforms: string[];
  type: string;
  required: boolean;
}

export interface Plan {
  headerRow: boolean;
  columns: PlanColumn[];
  dateOrder: string;
  dedupeKey: string[];
  notes: string[];
  questionsForClient: string[];
}

const PLAN_SCHEMA = {
  type: 'OBJECT',
  required: ['headerRow', 'columns', 'dateOrder', 'dedupeKey', 'notes', 'questionsForClient'],
  properties: {
    headerRow: { type: 'BOOLEAN' },
    columns: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        required: ['name', 'from', 'transforms', 'type', 'required'],
        properties: {
          name: { type: 'STRING' },
          from: { type: 'ARRAY', items: { type: 'STRING' } },
          join: { type: 'STRING', nullable: true },
          transforms: { type: 'ARRAY', items: { type: 'STRING', enum: [...TRANSFORMS] } },
          type: { type: 'STRING', enum: ['text', 'number', 'date', 'email', 'phone_bd'] },
          required: { type: 'BOOLEAN' },
        },
      },
    },
    dateOrder: { type: 'STRING', enum: ['DMY', 'MDY', 'YMD'] },
    dedupeKey: { type: 'ARRAY', items: { type: 'STRING' } },
    notes: { type: 'ARRAY', items: { type: 'STRING' } },
    questionsForClient: { type: 'ARRAY', items: { type: 'STRING' } },
  },
};

const MONTHS: Record<string, number> = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };

function validYmd(y: number, m: number, d: number): string | null {
  if (y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) return null;
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

const century = (yy: number): number => (yy < 100 ? (yy >= 50 ? 1900 + yy : 2000 + yy) : yy);

/** Parses one date value. Returns ISO text, or null when it is not a real date. `ambiguous` = day and month could be swapped. */
export function parseDate(raw: string, order: DateOrder): { iso: string | null; ambiguous: boolean } {
  const v = raw.trim();
  if (!v) return { iso: null, ambiguous: false };
  let m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T\s].*)?$/.exec(v);
  if (m) return { iso: validYmd(Number(m[1]), Number(m[2]), Number(m[3])), ambiguous: false };
  m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2}|\d{4})$/.exec(v);
  if (m) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    const y = century(Number(m[3]));
    if (order === 'YMD') return { iso: null, ambiguous: false };
    const iso = order === 'DMY' ? validYmd(y, b, a) : validYmd(y, a, b);
    return { iso, ambiguous: a <= 12 && b <= 12 && a !== b };
  }
  m = /^(\d{1,2})(?:st|nd|rd|th)?[\s-]+([A-Za-z]{3,9})\.?,?[\s-]+(\d{2}|\d{4})$/.exec(v);
  if (m) {
    const month = MONTHS[(m[2] ?? '').slice(0, 4).toLowerCase()] ?? MONTHS[(m[2] ?? '').slice(0, 3).toLowerCase()];
    return { iso: month ? validYmd(century(Number(m[3])), month, Number(m[1])) : null, ambiguous: false };
  }
  m = /^([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$/.exec(v);
  if (m) {
    const month = MONTHS[(m[1] ?? '').slice(0, 4).toLowerCase()] ?? MONTHS[(m[1] ?? '').slice(0, 3).toLowerCase()];
    return { iso: month ? validYmd(Number(m[3]), month, Number(m[2])) : null, ambiguous: false };
  }
  if (/^\d{5}(?:\.\d+)?$/.test(v)) {
    const n = Number(v);
    if (n >= 20000 && n <= 60000) return { iso: excelSerialToIso(Math.floor(n)), ambiguous: false }; // Excel day number
  }
  return { iso: null, ambiguous: false };
}

function applyTransform(value: string, t: Transform): string {
  switch (t) {
    case 'trim':
      return value.trim();
    case 'collapse_spaces':
      return value.replace(/\s+/g, ' ').trim();
    case 'upper':
      return value.toUpperCase();
    case 'lower':
      return value.toLowerCase();
    case 'title':
      return value.toLowerCase().replace(/(^|[\s\-'])\p{L}/gu, (c) => c.toUpperCase());
    case 'digits_only':
      return value.replace(/\D/g, '');
    case 'remove_currency':
      return value.replace(/[$€£৳]|\b(?:USD|BDT|Tk|TK|EUR|GBP)\b\.?/g, '').trim();
  }
}

/** Applies a column's type rule. `problem` set = the value breaks the rule and was left as it is. */
function applyType(value: string, type: ColumnType, order: DateOrder): { value: string; problem?: string; ambiguous?: boolean } {
  if (value === '') return { value };
  if (type === 'number') {
    const cleaned = value.replace(/[\s,]/g, '');
    return /^-?\d+(\.\d+)?$/.test(cleaned) ? { value: cleaned } : { value, problem: 'not a number' };
  }
  if (type === 'date') {
    const d = parseDate(value, order);
    return d.iso ? { value: d.iso, ambiguous: d.ambiguous } : { value, problem: 'not a valid date' };
  }
  if (type === 'email') {
    const v = value.toLowerCase();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? { value: v } : { value, problem: 'not a valid e-mail address' };
  }
  if (type === 'phone_bd') {
    const digits = value.replace(/\D/g, '').replace(/^(?:00)?880/, '0');
    return /^01[3-9]\d{8}$/.test(digits) ? { value: digits } : { value, problem: 'not a Bangladesh mobile number' };
  }
  return { value };
}

export interface Issue {
  row: number;
  column: string;
  value: string;
  problem: string;
}

export interface Applied {
  header: string[];
  rows: string[][];
  issues: Issue[];
  duplicates: { row: number; duplicateOf: number; values: string[] }[];
  emptyRows: number[];
  sourceRowCount: number;
  ambiguousDates: number;
  unusedSourceColumns: string[];
  planProblems: string[];
}

const fold = (s: string): string => s.trim().toLowerCase().replace(/\s+/g, ' ');

/** Applies a plan to a table. Pure and deterministic: same input, same output. */
export function applyPlan(table: string[][], plan: Plan): Applied {
  const planProblems: string[] = [];
  const headerRow = plan.headerRow !== false;
  const sourceHeader = headerRow ? (table[0] ?? []).map((h) => h.trim()) : (table[0] ?? []).map((_, i) => `Column ${i + 1}`);
  const data = headerRow ? table.slice(1) : table;
  const indexOf = (name: string): number => sourceHeader.findIndex((h) => fold(h) === fold(name));
  const order: DateOrder = plan.dateOrder === 'MDY' || plan.dateOrder === 'YMD' ? plan.dateOrder : 'DMY';

  const columns = plan.columns.filter((c) => c.name.trim());
  if (columns.length === 0) planProblems.push('the plan has no target columns');
  const seen = new Set<string>();
  const resolved = columns.map((c) => {
    if (seen.has(fold(c.name))) planProblems.push(`target column "${c.name}" appears twice`);
    seen.add(fold(c.name));
    const idx = c.from.map((f) => {
      const i = indexOf(f);
      if (i < 0) planProblems.push(`source column "${f}" (for "${c.name}") does not exist`);
      return i;
    });
    const transforms = c.transforms.filter((t): t is Transform => {
      const ok = (TRANSFORMS as readonly string[]).includes(t);
      if (!ok) planProblems.push(`unknown rule "${t}" on "${c.name}"`);
      return ok;
    });
    const type: ColumnType = ['number', 'date', 'email', 'phone_bd'].includes(c.type) ? (c.type as ColumnType) : 'text';
    if (c.required && idx.filter((i) => i >= 0).length === 0) planProblems.push(`required column "${c.name}" has no source`);
    return { name: c.name.trim(), idx: idx.filter((i) => i >= 0), join: c.join ?? ' ', transforms, type, required: c.required };
  });

  const used = new Set(resolved.flatMap((c) => c.idx));
  const unusedSourceColumns = sourceHeader.filter((h, i) => h && !used.has(i));
  const keyIdx = plan.dedupeKey.map((k) => {
    const i = resolved.findIndex((c) => fold(c.name) === fold(k));
    if (i < 0) planProblems.push(`duplicate key "${k}" is not a target column`);
    return i;
  }).filter((i) => i >= 0);

  const rows: string[][] = [];
  const issues: Issue[] = [];
  const duplicates: Applied['duplicates'] = [];
  const emptyRows: number[] = [];
  const firstSeen = new Map<string, number>();
  let ambiguousDates = 0;

  data.forEach((src, i) => {
    const rowNumber = i + (headerRow ? 2 : 1); // as the client sees it in a spreadsheet
    const pending: Issue[] = [];
    const out = resolved.map((c) => {
      let value = c.idx.map((k) => (src[k] ?? '').trim()).filter((v) => v !== '').join(c.join);
      for (const t of c.transforms) value = applyTransform(value, t);
      const typed = applyType(value, c.type, order);
      if (typed.ambiguous) ambiguousDates += 1;
      if (typed.problem) pending.push({ row: rowNumber, column: c.name, value: typed.value, problem: typed.problem });
      else if (c.required && typed.value === '') pending.push({ row: rowNumber, column: c.name, value: '', problem: 'required value is missing' });
      return typed.value;
    });
    if (out.every((v) => v === '')) return void emptyRows.push(rowNumber);
    if (keyIdx.length > 0) {
      const key = keyIdx.map((k) => fold(out[k] ?? '')).join('\u0001');
      if (key.replace(/\u0001/g, '') !== '') {
        const prior = firstSeen.get(key);
        if (prior !== undefined) return void duplicates.push({ row: rowNumber, duplicateOf: prior, values: out });
        firstSeen.set(key, rowNumber);
      }
    }
    rows.push(out);
    issues.push(...pending);
  });

  return { header: resolved.map((c) => c.name), rows, issues, duplicates, emptyRows, sourceRowCount: data.length, ambiguousDates, unusedSourceColumns, planProblems };
}

interface Transcript {
  header: string[];
  rows: string[][];
  uncertain: { row: number; column: string; note: string }[];
}

const TRANSCRIPT_SCHEMA = {
  type: 'OBJECT',
  required: ['header', 'rows', 'uncertain'],
  properties: {
    header: { type: 'ARRAY', items: { type: 'STRING' } },
    rows: { type: 'ARRAY', items: { type: 'ARRAY', items: { type: 'STRING' } } },
    uncertain: { type: 'ARRAY', items: { type: 'OBJECT', required: ['row', 'column', 'note'], properties: { row: { type: 'INTEGER' }, column: { type: 'STRING' }, note: { type: 'STRING' } } } },
  },
};

const MAX_ROWS = 50_000;

export async function dataWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs } = ctx;
  const targetText = textOf(inputs, 'target_columns');
  const rules = textOf(inputs, 'rules');
  const qa: QaCheck[] = [];

  let table: string[][] | undefined = inputs.tables.source_file;
  const pasted = inputs.answers.source_text ?? '';
  if (!table && pasted.trim()) table = parseDelimited(pasted);
  if (!table && inputs.fileText.source_file) table = parseDelimited(inputs.fileText.source_file);

  let uncertain: Transcript['uncertain'] = [];
  const scans = partsOf(inputs, 'source_file');
  const fromScan = !table && scans.length > 0;
  if (fromScan) {
    const t = await askJson<Transcript>(core, {
      system: `${CAMELLIA_RULES}\nTranscribe the table in the attached file. Give the header exactly as printed and every row in order, one string per cell. Copy values character for character; do not correct, complete or reformat them. For any cell you cannot read with confidence, still give your best reading and add an entry to "uncertain" (row = 1 for the first data row).`,
      parts: [...scans, { text: 'Transcribe every row of this table.' }],
      schema: TRANSCRIPT_SCHEMA,
      temperature: 0,
      maxOutputTokens: 16_000,
    });
    table = [t.header, ...t.rows];
    uncertain = t.uncertain;
  }

  if (!table || table.length < 2 || (table[0] ?? []).length === 0) {
    const problem = inputs.problems.join(' ');
    return { files: [], qa, ownerTasks: [], needsClient: true, questions: [`Your data as a CSV, Excel, JSON or text file with a header row (or a clear scan).${problem ? ` Problem with what was sent: ${problem}` : ''}`], summary: 'No readable table was supplied.' };
  }
  if (table.length - 1 > MAX_ROWS) {
    return { files: [], qa: [check('data_size', 'File fits the automatic pass', false, 'block', `${table.length - 1} rows; the automatic pass handles ${MAX_ROWS}.`)], ownerTasks: [`The file has ${table.length - 1} rows, more than the automatic pass handles. Split it or process it by hand. Nothing was dropped.`], questions: [], needsClient: false, summary: 'File too large; nothing was truncated.' };
  }

  const sample = table.slice(0, 16);
  const plan = await askJson<Plan>(core, {
    system: [
      CAMELLIA_RULES,
      'You are planning a data clean-up that software will carry out. You do not edit the data yourself.',
      'For each column the client wants, say which source column(s) feed it ("from", using the source header names exactly), how to join several (join), which rules to apply in order, its type and whether it is required.',
      `Rules available: ${TRANSFORMS.join(', ')}. Types: text, number, date (written out as YYYY-MM-DD), email, phone_bd (Bangladesh mobile, written as 01XXXXXXXXX).`,
      'dateOrder: how day and month are ordered in the source dates (DMY, MDY or YMD), judged from the samples and the client\'s rules.',
      'dedupeKey: the target columns that identify a duplicate row, or an empty list if the client did not ask for duplicates to be removed.',
      'If the client wants a column the source cannot supply, give it an empty "from" and ask about it in questionsForClient. Never invent a source column.',
    ].join('\n'),
    parts: [{ text: `COLUMNS THE CLIENT WANTS:\n${quoteUntrusted('TARGET', targetText, 4000)}\n\nCLIENT'S RULES:\n${quoteUntrusted('RULES', rules || '(none given)', 4000)}\n\nSOURCE HEADER AND FIRST ROWS (CSV):\n${quoteUntrusted('SAMPLE', toCsv(sample), 20_000)}${feedbackSection(ctx.feedback)}` }],
    schema: PLAN_SCHEMA,
    temperature: 0,
  });

  const applied = applyPlan(table, plan);
  const accounted = applied.rows.length + applied.duplicates.length + applied.emptyRows.length;
  const cells = Math.max(1, applied.rows.length * Math.max(1, applied.header.length));
  const issueRate = applied.issues.length / cells;
  const ungroundedTargets = applied.header.filter((h) => !fold(targetText).includes(fold(h)));

  qa.push(check('data_plan', 'The clean-up plan is valid', applied.planProblems.length === 0, 'block', applied.planProblems.length === 0 ? `${applied.header.length} target column(s).` : applied.planProblems.slice(0, 6).join('; ')));
  qa.push(check('data_accounting', 'Every source row is accounted for', accounted === applied.sourceRowCount, 'block', `${applied.sourceRowCount} source rows = ${applied.rows.length} delivered + ${applied.duplicates.length} duplicates + ${applied.emptyRows.length} empty.`));
  qa.push(check('data_columns', 'Columns are the ones the client asked for', ungroundedTargets.length === 0, 'warn', ungroundedTargets.length === 0 ? 'All target columns appear in the client\'s request.' : `Not found in the request: ${ungroundedTargets.slice(0, 8).join(', ')}.`));
  qa.push(check('data_issues', 'Few cells break a rule', issueRate <= 0.02, 'warn', `${applied.issues.length} of ${cells} cells (${(issueRate * 100).toFixed(1)}%) are listed on the Issues sheet, unchanged.`));
  qa.push(check('data_dates', 'Dates are unambiguous', applied.ambiguousDates === 0, 'warn', applied.ambiguousDates === 0 ? 'No date could be read two ways.' : `${applied.ambiguousDates} date(s) could be day-month or month-day; read as ${plan.dateOrder}. Confirm with the client.`));
  qa.push(check('data_unused', 'No source column was left out unnoticed', applied.unusedSourceColumns.length === 0, 'warn', applied.unusedSourceColumns.length === 0 ? 'Every source column is used.' : `Not carried over: ${applied.unusedSourceColumns.slice(0, 10).join(', ')}.`));
  if (fromScan) {
    qa.push(check('data_scan', 'Transcription compared with the source by a person', false, 'block', `The source was a scan or photo, read by the AI model (${uncertain.length} cell(s) marked uncertain). A person must compare the result with the original before it is delivered; then release with "release anyway".`));
  }

  const base = safeBaseName(`${order.orderId}-data`, 'data');
  const rulesSheet: Cell[][] = [['Target column', 'Source column(s)', 'Rules', 'Type', 'Required'], ...plan.columns.map((c) => [c.name, c.from.join(' + '), c.transforms.join(', '), c.type, c.required ? 'yes' : 'no'] as Cell[]), [], ['Date order read as', plan.dateOrder], ['Duplicate key', plan.dedupeKey.join(' + ') || '(duplicates not removed)']];
  const files: OutFile[] = [];
  const csv = Buffer.from('\uFEFF' + toCsv([applied.header, ...applied.rows]), 'utf8');
  files.push({ fileName: `${base}.csv`, mime: 'text/csv', bytes: csv, title: 'Cleaned data (CSV)', description: `${applied.rows.length} rows, ${applied.header.length} columns.`, kind: 'final' });
  const xlsx = renderXlsx([
    { name: 'Data', header: true, rows: [applied.header, ...applied.rows] },
    { name: 'Issues', header: true, rows: [['Source row', 'Column', 'Value', 'Problem'], ...applied.issues.map((i) => [i.row, i.column, i.value, i.problem] as Cell[]), ...uncertain.map((u) => [u.row + 1, u.column, '', `uncertain reading: ${u.note}`] as Cell[])] },
    { name: 'Duplicates removed', header: true, rows: [['Source row', 'Same as row', ...applied.header], ...applied.duplicates.map((d) => [d.row, d.duplicateOf, ...d.values] as Cell[])] },
    { name: 'Rules applied', header: true, rows: rulesSheet },
  ]);
  if (xlsx.length < 7_500_000) files.push({ fileName: `${base}.xlsx`, mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', bytes: xlsx, title: 'Cleaned data (Excel)', description: 'Data, Issues, Duplicates removed and Rules applied, one sheet each.', kind: 'final' });
  const json = Buffer.from(JSON.stringify(applied.rows.map((r) => Object.fromEntries(applied.header.map((h, i) => [h, r[i] ?? '']))), null, 1), 'utf8');
  if (json.length < 7_500_000) files.push({ fileName: `${base}.json`, mime: 'application/json', bytes: json, title: 'Cleaned data (JSON)', description: 'One object per row.', kind: 'final' });

  const questions = plan.questionsForClient.map((q) => q.trim()).filter(Boolean).slice(0, 10);
  const report = [
    '# Data clean-up report',
    '',
    `Order ${order.orderId}`,
    '',
    '## Row accounting',
    '',
    `| Source rows | Delivered | Duplicates removed | Empty rows dropped |`,
    `|---|---|---|---|`,
    `| ${applied.sourceRowCount} | ${applied.rows.length} | ${applied.duplicates.length} | ${applied.emptyRows.length} |`,
    '',
    '## Rules applied (by software, to every row)',
    '',
    '| Target column | From | Rules | Type |',
    '|---|---|---|---|',
    ...plan.columns.map((c) => `| ${c.name} | ${c.from.join(' + ') || '(no source)'} | ${c.transforms.join(', ') || '-'} | ${c.type} |`),
    '',
    `Dates were read as ${plan.dateOrder} and written as YYYY-MM-DD.`,
    '',
    '## Cells that break a rule',
    '',
    applied.issues.length === 0 ? 'None.' : `${applied.issues.length} cell(s) were left exactly as they were and are listed on the Issues sheet of the Excel file. The first few:`,
    '',
    ...applied.issues.slice(0, 15).map((i) => `- Row ${i.row}, ${i.column}: "${i.value}" — ${i.problem}`),
    '',
    '## Notes',
    '',
    ...(plan.notes.length > 0 ? plan.notes.slice(0, 10).map((n) => `- ${n}`) : ['- none']),
    ...(applied.unusedSourceColumns.length > 0 ? [`- Source columns not carried over: ${applied.unusedSourceColumns.join(', ')}`] : []),
    '',
    '## Questions for you',
    '',
    ...(questions.length > 0 ? questions.map((q) => `- ${q}`) : ['- none']),
    '',
  ].join('\n');
  const reportFiles = documentFiles(`${base}-report`, 'Data clean-up report', 'What was done to your data, row accounting, and anything that needs your attention.', report, { kind: 'report', withDocx: false });

  const preview = [`# Cleaned data — first rows`, '', `| ${applied.header.join(' | ')} |`, `|${applied.header.map(() => '---').join('|')}|`, ...applied.rows.slice(0, 40).map((r) => `| ${r.map((c) => c.replace(/\|/g, '/')).join(' | ')} |`), ''].join('\n');
  return { files: [...files, ...reportFiles.files], qa, ownerTasks: [], questions, needsClient: false, summary: `${applied.sourceRowCount} rows in, ${applied.rows.length} out (${applied.duplicates.length} duplicates, ${applied.emptyRows.length} empty); ${applied.issues.length} cell(s) flagged${fromScan ? '; SOURCE WAS A SCAN - compare by hand before release' : ''}.`, previewMarkdown: preview };
}
