/**
 * mrs-core — which worker handles which service (see `worker` in orders/catalog.ts).
 */
import { registerWorker } from '../engine.ts';
import { cvWorker } from './cv.ts';
import { dataWorker } from './data.ts';
import { learningWorker } from './learning.ts';
import { dnsWorker, gravatarAuditWorker, webAuditWorker } from './measured.ts';
import { packWorker } from './pack.ts';
import { writingWorker } from './writing.ts';

let done = false;

export function registerAllWorkers(): void {
  if (done) return;
  done = true;
  registerWorker('cv', cvWorker); //              S-MRS-06
  registerWorker('writing', writingWorker); //    S-MRS-02
  registerWorker('data', dataWorker); //          S-MRS-11
  registerWorker('learning', learningWorker); //  S-MRS-12
  registerWorker('gravatar_audit', gravatarAuditWorker); // S-GRV-01
  registerWorker('web_audit', webAuditWorker); // S-MRS-03
  registerWorker('dns', dnsWorker); //            S-MRS-07, S-GRV-03
  registerWorker('pack', packWorker); //          S-MRS-01, 04, 05, 08, 09, 10, S-GRV-02
}
