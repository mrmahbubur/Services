/**
 * mrs-core — S-MRS-12 Online Learning Resources.
 *
 * A course is only useful if what it promises is actually taught and tested. So the
 * structure is checked by code: every learning objective must be covered by a lesson
 * AND by at least one exercise or quiz question; every quiz question must have four
 * different options and a valid answer; every exercise must have a solution.
 *
 * Delivered as a learner book and a separate answer key (PDF + Word), plus a .zip of
 * Markdown files, one per lesson, which any LMS can import as pages.
 * NOTE: this does not produce a SCORM package.
 */
import type { QaCheck } from '../../types.ts';
import type { OutFile, WorkerCtx, WorkerResult } from '../engine.ts';
import { askJson, quoteUntrusted } from '../gemini.ts';
import { textOf } from '../inputs.ts';
import { zip } from '../render/zip.ts';
import { CAMELLIA_RULES, check, documentFiles, feedbackSection, fencesBalanced, findPlaceholders, pdfTextCheck, safeBaseName } from './common.ts';

interface Syllabus {
  title: string;
  objectives: { id: string; text: string }[];
  lessons: { n: number; title: string; objectiveIds: string[]; minutes: number; outline: string[] }[];
}

interface LessonBody {
  n: number;
  contentMarkdown: string;
  exercises: { prompt: string; solution: string; objectiveIds: string[] }[];
  quiz: { question: string; options: string[]; answerIndex: number; explanation: string; objectiveIds: string[] }[];
}

const STR = { type: 'STRING' };
const STRS = { type: 'ARRAY', items: STR };

const SYLLABUS_SCHEMA = {
  type: 'OBJECT',
  required: ['title', 'objectives', 'lessons'],
  properties: {
    title: STR,
    objectives: { type: 'ARRAY', items: { type: 'OBJECT', required: ['id', 'text'], properties: { id: STR, text: STR } } },
    lessons: { type: 'ARRAY', items: { type: 'OBJECT', required: ['n', 'title', 'objectiveIds', 'minutes', 'outline'], properties: { n: { type: 'INTEGER' }, title: STR, objectiveIds: STRS, minutes: { type: 'INTEGER' }, outline: STRS } } },
  },
};

const LESSONS_SCHEMA = {
  type: 'OBJECT',
  required: ['lessons'],
  properties: {
    lessons: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        required: ['n', 'contentMarkdown', 'exercises', 'quiz'],
        properties: {
          n: { type: 'INTEGER' },
          contentMarkdown: STR,
          exercises: { type: 'ARRAY', items: { type: 'OBJECT', required: ['prompt', 'solution', 'objectiveIds'], properties: { prompt: STR, solution: STR, objectiveIds: STRS } } },
          quiz: { type: 'ARRAY', items: { type: 'OBJECT', required: ['question', 'options', 'answerIndex', 'explanation', 'objectiveIds'], properties: { question: STR, options: STRS, answerIndex: { type: 'INTEGER' }, explanation: STR, objectiveIds: STRS } } },
        },
      },
    },
  },
};

const MAX_LESSONS = 12;

/** Structural checks, exported so they can be tested without a model. */
export function courseChecks(syllabus: Syllabus, bodies: LessonBody[], requestedLessons: number): QaCheck[] {
  const ids = syllabus.objectives.map((o) => o.id);
  const taught = new Set(syllabus.lessons.flatMap((l) => l.objectiveIds));
  const assessed = new Set(bodies.flatMap((b) => [...b.exercises.flatMap((e) => e.objectiveIds), ...b.quiz.flatMap((q) => q.objectiveIds)]));
  const untaught = ids.filter((id) => !taught.has(id));
  const unassessed = ids.filter((id) => !assessed.has(id));
  const unknownRefs = [...taught, ...assessed].filter((id) => !ids.includes(id));
  const missingBodies = syllabus.lessons.filter((l) => !bodies.some((b) => b.n === l.n && b.contentMarkdown.trim().length > 200)).map((l) => l.n);
  const badQuiz: string[] = [];
  const noSolution: string[] = [];
  for (const b of bodies) {
    b.quiz.forEach((q, i) => {
      const options = q.options.map((o) => o.trim().toLowerCase());
      if (options.length !== 4 || new Set(options).size !== 4 || options.some((o) => !o) || !Number.isInteger(q.answerIndex) || q.answerIndex < 0 || q.answerIndex > 3) badQuiz.push(`lesson ${b.n} question ${i + 1}`);
    });
    b.exercises.forEach((e, i) => {
      if (e.solution.trim().length < 10) noSolution.push(`lesson ${b.n} exercise ${i + 1}`);
    });
  }
  const text = bodies.map((b) => b.contentMarkdown).join('\n');
  const placeholders = findPlaceholders(text.replace(/```[\s\S]*?```/g, ''));
  const unbalanced = bodies.filter((b) => !fencesBalanced(b.contentMarkdown)).map((b) => b.n);
  const show = (xs: (string | number)[]): string => xs.slice(0, 8).join(', ');
  return [
    check('course_objectives_taught', 'Every objective is taught in a lesson', untaught.length === 0 && ids.length > 0, 'block', ids.length === 0 ? 'No objectives defined.' : untaught.length === 0 ? `${ids.length} objective(s).` : `Not taught: ${show(untaught)}.`),
    check('course_objectives_assessed', 'Every objective is tested by an exercise or quiz question', unassessed.length === 0 && ids.length > 0, 'block', unassessed.length === 0 ? 'All assessed.' : `Not assessed: ${show(unassessed)}.`),
    check('course_refs', 'Lessons refer only to defined objectives', unknownRefs.length === 0, 'block', unknownRefs.length === 0 ? 'OK.' : `Unknown objective ids: ${show([...new Set(unknownRefs)])}.`),
    check('course_lessons', 'Every planned lesson was written', missingBodies.length === 0, 'block', missingBodies.length === 0 ? `${syllabus.lessons.length} lesson(s).` : `Missing or too short: lesson ${show(missingBodies)}.`),
    check('course_quiz', 'Quiz questions are well-formed', badQuiz.length === 0, 'block', badQuiz.length === 0 ? 'Four distinct options and a valid answer each.' : `Malformed: ${show(badQuiz)}.`),
    check('course_solutions', 'Every exercise has a solution', noSolution.length === 0, 'block', noSolution.length === 0 ? 'OK.' : `No solution: ${show(noSolution)}.`),
    check('course_code', 'Code blocks are closed', unbalanced.length === 0, 'block', unbalanced.length === 0 ? 'OK.' : `Unclosed code block in lesson ${show(unbalanced)}.`),
    check('course_placeholders', 'No placeholder text', placeholders.length === 0, 'block', placeholders.length === 0 ? 'None.' : `Found: ${show(placeholders)}.`),
    check('course_size', 'Lesson count matches the request', syllabus.lessons.length === requestedLessons, 'warn', `${syllabus.lessons.length} written, ${requestedLessons} requested.`),
  ];
}

export async function learningWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs } = ctx;
  const a = inputs.answers;
  const requested = Math.min(MAX_LESSONS, Math.max(1, Number(/\d+/.exec(a.length ?? '')?.[0] ?? 6)));
  const brief = `SUBJECT: ${quoteUntrusted('SUBJECT', a.topic ?? '', 300)}\nLEVEL: ${a.level ?? ''}\nLEARNERS: ${quoteUntrusted('LEARNERS', a.audience ?? 'not specified', 400)}\nLENGTH: ${quoteUntrusted('LENGTH', a.length ?? '', 200)}\nBY THE END LEARNERS MUST BE ABLE TO:\n${quoteUntrusted('OUTCOMES', textOf(inputs, 'outcomes'), 4000)}\nCONSTRAINTS:\n${quoteUntrusted('CONSTRAINTS', textOf(inputs, 'constraints') || 'none', 3000)}`;

  const syllabus = await askJson<Syllabus>(core, {
    system: `${CAMELLIA_RULES}\nDesign a course syllabus. Write 3 to 8 measurable learning objectives with ids O1, O2, ... taken from what the client says learners must be able to do. Plan exactly ${requested} lesson(s), numbered from 1, each with a title, the objective ids it teaches, its length in minutes and a 3-6 point outline. Every objective must be taught in at least one lesson. Order lessons so each builds on the last.`,
    parts: [{ text: brief + feedbackSection(ctx.feedback) }],
    schema: SYLLABUS_SCHEMA,
    temperature: 0.3,
  });
  syllabus.lessons = syllabus.lessons.slice(0, MAX_LESSONS).sort((x, y) => x.n - y.n);

  const bodies: LessonBody[] = [];
  for (let i = 0; i < syllabus.lessons.length; i += 2) {
    const batch = syllabus.lessons.slice(i, i + 2);
    const out = await askJson<{ lessons: LessonBody[] }>(core, {
      system: [
        CAMELLIA_RULES,
        'Write complete lessons for the course below. For each lesson give:',
        '- contentMarkdown: the full teaching text in Markdown (explanations, worked examples, fenced code blocks where the subject needs them). Do not include a top-level heading; start with the explanation.',
        '- exercises: 2-4 practice tasks, each with a full worked solution and the objective ids it practises.',
        '- quiz: 3-5 multiple-choice questions, each with exactly 4 different options, answerIndex (0-3) of the correct one, a one-sentence explanation, and objective ids.',
        'Teach only what is correct and standard for the subject. If you are not sure a fact, command or API is right, leave it out.',
      ].join('\n'),
      parts: [{ text: `${brief}\n\nCOURSE: ${syllabus.title}\nOBJECTIVES:\n${syllabus.objectives.map((o) => `${o.id}: ${o.text}`).join('\n')}\n\nWRITE THESE LESSONS:\n${batch.map((l) => `Lesson ${l.n}: ${l.title} (${l.minutes} min; objectives ${l.objectiveIds.join(', ')})\n  - ${l.outline.join('\n  - ')}`).join('\n')}${feedbackSection(ctx.feedback)}` }],
      schema: LESSONS_SCHEMA,
      temperature: 0.3,
      maxOutputTokens: 16_000,
    });
    for (const b of out.lessons) if (batch.some((l) => l.n === b.n) && !bodies.some((x) => x.n === b.n)) bodies.push(b);
  }
  bodies.sort((x, y) => x.n - y.n);

  const qa = courseChecks(syllabus, bodies, requested);
  const letters = ['A', 'B', 'C', 'D'];
  const lessonMd = (l: Syllabus['lessons'][number], withAnswers: boolean): string => {
    const b = bodies.find((x) => x.n === l.n);
    const lines = [`## Lesson ${l.n}: ${l.title}`, '', `*${l.minutes} minutes · objectives ${l.objectiveIds.join(', ')}*`, ''];
    if (!withAnswers) lines.push(b?.contentMarkdown.trim() ?? '(not written)', '');
    if (b && b.exercises.length > 0) {
      lines.push('### Exercises', '');
      b.exercises.forEach((e, i) => {
        lines.push(`${i + 1}. ${e.prompt.trim()}`);
        if (withAnswers) lines.push('', `**Solution:** ${e.solution.trim()}`, '');
      });
      lines.push('');
    }
    if (b && b.quiz.length > 0) {
      lines.push('### Quiz', '');
      b.quiz.forEach((q, i) => {
        lines.push(`${i + 1}. ${q.question.trim()}`);
        q.options.forEach((o, k) => lines.push(`  - ${letters[k] ?? '?'}) ${o.trim()}`));
        if (withAnswers) lines.push('', `**Answer: ${letters[q.answerIndex] ?? '?'}** — ${q.explanation.trim()}`);
        lines.push('');
      });
    }
    return lines.join('\n');
  };
  const header = [`# ${syllabus.title}`, '', '## Learning objectives', '', ...syllabus.objectives.map((o) => `- **${o.id}** ${o.text}`), '', '## Course plan', '', '| Lesson | Title | Minutes | Objectives |', '|---|---|---|---|', ...syllabus.lessons.map((l) => `| ${l.n} | ${l.title} | ${l.minutes} | ${l.objectiveIds.join(', ')} |`), ''].join('\n');
  const learner = `${header}\n${syllabus.lessons.map((l) => lessonMd(l, false)).join('\n')}`;
  const key = `# ${syllabus.title} — answer key\n\nFor the instructor. Solutions to every exercise and the answer to every quiz question.\n\n${syllabus.lessons.map((l) => lessonMd(l, true)).join('\n')}`;

  const base = safeBaseName(syllabus.title, `${order.orderId}-course`);
  const book = documentFiles(base, syllabus.title.slice(0, 100), 'Learner book: objectives, lessons, exercises and quizzes.', learner, { footer: `M R S · ${order.orderId}` });
  const answers = documentFiles(`${base}-answer-key`, `${syllabus.title.slice(0, 80)} — answer key`, 'Instructor copy with all solutions.', key, { footer: `M R S · ${order.orderId} · instructor copy` });
  qa.push(pdfTextCheck(book.unsupportedChars + answers.unsupportedChars));
  const pack: OutFile = {
    fileName: `${base}-markdown.zip`,
    mime: 'application/zip',
    bytes: zip([{ name: '00-overview.md', data: header }, ...syllabus.lessons.map((l) => ({ name: `lesson-${String(l.n).padStart(2, '0')}.md`, data: lessonMd(l, false) })), { name: 'answer-key.md', data: key }]),
    title: 'Markdown package (.zip)',
    description: 'One Markdown file per lesson plus the answer key, for import into an LMS or a docs site.',
    kind: 'final',
  };
  const totalMinutes = syllabus.lessons.reduce((s, l) => s + (l.minutes || 0), 0);
  return { files: [...book.files, ...answers.files, pack], qa, ownerTasks: [], questions: [], needsClient: false, summary: `"${syllabus.title}": ${syllabus.lessons.length} lessons, ${totalMinutes} minutes, ${syllabus.objectives.length} objectives, ${bodies.reduce((s, b) => s + b.exercises.length, 0)} exercises, ${bodies.reduce((s, b) => s + b.quiz.length, 0)} quiz questions.`, previewMarkdown: learner };
}
