/**
 * mrs-core — real-world lookups the workers use.
 *
 * SECURITY: the server never opens an address chosen by a client. Every request
 * here goes to one of three fixed hosts (Gravatar, Google Public DNS, Google
 * PageSpeed). A client's domain or URL is only ever passed along as a query value
 * to those services, after it has been checked to be a public domain name. That
 * closes the door on requests to internal addresses (cloud metadata, localhost).
 */
import { createHash } from 'node:crypto';
import type { Core } from '../../core.ts';
import { isPublicDomain, isPublicHttpUrl } from '../../orders/catalog.ts';

export class LookupError extends Error {
  retryable: boolean;
  constructor(message: string, retryable: boolean) {
    super(message);
    this.retryable = retryable;
  }
}

async function getJson(core: Core, url: string, timeoutMs: number, headers: Record<string, string> = {}): Promise<{ status: number; json: unknown }> {
  let res: Response;
  try {
    res = await core.fetchFn(url, { headers: { Accept: 'application/json', ...headers }, redirect: 'error', signal: AbortSignal.timeout(timeoutMs) });
  } catch (err) {
    throw new LookupError(`could not reach ${new URL(url).host}: ${String((err as Error)?.message ?? err).slice(0, 100)}`, true);
  }
  let json: unknown = null;
  try {
    json = await res.json();
  } catch {
    /* a body that is not JSON is reported through the status code */
  }
  return { status: res.status, json };
}

// ---------------------------------------------------------------- Gravatar

export interface GravatarRecord {
  email: string;
  hash: string;
  hasProfile: boolean;
  hasAvatar: boolean;
  displayName?: string;
  profileUrl?: string;
  jobTitle?: string;
  company?: string;
  location?: string;
  description?: string;
  verifiedAccounts: { service: string; url: string }[];
}

export function gravatarHash(email: string): string {
  return createHash('sha256').update(email.trim().toLowerCase()).digest('hex');
}

/** Reads what Gravatar publicly shows for an e-mail address. */
export async function gravatarLookup(core: Core, email: string): Promise<GravatarRecord> {
  const hash = gravatarHash(email);
  const profile = await getJson(core, `https://api.gravatar.com/v3/profiles/${hash}`, 12_000);
  if (profile.status === 429) throw new LookupError('Gravatar rate limit reached', true);
  if (profile.status >= 500) throw new LookupError(`Gravatar answered ${profile.status}`, true);

  let hasAvatar = false;
  try {
    const avatar = await core.fetchFn(`https://gravatar.com/avatar/${hash}?d=404&s=80`, { method: 'GET', redirect: 'error', signal: AbortSignal.timeout(12_000) });
    hasAvatar = avatar.status === 200;
    await avatar.arrayBuffer().catch(() => undefined);
  } catch (err) {
    throw new LookupError(`could not reach gravatar.com: ${String((err as Error)?.message ?? err).slice(0, 100)}`, true);
  }

  const record: GravatarRecord = { email, hash, hasProfile: profile.status === 200, hasAvatar, verifiedAccounts: [] };
  if (profile.status === 200 && profile.json && typeof profile.json === 'object') {
    const p = profile.json as Record<string, unknown>;
    const str = (k: string): string | undefined => (typeof p[k] === 'string' && (p[k] as string).trim() ? (p[k] as string).trim().slice(0, 400) : undefined);
    const set = <K extends keyof GravatarRecord>(key: K, value: GravatarRecord[K] | undefined): void => {
      if (value !== undefined) record[key] = value;
    };
    set('displayName', str('display_name'));
    set('profileUrl', str('profile_url'));
    set('jobTitle', str('job_title'));
    set('company', str('company'));
    set('location', str('location'));
    set('description', str('description'));
    const accounts = Array.isArray(p.verified_accounts) ? (p.verified_accounts as Record<string, unknown>[]) : [];
    record.verifiedAccounts = accounts.filter((a) => a && typeof a === 'object').map((a) => ({ service: String(a.service_label ?? a.service_type ?? 'account').slice(0, 40), url: String(a.url ?? '').slice(0, 200) })).slice(0, 12);
  }
  return record;
}

// ---------------------------------------------------------------- DNS (Google Public DNS over HTTPS)

export interface DnsAnswer {
  type: string;
  /** NOERROR | NXDOMAIN | SERVFAIL | ... */
  status: string;
  records: string[];
}

const RCODE: Record<number, string> = { 0: 'NOERROR', 2: 'SERVFAIL', 3: 'NXDOMAIN', 5: 'REFUSED' };
const TYPE_NUMBER: Record<string, number> = { A: 1, NS: 2, CNAME: 5, MX: 15, TXT: 16, AAAA: 28, CAA: 257 };

export async function dnsQuery(core: Core, name: string, type: keyof typeof TYPE_NUMBER): Promise<DnsAnswer> {
  const host = name.trim().toLowerCase().replace(/\.$/, '');
  const bare = host.replace(/^_[a-z0-9-]+\./, ''); // _dmarc.example.com is checked as example.com
  if (!isPublicDomain(bare)) throw new LookupError(`"${name}" is not a public domain name`, false);
  const { status, json } = await getJson(core, `https://dns.google/resolve?name=${encodeURIComponent(host)}&type=${type}`, 10_000);
  if (status !== 200 || !json || typeof json !== 'object') throw new LookupError(`DNS lookup service answered ${status}`, true);
  const j = json as { Status?: number; Answer?: { type?: number; data?: string }[] };
  const wanted = TYPE_NUMBER[type];
  const records = (j.Answer ?? []).filter((a) => a.type === wanted && typeof a.data === 'string').map((a) => (a.data as string).replace(/^"|"$/g, '').replace(/" "/g, '').slice(0, 500));
  return { type, status: RCODE[j.Status ?? 0] ?? `RCODE ${j.Status}`, records };
}

export interface DnsSnapshot {
  domain: string;
  takenAt: string;
  exists: boolean;
  ns: string[];
  a: string[];
  aaaa: string[];
  cname: string[];
  mx: string[];
  txt: string[];
  spf: string[];
  dmarc: string[];
  wwwCname: string[];
  wwwA: string[];
}

export async function dnsSnapshot(core: Core, domain: string): Promise<DnsSnapshot> {
  const d = domain.trim().toLowerCase();
  const [ns, a, aaaa, cname, mx, txt, dmarc, wwwCname, wwwA] = await Promise.all([dnsQuery(core, d, 'NS'), dnsQuery(core, d, 'A'), dnsQuery(core, d, 'AAAA'), dnsQuery(core, d, 'CNAME'), dnsQuery(core, d, 'MX'), dnsQuery(core, d, 'TXT'), dnsQuery(core, `_dmarc.${d}`, 'TXT'), dnsQuery(core, `www.${d}`, 'CNAME'), dnsQuery(core, `www.${d}`, 'A')]);
  return {
    domain: d,
    takenAt: new Date().toISOString(),
    exists: a.status !== 'NXDOMAIN',
    ns: ns.records,
    a: a.records,
    aaaa: aaaa.records,
    cname: cname.records,
    mx: mx.records,
    txt: txt.records,
    spf: txt.records.filter((t) => /^v=spf1\b/i.test(t)),
    dmarc: dmarc.records.filter((t) => /^v=DMARC1\b/i.test(t)),
    wwwCname: wwwCname.records,
    wwwA: wwwA.records,
  };
}

const NS_PROVIDERS: [RegExp, string][] = [
  [/cloudflare\.com\.?$/i, 'Cloudflare'],
  [/domaincontrol\.com\.?$/i, 'GoDaddy'],
  [/registrar-servers\.com\.?$/i, 'Namecheap'],
  [/awsdns/i, 'Amazon Route 53'],
  [/googledomains\.com\.?$|google\.com\.?$/i, 'Google'],
  [/squarespacedns\.com\.?$/i, 'Squarespace'],
  [/hostinger|dns-parking\.com\.?$/i, 'Hostinger'],
  [/wordpress\.com\.?$/i, 'WordPress.com'],
  [/vercel-dns\.com\.?$/i, 'Vercel'],
  [/nsone\.net\.?$/i, 'NS1 / Netlify'],
  [/digitalocean\.com\.?$/i, 'DigitalOcean'],
];

export function dnsProvider(ns: string[]): string {
  for (const n of ns) for (const [re, label] of NS_PROVIDERS) if (re.test(n)) return label;
  return ns.length > 0 ? 'not recognised' : 'unknown';
}

export function mailProvider(mx: string[]): string {
  const all = mx.join(' ').toLowerCase();
  if (/google\.com|googlemail\.com/.test(all)) return 'Google Workspace';
  if (/zoho\./.test(all)) return 'Zoho Mail';
  if (/outlook\.com|protection\.outlook/.test(all)) return 'Microsoft 365';
  if (/mx\.cloudflare\.net/.test(all)) return 'Cloudflare Email Routing';
  return mx.length > 0 ? 'other' : 'none';
}

export interface DnsFinding {
  level: 'problem' | 'note';
  text: string;
}

/** Faults that can be read straight off the records. Decided by code, not by a model. */
export function dnsFindings(s: DnsSnapshot): DnsFinding[] {
  const out: DnsFinding[] = [];
  if (!s.exists) return [{ level: 'problem', text: 'The domain does not resolve at all (NXDOMAIN). It may be unregistered, expired, or its nameservers may not be set.' }];
  if (s.ns.length === 0) out.push({ level: 'problem', text: 'No nameserver (NS) records were returned.' });
  if (s.ns.length === 1) out.push({ level: 'note', text: 'Only one nameserver is published; two or more are expected.' });
  if (s.a.length === 0 && s.aaaa.length === 0 && s.cname.length === 0) out.push({ level: 'note', text: 'The bare domain has no A, AAAA or CNAME record, so it does not open a website.' });
  if (s.wwwA.length === 0 && s.wwwCname.length === 0) out.push({ level: 'note', text: 'www has no record, so the www address does not open a website.' });
  if (s.mx.length === 0) out.push({ level: 'note', text: 'No MX records: the domain cannot receive e-mail.' });
  if (s.spf.length > 1) out.push({ level: 'problem', text: `${s.spf.length} SPF records are published. Only one is allowed; with several, receivers treat SPF as failed.` });
  if (s.mx.length > 0 && s.spf.length === 0) out.push({ level: 'problem', text: 'The domain receives mail but has no SPF record, so its outgoing mail is more likely to be marked as spam.' });
  if (s.spf.length === 1 && /\+all\b/i.test(s.spf[0] ?? '')) out.push({ level: 'problem', text: 'The SPF record ends in "+all", which lets anyone send as this domain.' });
  if (s.mx.length > 0 && s.dmarc.length === 0) out.push({ level: 'problem', text: 'No DMARC record. Gmail and Yahoo require one from bulk senders, and without it spoofed mail is not rejected.' });
  if (s.dmarc.length > 1) out.push({ level: 'problem', text: 'More than one DMARC record is published; only one is allowed.' });
  return out;
}

// ---------------------------------------------------------------- PageSpeed Insights

export interface PageSpeedResult {
  strategy: 'mobile' | 'desktop';
  fetchedAt: string;
  /** 0-100, or null when Lighthouse could not score the category. */
  scores: { performance: number | null; seo: number | null; accessibility: number | null; bestPractices: number | null };
  metrics: { label: string; value: string }[];
  /** Failing audits, worst first. */
  opportunities: { id: string; title: string; detail: string; savingsMs: number }[];
  seoFailures: string[];
  /** Set when Google's test could not load the page. */
  error?: string;
}

const METRICS: [string, string][] = [
  ['largest-contentful-paint', 'Largest Contentful Paint'],
  ['cumulative-layout-shift', 'Cumulative Layout Shift'],
  ['total-blocking-time', 'Total Blocking Time'],
  ['first-contentful-paint', 'First Contentful Paint'],
  ['speed-index', 'Speed Index'],
];

export async function pageSpeed(core: Core, url: string, strategy: 'mobile' | 'desktop'): Promise<PageSpeedResult> {
  if (!isPublicHttpUrl(url)) throw new LookupError('the website address is not a public http(s) URL', false);
  const params = new URLSearchParams({ url, strategy });
  for (const c of ['performance', 'seo', 'accessibility', 'best-practices']) params.append('category', c);
  if (core.secrets.pagespeedApiKey) params.set('key', core.secrets.pagespeedApiKey);
  const { status, json } = await getJson(core, `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?${params.toString()}`, 75_000);
  const j = (json ?? {}) as { error?: { message?: string }; lighthouseResult?: { categories?: Record<string, { score?: number | null }>; audits?: Record<string, { title?: string; score?: number | null; displayValue?: string; scoreDisplayMode?: string; details?: { overallSavingsMs?: number } }>; categoryGroups?: unknown; runtimeError?: { message?: string } } };
  const empty: PageSpeedResult = { strategy, fetchedAt: new Date().toISOString(), scores: { performance: null, seo: null, accessibility: null, bestPractices: null }, metrics: [], opportunities: [], seoFailures: [] };
  if (status === 429) throw new LookupError('PageSpeed quota reached (add MRS_PAGESPEED_API_KEY for a higher limit)', true);
  if (status >= 500 && !j.error) throw new LookupError(`PageSpeed answered ${status}`, true);
  if (status !== 200 || !j.lighthouseResult) return { ...empty, error: (j.error?.message ?? `PageSpeed answered ${status}`).slice(0, 300) };

  const lr = j.lighthouseResult;
  if (lr.runtimeError?.message) return { ...empty, error: lr.runtimeError.message.slice(0, 300) };
  const score = (k: string): number | null => {
    const v = lr.categories?.[k]?.score;
    return typeof v === 'number' ? Math.round(v * 100) : null;
  };
  const audits = lr.audits ?? {};
  const metrics = METRICS.filter(([id]) => audits[id]?.displayValue).map(([id, label]) => ({ label, value: String(audits[id]?.displayValue).slice(0, 40) }));
  const opportunities = Object.entries(audits)
    .filter(([, a]) => typeof a.score === 'number' && a.score < 0.9 && (a.scoreDisplayMode === 'metricSavings' || a.scoreDisplayMode === 'opportunity' || (a.details?.overallSavingsMs ?? 0) > 0))
    .map(([id, a]) => ({ id, title: String(a.title ?? id).slice(0, 120), detail: String(a.displayValue ?? '').slice(0, 120), savingsMs: Math.round(a.details?.overallSavingsMs ?? 0) }))
    .sort((x, y) => y.savingsMs - x.savingsMs)
    .slice(0, 12);
  const seoIds = ['document-title', 'meta-description', 'http-status-code', 'link-text', 'crawlable-anchors', 'is-crawlable', 'robots-txt', 'image-alt', 'hreflang', 'canonical', 'viewport', 'font-size'];
  const seoFailures = seoIds.filter((id) => audits[id] && audits[id]?.score === 0).map((id) => String(audits[id]?.title ?? id).slice(0, 120));
  return { strategy, fetchedAt: new Date().toISOString(), scores: { performance: score('performance'), seo: score('seo'), accessibility: score('accessibility'), bestPractices: score('best-practices') }, metrics, opportunities, seoFailures };
}
