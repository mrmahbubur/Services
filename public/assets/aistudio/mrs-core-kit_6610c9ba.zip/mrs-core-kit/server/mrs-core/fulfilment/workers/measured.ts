/**
 * mrs-core — workers whose deliverable rests on MEASUREMENTS, not on the model:
 *
 *   S-GRV-01  Professional Identity Consultation   what Gravatar really shows
 *   S-MRS-03  Website Management                    Google PageSpeed, before and after
 *   S-MRS-07  Web Setup Services                    live DNS, before and after
 *   S-GRV-03  Custom Domain Mapping                 live DNS, before and after
 *
 * In each, code takes the measurements and writes the facts section of the report.
 * The model only adds explanation and next steps, and is told to use nothing but
 * those facts. The website and DNS services also need someone with access to the
 * client's accounts: that step is the owner's, and the pipeline measures again
 * afterwards so the report shows what actually changed.
 */
import type { Core } from '../../core.ts';
import type { QaCheck } from '../../types.ts';
import type { WorkerCtx, WorkerResult } from '../engine.ts';
import { askText, quoteUntrusted } from '../gemini.ts';
import { textOf } from '../inputs.ts';
import { CAMELLIA_RULES, check, documentFiles, feedbackSection, findPlaceholders, pdfTextCheck, safeBaseName, urlsIn } from './common.ts';
import type { DnsSnapshot, GravatarRecord, PageSpeedResult } from './lookups.ts';
import { dnsFindings, dnsProvider, dnsSnapshot, gravatarLookup, mailProvider, pageSpeed } from './lookups.ts';

async function saveState(core: Core, jobId: string, name: string, value: unknown): Promise<void> {
  await core.store.putBlob(`state_${jobId}_${name}`, Buffer.from(JSON.stringify(value), 'utf8'));
}
async function loadState<T>(core: Core, jobId: string, name: string): Promise<T | null> {
  const b = await core.store.getBlob(`state_${jobId}_${name}`);
  return b ? (JSON.parse(b.toString('utf8')) as T) : null;
}

/** Advice written by the model from facts gathered by code. */
async function advise(ctx: WorkerCtx, role: string, facts: string, ask: string): Promise<string> {
  const text = await askText(ctx.core, {
    system: `${CAMELLIA_RULES}\n${role}\nThe MEASURED FACTS were collected by software a moment ago and are correct. Base everything on them. Do not state any measurement, record, score or account that is not in them. Do not include links. Write Markdown using "### " sub-headings and short lists; no top-level heading.`,
    parts: [{ text: `MEASURED FACTS:\n${facts}\n\n${ask}${feedbackSection(ctx.feedback)}` }],
    temperature: 0.2,
    maxOutputTokens: 6000,
  });
  return text.replace(/^```(?:markdown|md)?\n([\s\S]*)\n```\s*$/i, '$1').trim();
}

/** Checks on the model's advice: no links of its own, no placeholders, not empty. */
function adviceChecks(advice: string, allowedUrls: string[]): QaCheck[] {
  const allowed = new Set(allowedUrls);
  const extra = urlsIn(advice).filter((u) => !allowed.has(u));
  const placeholders = findPlaceholders(advice);
  return [
    check('advice_links', 'No link was invented', extra.length === 0, 'block', extra.length === 0 ? 'The advice contains no links of its own.' : `Not from the measurements or the client: ${extra.slice(0, 5).join(', ')}.`),
    check('advice_placeholders', 'No placeholder text', placeholders.length === 0, 'block', placeholders.length === 0 ? 'None.' : `Found: ${placeholders.join(', ')}.`),
    check('advice_content', 'Advice has real content', advice.length >= 200, 'block', `${advice.length} characters.`),
  ];
}

// ================================================================ S-GRV-01

export async function gravatarAuditWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs } = ctx;
  const emails = [...new Set((inputs.answers.emails ?? '').split(/[\s,;]+/).map((e) => e.trim().toLowerCase()).filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)))].slice(0, 8);
  if (emails.length === 0) {
    return { files: [], qa: [], ownerTasks: [], needsClient: true, questions: ['The e-mail addresses to audit, one per line (we could not find a valid address in what you sent).'], summary: 'No valid e-mail address supplied.' };
  }
  const records: GravatarRecord[] = [];
  for (const email of emails) records.push(await gravatarLookup(core, email));

  const table = ['| E-mail | Profile | Avatar | Display name | Verified accounts |', '|---|---|---|---|---|', ...records.map((r) => `| ${r.email} | ${r.hasProfile ? 'yes' : 'no'} | ${r.hasAvatar ? 'yes' : 'no'} | ${r.displayName ?? '-'} | ${r.verifiedAccounts.map((a) => a.service).join(', ') || '-'} |`)].join('\n');
  const detail = records.map((r) => [`### ${r.email}`, '', `- SHA-256 hash: \`${r.hash}\``, `- Gravatar profile: ${r.hasProfile ? `yes (${r.profileUrl ?? 'public'})` : 'none found'}`, `- Avatar image: ${r.hasAvatar ? 'set' : 'not set (sites show a default picture)'}`, ...(r.jobTitle || r.company ? [`- Role shown: ${[r.jobTitle, r.company].filter(Boolean).join(', ')}`] : []), ...(r.location ? [`- Location shown: ${r.location}`] : []), ...(r.description ? [`- Bio shown: "${r.description.slice(0, 300)}"`] : []), ...(r.verifiedAccounts.length > 0 ? [`- Verified accounts: ${r.verifiedAccounts.map((a) => `${a.service} (${a.url})`).join('; ')}`] : ['- Verified accounts: none']), ''].join('\n')).join('\n');

  const role = textOf(inputs, 'role');
  const links = textOf(inputs, 'links');
  const advice = await advise(ctx, 'You are advising a professional on their Gravatar identity (the avatar and profile that follow an e-mail address across GitHub, WordPress, Slack and other sites).', `${table}\n\n${detail}\n\nHOW THE CLIENT WANTS TO BE SEEN:\n${quoteUntrusted('ROLE', role, 3000)}\n\nCLIENT'S OWN PUBLIC PROFILES:\n${quoteUntrusted('LINKS', links || 'none given', 1500)}`, 'Write: (1) "Findings" - what is inconsistent or missing across the addresses; (2) "Recommended profile" - a display name, a job title line and two bio options of at most 160 characters each, using only what the client told us about themselves; (3) "Accounts to verify" - which of the client\'s own profiles to connect; (4) "Step by step" - numbered actions in Gravatar, in the order to do them.');

  const known = [...urlsIn(links), ...records.flatMap((r) => [r.profileUrl ?? '', ...r.verifiedAccounts.map((a) => a.url)])].filter(Boolean);
  const qa = adviceChecks(advice, known);
  const withAvatar = records.filter((r) => r.hasAvatar).length;
  qa.push(check('gravatar_measured', 'Every address was looked up on Gravatar', true, 'block', `${records.length} address(es) checked at ${new Date().toISOString()}: ${records.filter((r) => r.hasProfile).length} with a profile, ${withAvatar} with an avatar.`));

  const md = ['# Professional identity audit', '', `Prepared for ${order.clientName} · order ${order.orderId}`, '', '## What Gravatar shows today', '', 'Looked up directly from Gravatar\'s public records.', '', table, '', detail, '## Recommendations', '', advice, ''].join('\n');
  const doc = documentFiles(safeBaseName(`${order.orderId}-identity-audit`, 'identity-audit'), 'Professional identity audit', 'What your e-mail addresses show on Gravatar today, and what to change.', md, { footer: `M R S · ${order.orderId}` });
  qa.push(pdfTextCheck(doc.unsupportedChars));
  return { files: doc.files, qa, ownerTasks: [], questions: [], needsClient: false, summary: `${records.length} address(es) audited on Gravatar: ${records.filter((r) => r.hasProfile).length} profile(s), ${withAvatar} avatar(s).`, previewMarkdown: md };
}

// ================================================================ S-MRS-03

function scoreRow(label: string, before: number | null | undefined, after?: number | null): string {
  const b = before ?? null;
  if (after === undefined) return `| ${label} | ${b ?? 'n/a'} |`;
  const delta = b !== null && after !== null ? `${after - b >= 0 ? '+' : ''}${after - b}` : 'n/a';
  return `| ${label} | ${b ?? 'n/a'} | ${after ?? 'n/a'} | ${delta} |`;
}

function speedFacts(r: PageSpeedResult): string {
  if (r.error) return `### ${r.strategy}\n\nGoogle's test could not load the page: ${r.error}\n`;
  return [`### ${r.strategy} (measured ${r.fetchedAt})`, '', '| Score (0-100) | Value |', '|---|---|', scoreRow('Performance', r.scores.performance), scoreRow('SEO', r.scores.seo), scoreRow('Accessibility', r.scores.accessibility), scoreRow('Best practices', r.scores.bestPractices), '', ...r.metrics.map((m) => `- ${m.label}: ${m.value}`), '', r.opportunities.length > 0 ? 'Largest opportunities:' : 'No significant opportunities reported.', ...r.opportunities.map((o) => `- ${o.title}${o.savingsMs ? ` (about ${o.savingsMs} ms)` : ''}${o.detail ? ` — ${o.detail}` : ''}`), ...(r.seoFailures.length > 0 ? ['', 'Failing SEO checks:', ...r.seoFailures.map((s) => `- ${s}`)] : []), ''].join('\n');
}

export async function webAuditWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs, job } = ctx;
  const url = (inputs.answers.site_url ?? '').trim();
  const platform = inputs.answers.platform ?? 'Other';
  const issues = textOf(inputs, 'issues');
  const base = safeBaseName(`${order.orderId}-website`, 'website');

  if (ctx.phase === 'prepare') {
    const mobile = await pageSpeed(core, url, 'mobile');
    const desktop = await pageSpeed(core, url, 'desktop');
    await saveState(core, job.id, 'before', { mobile, desktop });
    const facts = `Site: ${url}\nPlatform: ${platform}\n\n${speedFacts(mobile)}\n${speedFacts(desktop)}`;
    const unreachable = Boolean(mobile.error && desktop.error);
    const advice = unreachable ? 'Google\'s test could not load the site, so no plan can be drawn from measurements yet. Confirm the address is correct and the site is online.' : await advise(ctx, `You are planning maintenance for a ${platform} website.`, `${facts}\n\nWHAT THE CLIENT REPORTED:\n${quoteUntrusted('ISSUES', issues, 4000)}`, `Write: (1) "Diagnosis" - what the measurements say, in plain words; (2) "Fix plan" - a numbered list ordered by impact, each item naming the measured problem it addresses and how to do it on ${platform}; (3) "Client-reported issues" - how each will be investigated; (4) "Risks" - what could break and how it is guarded (backup first).`);
    const qa = unreachable ? [] : adviceChecks(advice, [url]);
    qa.push(check('web_measured', 'The site was measured by Google PageSpeed', !unreachable, 'block', unreachable ? `Could not be measured: ${mobile.error}` : `Mobile performance ${mobile.scores.performance ?? 'n/a'}, desktop ${desktop.scores.performance ?? 'n/a'}.`));
    const md = ['# Website audit and fix plan', '', `${url} · order ${order.orderId}`, '', '## Measurements', '', 'Taken with Google PageSpeed Insights (Lighthouse).', '', speedFacts(mobile), speedFacts(desktop), '## Plan', '', advice, ''].join('\n');
    const doc = documentFiles(`${base}-audit`, 'Website audit and fix plan', 'Measured speed and SEO results, and the plan to fix them.', md, { footer: `M R S · ${order.orderId}`, kind: 'report' });
    qa.push(pdfTextCheck(doc.unsupportedChars));
    const backupOk = (inputs.answers.backup_ok ?? '') === 'Yes';
    return {
      files: doc.files,
      qa,
      ownerTasks: [
        backupOk ? 'Take a full backup of the site (files and database) before changing anything.' : 'The client did NOT authorise a backup. Get that in writing, or agree which changes are safe without one, before touching the site.',
        'Arrange admin access with the client directly (never through the order form).',
        'Apply the fix plan in the attached audit, most impactful items first.',
        'Mark the hands-on step done with a short note of what you changed. The site is then measured again automatically.',
      ],
      questions: [],
      needsClient: false,
      summary: unreachable ? `PageSpeed could not load ${url}.` : `Measured ${url}: mobile performance ${mobile.scores.performance ?? 'n/a'}, desktop ${desktop.scores.performance ?? 'n/a'}; ${mobile.opportunities.length} opportunities.`,
    };
  }

  // finish: measure again and show what changed
  const before = await loadState<{ mobile: PageSpeedResult; desktop: PageSpeedResult }>(core, job.id, 'before');
  const mobile = await pageSpeed(core, url, 'mobile');
  const desktop = await pageSpeed(core, url, 'desktop');
  const compare = (label: string, b: PageSpeedResult | undefined, a: PageSpeedResult): string => [`### ${label}`, '', '| Score (0-100) | Before | After | Change |', '|---|---|---|---|', scoreRow('Performance', b?.scores.performance, a.scores.performance), scoreRow('SEO', b?.scores.seo, a.scores.seo), scoreRow('Accessibility', b?.scores.accessibility, a.scores.accessibility), scoreRow('Best practices', b?.scores.bestPractices, a.scores.bestPractices), '', ...a.metrics.map((m) => `- ${m.label} now: ${m.value}${b?.metrics.find((x) => x.label === m.label) ? ` (was ${b.metrics.find((x) => x.label === m.label)?.value})` : ''}`), ''].join('\n');
  const tables = `${compare('Mobile', before?.mobile, mobile)}\n${compare('Desktop', before?.desktop, desktop)}`;
  const advice = await advise(ctx, `You are writing the completion report for maintenance on a ${platform} website.`, `Site: ${url}\n\n${tables}\n\nWHAT THE TECHNICIAN DID (their own notes):\n${quoteUntrusted('WORK_DONE', ctx.ownerNotes, 4000)}`, 'Write: (1) "Work completed" - the technician\'s changes as a clear list, nothing added; (2) "Results" - what the before/after numbers show, stated honestly, including anything that did not improve; (3) "Keeping it fast" - a short maintenance checklist.');
  const qa = adviceChecks(advice, [url]);
  const measured = !mobile.error || !desktop.error;
  const dropped = [mobile, desktop].some((a, i) => {
    const b = i === 0 ? before?.mobile : before?.desktop;
    return typeof a.scores.performance === 'number' && typeof b?.scores.performance === 'number' && a.scores.performance < b.scores.performance - 5;
  });
  qa.push(check('web_remeasured', 'The site was measured again after the work', measured, 'block', measured ? `Mobile performance ${before?.mobile.scores.performance ?? 'n/a'} -> ${mobile.scores.performance ?? 'n/a'}; desktop ${before?.desktop.scores.performance ?? 'n/a'} -> ${desktop.scores.performance ?? 'n/a'}.` : `Could not be measured: ${mobile.error}`));
  qa.push(check('web_no_regression', 'Performance did not get worse', !dropped, 'warn', dropped ? 'A performance score fell by more than 5 points. Check before releasing.' : 'No score fell by more than 5 points.'));
  const md = ['# Website maintenance report', '', `${url} · order ${order.orderId}`, '', '## Before and after', '', 'Measured with Google PageSpeed Insights before the work and again after it.', '', tables, '## Report', '', advice, ''].join('\n');
  const doc = documentFiles(`${base}-report`, 'Website maintenance report', 'What was done and the measured before/after results.', md, { footer: `M R S · ${order.orderId}` });
  qa.push(pdfTextCheck(doc.unsupportedChars));
  return { files: doc.files, qa, ownerTasks: [], questions: [], needsClient: false, summary: `Re-measured ${url}: mobile ${before?.mobile.scores.performance ?? 'n/a'} -> ${mobile.scores.performance ?? 'n/a'}, desktop ${before?.desktop.scores.performance ?? 'n/a'} -> ${desktop.scores.performance ?? 'n/a'}.`, previewMarkdown: md };
}

// ================================================================ S-MRS-07 / S-GRV-03

function dnsTable(s: DnsSnapshot): string {
  const row = (k: string, v: string[]): string => `| ${k} | ${v.length > 0 ? v.join('; ').replace(/\|/g, '/') : '(none)'} |`;
  return ['| Record | Value |', '|---|---|', row('Nameservers (NS)', s.ns), row('A', s.a), row('AAAA', s.aaaa), row('CNAME', s.cname), row('www CNAME', s.wwwCname), row('www A', s.wwwA), row('MX', s.mx), row('SPF', s.spf), row('DMARC', s.dmarc), row('Other TXT', s.txt.filter((t) => !/^v=spf1\b/i.test(t)).map((t) => (t.length > 70 ? `${t.slice(0, 70)}…` : t)))].join('\n');
}

function dnsDiff(a: DnsSnapshot, b: DnsSnapshot): string[] {
  const keys: [keyof DnsSnapshot, string][] = [['ns', 'Nameservers'], ['a', 'A'], ['aaaa', 'AAAA'], ['cname', 'CNAME'], ['wwwCname', 'www CNAME'], ['wwwA', 'www A'], ['mx', 'MX'], ['spf', 'SPF'], ['dmarc', 'DMARC']];
  const out: string[] = [];
  for (const [k, label] of keys) {
    const before = [...(a[k] as string[])].sort().join('; ');
    const after = [...(b[k] as string[])].sort().join('; ');
    if (before !== after) out.push(`- ${label}: ${before || '(none)'} -> ${after || '(none)'}`);
  }
  return out;
}

export async function dnsWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs, job, service } = ctx;
  const gravatarMode = service.worker === 'dns:gravatar_domain';
  const domain = (inputs.answers.domain ?? '').trim().toLowerCase();
  const apex = domain.split('.').slice(-2).join('.');
  const goal = gravatarMode ? 'Make this domain or subdomain open the client\'s Gravatar profile.' : `${inputs.answers.goal ?? ''}. Hosting: ${inputs.answers.hosting || 'not stated'}. E-mail provider: ${inputs.answers.email_provider || 'not stated'}.`;
  const base = safeBaseName(`${order.orderId}-${domain}`, 'dns');
  const snap = await dnsSnapshot(core, domain);
  const zone = domain === apex ? snap : await dnsSnapshot(core, apex);
  const findings = dnsFindings(snap);
  const provider = dnsProvider(zone.ns);

  if (ctx.phase === 'prepare') {
    await saveState(core, job.id, 'before', snap);
    let profileLine = '';
    if (gravatarMode) {
      const g = await gravatarLookup(core, inputs.answers.gravatar_email ?? '');
      profileLine = `\nGravatar profile for the client's e-mail: ${g.hasProfile ? `exists (${g.profileUrl ?? 'public'})` : 'NOT FOUND - a profile must be created before a domain can point to it'}.`;
    }
    const facts = `Domain: ${domain}\nDNS is hosted at: ${provider} (nameservers: ${zone.ns.join(', ') || 'none'})\nE-mail currently handled by: ${mailProvider(snap.mx)}${profileLine}\n\n${dnsTable(snap)}\n\nFaults found by software:\n${findings.length > 0 ? findings.map((f) => `- [${f.level}] ${f.text}`).join('\n') : '- none'}`;
    const advice = await advise(ctx, 'You are planning DNS changes for a client\'s domain.', `${facts}\n\nGOAL: ${quoteUntrusted('GOAL', goal, 1500)}\nCLIENT NOTES: ${quoteUntrusted('NOTES', textOf(inputs, 'details') || 'none', 2000)}`, `Write: (1) "Current state" in plain words; (2) "Changes needed" - a numbered list of record changes for this goal. For values that the hosting, e-mail or Gravatar dashboard issues per account (verification codes, DKIM keys, target hostnames, IP addresses), do NOT guess: write "copy the value shown in <where>". (3) "Order of work" so that e-mail and the website are not interrupted; (4) "How we will verify" - which records will be re-checked afterwards.`);
    const qa = adviceChecks(advice, []);
    qa.push(check('dns_measured', 'Live DNS was read', snap.exists, 'block', snap.exists ? `${domain}: ${snap.ns.length || zone.ns.length} nameserver(s), ${snap.mx.length} MX, ${findings.filter((f) => f.level === 'problem').length} fault(s).` : `${domain} does not resolve (NXDOMAIN).`));
    const md = ['# DNS review and change plan', '', `${domain} · order ${order.orderId}`, '', '## Live DNS today', '', `Read from public DNS at ${snap.takenAt}. DNS hosted at: **${provider}**.`, '', dnsTable(snap), '', '## Faults found', '', ...(findings.length > 0 ? findings.map((f) => `- ${f.level === 'problem' ? '**Problem:**' : 'Note:'} ${f.text}`) : ['- None.']), '', '## Plan', '', advice, ''].join('\n');
    const doc = documentFiles(`${base}-plan`, 'DNS review and change plan', 'Your domain\'s live DNS, the faults found, and the changes to make.', md, { footer: `M R S · ${order.orderId}`, kind: 'report' });
    qa.push(pdfTextCheck(doc.unsupportedChars));
    return {
      files: doc.files,
      qa,
      ownerTasks: [
        `Arrange access to the DNS at ${provider} with the client directly (never through the order form).`,
        gravatarMode ? 'In the client\'s Gravatar account, start the custom-domain connection and copy the exact record it shows.' : 'Open the hosting / e-mail provider\'s dashboard and copy the exact record values it issues for this account.',
        'Export or screenshot the current records first, then make the changes in the attached plan.',
        'Mark the hands-on step done with a note of each record you added or changed. DNS is then read again automatically.',
      ],
      questions: [],
      needsClient: false,
      summary: `${domain}: DNS at ${provider}; ${findings.filter((f) => f.level === 'problem').length} fault(s) found.`,
    };
  }

  const before = await loadState<DnsSnapshot>(core, job.id, 'before');
  const changes = before ? dnsDiff(before, snap) : [];
  const stillBroken = findings.filter((f) => f.level === 'problem');
  const advice = await advise(ctx, 'You are writing the completion report for DNS work on a client\'s domain.', `Domain: ${domain}\n\nRECORDS THAT CHANGED (before -> after), read from public DNS:\n${changes.join('\n') || '- no change is visible yet'}\n\nLIVE DNS NOW:\n${dnsTable(snap)}\n\nFaults still present:\n${stillBroken.map((f) => `- ${f.text}`).join('\n') || '- none'}\n\nWHAT THE TECHNICIAN DID (their own notes):\n${quoteUntrusted('WORK_DONE', ctx.ownerNotes, 4000)}\n\nGOAL: ${quoteUntrusted('GOAL', goal, 1500)}`, 'Write: (1) "Work completed" from the technician\'s notes, nothing added; (2) "Verified" - what the live records now show; if a change the technician reports is not visible in DNS yet, say so plainly; (3) "What to expect" - propagation time and anything the client must still do.');
  const qa = adviceChecks(advice, []);
  qa.push(check('dns_changed', 'The reported changes are visible in live DNS', changes.length > 0, 'block', changes.length > 0 ? `${changes.length} record set(s) changed.` : 'Public DNS shows the same records as before the work. The change may not have been saved, or has not propagated. Check, then run this step again.'));
  qa.push(check('dns_faults', 'No DNS fault remains', stillBroken.length === 0, 'warn', stillBroken.length === 0 ? 'None.' : stillBroken.map((f) => f.text).join(' ').slice(0, 400)));
  const md = ['# DNS work report', '', `${domain} · order ${order.orderId}`, '', '## What changed', '', 'Compared from public DNS before the work and after it.', '', ...(changes.length > 0 ? changes : ['- No change is visible yet.']), '', '## Live DNS now', '', `Read at ${snap.takenAt}.`, '', dnsTable(snap), '', '## Report', '', advice, ''].join('\n');
  const doc = documentFiles(`${base}-report`, 'DNS work report', 'What was changed on your domain and what public DNS shows now.', md, { footer: `M R S · ${order.orderId}` });
  qa.push(pdfTextCheck(doc.unsupportedChars));
  return { files: doc.files, qa, ownerTasks: [], questions: [], needsClient: false, summary: `${domain}: ${changes.length} record set(s) changed; ${stillBroken.length} fault(s) remain.`, previewMarkdown: md };
}
