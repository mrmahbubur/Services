/**
 * mrs-core — services where a PERSON does the core work and Camellia prepares it,
 * then writes it up:
 *
 *   S-MRS-01 AI & Digital Productivity     design, prompts, test cases -> owner builds
 *   S-MRS-04 IT Support & Troubleshooting  diagnosis plan              -> owner runs the session
 *   S-MRS-05 App Store Publishing          listing text within limits  -> owner submits
 *   S-MRS-08 Peer & Subject Tutoring       lesson plan, practice set   -> owner teaches
 *   S-MRS-09 Graphics Design               creative brief, palette     -> owner designs
 *   S-MRS-10 Virtual Assistance            operating procedure, log    -> owner works
 *   S-GRV-02 Gravatar Profile Personalization   bio and link plan      -> applied in the account
 *
 * One table (SPECS) describes each: which sections to write, the hard rules that
 * code checks, and what the owner must do by hand. After the owner reports the work
 * done, a second pass writes the client's hand-over document from the owner's notes.
 */
import type { QaCheck } from '../../types.ts';
import type { WorkerCtx, WorkerResult } from '../engine.ts';
import { askJson, quoteUntrusted } from '../gemini.ts';
import type { JobInputs } from '../inputs.ts';
import { CAMELLIA_RULES, Grounding, check, documentFiles, feedbackSection, fencesBalanced, findPlaceholders, pdfTextCheck, safeBaseName, urlsIn } from './common.ts';

interface PackOutput {
  sections: { key: string; markdown: string }[];
  /** Short machine-checkable values, by name (see each spec). */
  fields: { name: string; value: string }[];
  questionsForClient: string[];
}

const PACK_SCHEMA = {
  type: 'OBJECT',
  required: ['sections', 'fields', 'questionsForClient'],
  properties: {
    sections: { type: 'ARRAY', items: { type: 'OBJECT', required: ['key', 'markdown'], properties: { key: { type: 'STRING' }, markdown: { type: 'STRING' } } } },
    fields: { type: 'ARRAY', items: { type: 'OBJECT', required: ['name', 'value'], properties: { name: { type: 'STRING' }, value: { type: 'STRING' } } } },
    questionsForClient: { type: 'ARRAY', items: { type: 'STRING' } },
  },
};

interface Spec {
  title: string;
  role: string;
  sections: { key: string; heading: string; write: string }[];
  /** Named short values the model must also return, with what each is. */
  fields?: { name: string; what: string }[];
  /** Extra rules for the model. */
  rules?: string[];
  /** Hard checks done by code. */
  validate?: (out: PackOutput, inputs: JobInputs, source: Grounding) => QaCheck[];
  ownerTasks: (inputs: JobInputs) => string[];
  /** Title and instruction for the hand-over document written after the owner's work. */
  finish: { title: string; write: string };
  /** Is the prepared pack itself something the client receives? */
  packIsDeliverable: boolean;
}

const field = (out: PackOutput, name: string): string => out.fields.find((f) => f.name === name)?.value.trim() ?? '';
const len = (s: string): number => [...s].length;

function limit(id: string, label: string, value: string, max: number): QaCheck {
  return check(id, `${label} is within ${max} characters`, value.length > 0 && len(value) <= max, 'block', value.length === 0 ? 'Missing.' : `${len(value)} of ${max} characters.`);
}

/** WCAG contrast ratio between two #RRGGBB colours. */
export function contrastRatio(hexA: string, hexB: string): number {
  const lum = (hex: string): number => {
    const v = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
    return 0.2126 * (v[0] ?? 0) + 0.7152 * (v[1] ?? 0) + 0.0722 * (v[2] ?? 0);
  };
  const [a, b] = [lum(hexA), lum(hexB)].sort((x, y) => y - x);
  return ((a ?? 0) + 0.05) / ((b ?? 0) + 0.05);
}

const DESTRUCTIVE = /\b(format\s+[a-z]:|rm\s+-rf|del\s+\/[sq]|rd\s+\/s|diskpart|clean\s+all|bcdedit|reg\s+delete|Set-ExecutionPolicy\s+Unrestricted|mkfs|dd\s+if=|chmod\s+-R\s+777|disable\s+(?:your\s+)?(?:antivirus|firewall|defender))\b/i;
const GRADED = /\b(assignment|homework|coursework|exam|quiz|graded|submission|deadline|take[- ]home)\b/i;
const STORE_HYPE = /\b(best|#\s?1|number one|top[- ]rated|free|sale|discount|award[- ]winning|guaranteed)\b/i;

const SPECS: Record<string, Spec> = {
  solution_design: {
    title: 'Automation design',
    role: 'You design workflow automations and AI prompt systems for a small business.',
    sections: [
      { key: 'current', heading: 'The process today', write: 'the manual process as numbered steps, exactly as the client described it' },
      { key: 'design', heading: 'Proposed automation', write: 'the automated flow as numbered steps: trigger, each action, which of the client\'s tools does it, and where a person approves' },
      { key: 'prompts', heading: 'Prompts', write: 'every AI prompt the design needs, each in its own fenced code block, ready to paste, with the inputs it expects' },
      { key: 'tests', heading: 'Test cases', write: 'a table of test inputs and the expected result, built from the client\'s sample input where one was given' },
      { key: 'limits', heading: 'Limits and risks', write: 'what the automation will not handle, what can go wrong, and what it depends on (accounts, API access, paid plans)' },
      { key: 'build', heading: 'Build checklist', write: 'the steps the builder follows, in order, with what to verify after each' },
    ],
    rules: ['Use only the tools the client named. If another tool is unavoidable, say so in "Limits and risks" and ask about it.'],
    validate: (out) => {
      const prompts = out.sections.find((s) => s.key === 'prompts')?.markdown ?? '';
      return [check('design_prompts', 'Prompts are given in full', (prompts.match(/```/g) ?? []).length >= 2 && fencesBalanced(prompts), 'block', 'Each prompt must be in its own code block.')];
    },
    ownerTasks: () => ['Review the design with the client and agree the scope.', 'Get access to the client\'s tools directly (never through the order form).', 'Build it following the build checklist, and run every test case.', 'Mark the hands-on step done with notes: what was built, where it lives, test results, anything that differs from the design.'],
    finish: { title: 'Automation hand-over', write: '(1) "What was built" from the builder\'s notes; (2) "How to use it" day to day; (3) "Test results" as the builder reported them; (4) "Maintenance" - what to check and when; (5) "Known limits".' },
    packIsDeliverable: true,
  },
  it_support: {
    title: 'Support session plan',
    role: 'You are a careful IT support technician preparing for a remote session.',
    sections: [
      { key: 'understanding', heading: 'The problem as reported', write: 'the symptom, the system and what changed, in the client\'s terms' },
      { key: 'causes', heading: 'Likely causes', write: 'the plausible causes ranked from most to least likely, each with the observation that would confirm it' },
      { key: 'before', heading: 'Before the session', write: 'safe things the client should do first: save work, note the exact error, back up important files, be at the computer. Nothing that changes system settings.' },
      { key: 'plan', heading: 'Session plan', write: 'the diagnostic steps the technician will take, in order, least invasive first, with a stop point before anything irreversible' },
      { key: 'safety', heading: 'Your control and privacy', write: 'that the client watches the whole session, can end it at any moment, should close private windows first, and is never asked for passwords in chat' },
    ],
    rules: ['Client-facing text must not contain commands that delete data, reformat, edit the registry or switch off security software.'],
    validate: (out) => {
      const text = out.sections.map((s) => s.markdown).join('\n');
      const hit = DESTRUCTIVE.exec(text);
      return [check('it_safe', 'No destructive instruction is given to the client', !hit, 'block', hit ? `Found "${hit[0]}". Remove it: risky steps belong to the technician, in the live session.` : 'None found.')];
    },
    ownerTasks: (i) => [`Schedule the session with the client (${i.answers.availability ?? 'see order'}), using ${i.answers.remote_tool ?? 'the agreed remote tool'}.`, 'Send the client the "Before the session" list.', 'Run the session; the client stays at the screen. Create a restore point before any system change.', 'Mark the hands-on step done with notes: the cause you found, exactly what you changed, and anything the client should watch for.'],
    finish: { title: 'Support session report', write: '(1) "What was wrong" - the cause the technician found; (2) "What was done" - each change, from the notes, nothing added; (3) "Keeping it healthy" - a short maintenance checklist that fits this problem; (4) "If it comes back" - what to note down and send us.' },
    packIsDeliverable: false,
  },
  store_listing: {
    title: 'App store listing',
    role: 'You prepare app store listings that comply with Google Play and Apple App Store metadata rules.',
    sections: [
      { key: 'listing', heading: 'Listing text', write: 'the final texts, each under its own sub-heading: Google Play title, short description and full description; App Store name, subtitle, promotional text, keywords and description. Only for the store(s) the client chose.' },
      { key: 'data_safety', heading: 'Data safety / App privacy answers', write: 'a table: each data type the client says the app collects or shares, the purpose, whether it is optional, whether it is shared with third parties. Use only what the client stated; list every unknown as a question.' },
      { key: 'rating', heading: 'Content rating and audience', write: 'the answers to give in the content-rating questionnaire and the target-audience setting, from what the client said about the app and its users' },
      { key: 'checklist', heading: 'Submission checklist', write: 'what must be ready before submitting: build, signing, icon and screenshot sizes, privacy policy link, test account for reviewers if the app has a login' },
    ],
    fields: [
      { name: 'play_title', what: 'Google Play title (max 30 characters). Empty if the client did not choose Google Play.' },
      { name: 'play_short', what: 'Google Play short description (max 80 characters).' },
      { name: 'play_full', what: 'Google Play full description (max 4000 characters).' },
      { name: 'ios_name', what: 'App Store name (max 30 characters). Empty if the client did not choose the App Store.' },
      { name: 'ios_subtitle', what: 'App Store subtitle (max 30 characters).' },
      { name: 'ios_promo', what: 'App Store promotional text (max 170 characters).' },
      { name: 'ios_keywords', what: 'App Store keywords, comma-separated, no spaces after commas (max 100 characters).' },
      { name: 'ios_description', what: 'App Store description (max 4000 characters).' },
    ],
    rules: ['Describe only features the client listed. No ranking or price claims ("best", "#1", "free"), no emojis, no competitor names, no ALL CAPS in titles.'],
    validate: (out, inputs, source) => {
      const store = inputs.answers.store ?? 'Both';
      const qa: QaCheck[] = [];
      const titles: string[] = [];
      if (store !== 'Apple App Store') {
        qa.push(limit('play_title', 'Google Play title', field(out, 'play_title'), 30), limit('play_short', 'Google Play short description', field(out, 'play_short'), 80), limit('play_full', 'Google Play full description', field(out, 'play_full'), 4000));
        titles.push(field(out, 'play_title'), field(out, 'play_short'));
      }
      if (store !== 'Google Play') {
        qa.push(limit('ios_name', 'App Store name', field(out, 'ios_name'), 30), limit('ios_subtitle', 'App Store subtitle', field(out, 'ios_subtitle'), 30), limit('ios_promo', 'App Store promotional text', field(out, 'ios_promo'), 170), limit('ios_keywords', 'App Store keywords', field(out, 'ios_keywords'), 100), limit('ios_description', 'App Store description', field(out, 'ios_description'), 4000));
        titles.push(field(out, 'ios_name'), field(out, 'ios_subtitle'));
      }
      const hype = titles.map((t) => STORE_HYPE.exec(t)?.[0]).filter(Boolean);
      const emoji = titles.some((t) => /\p{Extended_Pictographic}/u.test(t));
      qa.push(check('store_claims', 'Titles make no ranking or price claims', hype.length === 0 && !emoji, 'block', hype.length > 0 ? `Remove: ${hype.join(', ')}. Both stores reject such wording in titles.` : emoji ? 'Remove emojis from titles.' : 'OK.'));
      const figures = source.ungroundedNumbers([field(out, 'play_full'), field(out, 'ios_description')].join('\n')).filter((n) => n.length > 1);
      qa.push(check('store_figures', 'Figures come from the client', figures.length === 0, 'warn', figures.length === 0 ? 'No new figures.' : `Not stated by the client: ${figures.slice(0, 8).join(', ')}.`));
      const policy = inputs.answers.privacy_policy_url ?? '';
      qa.push(check('store_policy', 'Privacy policy link is the client\'s', urlsIn(out.sections.map((s) => s.markdown).join('\n')).every((u) => u === policy), 'block', 'The only link allowed in the listing pack is the client\'s privacy policy.'));
      return qa;
    },
    ownerTasks: (i) => [`Accept the client's invitation to their developer account (${i.answers.store ?? 'store'}); never ask for their password.`, 'Validate the release build (signing, target API level, 64-bit) in the console.', 'Enter the listing text and the data-safety answers from the attached pack; upload the client\'s icon and screenshots.', 'Submit for review. Mark the hands-on step done with the submission date, version and any warnings the console showed.'],
    finish: { title: 'Submission report', write: '(1) "Submitted" - what was submitted, where and when, from the notes; (2) "What happens next" - review timing and that approval is decided by Google / Apple; (3) "If it is rejected" - what to send us.' },
    packIsDeliverable: true,
  },
  tutoring: {
    title: 'Lesson plan',
    role: 'You are an experienced tutor preparing a one-to-one lesson. You teach methods; you never produce work for a student to hand in as their own.',
    sections: [
      { key: 'goals', heading: 'Session goals', write: '2-4 things the student will be able to do by the end, drawn from what they asked for' },
      { key: 'plan', heading: 'Lesson plan', write: 'a timed plan: check what they know, explain, worked example, guided practice, recap' },
      { key: 'examples', heading: 'Worked examples', write: '2-3 fully worked examples on the topic, on problems you invent that are similar to but NOT the same as anything in the student\'s material' },
      { key: 'practice', heading: 'Practice set', write: '5-8 practice problems of rising difficulty, invented by you, with answers in a separate list at the end' },
      { key: 'prep', heading: 'Before the session', write: 'what the student should have ready' },
    ],
    fields: [{ name: 'graded_work', what: '"yes" if the student\'s material looks like an assignment, exam or other graded work they must submit, otherwise "no".' }],
    rules: ['If the student\'s material is graded work, do not solve it or any part of it. Teach the method on different problems.'],
    validate: (out, inputs) => {
      const material = `${inputs.answers.material ?? ''}\n${inputs.answers.goals ?? ''}`;
      const flagged = field(out, 'graded_work').toLowerCase().startsWith('y') || GRADED.test(material);
      return [check('tutor_integrity', 'Material is not graded work', !flagged, 'warn', flagged ? 'The student\'s material looks like graded work. Teach the method on the practice problems; do not hand over a solution to submit.' : 'No sign of graded work.')];
    },
    ownerTasks: (i) => [`Confirm the time with the student (${i.answers.availability ?? 'see order'}) and send the meeting link.`, 'Teach the session from the attached plan. If the material is graded work, teach the method only.', 'Mark the hands-on step done with notes: what was covered, where the student struggled, what to practise next.'],
    finish: { title: 'Session notes', write: '(1) "What we covered" from the tutor\'s notes; (2) "What to practise" - specific next steps; (3) "Reference sheet" - a one-page summary of the key ideas from the session.' },
    packIsDeliverable: true,
  },
  creative_brief: {
    title: 'Creative brief',
    role: 'You are an art director writing a brief a designer can work from without asking again.',
    sections: [
      { key: 'objective', heading: 'Objective and audience', write: 'what the piece is for, who sees it and what it should make them think or do' },
      { key: 'directions', heading: 'Concept directions', write: 'three distinct visual directions, each in 3-4 lines: idea, shapes, mood' },
      { key: 'palette', heading: 'Colour palette', write: 'a table of colours with role (background, primary, accent, text) and HEX code, honouring colours the client asked for or ruled out' },
      { key: 'type', heading: 'Typography', write: 'a heading and body typeface pairing using widely available, freely licensed fonts, with fallbacks' },
      { key: 'copy', heading: 'Text on the design', write: 'the exact text to appear, character for character as the client gave it' },
      { key: 'exports', heading: 'Sizes and files', write: 'the sizes and file formats to deliver for this kind of item' },
    ],
    fields: [
      { name: 'background_hex', what: 'main background colour as #RRGGBB' },
      { name: 'text_hex', what: 'main text colour as #RRGGBB' },
      { name: 'palette_hex', what: 'all palette colours as #RRGGBB, comma-separated' },
    ],
    validate: (out, inputs) => {
      const hexes = field(out, 'palette_hex').split(/[\s,]+/).filter(Boolean);
      const bad = hexes.filter((h) => !/^#[0-9a-f]{6}$/i.test(h));
      const bg = field(out, 'background_hex');
      const fg = field(out, 'text_hex');
      const ok = /^#[0-9a-f]{6}$/i.test(bg) && /^#[0-9a-f]{6}$/i.test(fg);
      const ratio = ok ? contrastRatio(bg, fg) : 0;
      const brand = (inputs.answers.brand_name ?? '').trim();
      const all = out.sections.map((s) => s.markdown).join('\n');
      const copy = (inputs.answers.text_on_design ?? '').trim();
      const copySection = out.sections.find((s) => s.key === 'copy')?.markdown ?? '';
      return [
        check('brief_hex', 'Colour codes are valid', hexes.length >= 3 && bad.length === 0, 'block', bad.length > 0 ? `Not valid #RRGGBB: ${bad.join(', ')}.` : `${hexes.length} colour(s).`),
        check('brief_contrast', 'Text is readable on the background (WCAG AA)', ratio >= 4.5, 'warn', ok ? `Contrast ratio ${ratio.toFixed(2)}:1 (4.5:1 needed for body text).` : 'Background or text colour missing.'),
        check('brief_brand', 'Brand name is spelled exactly as given', brand === '' || all.includes(brand), 'block', brand === '' ? 'No brand name given.' : all.includes(brand) ? `"${brand}" appears exactly.` : `"${brand}" does not appear exactly as the client wrote it.`),
        check('brief_copy', 'Text on the design is exactly the client\'s', copy === '' || copySection.includes(copy), 'block', copy === '' ? 'Client gave no fixed text.' : copySection.includes(copy) ? 'Matches character for character.' : 'The text differs from what the client wrote.'),
      ];
    },
    ownerTasks: () => ['Design the artwork from the attached brief (three directions, then refine the one the client picks).', 'Upload the final files (vector source and web exports) to the order.', 'Mark the hands-on step done with a note of which direction was chosen and the files delivered.'],
    finish: { title: 'Design hand-over', write: '(1) "What you received" - the files and what each is for, from the designer\'s notes; (2) "Using your design" - sizes, clear space and colour codes from the brief; (3) "Rights" - that usage rights transfer on full payment.' },
    packIsDeliverable: false,
  },
  virtual_assistance: {
    title: 'Operating procedure',
    role: 'You write operating procedures for a virtual assistant taking over a client\'s routine tasks.',
    sections: [
      { key: 'tasks', heading: 'Task register', write: 'a table: task, how often, steps, tool, what "done" looks like. One row for every task the client listed, in their order.' },
      { key: 'rules', heading: 'Rules and approvals', write: 'what the assistant may do alone, what needs the client\'s approval first, and what is never done (payments, legal or financial commitments, sharing data)' },
      { key: 'escalation', heading: 'Escalation', write: 'when to stop and ask, whom, by which channel, and how fast a reply is expected' },
      { key: 'routine', heading: 'Daily and weekly routine', write: 'a checklist for each' },
      { key: 'log', heading: 'Work log format', write: 'the columns of the timestamped work log the client will see' },
    ],
    fields: [{ name: 'task_count', what: 'the number of rows in the task register' }],
    validate: (out, inputs) => {
      const listed = (inputs.answers.tasks ?? '').split(/\n|;/).map((t) => t.trim()).filter((t) => t.length > 3).length;
      const rows = Number(field(out, 'task_count')) || 0;
      const escalation = out.sections.find((s) => s.key === 'escalation')?.markdown ?? '';
      return [check('va_tasks', 'Every listed task is in the register', rows >= listed, 'warn', `${rows} row(s) for ${listed} task line(s) the client wrote.`), check('va_escalation', 'Escalation is defined', escalation.length > 80, 'block', 'There must be a clear rule for when to stop and ask.')];
    },
    ownerTasks: (i) => ['Agree the procedure with the client and get delegated access to each tool (delegate / invite, never a shared password).', `Work the agreed hours (${i.answers.hours ?? 'see order'}), keeping the work log.`, 'At the end of each block, mark the hands-on step done with the log: date, task, time spent, result, anything escalated.'],
    finish: { title: 'Work summary', write: '(1) "Completed" - a table of tasks done with dates and time, from the log, nothing added; (2) "Escalated or waiting on you"; (3) "Next block" - what is planned.' },
    packIsDeliverable: true,
  },
  gravatar_profile: {
    title: 'Gravatar profile plan',
    role: 'You write concise professional profiles.',
    sections: [
      { key: 'bio', heading: 'Bio options', write: 'three bios, each at most 160 characters, in the tone the client asked for, using only what they told us' },
      { key: 'card', heading: 'Profile card', write: 'display name, job title line, location line as they should appear' },
      { key: 'links', heading: 'Links, in order', write: 'the client\'s links in the order to show them, each with a short label, most important first' },
      { key: 'steps', heading: 'How to apply it', write: 'numbered steps in the Gravatar profile editor' },
    ],
    fields: [
      { name: 'bio_1', what: 'first bio (max 160 characters)' },
      { name: 'bio_2', what: 'second bio (max 160 characters)' },
      { name: 'bio_3', what: 'third bio (max 160 characters)' },
    ],
    validate: (out, inputs, source) => {
      const bios = [field(out, 'bio_1'), field(out, 'bio_2'), field(out, 'bio_3')];
      const figures = source.ungroundedNumbers(bios.join('\n'));
      const terms = source.ungroundedTerms(bios.join('\n'));
      const allowed = new Set(urlsIn(inputs.answers.links ?? ''));
      const foreign = urlsIn(out.sections.map((s) => s.markdown).join('\n')).filter((u) => !allowed.has(u));
      return [
        ...bios.map((b, i) => limit(`bio_${i + 1}`, `Bio ${i + 1}`, b, 160)),
        check('bio_figures', 'Bios state no figure the client did not give', figures.length === 0, 'block', figures.length === 0 ? 'None.' : `Not from the client: ${figures.join(', ')}.`),
        check('bio_terms', 'Bios name nothing the client did not mention', terms.length === 0, 'warn', terms.length === 0 ? 'None.' : `Not from the client (verify): ${terms.slice(0, 8).join(', ')}.`),
        check('bio_links', 'Only the client\'s own links are used', foreign.length === 0, 'block', foreign.length === 0 ? 'OK.' : `Not the client's: ${foreign.slice(0, 5).join(', ')}.`),
      ];
    },
    ownerTasks: () => ['Send the plan to the client to choose a bio, or apply it with them through a delegated Gravatar session (never their password).', 'Mark the hands-on step done with a note of which bio and links were applied.'],
    finish: { title: 'Profile update report', write: '(1) "Applied" - what was set on the profile, from the notes; (2) "Where it shows" - that sites using Gravatar pick it up within about an hour; (3) "Keeping it current".' },
    packIsDeliverable: true,
  },
};

interface FinishOutput {
  markdown: string;
}

export async function packWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, order, inputs, service } = ctx;
  const spec = SPECS[service.worker.split(':')[1] ?? ''];
  if (!spec) throw new Error(`no pack spec for ${service.worker}`);
  const answers = service.intake.filter((f) => f.type !== 'file' && inputs.answers[f.key]).map((f) => `${f.label}:\n${quoteUntrusted(f.key, inputs.answers[f.key] ?? '', 8000)}`).join('\n\n');
  const clientText = `${Object.values(inputs.answers).join('\n')}\n${order.details}`;
  const base = safeBaseName(`${order.orderId}-${spec.title}`, 'pack');

  if (ctx.phase === 'finish') {
    const out = await askJson<FinishOutput>(core, {
      system: `${CAMELLIA_RULES}\n${spec.role}\nWrite the client's hand-over document in Markdown ("## " headings, no top-level heading). Its factual content comes ONLY from the technician's notes and the client's original request. If the notes do not say something, do not state it.`,
      parts: [{ text: `SERVICE: ${service.name}\n\nCLIENT'S REQUEST:\n${answers}\n\nWHAT WAS DONE (the technician's own notes):\n${quoteUntrusted('WORK_DONE', ctx.ownerNotes, 4000)}\n\nWrite: ${spec.finish.write}${feedbackSection(ctx.feedback)}` }],
      schema: { type: 'OBJECT', required: ['markdown'], properties: { markdown: { type: 'STRING' } } },
      temperature: 0.2,
    });
    const md = `# ${spec.finish.title}\n\n${service.name} · order ${order.orderId}\n\n${out.markdown.trim()}\n`;
    const source = new Grounding(ctx.ownerNotes, clientText);
    const figures = source.ungroundedNumbers(out.markdown).filter((n) => n.length > 1);
    const placeholders = findPlaceholders(out.markdown.replace(/```[\s\S]*?```/g, ''));
    const allowed = new Set(urlsIn(`${ctx.ownerNotes}\n${clientText}`));
    const foreign = urlsIn(out.markdown).filter((u) => !allowed.has(u));
    const qa: QaCheck[] = [
      check('handover_content', 'Hand-over has real content', out.markdown.trim().length >= 200, 'block', `${out.markdown.trim().length} characters.`),
      check('handover_figures', 'Every figure comes from the notes', figures.length === 0, 'block', figures.length === 0 ? 'None added.' : `Not in the technician's notes or the request: ${figures.slice(0, 8).join(', ')}.`),
      check('handover_links', 'No link was invented', foreign.length === 0, 'block', foreign.length === 0 ? 'OK.' : `Not from the notes or the client: ${foreign.slice(0, 5).join(', ')}.`),
      check('handover_placeholders', 'No placeholder text', placeholders.length === 0, 'block', placeholders.length === 0 ? 'None.' : `Found: ${placeholders.join(', ')}.`),
    ];
    const doc = documentFiles(`${base}-report`, spec.finish.title, 'What was done, and what you need to know next.', md, { footer: `M R S · ${order.orderId}` });
    qa.push(pdfTextCheck(doc.unsupportedChars));
    return { files: doc.files, qa, ownerTasks: [], questions: [], needsClient: false, summary: `${spec.finish.title} written from the owner's notes.`, previewMarkdown: md };
  }

  const out = await askJson<PackOutput>(core, {
    system: [CAMELLIA_RULES, spec.role, ...(spec.rules ?? [])].join('\n'),
    parts: [
      {
        text: [
          `SERVICE: ${service.name}`,
          `WHAT THE CLIENT ASKED FOR:\n${quoteUntrusted('REQUEST', order.details, 6000)}`,
          `DETAILS THE CLIENT GAVE:\n${answers || '(none)'}`,
          '',
          'Write these sections. Return each under its key, as Markdown without a heading line:',
          ...spec.sections.map((s) => `- ${s.key}: ${s.write}`),
          ...(spec.fields ? ['', 'Also return these named fields:', ...spec.fields.map((f) => `- ${f.name}: ${f.what}`)] : ['', 'Return an empty "fields" list.']),
          '',
          'questionsForClient: anything you needed but were not told.',
          feedbackSection(ctx.feedback),
        ].join('\n'),
      },
    ],
    schema: PACK_SCHEMA,
    temperature: 0.3,
    maxOutputTokens: 12_000,
  });

  const source = new Grounding(clientText);
  const body = spec.sections.map((s) => out.sections.find((x) => x.key === s.key)?.markdown.trim() ?? '');
  const missing = spec.sections.filter((_, i) => (body[i] ?? '').length < 40).map((s) => s.heading);
  const all = body.join('\n');
  const placeholders = findPlaceholders(all.replace(/```[\s\S]*?```/g, ''));
  const qa: QaCheck[] = [
    check('pack_sections', 'Every section was written', missing.length === 0, 'block', missing.length === 0 ? `${spec.sections.length} section(s).` : `Missing or empty: ${missing.join(', ')}.`),
    check('pack_placeholders', 'No placeholder text', placeholders.length === 0, 'block', placeholders.length === 0 ? 'None.' : `Found: ${placeholders.join(', ')}.`),
    check('pack_code', 'Code blocks are closed', fencesBalanced(all), 'block', fencesBalanced(all) ? 'OK.' : 'An opening ``` has no closing ```.'),
    ...(spec.validate ? spec.validate(out, inputs, source) : []),
  ];
  const md = [`# ${spec.title}`, '', `${service.name} · order ${order.orderId}`, '', ...spec.sections.flatMap((s, i) => [`## ${s.heading}`, '', body[i] || '(not written)', '']), ''].join('\n');
  const doc = documentFiles(base, spec.title, spec.packIsDeliverable ? 'Prepared for your order.' : 'Working document for the technician.', md, { footer: `M R S · ${order.orderId}`, kind: spec.packIsDeliverable ? 'final' : 'report' });
  qa.push(pdfTextCheck(doc.unsupportedChars));
  const questions = out.questionsForClient.map((q) => q.trim()).filter(Boolean).slice(0, 10);
  return { files: doc.files, qa, ownerTasks: spec.ownerTasks(inputs), questions, needsClient: false, summary: `${spec.title} prepared (${spec.sections.length} sections); ${questions.length} question(s) for the client.`, previewMarkdown: md };
}
