/**
 * mrs-core — S-MRS-02 Technical Writing & Proofreading.
 *
 * Proofreading: the model corrects language only. Code then proves that it did not
 * touch the substance: every number, link and e-mail address is still there, code
 * samples are byte-for-byte identical, and the text was neither cut nor padded.
 *
 * Writing: an outline first, then the document. Code checks that every planned
 * section exists, that no link was invented, and lists figures and terms that are
 * not in the client's material for the reviewer.
 */
import type { QaCheck } from '../../types.ts';
import type { WorkerCtx, WorkerResult } from '../engine.ts';
import { askJson, askText, quoteUntrusted } from '../gemini.ts';
import { partsOf, textOf } from '../inputs.ts';
import { CAMELLIA_RULES, Grounding, check, documentFiles, feedbackSection, fencesBalanced, findPlaceholders, pdfTextCheck, safeBaseName, urlsIn, wordCount } from './common.ts';

const MAX_DOC_CHARS = 80_000;
const CHUNK_CHARS = 6000;
const SPLIT = '=====CHANGES=====';

interface Protected {
  text: string;
  blocks: string[];
}

/** Swaps code for tokens the model is told to leave alone. */
export function protectCode(text: string): Protected {
  const blocks: string[] = [];
  const stash = (m: string): string => {
    blocks.push(m);
    return `\u27E6CODE${blocks.length}\u27E7`;
  };
  const withoutFences = text.replace(/```[\s\S]*?```/g, stash);
  return { text: withoutFences.replace(/`[^`\n]+`/g, stash), blocks };
}

export function restoreCode(text: string, blocks: string[]): { text: string; missing: number[]; repeated: number[] } {
  const missing: number[] = [];
  const repeated: number[] = [];
  let out = text;
  blocks.forEach((block, i) => {
    const token = `\u27E6CODE${i + 1}\u27E7`;
    const count = out.split(token).length - 1;
    if (count === 0) missing.push(i + 1);
    if (count > 1) repeated.push(i + 1);
    out = out.split(token).join(block);
  });
  return { text: out, missing, repeated };
}

/** Splits at paragraph boundaries into pieces of at most `max` characters. */
export function chunkText(text: string, max = CHUNK_CHARS): string[] {
  const chunks: string[] = [];
  let current = '';
  for (const para of text.split(/\n{2,}/)) {
    if (current && current.length + para.length + 2 > max) {
      chunks.push(current);
      current = '';
    }
    if (para.length > max) {
      for (let i = 0; i < para.length; i += max) chunks.push(para.slice(i, i + max));
      continue;
    }
    current = current ? `${current}\n\n${para}` : para;
  }
  if (current) chunks.push(current);
  return chunks;
}

const numbersOf = (t: string): string[] => (t.match(/\d[\d,]*(?:\.\d+)?/g) ?? []).map((n) => n.replace(/,/g, '')).sort();
const emailsOf = (t: string): string[] => [...new Set(t.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g) ?? [])].sort();
const headingsOf = (t: string): number => (t.match(/^#{1,6}\s/gm) ?? []).length;

function diffLists(before: string[], after: string[]): { lost: string[]; added: string[] } {
  const a = [...before];
  const added: string[] = [];
  for (const x of after) {
    const i = a.indexOf(x);
    if (i >= 0) a.splice(i, 1);
    else added.push(x);
  }
  return { lost: a, added };
}

function changeRatio(before: string, after: string): number {
  const a = before.toLowerCase().match(/[\p{L}\p{N}']+/gu) ?? [];
  const b = after.toLowerCase().match(/[\p{L}\p{N}']+/gu) ?? [];
  const counts = new Map<string, number>();
  for (const w of a) counts.set(w, (counts.get(w) ?? 0) + 1);
  let shared = 0;
  for (const w of b) {
    const c = counts.get(w) ?? 0;
    if (c > 0) {
      shared += 1;
      counts.set(w, c - 1);
    }
  }
  return a.length + b.length === 0 ? 0 : 1 - (2 * shared) / (a.length + b.length);
}

/** The substance checks, exported so they can be tested without a model. */
export function proofreadChecks(original: string, corrected: string, missingTokens: number[], repeatedTokens: number[]): QaCheck[] {
  const nums = diffLists(numbersOf(original), numbersOf(corrected));
  const urls = diffLists(urlsIn(original).sort(), urlsIn(corrected).sort());
  const mails = diffLists(emailsOf(original), emailsOf(corrected));
  const ratio = original.length === 0 ? 1 : corrected.length / original.length;
  const changed = changeRatio(original, corrected);
  const show = (xs: string[]): string => xs.slice(0, 8).join(', ') + (xs.length > 8 ? ` (+${xs.length - 8} more)` : '');
  return [
    check('proof_numbers', 'Every number is unchanged', nums.lost.length === 0 && nums.added.length === 0, 'block', nums.lost.length + nums.added.length === 0 ? `${numbersOf(original).length} number(s) checked.` : `${nums.lost.length ? `Missing: ${show(nums.lost)}. ` : ''}${nums.added.length ? `New: ${show(nums.added)}.` : ''}`),
    check('proof_links', 'Every link and e-mail address is unchanged', urls.lost.length + urls.added.length + mails.lost.length + mails.added.length === 0, 'block', urls.lost.length + urls.added.length + mails.lost.length + mails.added.length === 0 ? 'All preserved.' : `Changed: ${show([...urls.lost, ...urls.added, ...mails.lost, ...mails.added])}.`),
    check('proof_code', 'Code samples are byte-for-byte identical', missingTokens.length === 0 && repeatedTokens.length === 0, 'block', missingTokens.length + repeatedTokens.length === 0 ? 'All code was kept exactly.' : `Code sample(s) ${[...missingTokens, ...repeatedTokens].join(', ')} were dropped or duplicated.`),
    check('proof_length', 'Nothing was cut or padded', ratio >= 0.8 && ratio <= 1.2, 'block', `Corrected text is ${Math.round(ratio * 100)}% of the original length.`),
    check('proof_headings', 'Same headings', headingsOf(original) === headingsOf(corrected), 'warn', `${headingsOf(original)} before, ${headingsOf(corrected)} after.`),
    check('proof_rewrite', 'Proofread, not rewritten', changed <= 0.35, 'warn', `About ${Math.round(changed * 100)}% of the words changed.`),
  ];
}

async function proofread(ctx: WorkerCtx, source: string, transcribed: boolean): Promise<WorkerResult> {
  const { core, order, inputs } = ctx;
  const style = textOf(inputs, 'style');
  const audience = textOf(inputs, 'audience');
  const prot = protectCode(source);
  const chunks = chunkText(prot.text);
  const corrected: string[] = [];
  const changes: string[] = [];

  for (const [i, chunk] of chunks.entries()) {
    const answer = await askText(core, {
      system: [
        CAMELLIA_RULES,
        'You are proofreading. Correct spelling, grammar, punctuation, word choice and unclear sentences. Keep the meaning, the structure, the order and the level of detail.',
        'Do NOT add or remove information. Do NOT change any number, name, link, heading text meaning or Markdown structure.',
        'Tokens such as \u27E6CODE3\u27E7 stand for code. Copy each token exactly once, exactly where it is.',
        `Output the corrected text only. Then, on its own line, write ${SPLIT} and list up to 6 notable corrections as "- before -> after (reason)".`,
        style ? `House style requested by the client: ${style.slice(0, 400)}` : '',
        audience ? `Readers: ${audience.slice(0, 200)}` : '',
      ]
        .filter(Boolean)
        .join('\n'),
      parts: [{ text: `Part ${i + 1} of ${chunks.length}.${feedbackSection(ctx.feedback)}\n\n${quoteUntrusted('DOCUMENT', chunk, CHUNK_CHARS + 200)}` }],
      temperature: 0.1,
      maxOutputTokens: 8192,
    });
    const [body, notes] = answer.split(SPLIT);
    corrected.push((body ?? '').replace(/<<<\/?DOCUMENT>>>/g, '').trim());
    for (const line of (notes ?? '').split('\n')) if (/^\s*[-*•]/.test(line)) changes.push(line.replace(/^\s*[-*•]\s*/, '').trim());
  }

  const joined = corrected.join('\n\n');
  const restored = restoreCode(joined, prot.blocks);
  const qa = proofreadChecks(source, restored.text, restored.missing, restored.repeated);
  qa.push(check('proof_source', 'Document text was read by code', !transcribed, 'warn', transcribed ? 'The document arrived as a PDF or image and was transcribed by the AI model before proofreading. Compare with the original.' : 'Read directly from the client\'s file.'));

  const base = safeBaseName(`${order.orderId}-proofread`, 'proofread');
  const doc = documentFiles(base, 'Proofread document', 'Your document with language corrections applied.', restored.text, { withMarkdown: true, footer: `M R S · ${order.orderId}` });
  qa.push(pdfTextCheck(doc.unsupportedChars));

  const report = ['# Proofreading report', '', `Order ${order.orderId} · ${wordCount(source)} words`, '', '## Checks run by software', '', ...qa.map((q) => `- ${q.passed ? 'PASS' : 'CHECK'} — ${q.label}: ${q.detail}`), '', '## Notable corrections', '', ...(changes.length > 0 ? changes.slice(0, 60).map((c) => `- ${c}`) : ['- (none listed)']), ''].join('\n');
  const reportFiles = documentFiles(`${base}-report`, 'Proofreading report', 'What was checked and the main corrections.', report, { kind: 'report', withDocx: false });

  const failed = qa.filter((q) => q.severity === 'block' && !q.passed);
  return { files: [...doc.files, ...reportFiles.files], qa, ownerTasks: [], questions: [], needsClient: false, summary: `Proofread ${wordCount(source)} words in ${chunks.length} part(s); ${changes.length} notable corrections; ${failed.length === 0 ? 'substance checks pass' : `${failed.length} substance check(s) FAILED`}.`, previewMarkdown: restored.text };
}

interface Outline {
  title: string;
  sections: { heading: string; purpose: string }[];
  questionsForClient: string[];
}

const OUTLINE_SCHEMA = {
  type: 'OBJECT',
  required: ['title', 'sections', 'questionsForClient'],
  properties: {
    title: { type: 'STRING' },
    sections: { type: 'ARRAY', items: { type: 'OBJECT', required: ['heading', 'purpose'], properties: { heading: { type: 'STRING' }, purpose: { type: 'STRING' } } } },
    questionsForClient: { type: 'ARRAY', items: { type: 'STRING' } },
  },
};

const norm = (s: string): string => s.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

async function write(ctx: WorkerCtx, source: string, transcribed: boolean): Promise<WorkerResult> {
  const { core, order, inputs } = ctx;
  const audience = textOf(inputs, 'audience');
  const style = textOf(inputs, 'style');
  const brief = `WHAT THE CLIENT ASKED FOR:\n${quoteUntrusted('REQUEST', order.details, 6000)}\n\nREADERS: ${audience.slice(0, 300)}\n${style ? `STYLE: ${style.slice(0, 400)}\n` : ''}\nSOURCE MATERIAL (the only facts you may use):\n${quoteUntrusted('SOURCE', source, 60_000)}`;

  const outline = await askJson<Outline>(core, {
    system: `${CAMELLIA_RULES}\nPlan a technical document. Give a title and 3 to 12 sections, each with one sentence on its purpose. Only plan sections the source material can actually fill. Put what is missing in questionsForClient.`,
    parts: [{ text: brief + feedbackSection(ctx.feedback) }],
    schema: OUTLINE_SCHEMA,
    temperature: 0.2,
  });
  const sections = outline.sections.filter((s) => s.heading.trim()).slice(0, 12);

  const draft = await askText(core, {
    system: [
      CAMELLIA_RULES,
      'Write the document in Markdown. Start with "# <title>". Use each planned section heading exactly as given, as a "## " heading, in the given order. You may add "### " sub-headings.',
      'Use numbered steps for procedures and fenced code blocks for code or commands taken from the source. Do not invent commands, options, endpoints, links or figures. Where the source is silent, leave the point out.',
      'Output the document only.',
    ].join('\n'),
    parts: [{ text: `${brief}\n\nTITLE: ${outline.title}\nSECTIONS:\n${sections.map((s, i) => `${i + 1}. ${s.heading} — ${s.purpose}`).join('\n')}${feedbackSection(ctx.feedback)}` }],
    temperature: 0.3,
    maxOutputTokens: 16_000,
  });
  const md = draft.replace(/^```(?:markdown|md)?\n([\s\S]*)\n```\s*$/i, '$1').trim() + '\n';

  const grounding = new Grounding(source, order.details);
  const headings = (md.match(/^#{1,3}\s+.+$/gm) ?? []).map((h) => norm(h.replace(/^#+\s+/, '')));
  const missingSections = sections.filter((s) => !headings.includes(norm(s.heading))).map((s) => s.heading);
  const sourceUrls = new Set(urlsIn(`${source}\n${order.details}`));
  const newUrls = urlsIn(md).filter((u) => !sourceUrls.has(u));
  const placeholders = findPlaceholders(md.replace(/```[\s\S]*?```/g, ''));
  const prose = md.replace(/```[\s\S]*?```/g, '');
  const figures = grounding.ungroundedNumbers(prose).filter((n) => n.replace(/\D/g, '').length >= 2);
  const terms = grounding.ungroundedTerms(prose);
  const show = (xs: string[]): string => xs.slice(0, 10).join(', ') + (xs.length > 10 ? ` (+${xs.length - 10} more)` : '');

  const qa: QaCheck[] = [
    check('doc_sections', 'Every planned section was written', missingSections.length === 0, 'block', missingSections.length === 0 ? `${sections.length} section(s).` : `Missing: ${show(missingSections)}.`),
    check('doc_links', 'No link was invented', newUrls.length === 0, 'block', newUrls.length === 0 ? 'Every link comes from the client\'s material.' : `Not in the source: ${show(newUrls)}.`),
    check('doc_code', 'Code blocks are closed', fencesBalanced(md), 'block', fencesBalanced(md) ? 'OK.' : 'An opening ``` has no closing ```.'),
    check('doc_placeholders', 'No placeholder text', placeholders.length === 0, 'block', placeholders.length === 0 ? 'None.' : `Found: ${show(placeholders)}.`),
    check('doc_length', 'Document has real content', wordCount(md) >= 150, 'block', `${wordCount(md)} words.`),
    check('doc_figures', 'Figures come from the source', figures.length === 0, 'warn', figures.length === 0 ? 'No new figures.' : `Not in the source (verify): ${show(figures)}.`),
    check('doc_terms', 'Names and technical terms come from the source', terms.length === 0, 'warn', terms.length === 0 ? 'No new terms.' : `Not in the source (verify): ${show(terms)}.`),
    check('doc_source', 'Source material was read by code', !transcribed, 'warn', transcribed ? 'The source arrived as a PDF or image and was transcribed by the AI model.' : 'Read directly from the client\'s file.'),
  ];

  const base = safeBaseName(outline.title, `${order.orderId}-document`);
  const doc = documentFiles(base, outline.title.slice(0, 100) || 'Document', 'Your document as PDF, editable Word file and Markdown source.', md, { withMarkdown: true, footer: `M R S · ${order.orderId}` });
  qa.push(pdfTextCheck(doc.unsupportedChars));
  const questions = outline.questionsForClient.map((q) => q.trim()).filter(Boolean).slice(0, 12);
  return { files: doc.files, qa, ownerTasks: [], questions, needsClient: false, summary: `Wrote "${outline.title}" (${wordCount(md)} words, ${sections.length} sections). ${questions.length} open question(s) for the client.`, previewMarkdown: md };
}

export async function writingWorker(ctx: WorkerCtx): Promise<WorkerResult> {
  const { core, inputs } = ctx;
  let source = textOf(inputs, 'source_text', 'document');
  const scans = partsOf(inputs, 'document');
  let transcribed = false;
  if (source.trim().length < 100 && scans.length > 0) {
    source = await askText(core, { system: `${CAMELLIA_RULES}\nTranscribe the attached document exactly, as Markdown. Keep every word, number, heading and code sample. Do not correct or summarise.`, parts: [...scans, { text: 'Transcribe this document.' }], temperature: 0, maxOutputTokens: 16_000 });
    transcribed = true;
  }
  if (source.trim().length < 100) {
    return { files: [], qa: [], ownerTasks: [], needsClient: true, questions: ['The document to proofread, or the notes / specifications to write from (upload a file or paste the text).'], summary: 'No source material supplied.' };
  }
  if (source.length > MAX_DOC_CHARS) {
    return {
      files: [],
      qa: [check('doc_size', 'Document fits the automatic pass', false, 'block', `${source.length.toLocaleString('en-US')} characters; the automatic pass handles ${MAX_DOC_CHARS.toLocaleString('en-US')}.`)],
      ownerTasks: [`The document is ${source.length.toLocaleString('en-US')} characters, more than one automatic pass handles. Split it into parts (or do it by hand) and upload the result. Nothing was shortened.`],
      questions: [],
      needsClient: false,
      summary: 'Document too long for the automatic pass; nothing was truncated.',
    };
  }
  return /proofread/i.test(inputs.answers.task ?? '') ? proofread(ctx, source, transcribed) : write(ctx, source, transcribed);
}
