/**
 * mrs-core — small HTTP helpers. Written to work on Express 4 and Express 5 alike:
 * every handler is wrapped (Express 4 does not catch rejected promises) and only
 * plain ":id" route parameters are used.
 */
import express from 'express';
import type { ErrorRequestHandler, NextFunction, Request, RequestHandler, Response } from 'express';
import type { Core } from './core.ts';
import { HttpError } from './util.ts';

export const jsonSmall: RequestHandler = express.json({ limit: '256kb' });
/** For requests that carry a base64 file (5 MB file -> about 6.7 MB of JSON). */
export const jsonUpload: RequestHandler = express.json({ limit: '8mb' });
/** Exact bytes, for requests whose signature must be checked before parsing. */
export const rawBody: RequestHandler = express.raw({ type: () => true, limit: '2mb' });

export type Handler = (req: Request, res: Response) => Promise<void> | void;

export function wrap(fn: Handler): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve()
      .then(() => fn(req, res))
      .catch(next);
  };
}

export function param(req: Request, name: string): string {
  const v = (req.params as Record<string, unknown>)[name];
  const s = Array.isArray(v) ? String(v[0] ?? '') : String(v ?? '');
  return s.slice(0, 200);
}

export function query(req: Request, name: string): string {
  const v = (req.query as Record<string, unknown>)[name];
  return typeof v === 'string' ? v.slice(0, 200) : '';
}

export function body(req: Request): Record<string, unknown> {
  const b: unknown = req.body;
  return b && typeof b === 'object' && !Buffer.isBuffer(b) && !Array.isArray(b) ? (b as Record<string, unknown>) : {};
}

/** API answers are never cached and never sniffed. */
export const apiHeaders: RequestHandler = (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
};

/** Sends a stored file as a download that a browser will not render or run. */
export function sendDownload(res: Response, fileName: string, mime: string, bytes: Buffer): void {
  const ascii = fileName.replace(/[^\w.\- ()]/g, '_').slice(0, 100) || 'file';
  const inert = /^(application\/pdf|image\/(png|jpeg|webp)|text\/(plain|csv|markdown)|application\/(json|zip)|application\/vnd\.openxmlformats-officedocument\.[a-z.]+)$/.test(mime) ? mime : 'application/octet-stream';
  res.setHeader('Content-Type', inert.startsWith('text/') ? `${inert}; charset=utf-8` : inert);
  res.setHeader('Content-Disposition', `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(fileName.slice(0, 100))}`);
  res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
  res.setHeader('Content-Length', String(bytes.length));
  res.status(200).end(bytes);
}

/** Turns errors into JSON. Details of unexpected errors are logged, never sent. */
export function errorHandler(core: Core): ErrorRequestHandler {
  return (err: unknown, req: Request, res: Response, _next: NextFunction): void => {
    if (res.headersSent) return;
    res.setHeader('Cache-Control', 'no-store');
    if (err instanceof HttpError) {
      res.status(err.status).json({ success: false, error: err.message, code: err.code, ...(err.extra ?? {}) });
      return;
    }
    const e = err as { type?: string; status?: number; statusCode?: number; message?: string };
    if (e?.type === 'entity.too.large') {
      res.status(413).json({ success: false, error: 'Request is too large.', code: 'too_large' });
      return;
    }
    if (e?.type === 'entity.parse.failed' || e?.type === 'encoding.unsupported' || e?.type === 'charset.unsupported') {
      res.status(400).json({ success: false, error: 'Request body is not valid JSON.', code: 'bad_json' });
      return;
    }
    core.log('error', 'unhandled error', { path: req.path, method: req.method, error: String(e?.message ?? err).slice(0, 500) });
    res.status(500).json({ success: false, error: 'Something went wrong on our side. Please try again.', code: 'internal' });
  };
}
