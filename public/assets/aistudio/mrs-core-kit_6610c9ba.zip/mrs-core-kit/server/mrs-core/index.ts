/**
 * mrs-core — entry point.
 *
 *   import express from 'express';
 *   import { installMrsCore, FirestoreStore } from './mrs-core/index.ts';
 *
 *   const app = express();
 *   installMrsCore(app, { store: new FirestoreStore(getFirestore(firebaseApp, databaseId)) });
 *   // ... the rest of the existing app (static files, other routes) AFTER this line
 *
 * Call it BEFORE app.use(express.json()) and before any existing /api routes:
 *  - signed collector requests need the exact request bytes, and
 *  - routes registered first win, so the earlier handlers for the same paths
 *    (which had no sign-in check) can no longer be reached.
 */
import type { Express } from 'express';
import type { BuildOptions } from './compose.ts';
import { buildCore } from './compose.ts';
import { checkSecrets, loadSecrets } from './config.ts';
import type { Core } from './core.ts';
import { GeminiClient } from './fulfilment/gemini.ts';
import { buildRouter } from './routes.ts';
import { getTrustedProxyHops, setAllowedOrigins, setTrustedProxyHops } from './security/auth.ts';
import { runTick } from './tick.ts';
import type { TickResult } from './tick.ts';

export { FirestoreStore } from './store/firestore.ts';
export { FileStore, MemoryStore } from './store/store.ts';
export type { Store } from './store/store.ts';
export { hashSecret } from './security/auth.ts';
export { buildCore } from './compose.ts';
export type { Core } from './core.ts';

export interface Installed {
  core: Core;
  /** Runs one tick in-process (for hosts that have their own scheduler). */
  tick: (budgetMs?: number) => Promise<TickResult>;
}

export function installMrsCore(app: Express, options: BuildOptions = {}): Installed {
  const env = options.env ?? process.env;
  const secrets = options.secrets ?? loadSecrets(env);
  const model = options.model ?? new GeminiClient(secrets.geminiApiKey, secrets.geminiModel, options.fetchFn);
  const core = buildCore({ ...options, env, secrets, model });

  const hops = Number(env.MRS_TRUSTED_PROXY_HOPS ?? 1);
  setTrustedProxyHops(hops);
  setAllowedOrigins(String(env.MRS_ALLOWED_ORIGINS ?? '').split(',').filter((v) => v.trim() !== ''));

  app.disable('x-powered-by');
  // Makes req.secure and req.ip correct behind the platform's proxy.
  if (app.get('trust proxy') === false || app.get('trust proxy') === undefined) app.set('trust proxy', getTrustedProxyHops());
  app.use(buildRouter(core));

  for (const p of checkSecrets(secrets)) core.log(p.level === 'error' ? 'error' : 'warn', `configuration: ${p.key} - ${p.message}`);
  if (!core.store.durable) {
    core.log(secrets.production ? 'error' : 'warn', 'storage is IN MEMORY: orders, payments and files are lost on every restart. Pass a FirestoreStore to installMrsCore() before going live.');
  }
  return { core, tick: (budgetMs = 40_000) => runTick(core, budgetMs) };
}
