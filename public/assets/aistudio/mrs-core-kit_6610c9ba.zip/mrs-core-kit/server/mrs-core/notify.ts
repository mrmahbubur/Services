/**
 * mrs-core — telling the owner that something needs them.
 *
 * Every alert is stored (so it shows in the admin queue even with no chat app) and,
 * when a Telegram bot is configured, pushed to the owner's chat. A failed push never
 * breaks the operation that raised it.
 */
import type { Secrets } from './config.ts';
import type { Store } from './store/store.ts';
import { C } from './store/store.ts';
import { newId, nowIso } from './util.ts';
import type { Core } from './core.ts';

export type AlertLevel = 'info' | 'action' | 'urgent';

export interface OwnerAlert {
  id: string;
  level: AlertLevel;
  topic: string;
  title: string;
  body: string;
  link?: string;
  createdAt: string;
  pushed: boolean;
  read: boolean;
}

export interface Notifier {
  owner(level: AlertLevel, topic: string, title: string, body: string, link?: string): Promise<void>;
}

export type FetchFn = (input: string, init?: RequestInit) => Promise<Response>;

/** Alerts on the same topic are pushed at most once per window, so a noisy fault cannot spam the owner. */
const PUSH_WINDOW_MS = 10 * 60_000;

export function createNotifier(store: Store, secrets: Secrets, fetchFn: FetchFn = fetch): Notifier {
  const lastPush = new Map<string, number>();

  async function pushTelegram(text: string): Promise<boolean> {
    if (!secrets.telegramBotToken || !secrets.telegramChatId) return false;
    try {
      const res = await fetchFn(`https://api.telegram.org/bot${secrets.telegramBotToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: secrets.telegramChatId, text: text.slice(0, 3500), disable_web_page_preview: true }),
        signal: AbortSignal.timeout(8000),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  return {
    async owner(level, topic, title, body, link) {
      const now = Date.now();
      const due = level !== 'info' && now - (lastPush.get(topic) ?? 0) > PUSH_WINDOW_MS;
      let pushed = false;
      if (due) {
        lastPush.set(topic, now);
        const icon = level === 'urgent' ? '🔴' : '🟡';
        const url = link ? `\n${secrets.publicBaseUrl}${link}` : '';
        pushed = await pushTelegram(`${icon} M R S — ${title}\n\n${body}${url}`);
      }
      const alert: OwnerAlert = { id: newId('ALR'), level, topic, title, body: body.slice(0, 1200), link, createdAt: nowIso(), pushed, read: false };
      try {
        await store.put(C.notifications, alert.id, alert);
      } catch {
        /* an alert must never break the caller */
      }
    },
  };
}

export async function listAlerts(store: Store, limit = 100): Promise<OwnerAlert[]> {
  const all = await store.list<OwnerAlert>(C.notifications, [], 2000);
  return all.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
}

export async function markAlertRead(store: Store, id: string): Promise<void> {
  const a = await store.get<OwnerAlert>(C.notifications, id);
  if (a) await store.put(C.notifications, id, { ...a, read: true });
}

/** Raises an alert at most once per `hours` for a topic, however often the cause repeats. */
export async function alertOnce(core: Pick<Core, 'store' | 'notifier'>, topic: string, hours: number, level: AlertLevel, title: string, text: string): Promise<boolean> {
  const id = `alerted:${topic}`;
  const last = await core.store.get<{ at: string }>(C.meta, id);
  if (last && Date.now() - Date.parse(last.at) < hours * 3600_000) return false;
  await core.store.put(C.meta, id, { at: nowIso() });
  await core.notifier.owner(level, topic, title, text, '/admin');
  return true;
}
