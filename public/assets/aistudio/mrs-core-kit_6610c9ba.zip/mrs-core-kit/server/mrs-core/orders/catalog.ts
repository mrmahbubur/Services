/**
 * mrs-core — the service catalogue as the SERVER knows it.
 *
 * Prices, payment timing and what a client must supply are decided here, not in the
 * browser. Ids, slugs, names and rates are the ones already published on the site.
 *
 * `mode` says, truthfully, who does the work:
 *   auto      Camellia produces the deliverable from what the client supplied.
 *             Code checks it; the owner releases it (or switches on auto-release).
 *   assisted  Camellia does the part software can do (audit, checks, drafts, the exact
 *             steps); the owner does the part that needs access to the client's
 *             accounts, then the pipeline verifies and packages the result.
 *   human     Live work (remote session, lesson, ongoing admin). Camellia prepares
 *             it and writes it up afterwards; the owner performs it.
 *   manual    Not handled by this pipeline.
 */
import type { FulfilmentMode, PaymentTiming } from '../types.ts';

export type IntakeType = 'text' | 'longtext' | 'choice' | 'url' | 'email' | 'domain' | 'file';

export interface IntakeField {
  key: string;
  label: string;
  type: IntakeType;
  required: boolean;
  help?: string;
  choices?: string[];
  /** Allowed upload types for `file` fields (lower-case extensions). */
  accept?: string[];
  /** Satisfied when ANY field of the same group is answered (e.g. upload a CV OR paste it). */
  group?: string;
  maxLength?: number;
}

export interface ServiceDef {
  id: string;
  serviceId: string;
  slug: string;
  category: 'M R S Services' | 'Gravatar Services' | 'M R S IPTV';
  name: string;
  shortDescription: string;
  typicalTurnaround: string;
  priceType: 'fixed' | 'quote' | 'hourly' | 'plan';
  fixedPriceUSD?: number;
  minPriceUSD?: number;
  maxPriceUSD?: number;
  /** For priceType 'plan': months -> USD. */
  plans?: Record<string, number>;
  rateUSD: string;
  rateBDT: string;
  paymentTimingNewClient: PaymentTiming;
  paymentTimingTrustedClient: PaymentTiming;
  depositPercent: number;
  lockableDeliverables: boolean;
  revisionsIncluded: number;
  notIncluded: string[];
  active: boolean;
  sortOrder: number;
  mode: FulfilmentMode;
  /** Which worker in fulfilment/workers handles it. */
  worker: string;
  /** One honest sentence for the client about how the work is done. */
  howItIsDone: string;
  intake: IntakeField[];
}

const DOCS = ['pdf', 'docx', 'txt', 'md'];
const NO_PASSWORDS = 'Do not type passwords here. Access is arranged with you directly.';

export const SERVICES: ServiceDef[] = [
  {
    id: 'ai-digital-productivity',
    serviceId: 'S-MRS-01',
    slug: 'ai-digital-productivity',
    category: 'M R S Services',
    name: 'AI & Digital Productivity',
    shortDescription: 'Custom prompt engineering, autonomous agent pipelines, workflow automation, and Gemini/OpenAI API integrations.',
    typicalTurnaround: '24–48 hours',
    priceType: 'quote',
    minPriceUSD: 50,
    maxPriceUSD: 100,
    rateUSD: '$50 – $100 / hour',
    rateBDT: '5,000 – 10,000 TK / hour',
    paymentTimingNewClient: 'B',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: true,
    revisionsIncluded: 2,
    notIncluded: ['Third-party API subscription costs', 'Proprietary platform license fees'],
    active: true,
    sortOrder: 1,
    mode: 'assisted',
    worker: 'pack:solution_design',
    howItIsDone: 'Camellia designs the workflow, prompts and test cases from your description; the owner builds and tests it in your tools.',
    intake: [
      { key: 'process', label: 'The task you do by hand today, step by step', type: 'longtext', required: true },
      { key: 'tools', label: 'Tools involved (e.g. Gmail, Sheets, Notion, Zapier)', type: 'text', required: true },
      { key: 'desired_output', label: 'What the result should look like', type: 'longtext', required: true },
      { key: 'sample_input', label: 'A real sample input (remove anything private)', type: 'longtext', required: false },
      { key: 'volume', label: 'How often it runs (per day / week)', type: 'text', required: false },
    ],
  },
  {
    id: 'technical-writing-proofreading',
    serviceId: 'S-MRS-02',
    slug: 'technical-writing-proofreading',
    category: 'M R S Services',
    name: 'Technical Writing & Proofreading',
    shortDescription: 'Developer-grade tutorials, software user manuals, architectural walkthroughs, API reference docs, and meticulous proofreading.',
    typicalTurnaround: '2–4 business days',
    priceType: 'quote',
    minPriceUSD: 40,
    maxPriceUSD: 80,
    rateUSD: '$40 – $80 / hour',
    rateBDT: '4,000 – 8,000 TK / hour',
    paymentTimingNewClient: 'A',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: true,
    revisionsIncluded: 3,
    notIncluded: ['Original software development'],
    active: true,
    sortOrder: 2,
    mode: 'auto',
    worker: 'writing',
    howItIsDone: 'Camellia proofreads or writes the document from your material; code checks that nothing factual was changed; the owner reviews before release.',
    intake: [
      { key: 'task', label: 'What do you need?', type: 'choice', required: true, choices: ['Proofread my document', 'Write a new document'] },
      { key: 'document', label: 'Your document or source material', type: 'file', required: false, accept: DOCS, group: 'source' },
      { key: 'source_text', label: '…or paste the text / feature notes here', type: 'longtext', required: false, group: 'source', maxLength: 60000 },
      { key: 'audience', label: 'Who will read it?', type: 'text', required: true },
      { key: 'style', label: 'Style guide, spelling (US/UK) or format requirements', type: 'text', required: false },
    ],
  },
  {
    id: 'website-management',
    serviceId: 'S-MRS-03',
    slug: 'website-management',
    category: 'M R S Services',
    name: 'Website Management (Blogger/WordPress)',
    shortDescription: 'Full CMS administration, Core Web Vitals optimization, on-page SEO, speed hardening, and rapid bug troubleshooting.',
    typicalTurnaround: '24–72 hours',
    priceType: 'quote',
    minPriceUSD: 30,
    maxPriceUSD: 60,
    rateUSD: '$30 – $60 / hour',
    rateBDT: '3,000 – 6,000 TK / hour',
    paymentTimingNewClient: 'B',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: false,
    revisionsIncluded: 2,
    notIncluded: ['Premium plugin purchase fees', 'External hosting migration server fees'],
    active: true,
    sortOrder: 3,
    mode: 'assisted',
    worker: 'web_audit',
    howItIsDone: 'Camellia runs a measured speed and SEO audit of your site and writes the fix plan; the owner applies the fixes with your admin access; the audit is run again to show before and after.',
    intake: [
      { key: 'site_url', label: 'Website address', type: 'url', required: true },
      { key: 'platform', label: 'Platform', type: 'choice', required: true, choices: ['WordPress', 'Blogger', 'Other'] },
      { key: 'issues', label: 'What is wrong or what you want improved', type: 'longtext', required: true },
      { key: 'backup_ok', label: 'May we take a full backup before changing anything?', type: 'choice', required: true, choices: ['Yes', 'No'] },
      { key: 'access_note', label: 'How you prefer to give admin access', type: 'text', required: false, help: NO_PASSWORDS },
    ],
  },
  {
    id: 'it-support-troubleshooting',
    serviceId: 'S-MRS-04',
    slug: 'it-support-troubleshooting',
    category: 'M R S Services',
    name: 'IT Support & Troubleshooting',
    shortDescription: 'Remote systems diagnostics, software configuration, peripheral connectivity, malware removal, and AnyDesk/RustDesk session support.',
    typicalTurnaround: 'Within 2–6 hours',
    priceType: 'quote',
    minPriceUSD: 25,
    maxPriceUSD: 50,
    rateUSD: '$25 – $50 / hour',
    rateBDT: '2,500 – 5,000 TK / hour',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 1,
    notIncluded: ['Hardware physical replacement'],
    active: true,
    sortOrder: 4,
    mode: 'human',
    worker: 'pack:it_support',
    howItIsDone: 'A person fixes it with you in a live remote session that you watch and can end at any time. Camellia prepares the diagnosis plan beforehand and writes your maintenance notes afterwards.',
    intake: [
      { key: 'system', label: 'Device and operating system', type: 'choice', required: true, choices: ['Windows 11', 'Windows 10', 'macOS', 'Linux', 'Android', 'Other'] },
      { key: 'symptom', label: 'What happens, and what you expected', type: 'longtext', required: true },
      { key: 'error_text', label: 'Exact error message, if any', type: 'text', required: false },
      { key: 'since', label: 'When it started / what changed before it', type: 'text', required: false },
      { key: 'remote_tool', label: 'Remote tool you will use', type: 'choice', required: true, choices: ['AnyDesk', 'RustDesk'] },
      { key: 'availability', label: 'When you are available (with time zone)', type: 'text', required: true, help: 'Do not send your AnyDesk/RustDesk ID or any password here; you share it at the start of the session.' },
    ],
  },
  {
    id: 'app-store-publishing',
    serviceId: 'S-MRS-05',
    slug: 'app-store-publishing',
    category: 'M R S Services',
    name: 'App Store Publishing',
    shortDescription: 'Submission management for Google Play Console and Apple App Store. Metadata compliance, policy verification, and signing.',
    typicalTurnaround: '24–48 hours',
    priceType: 'fixed',
    fixedPriceUSD: 25,
    rateUSD: '$25 USD',
    rateBDT: '2,500 TK',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 2,
    notIncluded: ['Developer account enrollment fees ($25 Google / $99 Apple)'],
    active: true,
    sortOrder: 5,
    mode: 'assisted',
    worker: 'pack:store_listing',
    howItIsDone: 'Camellia prepares the listing text within each store\'s limits and the data-safety answers from what you tell us; the owner submits the build through the access you grant. Approval is decided by Google and Apple.',
    intake: [
      { key: 'store', label: 'Store', type: 'choice', required: true, choices: ['Google Play', 'Apple App Store', 'Both'] },
      { key: 'app_name', label: 'App name', type: 'text', required: true, maxLength: 60 },
      { key: 'what_it_does', label: 'What the app does and its main features', type: 'longtext', required: true },
      { key: 'category', label: 'Store category', type: 'text', required: true },
      { key: 'audience', label: 'Intended users and minimum age', type: 'text', required: true },
      { key: 'data_collected', label: 'What user data the app collects, stores or shares (and any ads / analytics SDKs)', type: 'longtext', required: true },
      { key: 'privacy_policy_url', label: 'Privacy policy URL', type: 'url', required: true },
      { key: 'access_note', label: 'How you will invite us to the developer account', type: 'text', required: false, help: NO_PASSWORDS },
    ],
  },
  {
    id: 'ats-cv-resume',
    serviceId: 'S-MRS-06',
    slug: 'ats-cv-resume',
    category: 'M R S Services',
    name: 'Advanced ATS CV & Resume',
    shortDescription: 'Executive resume rewrite engineered to clear modern Applicant Tracking Systems with metrics-driven achievements.',
    typicalTurnaround: '24–48 hours',
    priceType: 'fixed',
    fixedPriceUSD: 15,
    rateUSD: '$15 / 1,500 TK',
    rateBDT: '1,500 TK',
    paymentTimingNewClient: 'A',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: true,
    revisionsIncluded: 2,
    notIncluded: ['Cover letter (available as add-on quote)'],
    active: true,
    sortOrder: 6,
    mode: 'auto',
    worker: 'cv',
    howItIsDone: 'Camellia rewrites your CV for the roles you name, using only facts from the CV you supply. Code checks that no employer, title, date, qualification or figure was added. The owner reviews before release.',
    intake: [
      { key: 'cv_file', label: 'Your current CV', type: 'file', required: false, accept: DOCS, group: 'cv' },
      { key: 'cv_text', label: '…or paste your CV / career notes', type: 'longtext', required: false, group: 'cv', maxLength: 40000 },
      { key: 'job_postings', label: 'Text of 1–3 job postings you are targeting (paste the text, not a link)', type: 'longtext', required: true, maxLength: 30000 },
      { key: 'notes', label: 'Anything to emphasise or leave out', type: 'longtext', required: false },
    ],
  },
  {
    id: 'web-setup',
    serviceId: 'S-MRS-07',
    slug: 'web-setup',
    category: 'M R S Services',
    name: 'Web Setup Services',
    shortDescription: 'Domain DNS routing, nameserver mapping, Cloudflare SSL configuration, business email setup, and hosting environment spin-up.',
    typicalTurnaround: '12–24 hours',
    priceType: 'hourly',
    minPriceUSD: 18,
    rateUSD: '~$18 per hour',
    rateBDT: '~1,800 TK per hour',
    paymentTimingNewClient: 'B',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: false,
    revisionsIncluded: 2,
    notIncluded: ['Domain purchase or hosting subscription costs'],
    active: true,
    sortOrder: 7,
    mode: 'assisted',
    worker: 'dns:web_setup',
    howItIsDone: 'Camellia reads your domain\'s live DNS, works out the exact records to add or change, and re-checks them afterwards; the owner makes the changes with your registrar access.',
    intake: [
      { key: 'domain', label: 'Domain name', type: 'domain', required: true },
      { key: 'goal', label: 'What you need set up', type: 'choice', required: true, choices: ['Point the domain to my hosting', 'Business e-mail on my domain', 'Cloudflare + SSL', 'Several of these'] },
      { key: 'hosting', label: 'Hosting provider or target (e.g. Vercel, Netlify, cPanel host)', type: 'text', required: false },
      { key: 'email_provider', label: 'E-mail provider', type: 'choice', required: false, choices: ['Google Workspace', 'Zoho Mail', 'Other', 'Not needed'] },
      { key: 'details', label: 'Anything else we should know', type: 'longtext', required: false, help: NO_PASSWORDS },
    ],
  },
  {
    id: 'tutoring',
    serviceId: 'S-MRS-08',
    slug: 'tutoring',
    category: 'M R S Services',
    name: 'Peer & Subject Tutoring',
    shortDescription: 'Live 1-on-1 coaching in computer science, software engineering fundamentals, web development, algorithms, and technical problem-solving.',
    typicalTurnaround: 'Scheduled by appointment',
    priceType: 'hourly',
    minPriceUSD: 16,
    rateUSD: '~$16 per hour',
    rateBDT: '~1,600 TK per hour',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 1,
    notIncluded: ['Completing academic exam submissions on behalf of student'],
    active: true,
    sortOrder: 8,
    mode: 'human',
    worker: 'pack:tutoring',
    howItIsDone: 'A person teaches the live session. Camellia prepares the lesson plan and practice problems beforehand. We teach; we do not complete graded work for you.',
    intake: [
      { key: 'topic', label: 'Subject and topics', type: 'text', required: true },
      { key: 'level', label: 'Your level', type: 'choice', required: true, choices: ['Beginner', 'Intermediate', 'Advanced'] },
      { key: 'goals', label: 'What you want to be able to do after the session', type: 'longtext', required: true },
      { key: 'material', label: 'Syllabus, notes or the problem you are stuck on', type: 'longtext', required: false },
      { key: 'availability', label: 'When you are available (with time zone)', type: 'text', required: true },
    ],
  },
  {
    id: 'graphics-design',
    serviceId: 'S-MRS-09',
    slug: 'graphics-design',
    category: 'M R S Services',
    name: 'Graphics Design',
    shortDescription: 'Vector logos, branding assets, social media banners, marketing collateral, UI icons, and technical system diagrams.',
    typicalTurnaround: '24–48 hours',
    priceType: 'hourly',
    minPriceUSD: 15,
    rateUSD: '~$15 per hour',
    rateBDT: '~1,500 TK per hour',
    paymentTimingNewClient: 'A',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: true,
    revisionsIncluded: 3,
    notIncluded: ['Print press production delivery fees'],
    active: true,
    sortOrder: 9,
    mode: 'assisted',
    worker: 'pack:creative_brief',
    howItIsDone: 'Camellia turns your request into a creative brief with palette, type and size specifications; the owner designs the artwork and uploads the final files.',
    intake: [
      { key: 'item', label: 'What you need', type: 'choice', required: true, choices: ['Logo', 'Social media banner', 'Marketing material', 'Icons', 'Diagram', 'Other'] },
      { key: 'brand_name', label: 'Brand or project name (exact spelling)', type: 'text', required: true },
      { key: 'description', label: 'What it is for and the feeling it should give', type: 'longtext', required: true },
      { key: 'colors', label: 'Colours to use or avoid', type: 'text', required: false },
      { key: 'text_on_design', label: 'Exact text that must appear', type: 'text', required: false },
      { key: 'references', label: 'Designs you like (describe or name them)', type: 'longtext', required: false },
    ],
  },
  {
    id: 'virtual-assistance',
    serviceId: 'S-MRS-10',
    slug: 'virtual-assistance',
    category: 'M R S Services',
    name: 'Virtual Assistance & Admin Support',
    shortDescription: 'Executive administrative operations, email inbox management, calendar coordination, document formatting, and spreadsheet automation.',
    typicalTurnaround: 'Daily ongoing blocks',
    priceType: 'quote',
    minPriceUSD: 15,
    maxPriceUSD: 25,
    rateUSD: '$15 – $25 / hour',
    rateBDT: '1,500 – 2,500 TK / hour',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 2,
    notIncluded: ['Legal or financial fiduciary execution'],
    active: true,
    sortOrder: 10,
    mode: 'human',
    worker: 'pack:virtual_assistance',
    howItIsDone: 'A person does the ongoing work inside your accounts. Camellia writes the operating procedure from your instructions and keeps the task log.',
    intake: [
      { key: 'tasks', label: 'Tasks to hand over, with how often each happens', type: 'longtext', required: true },
      { key: 'tools', label: 'Tools and accounts involved', type: 'text', required: true, help: NO_PASSWORDS },
      { key: 'hours', label: 'Hours per week and preferred working window', type: 'text', required: true },
      { key: 'rules', label: 'Rules: what must always / never be done, who to escalate to', type: 'longtext', required: false },
    ],
  },
  {
    id: 'data-entry',
    serviceId: 'S-MRS-11',
    slug: 'data-entry',
    category: 'M R S Services',
    name: 'Data Entry',
    shortDescription: 'High-accuracy data transcription, deduplication, schema normalization, CSV/JSON spreadsheet cleanup, and database population.',
    typicalTurnaround: '24–48 hours',
    priceType: 'hourly',
    minPriceUSD: 10,
    rateUSD: '~$10 per hour',
    rateBDT: '~1,000 TK per hour',
    paymentTimingNewClient: 'A',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: true,
    revisionsIncluded: 2,
    notIncluded: ['Custom database server engineering'],
    active: true,
    sortOrder: 11,
    mode: 'auto',
    worker: 'data',
    howItIsDone: 'For spreadsheets and text files, code does the cleaning by fixed rules that Camellia proposes and that are listed in your report, with every row accounted for. Scans and photos are transcribed by Camellia and then checked by a person.',
    intake: [
      { key: 'source_file', label: 'Your data file', type: 'file', required: false, accept: ['csv', 'tsv', 'txt', 'json', 'xlsx', 'pdf', 'png', 'jpg', 'jpeg'], group: 'source' },
      { key: 'source_text', label: '…or paste the data', type: 'longtext', required: false, group: 'source', maxLength: 100000 },
      { key: 'target_columns', label: 'The columns you want, in order', type: 'longtext', required: true },
      { key: 'rules', label: 'Rules (date format, how to treat duplicates, required fields…)', type: 'longtext', required: false },
    ],
  },
  {
    id: 'online-learning-resources',
    serviceId: 'S-MRS-12',
    slug: 'online-learning-resources',
    category: 'M R S Services',
    name: 'Online Learning Resources',
    shortDescription: 'Custom curriculum design, interactive study blueprints, technical quiz authoring, and structured digital training materials.',
    typicalTurnaround: '3–5 business days',
    priceType: 'quote',
    minPriceUSD: 20,
    maxPriceUSD: 40,
    rateUSD: '$20 – $40 / hour',
    rateBDT: '2,000 – 4,000 TK / hour',
    paymentTimingNewClient: 'A',
    paymentTimingTrustedClient: 'A',
    depositPercent: 50,
    lockableDeliverables: true,
    revisionsIncluded: 2,
    notIncluded: ['Video production / voice narration'],
    active: true,
    sortOrder: 12,
    mode: 'auto',
    worker: 'learning',
    howItIsDone: 'Camellia writes the syllabus, lessons, exercises and answer keys; code checks that every learning objective is taught and assessed; the owner reviews before release.',
    intake: [
      { key: 'topic', label: 'Subject', type: 'text', required: true },
      { key: 'level', label: 'Learner level', type: 'choice', required: true, choices: ['Beginner', 'Intermediate', 'Advanced'] },
      { key: 'outcomes', label: 'What learners must be able to do at the end', type: 'longtext', required: true },
      { key: 'length', label: 'Course length (e.g. 6 lessons of 45 minutes)', type: 'text', required: true },
      { key: 'audience', label: 'Who the learners are', type: 'text', required: false },
      { key: 'constraints', label: 'Tools, language or syllabus the course must follow', type: 'longtext', required: false },
    ],
  },
  {
    id: 'gravatar-identity-consultation',
    serviceId: 'S-GRV-01',
    slug: 'gravatar-identity-consultation',
    category: 'Gravatar Services',
    name: 'Professional Identity Consultation',
    shortDescription: 'Digital identity audit, e-mail avatar hash linkage, and cross-platform profile optimization.',
    typicalTurnaround: '24 hours',
    priceType: 'fixed',
    fixedPriceUSD: 25,
    rateUSD: '$25 USD',
    rateBDT: '2,500 TK',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: true,
    revisionsIncluded: 1,
    notIncluded: ['Managing client private passwords'],
    active: true,
    sortOrder: 13,
    mode: 'auto',
    worker: 'gravatar_audit',
    howItIsDone: 'Camellia looks up the public Gravatar record of each e-mail address you list and writes the audit and recommendations from what is actually there.',
    intake: [
      { key: 'emails', label: 'E-mail addresses to audit (one per line, up to 8)', type: 'longtext', required: true, maxLength: 800 },
      { key: 'role', label: 'Your profession and how you want to be seen', type: 'longtext', required: true },
      { key: 'links', label: 'Your public profiles (GitHub, LinkedIn, website)', type: 'longtext', required: false },
    ],
  },
  {
    id: 'gravatar-profile-personalization',
    serviceId: 'S-GRV-02',
    slug: 'gravatar-profile-personalization',
    category: 'Gravatar Services',
    name: 'Profile Personalization',
    shortDescription: 'Custom Gravatar bio crafting, contact card optimization, and social links architecture.',
    typicalTurnaround: '24 hours',
    priceType: 'quote',
    minPriceUSD: 10,
    maxPriceUSD: 20,
    rateUSD: '$10 – $20',
    rateBDT: '1,000 – 2,000 TK',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 2,
    notIncluded: ['Third-party account verification disputes'],
    active: true,
    sortOrder: 14,
    mode: 'assisted',
    worker: 'pack:gravatar_profile',
    howItIsDone: 'Camellia writes the bio, link order and contact card from what you tell us; the changes are entered in your Gravatar account by you or by the owner.',
    intake: [
      { key: 'email', label: 'Your Gravatar e-mail address', type: 'email', required: true },
      { key: 'about', label: 'Who you are and what you do', type: 'longtext', required: true },
      { key: 'links', label: 'Links to show (one per line)', type: 'longtext', required: false },
      { key: 'tone', label: 'Tone', type: 'choice', required: false, choices: ['Formal', 'Friendly', 'Technical'] },
    ],
  },
  {
    id: 'gravatar-custom-domain-mapping',
    serviceId: 'S-GRV-03',
    slug: 'gravatar-custom-domain-mapping',
    category: 'Gravatar Services',
    name: 'Custom Domain Mapping',
    shortDescription: 'DNS mapping to route your personal domain or subdomain to your Gravatar profile.',
    typicalTurnaround: '12–24 hours',
    priceType: 'quote',
    minPriceUSD: 15,
    maxPriceUSD: 30,
    rateUSD: '$15 – $30',
    rateBDT: '1,500 – 3,000 TK',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'A',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 2,
    notIncluded: ['Domain purchase fees'],
    active: true,
    sortOrder: 15,
    mode: 'assisted',
    worker: 'dns:gravatar_domain',
    howItIsDone: 'Camellia reads your domain\'s live DNS and re-checks it after the change; the owner adds the record with your DNS access.',
    intake: [
      { key: 'domain', label: 'Domain or subdomain to use (e.g. me.example.com)', type: 'domain', required: true },
      { key: 'gravatar_email', label: 'Your Gravatar e-mail address', type: 'email', required: true },
      { key: 'dns_provider', label: 'Where the domain\'s DNS is managed', type: 'text', required: false, help: NO_PASSWORDS },
    ],
  },
  {
    id: 'iptv-vip-pass',
    serviceId: 'S-IPTV-01',
    slug: 'iptv-vip-pass',
    category: 'M R S IPTV',
    name: 'M R S IPTV VIP Pass',
    shortDescription: 'Available in 1, 2, 6, or 12-month plans.',
    typicalTurnaround: 'After payment verification',
    priceType: 'plan',
    plans: { '1': 12, '2': 22, '6': 55, '12': 99 },
    rateUSD: '1, 2, 6, 12 Month Plans',
    rateBDT: '1, 2, 6, 12 Month Plans',
    paymentTimingNewClient: 'C',
    paymentTimingTrustedClient: 'C',
    depositPercent: 100,
    lockableDeliverables: false,
    revisionsIncluded: 0,
    notIncluded: ['Physical media streaming hardware'],
    active: true,
    sortOrder: 16,
    mode: 'manual',
    worker: 'none',
    howItIsDone: 'Handled by the owner directly.',
    intake: [
      { key: 'plan', label: 'Plan (months)', type: 'choice', required: true, choices: ['1', '2', '6', '12'] },
      { key: 'device', label: 'Device type', type: 'text', required: false },
    ],
  },
];

export function findService(idOrSlug: string): ServiceDef | undefined {
  const key = idOrSlug.trim().toLowerCase();
  return SERVICES.find((s) => s.active && (s.id === key || s.slug === key || s.serviceId.toLowerCase() === key));
}

/** What the browser may see. */
export function publicCatalog(): Record<string, unknown>[] {
  return SERVICES.filter((s) => s.active).map((s) => ({
    id: s.id,
    serviceId: s.serviceId,
    slug: s.slug,
    category: s.category,
    name: s.name,
    shortDescription: s.shortDescription,
    typicalTurnaround: s.typicalTurnaround,
    priceType: s.priceType,
    fixedPriceUSD: s.fixedPriceUSD,
    minPriceUSD: s.minPriceUSD,
    maxPriceUSD: s.maxPriceUSD,
    plans: s.plans,
    rateUSD: s.rateUSD,
    rateBDT: s.rateBDT,
    paymentTimingNewClient: s.paymentTimingNewClient,
    paymentTimingTrustedClient: s.paymentTimingTrustedClient,
    depositPercent: s.depositPercent,
    lockableDeliverables: s.lockableDeliverables,
    revisionsIncluded: s.revisionsIncluded,
    notIncluded: s.notIncluded,
    sortOrder: s.sortOrder,
    fulfilmentMode: s.mode,
    howItIsDone: s.howItIsDone,
    intake: s.intake,
  }));
}

// ---------------------------------------------------------------- intake validation

// Last label: letters, or a punycode internationalised TLD such as xn--54b7fta0cc (.বাংলা).
const DOMAIN_RE = /^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:[a-z]{2,24}|xn--[a-z0-9]{2,59})$/i;
const SECRET_RE = /\b(pass(word|code|wd)?|pwd|pin|otp|secret|api[_ -]?key|token)\b\s*(is|[:=])\s*\S{3,}/i;

export function isPublicDomain(value: string): boolean {
  const v = value.trim().toLowerCase();
  if (!DOMAIN_RE.test(v)) return false;
  return !/(^|\.)(localhost|local|internal|lan|home|corp|test|invalid|example)$/.test(v);
}

/** A syntactically valid public http(s) URL whose host is a domain name (never an IP address). */
export function isPublicHttpUrl(value: string): boolean {
  let u: URL;
  try {
    u = new URL(value.trim());
  } catch {
    return false;
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return false;
  if (u.username || u.password || (u.port && !['80', '443'].includes(u.port))) return false;
  return isPublicDomain(u.hostname);
}

export interface IntakeCheck {
  /** Cleaned answers that may be stored. */
  answers: Record<string, string>;
  /** Field key -> what is wrong. */
  errors: Record<string, string>;
}

/** Validates answers for the fields that were sent. Does not judge completeness. */
export function validateIntake(service: ServiceDef, input: unknown): IntakeCheck {
  const raw = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const answers: Record<string, string> = {};
  const errors: Record<string, string> = {};
  for (const field of service.intake) {
    if (field.type === 'file') continue;
    const v = raw[field.key];
    if (v === undefined || v === null || v === '') continue;
    if (typeof v !== 'string') {
      errors[field.key] = 'Must be text.';
      continue;
    }
    const value = v.trim();
    const max = field.maxLength ?? (field.type === 'longtext' ? 8000 : 300);
    if (value.length > max) {
      errors[field.key] = `Too long (maximum ${max} characters).`;
      continue;
    }
    if (SECRET_RE.test(value)) {
      errors[field.key] = 'Please remove passwords, PINs and keys. We never need them in this form.';
      continue;
    }
    if (field.type === 'choice' && !(field.choices ?? []).includes(value)) errors[field.key] = 'Choose one of the listed options.';
    else if (field.type === 'email' && !/^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(value)) errors[field.key] = 'Enter a valid e-mail address.';
    else if (field.type === 'domain' && !isPublicDomain(value)) errors[field.key] = 'Enter a domain name such as example.com.';
    else if (field.type === 'url' && !isPublicHttpUrl(value)) errors[field.key] = 'Enter a full public web address starting with https://';
    else answers[field.key] = value;
  }
  return { answers, errors };
}

/** Labels of required items still missing, given stored answers and uploaded files. */
export function missingIntake(service: ServiceDef, answers: Record<string, string>, fileFieldKeys: string[]): string[] {
  const has = (f: IntakeField): boolean => (f.type === 'file' ? fileFieldKeys.includes(f.key) : Boolean(answers[f.key]?.trim()));
  const missing: string[] = [];
  const groupsDone = new Set<string>();
  const groupsSeen = new Map<string, string[]>();
  for (const f of service.intake) {
    if (f.group) {
      groupsSeen.set(f.group, [...(groupsSeen.get(f.group) ?? []), f.label]);
      if (has(f)) groupsDone.add(f.group);
    } else if (f.required && !has(f)) missing.push(f.label);
  }
  for (const [group, labels] of groupsSeen) if (!groupsDone.has(group)) missing.push(labels[0] ?? group);
  return missing;
}
