/**
 * mrs-core — clients, orders, invoices and the order thread, kept on the SERVER.
 *
 * Until now an order existed only in the visitor's own browser, so the owner never
 * received it and there was nothing to verify a payment against. Here every order,
 * invoice and message is stored once, on the server, and both the client portal and
 * the admin console read the same record.
 *
 * An order's state is never set by hand. advance() recomputes it from facts
 * (is there a price? is the deposit in? is the intake complete? has the work been
 * released? is it paid?), so calling it twice, or after a crash, is always safe.
 */
import type { Core } from '../core.ts';
import { getSettings } from '../core.ts';
import { readAuditHead, writeAudit } from '../audit.ts';
import { depositMet, fullyPaid, refreshInvoice } from '../payments/invoice.ts';
import { hashSecret, verifySecret } from '../security/auth.ts';
import { C } from '../store/store.ts';
import type { Client, Deliverable, IntakeFile, Invoice, Job, Message, Order, OrderState, Payment, PaymentTiming } from '../types.ts';
import { HttpError, clampText, formatMoney, isEmail, newId, nowIso, randomCode, randomDigits, sha256Hex, toMinor, usdToBdtMinor, yymm } from '../util.ts';
import type { ServiceDef } from './catalog.ts';
import { findService, missingIntake, validateIntake } from './catalog.ts';

const STATUS_LABEL: Record<OrderState, string> = {
  quote_pending: 'Quote pending',
  awaiting_payment: 'Awaiting payment',
  intake_pending: 'Waiting for your details',
  in_progress: 'In progress',
  owner_review: 'In progress',
  delivered: 'Delivered',
  revision: 'In progress',
  closed: 'Completed',
  cancelled: 'Cancelled',
};

const COUPONS: Record<string, { type: 'percent' | 'fixed'; value: number }> = {
  AUTOMATE10: { type: 'percent', value: 10 },
  WELCOME15: { type: 'fixed', value: 15 },
};
const MIN_CHARGE_MINOR = 500; // never below $5 after a coupon, as on the existing site
const RUSH_PERCENT = 35;
const TRUSTED_AFTER_PAID_ORDERS = 2;
const PIN_MAX_FAILS = 5;
const PIN_LOCK_MINUTES = 15;

// ---------------------------------------------------------------- clients

function emailKey(email: string): string {
  return sha256Hex(email.trim().toLowerCase()).slice(0, 40);
}

export function publicClient(c: Client): Record<string, unknown> {
  return { clientId: c.clientId, name: c.name, email: c.email, whatsapp: c.whatsapp, country: c.country, status: c.status, trustTier: c.trustTier, completedPaidOrders: c.completedPaidOrders, createdAt: c.createdAt };
}

export async function loginClient(core: Core, clientIdRaw: unknown, pinRaw: unknown): Promise<Client> {
  const clientId = clampText(clientIdRaw, 20).toUpperCase();
  const pin = clampText(pinRaw, 12);
  const generic = new HttpError(401, 'bad_login', 'Client ID or PIN is not correct.');
  if (!/^MRS-\d{4}-[A-Z0-9]{4,8}$/.test(clientId) || !/^\d{6}$/.test(pin)) throw generic;

  const client = await core.store.get<Client>(C.clients, clientId);
  if (!client) {
    hashSecret(pin); // spend the same time as a real check so ids cannot be probed by timing
    throw generic;
  }
  if (client.pinLockedUntil && Date.parse(client.pinLockedUntil) > Date.now()) {
    throw new HttpError(429, 'pin_locked', `Too many wrong PINs. Try again after ${PIN_LOCK_MINUTES} minutes.`);
  }
  if (client.status !== 'active') throw new HttpError(403, 'client_suspended', 'This account is suspended. Please contact us.');

  const ok = verifySecret(pin, client.pinHash);
  await core.store.tx(async (t) => {
    const fresh = await t.get<Client>(C.clients, clientId);
    if (!fresh) return;
    if (ok) t.put(C.clients, clientId, { ...fresh, failedPinAttempts: 0, pinLockedUntil: undefined });
    else {
      const fails = fresh.failedPinAttempts + 1;
      t.put(C.clients, clientId, { ...fresh, failedPinAttempts: fails >= PIN_MAX_FAILS ? 0 : fails, ...(fails >= PIN_MAX_FAILS ? { pinLockedUntil: new Date(Date.now() + PIN_LOCK_MINUTES * 60_000).toISOString() } : {}) });
    }
  });
  if (!ok) throw generic;
  return client;
}

// ---------------------------------------------------------------- pricing

export interface Quote {
  /** USD cents; null when the owner still has to set the price. */
  totalMinor: number | null;
  listMinor: number | null;
  couponDiscountMinor: number;
  couponCode?: string;
  rush: boolean;
}

export function priceOrder(service: ServiceDef, opts: { planMonths?: string; couponCode?: string; rush?: boolean }): Quote {
  let listMinor: number | null = null;
  if (service.priceType === 'fixed' && service.fixedPriceUSD) listMinor = Math.round(service.fixedPriceUSD * 100);
  if (service.priceType === 'plan') {
    const usd = service.plans?.[String(opts.planMonths ?? '')];
    if (!usd) throw new HttpError(400, 'plan_required', 'Choose a plan.');
    listMinor = Math.round(usd * 100);
  }
  const rush = Boolean(opts.rush);
  if (listMinor === null) return { totalMinor: null, listMinor: null, couponDiscountMinor: 0, rush };

  const code = (opts.couponCode ?? '').trim().toUpperCase();
  const coupon = COUPONS[code];
  let afterCoupon = listMinor;
  if (coupon) {
    const discount = coupon.type === 'percent' ? Math.round((listMinor * coupon.value) / 100) : coupon.value * 100;
    afterCoupon = Math.max(Math.min(listMinor, MIN_CHARGE_MINOR), listMinor - discount);
  }
  const total = rush ? Math.round(afterCoupon * (1 + RUSH_PERCENT / 100)) : afterCoupon;
  return { totalMinor: total, listMinor, couponDiscountMinor: listMinor - afterCoupon, ...(coupon ? { couponCode: code } : {}), rush };
}

function depositFor(timing: PaymentTiming, totalMinor: number, depositPercent: number): number {
  if (timing === 'C') return totalMinor;
  if (timing === 'B') return Math.round((totalMinor * Math.min(100, Math.max(0, depositPercent))) / 100);
  return 0;
}

// ---------------------------------------------------------------- create an order

export interface OrderInput {
  serviceId?: unknown;
  details?: unknown;
  clientName?: unknown;
  clientEmail?: unknown;
  clientWhatsapp?: unknown;
  clientCountry?: unknown;
  couponCode?: unknown;
  isRush?: unknown;
  rushDelivery?: unknown;
  noAi?: unknown;
  planMonths?: unknown;
  intake?: unknown;
  ref?: unknown;
  acceptTerms?: unknown;
}

export interface OrderCreated {
  order: Order;
  client: Client;
  invoice: Invoice | null;
  /** Shown once, at creation. Only a hash is stored. */
  plainPin?: string;
  isNewClient: boolean;
}

async function allocate(core: Core, collection: string, make: (attempt: number) => string): Promise<string> {
  for (let attempt = 0; attempt < 12; attempt++) {
    const id = make(attempt);
    if (!(await core.store.get(collection, id))) return id;
  }
  throw new HttpError(503, 'id_space_busy', 'Could not allocate an id. Please try again.');
}

function buildInvoice(order: Order, service: ServiceDef, totalMinor: number, rate: number, dueDate: string): Invoice {
  const suffix = order.orderId.replace(/^ORD-/, '');
  const now = nowIso();
  return refreshInvoice({
    invoiceId: `INV-${suffix}`,
    invoiceNumber: `INV-${suffix}`,
    orderId: order.orderId,
    clientId: order.clientId,
    clientName: order.clientName,
    clientEmail: order.clientEmail,
    serviceId: order.serviceId,
    items: [{ description: `${service.name} (${service.serviceId})`, amountUSD: totalMinor / 100, amountBDT: usdToBdtMinor(totalMinor, rate) / 100 }],
    totalMinor,
    paidMinor: 0,
    depositMinor: depositFor(order.paymentTiming, totalMinor, service.depositPercent),
    overpaidMinor: 0,
    writtenOffMinor: 0,
    rateSnapshot: rate,
    status: 'issued',
    paymentReferenceCode: `PAY-${suffix}`,
    reference: `PAY-${suffix}`,
    dueDate,
    issuedAt: now,
    issuedDate: now,
    total: 0,
    amountUSD: 0,
    amountBDT: 0,
    depositCredited: 0,
    amountDue: 0,
    currency: 'USD',
  });
}

/**
 * Creates an order. `actingClientId` is the signed-in client, if any.
 * A visitor who is not signed in can only create an order under a NEW e-mail address;
 * an e-mail that already has an account must sign in first, so nobody can attach
 * orders to (or peek into) someone else's account.
 */
export async function createOrder(core: Core, input: OrderInput, actingClientId: string | null, ip: string): Promise<OrderCreated> {
  const service = findService(clampText(input.serviceId, 60));
  if (!service) throw new HttpError(400, 'unknown_service', 'That service is not available.');
  if (input.acceptTerms === false) throw new HttpError(400, 'terms_required', 'Please accept the service agreement.');

  const details = clampText(input.details, 6000);
  const intake = validateIntake(service, input.intake);
  if (Object.keys(intake.errors).length > 0) throw new HttpError(400, 'bad_intake', 'Some details need correcting.', { fields: intake.errors });
  if (/\b(pass(word|code)?|pwd|otp|api[_ -]?key)\b\s*(is|[:=])\s*\S{3,}/i.test(details)) {
    throw new HttpError(400, 'secret_in_details', 'Please remove passwords and keys from the description. We never need them here.');
  }

  const quote = priceOrder(service, { planMonths: clampText(input.planMonths, 4) || intake.answers.plan, couponCode: clampText(input.couponCode, 24), rush: input.isRush === true || input.rushDelivery === true });
  const settings = await getSettings(core.store);

  // ---- who is ordering
  let client: Client | null = actingClientId ? await core.store.get<Client>(C.clients, actingClientId) : null;
  let plainPin: string | undefined;
  let isNewClient = false;
  let newClient: Client | null = null;
  if (!client) {
    const email = clampText(input.clientEmail, 200).toLowerCase();
    const name = clampText(input.clientName, 80);
    if (!isEmail(email)) throw new HttpError(400, 'bad_email', 'Enter a valid e-mail address.');
    if (name.length < 2) throw new HttpError(400, 'bad_name', 'Enter your name.');
    if (await core.store.get(C.clientEmails, emailKey(email))) {
      throw new HttpError(409, 'existing_client', 'This e-mail address already has a Client ID. Sign in with your Client ID and PIN to place the order.');
    }
    const clientId = await allocate(core, C.clients, () => `MRS-${yymm()}-${randomCode(4)}`);
    plainPin = randomDigits(6);
    newClient = {
      clientId,
      name,
      email,
      ...(clampText(input.clientWhatsapp, 30) ? { whatsapp: clampText(input.clientWhatsapp, 30) } : {}),
      ...(clampText(input.clientCountry, 60) ? { country: clampText(input.clientCountry, 60) } : {}),
      pinHash: hashSecret(plainPin),
      status: 'active',
      trustTier: 'new',
      completedPaidOrders: 0,
      failedPinAttempts: 0,
      createdAt: nowIso(),
    };
    client = newClient;
    isNewClient = true;
  }
  if (client.status !== 'active') throw new HttpError(403, 'client_suspended', 'This account is suspended. Please contact us.');

  const timing: PaymentTiming = client.trustTier === 'trusted' ? service.paymentTimingTrustedClient : service.paymentTimingNewClient;
  const orderId = await allocate(core, C.orders, (attempt) => `ORD-${yymm()}-${attempt < 4 ? 1000 + Math.floor(Math.random() * 9000) : randomCode(6)}`);
  const dueDays = (quote.totalMinor ?? 0) > 20_000 ? 7 : 2;
  const dueDate = new Date(Date.now() + dueDays * 86_400_000).toISOString().slice(0, 10);
  const now = nowIso();

  const order: Order = {
    orderId,
    clientId: client.clientId,
    clientName: client.name,
    clientEmail: client.email,
    ...(client.whatsapp ? { clientWhatsapp: client.whatsapp } : {}),
    ...(client.country ? { clientCountry: client.country } : {}),
    serviceId: service.serviceId,
    serviceSlug: service.slug,
    category: service.category,
    serviceName: service.name,
    details,
    quoteAmount: quote.totalMinor !== null ? quote.totalMinor / 100 : 0,
    currency: 'USD',
    state: 'quote_pending',
    status: STATUS_LABEL.quote_pending,
    paymentTiming: timing,
    deliverablesLocked: false,
    dueDays,
    dueDate,
    ref: clampText(input.ref, 40) || 'direct',
    agreementAcceptedAt: now,
    agreementVersion: 'v2.4',
    agreementIp: ip.slice(0, 60),
    isRush: quote.rush,
    rushDelivery: quote.rush,
    rushSurchargePercent: quote.rush ? RUSH_PERCENT : 0,
    ...(quote.couponCode ? { couponCode: quote.couponCode } : {}),
    couponDiscount: quote.couponDiscountMinor / 100,
    revisionsUsed: 0,
    revisionsTotal: service.revisionsIncluded,
    noAiRequested: input.noAi === true,
    intake: intake.answers,
    intakeFiles: [],
    kickoffChecklist: service.intake.filter((f) => f.required || f.group).map((f, i) => ({ id: `chk-${i}`, title: f.label, required: true, completed: false })),
    createdAt: now,
    updatedAt: now,
  };

  const invoice = quote.totalMinor !== null ? buildInvoice(order, service, quote.totalMinor, settings.usdToBdt, dueDate) : null;
  if (invoice) order.invoiceId = invoice.invoiceId;

  await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    if (newClient) {
      if (await t.get(C.clientEmails, emailKey(newClient.email))) throw new HttpError(409, 'existing_client', 'This e-mail address already has a Client ID. Sign in to place the order.');
      if (await t.get(C.clients, newClient.clientId)) throw new HttpError(503, 'id_space_busy', 'Please try again.');
    }
    if (await t.get(C.orders, orderId)) throw new HttpError(503, 'id_space_busy', 'Please try again.');
    const couponMarker = order.couponCode ? `coupon:${order.couponCode}:${order.clientId}` : null;
    if (couponMarker && (await t.get(C.meta, couponMarker))) throw new HttpError(409, 'coupon_used', 'This coupon has already been used on your account.');
    if (couponMarker) t.put(C.meta, couponMarker, { orderId, at: now });
    if (newClient) {
      t.put(C.clients, newClient.clientId, newClient);
      t.put(C.clientEmails, emailKey(newClient.email), { clientId: newClient.clientId });
    }
    t.put(C.orders, orderId, order);
    if (invoice) t.put(C.invoices, invoice.invoiceId, invoice);
    writeAudit(t, head, [{ actor: `client:${order.clientId}`, action: 'order.created', target: orderId, detail: `${service.serviceId} ${invoice ? formatMoney(invoice.totalMinor, 'USD') : 'price to be quoted'} timing ${timing}` }]);
  });

  await addMessage(core, order, 'system', 'M R S', `Order ${orderId} received for ${service.name}. ${service.howItIsDone}`);
  if (!invoice) {
    await core.notifier.owner('action', `quote:${orderId}`, 'New order needs a price', `${orderId} - ${service.name} for ${order.clientName}.\n${details.slice(0, 300)}`, '/admin');
  } else {
    await core.notifier.owner('info', `order:${orderId}`, 'New order', `${orderId} - ${service.name} for ${order.clientName} (${formatMoney(invoice.totalMinor, 'USD')}).`);
  }
  const advanced = await advance(core, orderId);
  return { order: advanced ?? order, client, invoice, ...(plainPin ? { plainPin } : {}), isNewClient };
}

// ---------------------------------------------------------------- order thread

export async function addMessage(core: Core, order: Pick<Order, 'orderId' | 'clientId'>, sender: Message['sender'], senderName: string, text: string, isInternalNote = false): Promise<Message> {
  const msg: Message = { id: newId('MSG'), clientId: order.clientId, orderId: order.orderId, sender, senderName, text: text.slice(0, 6000), isInternalNote, timestamp: nowIso() };
  await core.store.put(C.messages, msg.id, msg);
  return msg;
}

export async function listMessages(core: Core, orderId: string, includeInternal: boolean): Promise<Message[]> {
  const all = await core.store.list<Message>(C.messages, [['orderId', orderId]], 1000);
  return all.filter((m) => includeInternal || !m.isInternalNote).sort((a, b) => a.timestamp.localeCompare(b.timestamp));
}

// ---------------------------------------------------------------- state

export interface OrderFacts {
  invoice: Invoice | null;
  job: Job | null;
  service: ServiceDef | undefined;
  missing: string[];
}

export async function factsFor(core: Core, order: Order): Promise<OrderFacts> {
  const service = findService(order.serviceId);
  const invoice = order.invoiceId ? await core.store.get<Invoice>(C.invoices, order.invoiceId) : null;
  const job = order.jobId ? await core.store.get<Job>(C.jobs, order.jobId) : null;
  const missing = service ? missingIntake(service, order.intake, order.intakeFiles.map((f) => f.id.split(':')[0] ?? '')) : [];
  return { invoice, job, service, missing };
}

/** Pure: what state do these facts imply? */
export function decideState(order: Order, facts: OrderFacts): { state: OrderState; locked: boolean } {
  if (order.state === 'cancelled' || order.state === 'closed') return { state: order.state, locked: order.deliverablesLocked };
  const { invoice, job, service, missing } = facts;
  if (!invoice) return { state: 'quote_pending', locked: false };
  if (!depositMet(invoice)) return { state: 'awaiting_payment', locked: false };
  if (service?.mode !== 'manual' && missing.length > 0 && (!job || job.state === 'waiting_inputs')) return { state: 'intake_pending', locked: false };
  if (job?.state === 'released') {
    const locked = Boolean(service?.lockableDeliverables) && !fullyPaid(invoice);
    return { state: 'delivered', locked };
  }
  if (job?.state === 'owner_review') return { state: 'owner_review', locked: false };
  if (order.state === 'revision' && job) return { state: 'revision', locked: false };
  return { state: 'in_progress', locked: false };
}

/** Hook set by the fulfilment engine: make sure a job exists for a workable order. */
export type EnsureJob = (core: Core, order: Order) => Promise<void>;
let ensureJob: EnsureJob | null = null;
export function registerEnsureJob(fn: EnsureJob): void {
  ensureJob = fn;
}

/**
 * Recomputes an order's state from facts and performs the one-off effects of a
 * change (start the job, unlock the files, credit the client's record).
 */
export async function advance(core: Core, orderId: string): Promise<Order | null> {
  let order = await core.store.get<Order>(C.orders, orderId);
  if (!order) return null;
  const facts = await factsFor(core, order);
  const { state, locked } = decideState(order, facts);

  const workable = state === 'in_progress' || state === 'revision';
  if (workable && !facts.job && ensureJob && facts.service?.mode !== 'manual') {
    await ensureJob(core, order);
    order = (await core.store.get<Order>(C.orders, orderId)) ?? order;
  }

  const wasLocked = order.deliverablesLocked;
  const prevState = order.state;
  if (state !== prevState || locked !== wasLocked) {
    const next: Order = { ...order, state, status: STATUS_LABEL[state], deliverablesLocked: locked, updatedAt: nowIso() };
    await core.store.put(C.orders, orderId, next);
    order = next;

    if (state === 'awaiting_payment' && prevState !== 'awaiting_payment' && facts.invoice) {
      const inv = facts.invoice;
      const need = Math.min(inv.depositMinor, inv.totalMinor) - inv.paidMinor;
      await addMessage(core, order, 'system', 'M R S', `Invoice ${inv.invoiceId}: ${formatMoney(inv.totalMinor, 'USD')} (Tk ${(usdToBdtMinor(inv.totalMinor, inv.rateSnapshot) / 100).toLocaleString('en-US')}). To start, pay ${formatMoney(need, 'USD')} and write the reference ${inv.paymentReferenceCode} on the transfer.`);
    }
    if (state === 'intake_pending' && prevState !== 'intake_pending') {
      await addMessage(core, order, 'camellia', 'Camellia', `To start I still need:\n${facts.missing.map((m) => `• ${m}`).join('\n')}\n\nThe turnaround clock starts when these arrive.`);
    }
    if (state === 'in_progress' && prevState !== 'in_progress' && facts.service?.mode === 'manual') {
      await core.notifier.owner('action', `manual:${orderId}`, 'An order is ready for you to fulfil', `${orderId} - ${order.serviceName} for ${order.clientName}. This service is not automated; deliver it from the admin console.`, '/admin');
    }
    if (state === 'delivered' && prevState !== 'delivered') {
      await addMessage(core, order, 'system', 'M R S', locked && facts.invoice ? `Your work is ready. A preview is available now; the full files unlock as soon as the balance of ${formatMoney(Math.max(0, facts.invoice.totalMinor - facts.invoice.paidMinor - facts.invoice.writtenOffMinor), 'USD')} is confirmed (reference ${facts.invoice.paymentReferenceCode}).` : 'Your work is ready. The files are in your portal.');
    }
    if (state === 'delivered' && wasLocked && !locked && prevState === 'delivered') {
      await addMessage(core, order, 'system', 'M R S', 'Payment confirmed in full. Your files are unlocked.');
    }
  }

  // A fully paid, delivered order counts towards the client's trusted status - once.
  if (order.state === 'delivered' && facts.invoice && fullyPaid(facts.invoice)) {
    const marker = `paidOrder:${orderId}`;
    if (await core.store.create(C.meta, marker, { at: nowIso() })) {
      await core.store.tx(async (t) => {
        const c = await t.get<Client>(C.clients, order?.clientId ?? '');
        if (!c) return;
        const done = c.completedPaidOrders + 1;
        t.put(C.clients, c.clientId, { ...c, completedPaidOrders: done, trustTier: done >= TRUSTED_AFTER_PAID_ORDERS ? 'trusted' : c.trustTier });
      });
    }
  }
  return order;
}

/** Invoices and orders can drift apart if the process stops mid-way; this pulls them together. */
export async function advanceAllOpen(core: Core): Promise<number> {
  const open: OrderState[] = ['quote_pending', 'awaiting_payment', 'intake_pending', 'in_progress', 'owner_review', 'revision', 'delivered'];
  let n = 0;
  for (const state of open) {
    const orders = await core.store.list<Order>(C.orders, [['state', state]], 300);
    for (const o of orders) {
      if (state === 'delivered' && !o.deliverablesLocked) continue;
      await advance(core, o.orderId);
      n += 1;
    }
  }
  return n;
}

export async function onInvoiceChanged(core: Core, invoiceId: string): Promise<void> {
  const invoice = await core.store.get<Invoice>(C.invoices, invoiceId);
  if (invoice) await advance(core, invoice.orderId);
}

// ---------------------------------------------------------------- owner: price an order

export async function setQuote(core: Core, orderId: string, amountUsd: unknown, note: unknown): Promise<{ order: Order; invoice: Invoice }> {
  const totalMinor = toMinor(typeof amountUsd === 'number' ? amountUsd : String(amountUsd ?? ''));
  if (!Number.isFinite(totalMinor) || totalMinor < 100 || totalMinor > 5_000_000) throw new HttpError(400, 'bad_amount', 'Enter the price in USD (1 to 50,000).');
  const settings = await getSettings(core.store);

  const result = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const order = await t.get<Order>(C.orders, orderId);
    if (!order) throw new HttpError(404, 'order_not_found', 'Order not found.');
    const service = findService(order.serviceId);
    if (!service) throw new HttpError(409, 'service_gone', 'Service no longer exists.');
    const existing = order.invoiceId ? await t.get<Invoice>(C.invoices, order.invoiceId) : null;
    if (existing && existing.paidMinor > 0) throw new HttpError(409, 'already_paid_towards', 'Money has already been received on this invoice; the price can no longer be changed here.');

    const invoice = buildInvoice(order, service, totalMinor, settings.usdToBdt, order.dueDate);
    const next: Order = { ...order, quoteAmount: totalMinor / 100, invoiceId: invoice.invoiceId, updatedAt: nowIso() };
    t.put(C.invoices, invoice.invoiceId, invoice);
    t.put(C.orders, orderId, next);
    writeAudit(t, head, [{ actor: 'owner', action: 'order.quoted', target: orderId, detail: `${formatMoney(totalMinor, 'USD')}${existing ? ` (was ${formatMoney(existing.totalMinor, 'USD')})` : ''}` }]);
    return { order: next, invoice };
  });

  const text = clampText(note, 600);
  await addMessage(core, result.order, 'owner', 'M R S', `Your quote: ${formatMoney(totalMinor, 'USD')}.${text ? ` ${text}` : ''}`);
  const order = (await advance(core, orderId)) ?? result.order;
  return { order, invoice: result.invoice };
}

export async function cancelOrder(core: Core, orderId: string, reason: string): Promise<Order> {
  const order = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const o = await t.get<Order>(C.orders, orderId);
    if (!o) throw new HttpError(404, 'order_not_found', 'Order not found.');
    const inv = o.invoiceId ? await t.get<Invoice>(C.invoices, o.invoiceId) : null;
    if (inv && inv.paidMinor > 0) throw new HttpError(409, 'money_received', 'Money was received for this order. Refund it first, then cancel.');
    const next: Order = { ...o, state: 'cancelled', status: STATUS_LABEL.cancelled, updatedAt: nowIso() };
    t.put(C.orders, orderId, next);
    if (inv) t.put(C.invoices, inv.invoiceId, refreshInvoice({ ...inv, status: 'void' }));
    writeAudit(t, head, [{ actor: 'owner', action: 'order.cancelled', target: orderId, detail: reason.slice(0, 200) }]);
    return next;
  });
  await addMessage(core, order, 'owner', 'M R S', `This order was cancelled. ${reason}`.trim());
  return order;
}

// ---------------------------------------------------------------- client: intake

const MAX_INTAKE_FILE = 5 * 1024 * 1024;
const MAX_INTAKE_FILES = 6;

const EXT_MIME: Record<string, string> = {
  pdf: 'application/pdf',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  txt: 'text/plain',
  md: 'text/markdown',
  csv: 'text/csv',
  tsv: 'text/tab-separated-values',
  json: 'application/json',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
};

/** Checks that the bytes are what the extension says (so a renamed executable is refused). */
function contentMatches(ext: string, bytes: Buffer): boolean {
  const head = bytes.subarray(0, 8);
  if (ext === 'pdf') return head.subarray(0, 5).toString('latin1') === '%PDF-';
  if (ext === 'docx' || ext === 'xlsx') return head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x03 && head[3] === 0x04;
  if (ext === 'png') return head.equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (ext === 'jpg' || ext === 'jpeg') return head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff;
  // text formats: must be valid UTF-8 without NUL bytes
  if (bytes.includes(0)) return false;
  try {
    new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    return true;
  } catch {
    return false;
  }
}

async function ownOrder(core: Core, orderId: string, clientId: string | null): Promise<Order> {
  const order = await core.store.get<Order>(C.orders, orderId);
  if (!order || (clientId !== null && order.clientId !== clientId)) throw new HttpError(404, 'order_not_found', 'Order not found.');
  return order;
}

export async function submitIntake(core: Core, orderId: string, clientId: string | null, input: unknown): Promise<Order> {
  const order = await ownOrder(core, orderId, clientId);
  const service = findService(order.serviceId);
  if (!service) throw new HttpError(409, 'service_gone', 'Service no longer exists.');
  if (order.state === 'cancelled' || order.state === 'closed') throw new HttpError(409, 'order_closed', 'This order is closed.');
  const check = validateIntake(service, input);
  if (Object.keys(check.errors).length > 0) throw new HttpError(400, 'bad_intake', 'Some details need correcting.', { fields: check.errors });
  if (Object.keys(check.answers).length === 0) throw new HttpError(400, 'empty_intake', 'Nothing to save.');
  await core.store.tx(async (t) => {
    const fresh = await t.get<Order>(C.orders, orderId);
    if (!fresh) return;
    t.put(C.orders, orderId, { ...fresh, intake: { ...fresh.intake, ...check.answers }, updatedAt: nowIso() });
  });
  await intakeChanged(core, orderId);
  return (await advance(core, orderId)) ?? order;
}

export async function addIntakeFile(core: Core, orderId: string, clientId: string | null, fieldKey: unknown, fileName: unknown, bytes: Buffer): Promise<IntakeFile> {
  const order = await ownOrder(core, orderId, clientId);
  const service = findService(order.serviceId);
  const field = service?.intake.find((f) => f.type === 'file' && f.key === clampText(fieldKey, 40));
  if (!service || !field) throw new HttpError(400, 'unknown_field', 'This service does not take that file.');
  if (order.state === 'cancelled' || order.state === 'closed') throw new HttpError(409, 'order_closed', 'This order is closed.');
  if (order.intakeFiles.length >= MAX_INTAKE_FILES) throw new HttpError(409, 'too_many_files', `At most ${MAX_INTAKE_FILES} files per order.`);
  if (bytes.length > MAX_INTAKE_FILE) throw new HttpError(413, 'file_too_large', 'File is larger than 5 MB.');

  const name = clampText(fileName, 100).replace(/[^\w.\- ()]/g, '_') || 'file';
  const ext = (name.split('.').pop() ?? '').toLowerCase();
  if (!(field.accept ?? []).includes(ext) || !EXT_MIME[ext]) throw new HttpError(415, 'bad_file_type', `Accepted file types: ${(field.accept ?? []).join(', ')}.`);
  if (!contentMatches(ext, bytes)) throw new HttpError(415, 'bad_file_content', `The file content is not a valid .${ext} file.`);

  const sha256 = sha256Hex(bytes);
  const file: IntakeFile = { id: `${field.key}:${sha256.slice(0, 16)}`, fileName: name, mime: EXT_MIME[ext] ?? 'application/octet-stream', size: bytes.length, sha256, uploadedAt: nowIso() };
  await core.store.putBlob(`intake_${orderId}_${file.id.replace(':', '_')}`, bytes);
  await core.store.tx(async (t) => {
    const fresh = await t.get<Order>(C.orders, orderId);
    if (!fresh) return;
    t.put(C.orders, orderId, { ...fresh, intakeFiles: [...fresh.intakeFiles.filter((f) => f.id !== file.id), file], updatedAt: nowIso() });
  });
  await intakeChanged(core, orderId);
  await advance(core, orderId);
  return file;
}

export function intakeBlobId(orderId: string, file: IntakeFile): string {
  return `intake_${orderId}_${file.id.replace(':', '_')}`;
}

/** Hook set by the fulfilment engine: new client input arrived for a waiting job. */
export type IntakeListener = (core: Core, orderId: string) => Promise<void>;
let intakeListener: IntakeListener | null = null;
export function registerIntakeListener(fn: IntakeListener): void {
  intakeListener = fn;
}
async function intakeChanged(core: Core, orderId: string): Promise<void> {
  if (intakeListener) await intakeListener(core, orderId);
}

// ---------------------------------------------------------------- views

export interface PortalView {
  client: Record<string, unknown>;
  orders: Order[];
  invoices: Invoice[];
  payments: Record<string, unknown>[];
  deliverables: Record<string, unknown>[];
  messages: Message[];
}

/** A deliverable as the client may see it. `downloadable` is decided here, on the server. */
export function clientDeliverable(d: Deliverable, order: Order): Record<string, unknown> {
  const locked = order.deliverablesLocked && d.kind !== 'preview';
  return { id: d.id, orderId: d.orderId, title: d.title, description: d.description, fileName: d.fileName, mime: d.mime, size: d.size, kind: d.kind, locked, downloadable: !locked, externalUrl: locked ? undefined : d.externalUrl, createdAt: d.createdAt };
}

export async function portalView(core: Core, clientId: string, paymentView: (p: Payment) => Record<string, unknown>): Promise<PortalView> {
  const client = await core.store.get<Client>(C.clients, clientId);
  if (!client) throw new HttpError(404, 'client_not_found', 'Client not found.');
  const where: [string, string][] = [['clientId', clientId]];
  const orders = (await core.store.list<Order>(C.orders, where, 500)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const byId = new Map(orders.map((o) => [o.orderId, o]));
  const invoices = (await core.store.list<Invoice>(C.invoices, where, 500)).sort((a, b) => b.issuedAt.localeCompare(a.issuedAt));
  const payments = (await core.store.list<Payment>(C.payments, where, 500)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(paymentView);
  const deliverables = (await core.store.list<Deliverable>(C.deliverables, where, 1000))
    .filter((d) => d.released && byId.has(d.orderId))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .map((d) => clientDeliverable(d, byId.get(d.orderId) as Order));
  const messages = (await core.store.list<Message>(C.messages, where, 2000)).filter((m) => !m.isInternalNote).sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  return { client: publicClient(client), orders, invoices, payments, deliverables, messages };
}

export async function getOwnOrder(core: Core, orderId: string, clientId: string | null): Promise<Order> {
  return ownOrder(core, orderId, clientId);
}
