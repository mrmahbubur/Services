/**
 * mrs-core — running-balance check for SMS wallets.
 *
 * Signing the phone's requests proves a message came from the owner's phone. It
 * cannot prove the SMS itself was genuine: a text can be sent to that phone with a
 * forged "bKash" sender name. What a forger does not know is the wallet's balance.
 *
 * Every operator SMS ends with the new balance, so genuine messages form a chain:
 *
 *     previous balance + this movement = balance printed in this message
 *
 * A message that fits the trusted chain is clean. One that does not fit starts a
 * separate, UNTRUSTED chain: it and everything that follows it needs the owner,
 * until the owner confirms the balance in the wallet app (one tap). A genuine
 * message that arrives after a forged one still fits the trusted chain and is
 * unaffected.
 *
 * Cost when a real SMS is lost or arrives in a format we cannot read: the next
 * payment needs one owner tap, after which the chain is trusted again.
 */

export interface BalanceAnchor {
  /** Last balance on the chain the owner has (implicitly or explicitly) confirmed. */
  trustedMinor: number | null;
  /** Last balance on a chain that does not connect to the trusted one. */
  suspectMinor: number | null;
  /** Consecutive messages that fitted the suspect chain. */
  suspectStreak: number;
  updatedAt: string;
}

export const EMPTY_ANCHOR: BalanceAnchor = { trustedMinor: null, suspectMinor: null, suspectStreak: 0, updatedAt: '' };

export interface BalanceVerdict {
  anchor: BalanceAnchor;
  /** Empty = fits the trusted chain. */
  flags: string[];
}

/**
 * @param deltaMinor  signed movement the message implies, or null when unknown
 * @param balanceMinor balance printed in the message
 * @param autoHealAfter adopt an untrusted chain after this many consecutive fitting
 *        messages (0 = never; only the owner can re-trust). Default 0.
 */
export function applyBalance(prev: BalanceAnchor, deltaMinor: number | null, balanceMinor: number, at: string, autoHealAfter = 0): BalanceVerdict {
  const fits = (from: number | null): boolean => from !== null && deltaMinor !== null && from + deltaMinor === balanceMinor;

  if (fits(prev.trustedMinor)) {
    return { anchor: { trustedMinor: balanceMinor, suspectMinor: null, suspectStreak: 0, updatedAt: at }, flags: [] };
  }

  if (fits(prev.suspectMinor)) {
    const streak = prev.suspectStreak + 1;
    if (autoHealAfter > 0 && streak >= autoHealAfter) {
      // Chain adopted from here on; this message itself was still checked against an untrusted balance.
      return { anchor: { trustedMinor: balanceMinor, suspectMinor: null, suspectStreak: 0, updatedAt: at }, flags: ['balance_chain_unverified'] };
    }
    return { anchor: { ...prev, suspectMinor: balanceMinor, suspectStreak: streak, updatedAt: at }, flags: ['balance_chain_unverified'] };
  }

  const first = prev.trustedMinor === null && prev.suspectMinor === null;
  return {
    anchor: { trustedMinor: prev.trustedMinor, suspectMinor: balanceMinor, suspectStreak: 0, updatedAt: at },
    flags: [first ? 'balance_unanchored' : 'balance_gap'],
  };
}

/** The owner looked at the wallet app and the balance is right: trust the latest chain. */
export function trustLatest(prev: BalanceAnchor, at: string): BalanceAnchor {
  if (prev.suspectMinor === null) return { ...prev, updatedAt: at };
  return { trustedMinor: prev.suspectMinor, suspectMinor: null, suspectStreak: 0, updatedAt: at };
}

/** The owner typed the balance shown in the wallet app. */
export function setTrusted(balanceMinor: number, at: string): BalanceAnchor {
  return { trustedMinor: balanceMinor, suspectMinor: null, suspectStreak: 0, updatedAt: at };
}

export const BALANCE_FLAGS = ['balance_unanchored', 'balance_gap', 'balance_chain_unverified', 'balance_missing'] as const;
