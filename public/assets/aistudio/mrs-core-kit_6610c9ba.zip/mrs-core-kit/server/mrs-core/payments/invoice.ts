/**
 * mrs-core — invoice arithmetic (pure functions, integer cents only).
 */
import type { Invoice, PaymentSettings } from '../types.ts';
import { fromMinor, nowIso, toleranceMinor, usdToBdtMinor } from '../util.ts';

/** USD cents still owed. Never negative. */
export function dueMinor(inv: Pick<Invoice, 'totalMinor' | 'paidMinor' | 'writtenOffMinor'>): number {
  return Math.max(0, inv.totalMinor - inv.paidMinor - inv.writtenOffMinor);
}

/** True once enough has been paid for work to begin (deposit or prepayment met). */
export function depositMet(inv: Pick<Invoice, 'depositMinor' | 'paidMinor' | 'writtenOffMinor' | 'totalMinor'>): boolean {
  return inv.paidMinor + inv.writtenOffMinor >= Math.min(inv.depositMinor, inv.totalMinor);
}

export function fullyPaid(inv: Pick<Invoice, 'totalMinor' | 'paidMinor' | 'writtenOffMinor'>): boolean {
  return dueMinor(inv) === 0;
}

/** Recomputes status and the legacy display fields from the authoritative cent amounts. */
export function refreshInvoice<T extends Invoice>(inv: T): T {
  const due = dueMinor(inv);
  let status = inv.status;
  if (status !== 'void') {
    if (due === 0 && inv.totalMinor > 0) status = 'paid_verified';
    else if (inv.paidMinor > 0) status = 'partially_paid';
    else status = 'issued';
  }
  return {
    ...inv,
    status,
    total: fromMinor(inv.totalMinor),
    amountUSD: fromMinor(inv.totalMinor),
    amountBDT: fromMinor(usdToBdtMinor(inv.totalMinor, inv.rateSnapshot)),
    depositCredited: fromMinor(inv.paidMinor),
    amountDue: fromMinor(due),
    currency: 'USD',
  };
}

export interface CreditOutcome {
  invoice: Invoice;
  /** Cents applied to the invoice. */
  appliedMinor: number;
  /** Cents beyond what was owed. */
  surplusMinor: number;
  /** Cents forgiven under the tolerance rule. */
  forgivenMinor: number;
  nowFullyPaid: boolean;
}

/**
 * Applies received money to an invoice.
 *  - More than owed: the invoice is paid and the surplus is recorded for the owner.
 *  - Short by no more than the tolerance: paid in full, shortfall written off.
 *  - Short by more: partial credit; the rest stays due.
 */
export function applyCredit(inv: Invoice, creditMinor: number, settings: Pick<PaymentSettings, 'amountToleranceBps' | 'amountToleranceFixedMinor'>): CreditOutcome {
  const dueBefore = dueMinor(inv);
  const applied = Math.min(creditMinor, dueBefore);
  const surplus = Math.max(0, creditMinor - dueBefore);
  const next: Invoice = { ...inv, paidMinor: inv.paidMinor + applied, overpaidMinor: inv.overpaidMinor + surplus };

  let forgiven = 0;
  const remaining = dueMinor(next);
  if (remaining > 0 && remaining <= toleranceMinor(inv.totalMinor, settings.amountToleranceBps, settings.amountToleranceFixedMinor)) {
    forgiven = remaining;
    next.writtenOffMinor = inv.writtenOffMinor + forgiven;
  }

  const paid = fullyPaid(next);
  if (paid && !next.paidAt) {
    next.paidAt = nowIso();
    next.receiptNumber = next.receiptNumber ?? next.invoiceId.replace(/^INV-/, 'RCP-');
  }
  return { invoice: refreshInvoice(next), appliedMinor: applied, surplusMinor: surplus, forgivenMinor: forgiven, nowFullyPaid: paid };
}
