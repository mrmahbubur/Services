/**
 * mrs-core — the ledger of money that actually arrived.
 *
 * The ledger is the ONLY thing that can settle an invoice. It is written exclusively
 * from channels the owner controls (the owner's phone, the owner's Gmail, the
 * owner's API key, the signed-in owner). Nothing a client types, uploads or says
 * ever creates a ledger entry.
 *
 * Each transaction id can exist once. A replayed message, a retried webhook or the
 * same payment seen through two channels can therefore never count twice.
 */
import { methodDef } from '../config.ts';
import type { Core } from '../core.ts';
import { readAuditHead, writeAudit } from '../audit.ts';
import type { Tx } from '../store/store.ts';
import { C } from '../store/store.ts';
import type { Currency, EvidenceSource, LedgerEntry, LedgerKind, Method } from '../types.ts';
import { formatMoney, hoursBetween, maskProviderText, maskSender, nowIso, sha256Hex } from '../util.ts';
import { applyBalance, EMPTY_ANCHOR, setTrusted } from './balance.ts';
import type { BalanceAnchor } from './balance.ts';
import { parseProviderEmail, verifyEmailAuth } from './parsers/email.ts';
import { parseWalletSms, walletForSender } from './parsers/sms.ts';
import type { ParsedSms } from './parsers/sms.ts';

export interface LedgerDraft {
  source: EvidenceSource;
  method: Method;
  trxId: string;
  kind: LedgerKind;
  amountMinor: number;
  currency: Currency;
  asset?: string;
  senderRaw?: string;
  reference?: string;
  balanceAfterMinor?: number;
  /** ISO time the provider reports; '' when unknown (ingestion time is then used and flagged). */
  receivedAt: string;
  rawText: string;
  sourceRef?: string;
  flags: string[];
  /** The provider gave no usable id; `trxId` was derived from the message itself. */
  syntheticId?: boolean;
}

// ---------------------------------------------------------------- transaction ids

/** Upper-case, no separators; Binance prefixes such as "M_P_" / "P_" removed. */
export function normalizeTrxId(method: Method | 'usd_unspecified', raw: string): string {
  let v = raw.trim().toUpperCase();
  if (method === 'binance_pay' || method === 'usd_unspecified') v = v.replace(/^(?:[A-Z]{1,2}_)+/, '');
  return v.replace(/[^A-Z0-9]/g, '');
}

export function trxKeyOf(method: Method, normalizedTrxId: string): string {
  return `${method}:${normalizedTrxId}`;
}

/** Collapses characters people mistype for one another (O/0, I/L/1, S/5, B/8, Z/2). */
export function confusableKey(normalizedTrxId: string): string {
  return normalizedTrxId.replace(/O/g, '0').replace(/[IL]/g, '1').replace(/S/g, '5').replace(/B/g, '8').replace(/Z/g, '2');
}

/** Payment references (PAY-2611-1044) found in free text, normalised. */
export function extractPayReferences(text: string | undefined): string[] {
  if (!text) return [];
  const out = new Set<string>();
  const re = /\bPAY[\s_-]?(\d{4})[\s_-]?([A-Z0-9]{4,8})\b/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) out.add(`PAY-${m[1]}-${(m[2] ?? '').toUpperCase()}`);
  return [...out];
}

// ---------------------------------------------------------------- ingest

export type IngestStatus = 'new' | 'duplicate' | 'ignored' | 'quarantined' | 'rejected';

export interface IngestResult {
  status: IngestStatus;
  entry?: LedgerEntry;
  reason?: string;
}

const FUTURE_SLACK_MS = 15 * 60_000;

function buildEntry(draft: LedgerDraft): LedgerEntry {
  const def = methodDef(draft.method);
  const flags = [...new Set(draft.flags)];
  const now = nowIso();

  let receivedAt = draft.receivedAt;
  if (!receivedAt || Number.isNaN(Date.parse(receivedAt))) {
    receivedAt = now;
    if (!flags.includes('time_missing')) flags.push('time_missing');
  } else if (Date.parse(receivedAt) - Date.now() > FUTURE_SLACK_MS) {
    flags.push('time_in_future');
  }

  if (draft.currency !== def.currency) flags.push('currency_not_accepted');
  if (!Number.isInteger(draft.amountMinor) || draft.amountMinor <= 0) flags.push('amount_invalid');

  const rawHash = sha256Hex(`${draft.method}|${draft.rawText}`);
  const normalized = normalizeTrxId(draft.method, draft.trxId);
  const ambiguous = flags.includes('ambiguous_message') || normalized.length < 5;
  // An unclear message must never occupy the slot of the id it claims to carry.
  const keyId = ambiguous ? `AMB${rawHash.slice(0, 14).toUpperCase()}` : normalized;
  if (ambiguous && normalized.length < 5 && !flags.includes('trx_id_invalid')) flags.push('trx_id_invalid');

  const trxKey = trxKeyOf(draft.method, keyId);
  return {
    id: trxKey,
    source: draft.source,
    method: draft.method,
    accountId: def.accountId,
    trxKey,
    trxId: draft.trxId.trim().slice(0, 48),
    kind: draft.kind,
    amountMinor: Math.max(0, Math.trunc(draft.amountMinor) || 0),
    currency: draft.currency,
    ...(draft.asset ? { asset: draft.asset } : {}),
    senderMask: draft.senderRaw ? maskSender(draft.senderRaw) : '',
    ...(draft.senderRaw ? { senderRaw: draft.senderRaw } : {}),
    ...(draft.reference ? { reference: draft.reference } : {}),
    ...(draft.balanceAfterMinor !== undefined ? { balanceAfterMinor: draft.balanceAfterMinor } : {}),
    receivedAt,
    ingestedAt: now,
    rawMasked: maskProviderText(draft.rawText),
    rawHash,
    status: ambiguous ? 'quarantined' : 'unmatched',
    integrityFlags: flags,
    ...(draft.sourceRef ? { sourceRef: draft.sourceRef } : {}),
    ...(draft.syntheticId || ambiguous ? { syntheticId: true } : {}),
  };
}

/**
 * When the same money is seen once with the provider's id and once without (an
 * e-mail that carries no id), the id-less copy is set aside so it cannot settle a
 * second invoice.
 */
async function quarantineTwin(core: Core, entry: LedgerEntry): Promise<void> {
  const peers = await core.store.list<LedgerEntry>(C.ledger, [['method', entry.method], ['amountMinor', entry.amountMinor]], 200);
  for (const peer of peers) {
    if (peer.id === entry.id || peer.status === 'quarantined') continue;
    if (hoursBetween(peer.receivedAt, entry.receivedAt) > 0.25) continue;
    const weak = entry.syntheticId && !peer.syntheticId ? entry : peer.syntheticId && !entry.syntheticId ? peer : null;
    if (!weak || weak.status !== 'unmatched') continue;
    const strong = weak.id === entry.id ? peer : entry;
    await core.store.put(C.ledger, weak.id, { ...weak, status: 'quarantined', integrityFlags: [...new Set([...weak.integrityFlags, `twin_of:${strong.id}`])] });
    if (weak.id === entry.id) {
      entry.status = 'quarantined';
      entry.integrityFlags = [...new Set([...entry.integrityFlags, `twin_of:${strong.id}`])];
    }
    return;
  }
}

/** Adds one incoming-funds record. Safe to call any number of times with the same record. */
export async function ingestDraft(core: Core, draft: LedgerDraft, actor: string): Promise<IngestResult> {
  const entry = buildEntry(draft);
  const outcome = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const existing = await t.get<LedgerEntry>(C.ledger, entry.id);
    if (existing) return { status: 'duplicate' as const, entry: existing };
    t.put(C.ledger, entry.id, entry);
    writeAudit(t, head, [{ actor, action: 'ledger.ingested', target: entry.id, detail: `${entry.source} ${formatMoney(entry.amountMinor, entry.currency)} flags=[${entry.integrityFlags.join(',')}]` }]);
    return { status: 'new' as const, entry };
  });

  if (outcome.status === 'duplicate') {
    const prior = outcome.entry;
    if (prior.amountMinor !== entry.amountMinor && !entry.syntheticId) {
      await core.notifier.owner('action', `ledger-conflict:${entry.id}`, 'Two records disagree about one transaction', `${entry.method} ${entry.trxId}: earlier record (${prior.source}) says ${formatMoney(prior.amountMinor, prior.currency)}, new record (${entry.source}) says ${formatMoney(entry.amountMinor, entry.currency)}. The earlier record was kept. Check the provider app.`, '/admin');
    }
    return { status: 'duplicate', entry: prior };
  }

  await quarantineTwin(core, entry);
  return { status: entry.status === 'quarantined' ? 'quarantined' : 'new', entry };
}

// ---------------------------------------------------------------- SMS

export interface SmsInput {
  senderId: string;
  text: string;
  /** Unique id of the delivery from the phone app, when it gives one. */
  eventId?: string;
}

function balanceId(method: Method): string {
  return `balance:${method}`;
}

export async function getBalanceAnchor(core: Core, method: Method): Promise<BalanceAnchor> {
  return (await core.store.get<BalanceAnchor>(C.meta, balanceId(method))) ?? EMPTY_ANCHOR;
}

/**
 * The owner confirms the wallet balance shown in the provider app. From that figure
 * on, messages are checked automatically again.
 */
export async function trustBalance(core: Core, method: Method, balanceMinor: number, why: string): Promise<BalanceAnchor> {
  return core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const next = setTrusted(balanceMinor, nowIso());
    t.put(C.meta, balanceId(method), next);
    writeAudit(t, head, [{ actor: 'owner', action: 'ledger.balance_trusted', target: method, detail: `${formatMoney(balanceMinor, 'BDT')} - ${why}`.slice(0, 200) }]);
    return next;
  });
}

/**
 * The owner approved a flagged SMS record by hand, i.e. saw that money in the wallet.
 * If that record is the newest message of the unverified chain, its balance becomes
 * trusted. Approving an older record proves nothing about later messages, so the
 * chain is then left as it is.
 */
export async function trustBalanceFromEntry(core: Core, entry: LedgerEntry): Promise<boolean> {
  if (entry.source !== 'sms' || entry.balanceAfterMinor === undefined) return false;
  const anchor = await getBalanceAnchor(core, entry.method);
  if (anchor.suspectMinor !== entry.balanceAfterMinor) return false;
  await trustBalance(core, entry.method, entry.balanceAfterMinor, `owner approved ${entry.id}`);
  return true;
}

async function quarantineText(core: Core, tx: Tx | null, origin: string, text: string, reason: string): Promise<void> {
  const id = 'Q' + sha256Hex(origin + '|' + text).slice(0, 20).toUpperCase();
  const doc = { id, origin, reason, rawMasked: maskProviderText(text), at: nowIso() };
  if (tx) tx.put(C.quarantine, id, doc);
  else await core.store.put(C.quarantine, id, doc);
}

/**
 * Handles one SMS forwarded by the owner's phone.
 * Messages from senders that are not wallet operators, and operator messages that
 * are not transactions (OTP, promotions), are dropped without being stored.
 */
export async function ingestSms(core: Core, input: SmsInput): Promise<IngestResult> {
  const wallet = walletForSender(input.senderId, core.senderRules);
  if (!wallet) return { status: 'ignored', reason: 'sender is not a wallet operator' };

  const parsed: ParsedSms = parseWalletSms(wallet, input.text);
  if (parsed.outcome === 'ignored') return { status: 'ignored', reason: parsed.reason };

  const contentKey = 'sms:' + sha256Hex(`${wallet}|${input.text.trim()}`).slice(0, 32);

  if (parsed.outcome === 'unparsed') {
    const fresh = await core.store.create(C.replay, contentKey, { at: nowIso(), kind: 'unparsed' });
    if (!fresh) return { status: 'duplicate' };
    await quarantineText(core, null, `sms:${wallet}`, input.text, parsed.reason ?? 'unparsed');
    await core.notifier.owner('action', `sms-unparsed:${wallet}`, `A ${wallet} message could not be read`, `A message from ${input.senderId} mentions money but is in a format the system does not recognise (${parsed.reason}). Payments on ${wallet} may need your confirmation until this is looked at.`, '/admin');
    return { status: 'quarantined', reason: parsed.reason };
  }

  const balance = parsed.balanceMinor;
  const result = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    if (await t.get(C.replay, contentKey)) return { status: 'duplicate' as const };
    const anchorPrev = (await t.get<BalanceAnchor>(C.meta, balanceId(wallet))) ?? EMPTY_ANCHOR;

    // A message with a duplicated field may carry a payer-written "balance"; it must
    // not move the chain. The next genuine message then needs one owner confirmation.
    const usableBalance = balance !== undefined && !parsed.flags.includes('ambiguous_message');
    let balanceFlags: string[] = [];
    let anchorNext = anchorPrev;
    if (usableBalance) {
      const verdict = applyBalance(anchorPrev, parsed.deltaMinor, balance, nowIso(), core.balanceAutoHeal);
      balanceFlags = verdict.flags;
      anchorNext = verdict.anchor;
    }

    if (parsed.outcome === 'balance_only') {
      t.put(C.replay, contentKey, { at: nowIso(), kind: 'balance_only' });
      if (usableBalance) t.put(C.meta, balanceId(wallet), anchorNext);
      return { status: 'ignored' as const, reason: 'not an incoming payment' };
    }

    const entry = buildEntry({
      source: 'sms',
      method: wallet,
      trxId: parsed.trxId ?? '',
      kind: parsed.kind ?? 'other_credit',
      amountMinor: parsed.amountMinor ?? 0,
      currency: 'BDT',
      senderRaw: parsed.sender,
      reference: parsed.reference,
      balanceAfterMinor: balance,
      receivedAt: parsed.providerTime ?? '',
      rawText: input.text,
      sourceRef: input.eventId ? `sms:${input.eventId}` : undefined,
      flags: [...parsed.flags, ...balanceFlags],
    });

    const existing = await t.get<LedgerEntry>(C.ledger, entry.id);
    t.put(C.replay, contentKey, { at: nowIso(), kind: 'credit', ledgerId: entry.id });
    // The SMS is new even when the transaction is already known (e.g. typed in by the
    // owner earlier), so the running balance still has to follow it.
    if (usableBalance) t.put(C.meta, balanceId(wallet), anchorNext);
    if (existing) return { status: 'duplicate' as const, entry: existing, smsAmountMinor: entry.amountMinor };

    t.put(C.ledger, entry.id, entry);
    writeAudit(t, head, [{ actor: 'collector:sms', action: 'ledger.ingested', target: entry.id, detail: `sms ${formatMoney(entry.amountMinor, 'BDT')} flags=[${entry.integrityFlags.join(',')}]` }]);
    return { status: entry.status === 'quarantined' ? ('quarantined' as const) : ('new' as const), entry };
  });

  const entry = 'entry' in result ? result.entry : undefined;
  if (entry && result.status === 'duplicate' && 'smsAmountMinor' in result && typeof result.smsAmountMinor === 'number' && result.smsAmountMinor !== entry.amountMinor) {
    // e.g. the owner confirmed a payment by hand for the amount the client claimed, and the operator's SMS now says otherwise
    await core.notifier.owner('urgent', `ledger-conflict:${entry.id}`, 'The bank SMS disagrees with a recorded payment', `${wallet} transaction ${entry.trxId} was recorded (${entry.source}) as ${formatMoney(entry.amountMinor, entry.currency)}, but the operator's SMS says ${formatMoney(result.smsAmountMinor, 'BDT')}. Check the wallet app. If the recorded amount is wrong, reverse that payment and confirm it again with the right amount.`, '/admin');
  }
  if (entry && result.status !== 'duplicate') {
    const f = entry.integrityFlags;
    if (f.includes('balance_gap') || f.includes('balance_chain_unverified')) {
      await core.notifier.owner('urgent', `balance:${wallet}`, `${wallet} balance does not add up`, `An SMS says ${formatMoney(entry.amountMinor, 'BDT')} was received and the balance is now ${balance !== undefined ? formatMoney(balance, 'BDT') : 'unknown'}, which does not follow from the previous balance.\n\nOpen your ${wallet} app. If it shows that balance, confirm it in the admin panel. If it does not, do NOT approve: someone may be sending fake SMS to your phone.`, '/admin');
    } else if (f.includes('balance_unanchored')) {
      await core.notifier.owner('action', `balance:${wallet}`, `Confirm your ${wallet} balance once`, `First ${wallet} message received. Balance in the SMS: ${balance !== undefined ? formatMoney(balance, 'BDT') : 'unknown'}. Confirm it in the admin panel so later payments can be checked automatically.`, '/admin');
    } else if (f.includes('ambiguous_message')) {
      await core.notifier.owner('action', `sms-ambiguous:${wallet}`, `A ${wallet} message needs your eyes`, 'A payment SMS contains a field twice (the payer may have typed bank-like text in the reference). It was set aside and will not settle anything by itself.', '/admin');
    }
  }
  return result;
}

// ---------------------------------------------------------------- e-mail

export interface EmailInput {
  messageId: string;
  /** First "Authentication-Results" header of the raw message (the one Gmail added). */
  authResults: string;
  from: string;
  subject: string;
  body: string;
  /** When Gmail received it (ISO). */
  date: string;
}

export async function ingestEmail(core: Core, input: EmailInput): Promise<IngestResult> {
  const replayKey = 'email:' + sha256Hex(input.messageId).slice(0, 32);
  if (await core.store.get(C.replay, replayKey)) return { status: 'duplicate' };

  const auth = verifyEmailAuth(input.authResults, input.from);
  if (!auth.ok || !auth.method) {
    await core.store.create(C.replay, replayKey, { at: nowIso(), kind: 'rejected' });
    if (/received|sent you|payment/i.test(input.subject)) {
      await core.notifier.owner('action', 'email-unauthenticated', 'A payment e-mail failed authentication', `An e-mail with the subject "${input.subject.slice(0, 80)}" claims to be a payment notice but is NOT proven to come from the provider (${auth.reason}). It was ignored. Fake "you received money" e-mails are a common scam.`, '/admin');
    }
    return { status: 'rejected', reason: auth.reason };
  }

  const parsed = parseProviderEmail(auth.method, input.subject, input.body, input.messageId);
  if (parsed.outcome === 'not_payment') {
    await core.store.create(C.replay, replayKey, { at: nowIso(), kind: 'not_payment' });
    return { status: 'ignored', reason: parsed.reason };
  }
  if (parsed.outcome === 'unparsed' || !parsed.trxId || !parsed.amountMinor) {
    const fresh = await core.store.create(C.replay, replayKey, { at: nowIso(), kind: 'unparsed' });
    if (fresh) {
      await quarantineText(core, null, `email:${auth.method}`, `${input.subject}\n${input.body.slice(0, 300)}`, parsed.reason ?? 'unparsed');
      await core.notifier.owner('action', `email-unparsed:${auth.method}`, `A ${auth.method} e-mail could not be read`, `A genuine ${auth.method} notice about received money is in a format the system does not recognise (${parsed.reason}). Confirm that payment by hand.`, '/admin');
    }
    return { status: 'quarantined', reason: parsed.reason };
  }

  const result = await ingestDraft(
    core,
    {
      source: 'email',
      method: auth.method,
      trxId: parsed.trxId,
      kind: 'received',
      amountMinor: parsed.amountMinor,
      currency: 'USD',
      asset: parsed.asset,
      senderRaw: parsed.sender,
      reference: extractPayReferences(`${input.subject}\n${input.body}`)[0],
      receivedAt: input.date,
      rawText: `${input.subject} | ${input.body.replace(/\s+/g, ' ').slice(0, 240)}`,
      sourceRef: `gmail:${input.messageId}`,
      flags: parsed.flags,
      syntheticId: parsed.syntheticId,
    },
    'collector:email',
  );
  await core.store.create(C.replay, replayKey, { at: nowIso(), kind: 'credit', ledgerId: result.entry?.id });
  return result;
}

// ---------------------------------------------------------------- owner entry

/** A line the signed-in owner types after seeing the money in the provider app. */
export async function ingestManual(core: Core, method: Method, trxId: string, amountMinor: number, reason: string): Promise<IngestResult> {
  const def = methodDef(method);
  return ingestDraft(
    core,
    {
      source: 'manual',
      method,
      trxId,
      kind: 'received',
      amountMinor,
      currency: def.currency,
      receivedAt: nowIso(),
      rawText: `Owner entry: ${trxId} +${(amountMinor / 100).toFixed(2)} ${def.currency}. ${reason}`.slice(0, 300),
      sourceRef: 'owner',
      flags: [],
    },
    'owner',
  );
}

export async function listLedger(core: Core, limit = 500): Promise<LedgerEntry[]> {
  const all = await core.store.list<LedgerEntry>(C.ledger, [], 5000);
  return all.sort((a, b) => b.receivedAt.localeCompare(a.receivedAt)).slice(0, limit);
}

/** Ledger entry without the fields that must never reach a browser. */
export function publicLedgerEntry(e: LedgerEntry): Omit<LedgerEntry, 'senderRaw'> {
  const { senderRaw: _senderRaw, ...rest } = e;
  return rest;
}
