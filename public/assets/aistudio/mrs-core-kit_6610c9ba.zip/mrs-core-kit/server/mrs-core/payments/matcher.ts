/**
 * mrs-core — deciding whether a client's claim and a ledger record are the same payment,
 * and whether that can be settled without the owner.
 *
 * Pure function: same inputs, same answer. No I/O.
 *
 * What the client typed is used ONLY to find the record (the transaction id) and to
 * raise doubts. The amount credited always comes from the ledger record - never from
 * the amount the client claims to have sent.
 */
import { methodDef } from '../config.ts';
import type { CheckResult, Invoice, LedgerEntry, Payment, PaymentSettings } from '../types.ts';
import { formatMoney, hoursBetween, lastDigits, normaliseForMatch, toUsdMinor, toleranceMinor } from '../util.ts';
import { dueMinor } from './invoice.ts';
import { confusableKey, extractPayReferences, normalizeTrxId } from './ledger.ts';

export interface MatchContext {
  payment: Payment;
  entry: LedgerEntry;
  invoice: Invoice;
  settings: PaymentSettings;
  /** Other live claims that name the same transaction id for a different invoice. */
  competingClaims: number;
  /** Earlier rejected submissions on this invoice. */
  priorRejections: number;
}

export interface MatchVerdict {
  decision: 'auto' | 'review';
  /** USD cents the ledger record is worth for this invoice. */
  creditMinor: number;
  flags: string[];
  riskScore: number;
  checks: CheckResult[];
}

/** Flags that always need the owner. */
const HARD = new Set([
  'kill_switch',
  'source_disabled',
  'ledger_flagged',
  'ledger_not_available',
  'wrong_destination',
  'not_a_direct_transfer',
  'currency_not_accepted',
  'reference_names_other_invoice',
  'contested_transaction',
  'paid_before_invoice',
  'ledger_too_old',
  'over_auto_limit',
  'evidence_reused',
  'sender_mismatch',
  'no_provider_id',
  'reversed',
]);

const SOFT: Record<string, number> = {
  trx_id_typo_corrected: 10,
  claimed_amount_differs: 10,
  claimed_time_differs: 5,
  sender_not_provided: 5,
};

/** How the claimed transaction id relates to the ledger record's id. */
export function compareTrxIds(payment: Pick<Payment, 'trxId'>, entry: Pick<LedgerEntry, 'method' | 'trxId' | 'syntheticId'>): 'exact' | 'typo' | 'different' {
  if (entry.syntheticId) return 'different';
  const claimed = normalizeTrxId(entry.method, payment.trxId);
  const actual = normalizeTrxId(entry.method, entry.trxId);
  if (!claimed || !actual) return 'different';
  if (claimed === actual) return 'exact';
  return confusableKey(claimed) === confusableKey(actual) ? 'typo' : 'different';
}

function senderCheck(payment: Payment, entry: LedgerEntry): 'match' | 'mismatch' | 'not_provided' | 'unknown' {
  const claimed = (payment.senderMask ?? '').trim();
  if (!claimed) return 'not_provided';
  if (!entry.senderRaw) return 'unknown';
  const claimedDigits = lastDigits(claimed, 4);
  const actualDigits = lastDigits(entry.senderRaw, 4);
  if (claimedDigits.length === 4 && actualDigits.length === 4) return claimedDigits === actualDigits ? 'match' : 'mismatch';
  // Names / e-mail addresses (Payoneer, Skrill, Binance nickname): loose containment either way.
  const a = normaliseForMatch(claimed);
  const b = normaliseForMatch(entry.senderRaw);
  if (a.length < 3 || b.length < 3) return 'unknown';
  if (a.includes(b) || b.includes(a)) return 'match';
  const shared = a.split(' ').filter((w) => w.length >= 3 && b.split(' ').includes(w));
  return shared.length > 0 ? 'match' : 'unknown'; // a differing display name is not proof of fraud
}

export function evaluateMatch(ctx: MatchContext): MatchVerdict {
  const { payment, entry, invoice, settings } = ctx;
  const flags: string[] = [];
  const checks: CheckResult[] = [];
  const def = methodDef(entry.method);
  const add = (id: string, label: string, status: CheckResult['status'], detail: string): void => void checks.push({ id, label, status, detail });

  // 1. the record exists and is free
  if (entry.status !== 'unmatched') flags.push('ledger_not_available');
  add('ledger_record', 'Money found in the provider record', entry.status === 'unmatched' ? 'pass' : 'fail', entry.status === 'unmatched' ? `Seen via ${entry.source} at ${entry.receivedAt}.` : 'The matching record has already been used or was set aside.');

  // 2. transaction id
  const idMatch = compareTrxIds(payment, entry);
  if (idMatch === 'typo') flags.push('trx_id_typo_corrected');
  if (entry.syntheticId) flags.push('no_provider_id');
  add('transaction_id', 'Transaction ID', idMatch === 'exact' ? 'pass' : idMatch === 'typo' ? 'warn' : 'fail', idMatch === 'exact' ? 'Matches the provider record exactly.' : idMatch === 'typo' ? 'Matches after correcting look-alike characters (such as O and 0).' : 'The provider record carries no comparable transaction ID.');

  // 3. destination
  const destinationOk = entry.accountId === def.accountId;
  if (!destinationOk) flags.push('wrong_destination');
  add('destination', 'Paid to the official account', destinationOk ? 'pass' : 'fail', destinationOk ? `${def.label}.` : 'The record is for a different account.');

  // 4. kind of transfer and currency
  if (entry.kind !== 'received') flags.push('not_a_direct_transfer');
  if (entry.currency !== def.currency || entry.integrityFlags.includes('currency_not_accepted')) flags.push('currency_not_accepted');

  // 5. integrity of the record itself
  const integrity = entry.integrityFlags.filter((f) => f !== 'currency_not_accepted' && f !== 'reversed');
  if (integrity.length > 0) flags.push('ledger_flagged');
  add('integrity', 'Provider record integrity', integrity.length === 0 ? 'pass' : 'warn', integrity.length === 0 ? 'No irregularities.' : 'The record needs a manual look before it can be used.');

  // 6. amount (from the ledger, in the invoice's terms)
  const creditMinor = toUsdMinor(entry.amountMinor, entry.currency, invoice.rateSnapshot);
  const due = dueMinor(invoice);
  const tolerance = toleranceMinor(invoice.totalMinor, settings.amountToleranceBps, settings.amountToleranceFixedMinor);
  const received = formatMoney(entry.amountMinor, entry.currency);
  if (creditMinor >= due - tolerance) {
    add('amount', 'Amount received', creditMinor > due ? 'warn' : 'pass', creditMinor > due ? `${received} received, which is more than the ${formatMoney(due, 'USD')} due. The extra is recorded for the owner.` : `${received} received; covers the amount due.`);
  } else {
    add('amount', 'Amount received', 'warn', `${received} received (${formatMoney(creditMinor, 'USD')}); ${formatMoney(due - creditMinor, 'USD')} is still due.`);
  }
  const claimedUsd = toUsdMinor(payment.amountMinor, payment.currency, invoice.rateSnapshot);
  if (payment.submittedBy === 'client' && Math.abs(claimedUsd - creditMinor) > Math.max(tolerance, 1)) flags.push('claimed_amount_differs');

  // 7. timing
  const slackMs = settings.timeToleranceMinutes * 60_000;
  const paidBeforeInvoice = Date.parse(entry.receivedAt) < Date.parse(invoice.issuedAt) - slackMs;
  const tooOld = hoursBetween(entry.receivedAt, Date.now()) > settings.reviewWindowDays * 24;
  if (paidBeforeInvoice) flags.push('paid_before_invoice');
  if (tooOld) flags.push('ledger_too_old');
  if (payment.submittedBy === 'client' && hoursBetween(payment.paidAt, entry.receivedAt) > 24) flags.push('claimed_time_differs');
  add('timing', 'Payment time', paidBeforeInvoice || tooOld ? 'warn' : 'pass', paidBeforeInvoice ? 'The transfer was made before this invoice existed.' : tooOld ? 'The transfer is older than the review window.' : 'Made after the invoice was issued.');

  // 8. payer
  const sender = senderCheck(payment, entry);
  if (sender === 'mismatch') flags.push('sender_mismatch');
  if (sender === 'not_provided' && payment.submittedBy === 'client') flags.push('sender_not_provided');
  add('payer', 'Payer', sender === 'match' ? 'pass' : sender === 'mismatch' ? 'fail' : 'skip', sender === 'match' ? 'The payer you named matches the record.' : sender === 'mismatch' ? 'The payer you named differs from the record.' : 'Not compared.');

  // 9. reference written by the payer
  const refs = extractPayReferences(entry.reference);
  const refOk = refs.includes(invoice.paymentReferenceCode);
  if (refs.length > 0 && !refOk) flags.push('reference_names_other_invoice');
  add('reference', 'Payment reference', refOk ? 'pass' : refs.length > 0 ? 'fail' : 'skip', refOk ? `Reference ${invoice.paymentReferenceCode} is on the transfer.` : refs.length > 0 ? 'The transfer carries the reference of a different invoice.' : 'No reference on the transfer.');

  // 10. nobody else claims it
  if (ctx.competingClaims > 0) flags.push('contested_transaction');
  add('unique', 'Single claimant', ctx.competingClaims === 0 ? 'pass' : 'fail', ctx.competingClaims === 0 ? 'No other order claims this transaction.' : 'Another order claims the same transaction.');

  // 11. reused screenshot
  if (payment.evidence.some((e) => e.reusedFromPaymentId)) flags.push('evidence_reused');

  // 11b. the owner reversed this payment once; only the owner may verify it again
  if (payment.flags.includes('reversed') || entry.integrityFlags.includes('reversed')) flags.push('reversed');

  // 12. policy
  if (settings.killSwitch) flags.push('kill_switch');
  if (!settings.autoVerifySources[entry.source]) flags.push('source_disabled');
  const limitMinor = Math.round((settings.autoVerifyLimitsUsd[entry.source] ?? 0) * 100);
  if (creditMinor > limitMinor) flags.push('over_auto_limit');
  add('limit', 'Automatic approval limit', creditMinor > limitMinor ? 'warn' : 'pass', creditMinor > limitMinor ? 'Above the amount that may be approved automatically for this kind of evidence; the owner confirms it.' : 'Within the automatic limit.');

  const unique = [...new Set(flags)];
  const hard = unique.some((f) => HARD.has(f));
  const riskScore = Math.min(100, unique.reduce((sum, f) => sum + (HARD.has(f) ? 100 : (SOFT[f] ?? 0)), 0) + Math.min(30, ctx.priorRejections * 10));
  const decision: MatchVerdict['decision'] = !hard && riskScore < settings.riskThresholdAuto ? 'auto' : 'review';
  return { decision, creditMinor, flags: unique, riskScore, checks };
}

/** Checks shown while no provider record has been found yet. */
export function pendingChecks(payment: Payment, bridgeHealthy: boolean): CheckResult[] {
  return [
    { id: 'submitted', label: 'Claim received', status: 'pass', detail: `Transaction ID ${payment.normalizedTrxId} recorded.` },
    {
      id: 'ledger_record',
      label: 'Money found in the provider record',
      status: 'pending',
      detail: bridgeHealthy ? 'Waiting for the provider to report this transfer. This usually takes a few minutes.' : 'Automatic reporting for this payment method is not connected right now; the owner will confirm it by hand.',
    },
  ];
}
