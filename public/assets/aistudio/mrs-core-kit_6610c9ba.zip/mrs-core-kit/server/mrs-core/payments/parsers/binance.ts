/**
 * mrs-core — Binance Pay history (the owner's own account, read-only API key).
 *
 *   GET https://api.binance.com/sapi/v1/pay/transactions   (signed, weight 3000)
 *
 * It lists every Pay transfer into the account with Binance's own transaction id,
 * amount, asset and time. That is first-hand evidence, so it can settle a claim
 * without the owner.
 *
 * WHERE THE CALL IS MADE FROM MATTERS: Binance refuses requests from United States
 * addresses, and Google Cloud addresses are commonly treated as such (HTTP 451).
 * This site runs on Google Cloud, so the normal set-up is the small poller in
 * collectors/poller.mjs running on the owner's own computer or phone, which signs
 * its reports and posts them to /api/ingest/provider. The direct client below is
 * used by that poller, and by the server itself only if a direct call works.
 *
 * NOT YET CONFIRMED WITH A REAL PAYMENT: that the "Order ID" a payer sees on their
 * receipt is the same string as `transactionId` here. Ids are compared after
 * removing prefixes such as "M_P_" / "P_", and an unmatched claim still reaches the
 * owner with this record beside it.
 */
import { createHmac } from 'node:crypto';
import type { LedgerDraft } from '../ledger.ts';

export interface BinancePayRow {
  orderType?: string;
  transactionId?: string;
  transactionTime?: number;
  amount?: string;
  currency?: string;
  payerInfo?: { name?: string; type?: string; binanceId?: string | number };
  receiverInfo?: { name?: string; binanceId?: string | number; accountId?: string | number };
}

const STABLE = new Set(['USDT', 'USDC']);
const ACCEPTED_TYPES = new Set(['C2C']);

/** Decimal string -> cents, truncating (14.999 USDT is 14.99, never 15.00). */
function centsFloor(amount: string): number {
  const m = /^(\d+)(?:\.(\d+))?$/.exec(amount.trim());
  if (!m) return NaN;
  return Number(m[1]) * 100 + Number(((m[2] ?? '') + '00').slice(0, 2));
}

/** Turns one history row into a ledger draft, or null for rows that are not money coming in. */
export function mapBinancePayRow(row: BinancePayRow, ownUid: string): LedgerDraft | null {
  const amountText = String(row.amount ?? '').trim();
  if (!row.transactionId || !amountText || amountText.startsWith('-')) return null; // outgoing or malformed
  const amountMinor = centsFloor(amountText);
  if (!Number.isFinite(amountMinor) || amountMinor <= 0) return null;

  const flags: string[] = [];
  const asset = String(row.currency ?? '').toUpperCase();
  if (!STABLE.has(asset)) flags.push('currency_not_accepted');
  if (!ACCEPTED_TYPES.has(String(row.orderType ?? '').toUpperCase())) flags.push('unexpected_order_type');

  const receiver = row.receiverInfo?.binanceId;
  if (receiver !== undefined && receiver !== null && String(receiver) !== ownUid) flags.push('wrong_receiver');

  const time = Number(row.transactionTime);
  const receivedAt = Number.isFinite(time) && time > 0 ? new Date(time).toISOString() : '';
  if (!receivedAt) flags.push('time_missing');

  return {
    source: 'api',
    method: 'binance_pay',
    trxId: String(row.transactionId),
    kind: 'received',
    amountMinor,
    currency: 'USD',
    asset,
    senderRaw: row.payerInfo?.name ? String(row.payerInfo.name).slice(0, 60) : undefined,
    receivedAt,
    rawText: `Binance Pay ${row.orderType ?? '?'} +${amountText} ${asset} from ${row.payerInfo?.name ?? 'unknown'} id ${row.transactionId}`,
    sourceRef: `binance:${row.transactionId}`,
    flags,
  };
}

export class BinanceError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export interface BinanceClientOptions {
  apiKey: string;
  apiSecret: string;
  baseUrl?: string;
  fetchFn?: (input: string, init?: RequestInit) => Promise<Response>;
  /** Milliseconds to add to the local clock (set after a -1021 "timestamp" error). */
  clockOffsetMs?: number;
}

/** Reads Pay history since `startTime` (ms). Throws BinanceError with a plain-language reason. */
export async function fetchBinancePayHistory(opts: BinanceClientOptions, startTime: number): Promise<BinancePayRow[]> {
  const fetchFn = opts.fetchFn ?? fetch;
  const base = (opts.baseUrl ?? 'https://api.binance.com').replace(/\/+$/, '');
  const params = new URLSearchParams({
    startTime: String(Math.max(0, Math.floor(startTime))),
    limit: '100',
    recvWindow: '10000',
    timestamp: String(Date.now() + (opts.clockOffsetMs ?? 0)),
  });
  const signature = createHmac('sha256', opts.apiSecret).update(params.toString()).digest('hex');
  const res = await fetchFn(`${base}/sapi/v1/pay/transactions?${params.toString()}&signature=${signature}`, {
    headers: { 'X-MBX-APIKEY': opts.apiKey },
    signal: AbortSignal.timeout(15_000),
  });
  const text = await res.text();
  if (res.status === 451 || /restricted location/i.test(text)) {
    throw new BinanceError('restricted_location', 'Binance refuses requests from this server location. Run collectors/poller.mjs on your own computer instead.');
  }
  if (res.status === 418 || res.status === 429) throw new BinanceError('rate_limited', 'Binance rate limit reached; will retry later.');
  let json: { code?: string | number; message?: string; msg?: string; data?: BinancePayRow[] };
  try {
    json = JSON.parse(text) as typeof json;
  } catch {
    throw new BinanceError('bad_response', `Binance answered HTTP ${res.status} with a non-JSON body.`);
  }
  if (Number(json.code) === -1021) throw new BinanceError('clock_skew', 'Clock differs from Binance server time.');
  if (Number(json.code) === -2015 || Number(json.code) === -2014) {
    throw new BinanceError('bad_key', 'Binance rejected the API key (wrong key, missing read permission, or IP not allowed).');
  }
  if (!res.ok || (json.code !== undefined && String(json.code) !== '000000')) {
    throw new BinanceError('api_error', `Binance error ${json.code ?? res.status}: ${json.message ?? json.msg ?? 'unknown'}`);
  }
  return Array.isArray(json.data) ? json.data : [];
}
