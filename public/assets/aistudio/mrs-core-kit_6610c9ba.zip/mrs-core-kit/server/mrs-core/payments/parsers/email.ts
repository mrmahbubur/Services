/**
 * mrs-core — provider e-mail notices (Payoneer, Skrill, Binance) as payment evidence.
 *
 * Payoneer has no API for individual accounts; Skrill's needs a merchant account and
 * a fixed IP. What every provider does do is e-mail the account owner when money
 * arrives. A small script in the owner's Gmail forwards those notices here.
 *
 * Two separate questions are answered, in this order:
 *
 *  1. Is the e-mail really from the provider?  Decided ONLY by Gmail's own
 *     Authentication-Results header (dmarc=pass for the provider's domain). The
 *     display name, the From text and the body prove nothing.
 *
 *  2. What does it say?  Read with fixed patterns, never with an AI model, because
 *     the payer's name and note are printed inside the e-mail. Anything unclear
 *     (two different amounts, no transaction id, "pending") is flagged so that it
 *     can only be settled by the owner.
 *
 * LIMIT: the exact wording of these notices was not available when this was written.
 * Use the admin "test a message" tool with one real notice per provider before
 * relying on automatic settlement from e-mail.
 */
import type { Method } from '../../types.ts';
import { sha256Hex, toMinor } from '../../util.ts';

const PROVIDER_DOMAINS: { method: Method; domain: string }[] = [
  { method: 'payoneer', domain: 'payoneer.com' },
  { method: 'skrill', domain: 'skrill.com' },
  { method: 'binance_pay', domain: 'binance.com' },
];

function underDomain(host: string, domain: string): boolean {
  const h = host.toLowerCase().replace(/^.*@/, '').replace(/[>\s]+$/g, '');
  return h === domain || h.endsWith('.' + domain);
}

export interface AuthVerdict {
  ok: boolean;
  method?: Method;
  domain?: string;
  reason?: string;
}

/**
 * Reads Gmail's verdict. `authResults` must be the FIRST "Authentication-Results"
 * header of the raw message - the one Gmail itself added on receipt. (A sender can
 * add look-alike headers, but only below Gmail's.)
 */
export function verifyEmailAuth(authResults: string, fromHeader: string): AuthVerdict {
  const header = authResults.replace(/\s+/g, ' ').trim();
  if (!header) return { ok: false, reason: 'no Authentication-Results header' };

  const [authserv = ''] = header.split(';');
  if (authserv.trim().toLowerCase() !== 'mx.google.com') {
    return { ok: false, reason: 'verdict was not issued by Gmail (mx.google.com)' };
  }

  const dmarc = /\bdmarc=(\w+)/i.exec(header)?.[1]?.toLowerCase();
  if (dmarc !== 'pass') return { ok: false, reason: `dmarc=${dmarc ?? 'missing'}` };

  const headerFrom = /\bheader\.from=([^\s;)]+)/i.exec(header)?.[1]?.toLowerCase() ?? '';
  const provider = PROVIDER_DOMAINS.find((p) => underDomain(headerFrom, p.domain));
  if (!provider) return { ok: false, reason: `sender domain "${headerFrom || 'unknown'}" is not a payment provider` };

  // The visible From address must be in the same domain family as the authenticated one.
  const fromAddr = /<([^>]+)>/.exec(fromHeader)?.[1] ?? fromHeader.trim();
  if (!underDomain(fromAddr, provider.domain)) {
    return { ok: false, reason: 'visible From address does not match the authenticated domain' };
  }
  return { ok: true, method: provider.method, domain: provider.domain };
}

export interface ParsedEmail {
  /** credit: an incoming payment. not_payment: provider mail about something else. unparsed: unclear. */
  outcome: 'credit' | 'not_payment' | 'unparsed';
  method: Method;
  trxId?: string;
  syntheticId?: boolean;
  amountMinor?: number;
  asset?: string;
  sender?: string;
  flags: string[];
  reason?: string;
}

const AMOUNT_PATTERNS = [
  // $1,234.56 / US$ 20 / USD 20.00
  /(?:US\$|USD\s?\$?|\$)\s?(\d[\d,]*(?:\.\d{1,8})?)(?!\d)/gi,
  // 20.00 USD / 15 USDT
  /(?<![\d.,])(\d[\d,]*(?:\.\d{1,8})?)\s?(USD|USDT|USDC|FDUSD|EUR|GBP|BDT|BTC|BNB|ETH)\b/gi,
];

const INCOMING = [
  /\byou(?:'|’)?ve received\b/i,
  /\byou have received\b/i,
  /\byou received\b/i,
  /\bpayment received\b/i,
  /\breceived a payment\b/i,
  /\bpayment receive successful\b/i,
  /\bmoney received\b/i,
  /\bsent you (?:a payment|money|\$|usd|[\d])/i,
  /\bhas (?:paid|sent) you\b/i,
  /\b(?:was|has been|were) (?:loaded|credited|added) to your\b/i,
  /\bincoming (?:payment|transfer)\b/i,
];

const NOT_INCOMING = [
  /\byou(?:'|’)?ve sent\b/i,
  /\byou (?:have )?sent\b/i,
  /\bpayment sent\b/i,
  /\bwithdraw(?:al|n)?\b/i,
  /\b(?:requested|requests|is requesting|request for) (?:a )?payment\b/i,
  /\bpayment request\b/i,
  /\binvoice (?:from|sent)\b/i,
  /\b(?:declined|failed|cancell?ed|reversed|refunded|returned|expired)\b/i,
];

const PENDING = /\b(pending|under review|being reviewed|on hold|awaiting (?:approval|review)|not yet available|will be available)\b/i;

const ID_PATTERN = /\b(?:transaction|payment|order|transfer|reference)\s*(?:id|no\.?|number|#)\s*[:#]?\s*([A-Za-z0-9][A-Za-z0-9_-]{4,40})\b/gi;

interface Found {
  value: string;
  asset: string;
  index: number;
}

function findAmounts(text: string): Found[] {
  const out: Found[] = [];
  for (const re of AMOUNT_PATTERNS) {
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      const asset = (m[2] ?? 'USD').toUpperCase();
      out.push({ value: (m[1] ?? '').replace(/,/g, ''), asset, index: m.index });
    }
  }
  return out.sort((a, b) => a.index - b.index);
}

const USD_LIKE = new Set(['USD', 'USDT', 'USDC']);

/**
 * Extracts the facts from an AUTHENTICATED provider notice.
 * `messageId` is Gmail's id for the message; it seeds the id when the provider gives none.
 */
export function parseProviderEmail(method: Method, subject: string, body: string, messageId: string): ParsedEmail {
  const subj = subject.replace(/\s+/g, ' ').trim().slice(0, 300);
  const text = body.replace(/\r/g, '').replace(/[ \t\u00a0]+/g, ' ').slice(0, 8000);
  const whole = `${subj}\n${text}`;
  const flags: string[] = [];

  if (NOT_INCOMING.some((re) => re.test(subj))) return { outcome: 'not_payment', method, flags, reason: 'subject is not about incoming money' };
  if (!INCOMING.some((re) => re.test(whole))) return { outcome: 'not_payment', method, flags, reason: 'no "received" wording' };
  if (NOT_INCOMING.some((re) => re.test(whole))) flags.push('mixed_wording');
  if (PENDING.test(whole)) flags.push('pending_at_provider');

  // Amount: prefer the subject line (written by the provider before any payer text).
  const inSubject = findAmounts(subj);
  const inBody = findAmounts(text);
  const candidates = inSubject.length > 0 ? inSubject : inBody;
  const first = candidates[0];
  if (!first) return { outcome: 'unparsed', method, flags, reason: 'no amount found' };

  const distinct = new Set([...inSubject, ...inBody].map((a) => `${Number(a.value)}|${USD_LIKE.has(a.asset) ? 'USD' : a.asset}`));
  if (distinct.size > 1) flags.push('multiple_amounts');

  const amountMinor = toMinor(first.value);
  if (!Number.isFinite(amountMinor) || amountMinor <= 0) return { outcome: 'unparsed', method, flags, reason: 'amount unreadable' };
  if (!USD_LIKE.has(first.asset)) flags.push('currency_not_accepted');

  // Transaction id
  ID_PATTERN.lastIndex = 0;
  const ids = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = ID_PATTERN.exec(whole)) !== null) {
    const id = (m[1] ?? '').toUpperCase();
    if (/\d/.test(id)) ids.add(id); // a real id contains digits; avoids matching words
  }
  let trxId: string;
  let syntheticId = false;
  if (ids.size === 1) {
    trxId = [...ids][0] ?? '';
  } else {
    if (ids.size > 1) flags.push('multiple_ids');
    else flags.push('no_provider_id');
    trxId = 'EM' + sha256Hex(`${method}|${messageId}`).slice(0, 14).toUpperCase();
    syntheticId = true;
  }

  const sender = /\bfrom\s+([^\n.,;:()]{2,60})/i.exec(subj)?.[1]?.trim() ?? /\b(?:from|sender|payer)\s*:?\s+([^\n.,;:()]{2,60})/i.exec(text)?.[1]?.trim();

  return { outcome: 'credit', method, trxId, syntheticId, amountMinor, asset: first.asset, sender, flags };
}
