/**
 * mrs-core — bKash / Nagad SMS parser.
 *
 * Personal bKash and Nagad wallets have no API. The only machine-readable proof that
 * money arrived is the SMS the operator sends to the wallet's SIM. The owner's phone
 * forwards those SMS to POST /api/ingest/sms, and this file turns them into facts.
 *
 * Rules that matter:
 *  - Which wallet a message belongs to is decided by the SENDER ID the phone reports
 *    (bKash / NAGAD short codes), never by words inside the message.
 *  - The payer controls the "Reference" text, and it is printed inside the SMS. So a
 *    message in which any key field appears twice is treated as ambiguous and is
 *    never settled automatically.
 *  - Anything that is not a transaction (OTP, PIN, promotion) is dropped unread:
 *    the caller is told to ignore it and must not store its text.
 */
import type { LedgerKind } from '../../types.ts';
import { parseDhakaDateTime, toMinor } from '../../util.ts';

export type Wallet = 'bkash' | 'nagad';

export interface SenderRules {
  bkash: string[];
  nagad: string[];
}

export const DEFAULT_SENDERS: SenderRules = {
  bkash: ['bkash', '16247'],
  nagad: ['nagad', '16167'],
};

export function senderRulesFromEnv(env: Record<string, string | undefined> = process.env): SenderRules {
  const list = (v: string | undefined, fallback: string[]): string[] => {
    const items = (v ?? '')
      .split(',')
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);
    return items.length > 0 ? items : fallback;
  };
  return { bkash: list(env.MRS_SMS_SENDERS_BKASH, DEFAULT_SENDERS.bkash), nagad: list(env.MRS_SMS_SENDERS_NAGAD, DEFAULT_SENDERS.nagad) };
}

/** Maps the sender id reported by the phone to a wallet, or null when it is not an operator id. */
export function walletForSender(senderId: string, rules: SenderRules = DEFAULT_SENDERS): Wallet | null {
  const s = senderId.trim().toLowerCase();
  if (!s) return null;
  if (rules.bkash.includes(s)) return 'bkash';
  if (rules.nagad.includes(s)) return 'nagad';
  return null;
}

export interface ParsedSms {
  /**
   * credit       money came IN and the message carries a transaction id -> ledger entry
   * balance_only a real wallet movement that is not a client payment (cash out, etc.);
   *              used only to keep the running balance in step
   * ignored      not a transaction (OTP, promotion). Do not store the text.
   * unparsed     looks like money but could not be read safely -> quarantine + alert
   */
  outcome: 'credit' | 'balance_only' | 'ignored' | 'unparsed';
  wallet: Wallet;
  kind?: LedgerKind;
  trxId?: string;
  amountMinor?: number;
  feeMinor?: number;
  sender?: string;
  reference?: string;
  balanceMinor?: number;
  /** Signed change of the wallet balance this message implies; null when unknown. */
  deltaMinor: number | null;
  /** Provider's own timestamp (ISO, UTC) or null when the message has none. */
  providerTime: string | null;
  flags: string[];
  reason?: string;
}

const NUM = String.raw`([\d,]+(?:\.\d{1,2})?)`;
const TK = String.raw`(?:Tk|BDT|৳)\.?\s*`;

const RE = {
  trx: /\b(?:Trx\s*ID|Txn\s*ID|TxnId|Transaction\s*ID)\s*[:#]?\s*([A-Za-z0-9]{6,16})\b/gi,
  balance: new RegExp(String.raw`\b(?:New\s+)?Bal(?:ance)?\.?\s*:?\s*(?:${TK})?${NUM}`, 'gi'),
  fee: new RegExp(String.raw`\b(?:Fee|Charge)\s*:?\s*${TK}${NUM}`, 'gi'),
  anyAmount: new RegExp(String.raw`${TK}${NUM}`, 'i'),
  // bKash family: "You have received Tk 1,500.00 from 01712345678."
  bkashReceived: new RegExp(String.raw`You have received\s+(?:(?:a\s+)?(?:deposit|payment)\s+of\s+)?${TK}${NUM}\s+from\s+(.+?)(?:\.\s|\.$|\s+Ref\b|\s+Fee\b|\s+Balance\b|$)`, 'i'),
  bkashCashIn: new RegExp(String.raw`Cash\s*In\s+${TK}${NUM}\s+from\s+(.+?)\s+successful`, 'i'),
  // Nagad family: "Money Received. Amount: Tk 500.00 Sender: 01712345678 ..."
  labelAmount: new RegExp(String.raw`\bAmount\s*:\s*(?:${TK})?${NUM}`, 'i'),
  labelSender: /\b(?:Sender|From|Uddokta|Agent)\s*:\s*(\+?[\d*xX•]{6,16})/i,
  refInline: /\bRef(?:erence)?\b\s*:?\s*(.{0,60}?)(?=\.\s|\.$|\s+Fee\b|\s+Balance\b|\s+at\s+\d|\s+(?:Trx\s*ID|Txn\s*ID|TxnId)\b|\n|$)/i,
  otp: /\b(OTP|one[- ]time|verification code|security code|passcode|password|reset your pin|your pin is|login code)\b/i,
  moneyIn: /\b(received|cash\s*in|add\s*money|credited|refund(ed)?|cashback|bonus|interest|remittance|reversal)\b/i,
  moneyOut: /\b(send\s*money|sent|cash\s*out|payment|paid|recharge|bill|withdraw(n|al)?|transfer(red)?\s+to|purchase|donation|debited)\b/i,
};

function all(text: string, re: RegExp): RegExpExecArray[] {
  re.lastIndex = 0;
  const out: RegExpExecArray[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    out.push(m);
    if (m[0].length === 0) re.lastIndex += 1;
  }
  return out;
}

function cleanParty(raw: string): string {
  return raw.replace(/[\s.]+$/g, '').trim().slice(0, 40);
}

function cleanReference(raw: string | undefined): string | undefined {
  if (!raw) return undefined;
  const v = raw.replace(/[\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!v || /^(n\/?a|none|nil|-+)$/i.test(v)) return undefined;
  return v.slice(0, 60);
}

/**
 * Parses one SMS that the phone reported as coming from `wallet`'s operator id.
 * Pure function: no I/O, no clock.
 */
export function parseWalletSms(wallet: Wallet, rawText: string): ParsedSms {
  const text = rawText.replace(/\r/g, '').replace(/[ \t]+/g, ' ').trim();
  const flat = text.replace(/\n+/g, ' ');
  const base = { wallet, deltaMinor: null as number | null, providerTime: parseDhakaDateTime(flat), flags: [] as string[] };

  const trxMatches = all(flat, RE.trx);
  const balMatches = all(flat, RE.balance);
  const feeMatches = all(flat, RE.fee);
  const balanceMinor = balMatches.length > 0 ? toMinor(balMatches[0]?.[1] ?? '') : undefined;
  const feeMinor = feeMatches.length > 0 ? toMinor(feeMatches[0]?.[1] ?? '') : 0;
  const hasMoney = RE.anyAmount.test(flat);

  // Not a transaction at all -> never keep the text.
  if (trxMatches.length === 0) {
    if (RE.otp.test(flat) || !hasMoney) return { ...base, outcome: 'ignored', reason: 'not a transaction message' };
    if (balanceMinor !== undefined && Number.isFinite(balanceMinor)) {
      // e.g. an interest or fee notice without a transaction id: keep the balance in step.
      return { ...base, outcome: 'balance_only', balanceMinor, reason: 'balance notice without transaction id' };
    }
    return { ...base, outcome: 'unparsed', reason: 'mentions money but has no transaction id' };
  }

  const flags: string[] = [];
  if (trxMatches.length > 1 || balMatches.length > 1 || feeMatches.length > 1) flags.push('ambiguous_message');

  const trxId = (trxMatches[0]?.[1] ?? '').toUpperCase();

  // ---- incoming money
  let kind: LedgerKind | undefined;
  let amountText: string | undefined;
  let party: string | undefined;

  const received = RE.bkashReceived.exec(flat);
  const cashIn = RE.bkashCashIn.exec(flat);
  const labelled = /\b(Money Received|Cash\s*In Received|Received)\b/i.test(flat) ? RE.labelAmount.exec(flat) : null;

  if (received) {
    kind = 'received';
    amountText = received[1];
    party = cleanParty(received[2] ?? '');
  } else if (cashIn) {
    kind = 'cash_in';
    amountText = cashIn[1];
    party = cleanParty(cashIn[2] ?? '');
  } else if (labelled) {
    kind = /\bCash\s*In\b/i.test(flat) ? 'cash_in' : /\bMoney Received\b/i.test(flat) ? 'received' : 'other_credit';
    amountText = labelled[1];
    party = RE.labelSender.exec(flat)?.[1];
  }

  if (kind && amountText) {
    const amountMinor = toMinor(amountText);
    if (!Number.isFinite(amountMinor) || amountMinor <= 0) {
      return { ...base, outcome: 'unparsed', reason: 'could not read the amount', flags };
    }
    if ((flat.match(/You have received/gi)?.length ?? 0) > 1 || (flat.match(/Money Received/gi)?.length ?? 0) > 1) {
      if (!flags.includes('ambiguous_message')) flags.push('ambiguous_message');
    }
    if (balanceMinor === undefined || !Number.isFinite(balanceMinor)) flags.push('balance_missing');
    const reference = cleanReference(RE.refInline.exec(flat)?.[1]);
    return {
      ...base,
      outcome: 'credit',
      kind,
      trxId,
      amountMinor,
      feeMinor,
      sender: party || undefined,
      reference,
      balanceMinor: balanceMinor !== undefined && Number.isFinite(balanceMinor) ? balanceMinor : undefined,
      deltaMinor: amountMinor,
      flags,
    };
  }

  // ---- any other wallet movement: only the running balance matters
  if (balanceMinor !== undefined && Number.isFinite(balanceMinor)) {
    const amt = RE.anyAmount.exec(flat);
    const amountMinor = amt ? toMinor(amt[1] ?? '') : NaN;
    let deltaMinor: number | null = null;
    if (Number.isFinite(amountMinor)) {
      if (RE.moneyIn.test(flat) && !RE.moneyOut.test(flat)) deltaMinor = amountMinor;
      else if (RE.moneyOut.test(flat) && !RE.moneyIn.test(flat)) deltaMinor = -(amountMinor + (Number.isFinite(feeMinor) ? feeMinor : 0));
    }
    return { ...base, outcome: 'balance_only', trxId, balanceMinor, deltaMinor, flags, reason: 'wallet movement that is not an incoming payment' };
  }

  if (RE.moneyIn.test(flat)) return { ...base, outcome: 'unparsed', trxId, flags, reason: 'looks like incoming money in an unknown format' };
  return { ...base, outcome: 'ignored', reason: 'outgoing or informational message' };
}
