/**
 * mrs-core — statement lines supplied by the owner.
 *
 * Works for every payment method and needs no bridge: the owner exports or copies
 * the provider's own transaction list and imports it. Because it comes from the
 * signed-in owner, it is treated as first-hand evidence.
 *
 * Two inputs are accepted:
 *   rows  [{ trxId, amount, sender, date }]        (what the existing admin screen sends)
 *   csv   text with a header row                    (provider export, e.g. Skrill history)
 */
import type { Currency, Method } from '../../types.ts';
import { parseDhakaDateTime, toMinor } from '../../util.ts';
import type { LedgerDraft } from '../ledger.ts';

export interface StatementRow {
  trxId?: unknown;
  amount?: unknown;
  sender?: unknown;
  date?: unknown;
  reference?: unknown;
}

export interface StatementResult {
  drafts: LedgerDraft[];
  skipped: { line: number; reason: string }[];
}

function parseWhen(value: unknown): string {
  const raw = typeof value === 'string' ? value.trim() : '';
  if (!raw) return '';
  const dhaka = /^\d{1,2}\/\d{1,2}\/\d{4}/.test(raw) ? parseDhakaDateTime(raw) : null;
  if (dhaka) return dhaka;
  const t = Date.parse(raw);
  return Number.isFinite(t) ? new Date(t).toISOString() : '';
}

export function draftsFromRows(method: Method, currency: Currency, rows: StatementRow[], fileName: string): StatementResult {
  const drafts: LedgerDraft[] = [];
  const skipped: StatementResult['skipped'] = [];
  rows.slice(0, 2000).forEach((row, i) => {
    const line = i + 1;
    const trxId = typeof row.trxId === 'string' ? row.trxId.trim() : '';
    const amountMinor = typeof row.amount === 'number' ? toMinor(row.amount) : toMinor(String(row.amount ?? ''));
    if (!/^[A-Za-z0-9_-]{5,48}$/.test(trxId)) return void skipped.push({ line, reason: 'transaction id missing or malformed' });
    if (!Number.isFinite(amountMinor) || amountMinor <= 0) return void skipped.push({ line, reason: 'amount is not a positive number (only money received is imported)' });
    const flags: string[] = [];
    const receivedAt = parseWhen(row.date);
    if (!receivedAt) flags.push('time_missing');
    drafts.push({
      source: 'statement',
      method,
      trxId,
      kind: 'received',
      amountMinor,
      currency,
      senderRaw: typeof row.sender === 'string' && row.sender.trim() ? row.sender.trim().slice(0, 60) : undefined,
      reference: typeof row.reference === 'string' ? row.reference.trim().slice(0, 60) || undefined : undefined,
      receivedAt,
      rawText: `Statement ${fileName} line ${line}: ${trxId} +${(amountMinor / 100).toFixed(2)} ${currency}`,
      sourceRef: `statement:${fileName}:${line}`,
      flags,
    });
  });
  return { drafts, skipped };
}

/** Minimal RFC-4180 CSV reader (quotes, embedded commas and newlines). */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  const src = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',' || ch === ';' || ch === '\t') {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && src[i + 1] === '\n') i++;
      row.push(cell);
      cell = '';
      if (row.some((c) => c.trim() !== '')) rows.push(row);
      row = [];
    } else cell += ch;
  }
  row.push(cell);
  if (row.some((c) => c.trim() !== '')) rows.push(row);
  return rows;
}

function findColumn(header: string[], patterns: RegExp[]): number {
  for (const re of patterns) {
    const i = header.findIndex((h) => re.test(h.trim()));
    if (i >= 0) return i;
  }
  return -1;
}

/**
 * Reads a provider CSV export by its header names (order does not matter).
 * Recognises the Skrill account-history layout
 *   ID, Time (CET), Type, Transaction Details, [-] USD, [+] USD, Status, Balance, Reference, ...
 * and generic exports that have an id, an amount / credit column and a date.
 */
export function draftsFromCsv(method: Method, currency: Currency, csv: string, fileName: string): StatementResult {
  const table = parseCsv(csv);
  const skipped: StatementResult['skipped'] = [];
  if (table.length < 2) return { drafts: [], skipped: [{ line: 1, reason: 'no data rows' }] };
  const header = table[0] ?? [];

  const col = {
    id: findColumn(header, [/^id$/i, /transaction\s*id/i, /^trx\s*id$/i, /^txn\s*id$/i, /payment\s*id/i, /reference\s*(id|no|number)/i]),
    credit: findColumn(header, [/^\[\+\]/, /^credit/i, /amount\s*received/i, /^received/i, /^amount$/i, /^amount\b/i]),
    debit: findColumn(header, [/^\[-\]/, /^debit/i]),
    when: findColumn(header, [/^time/i, /^date/i, /created/i, /completed/i]),
    type: findColumn(header, [/^type$/i, /transaction\s*type/i]),
    status: findColumn(header, [/^status$/i]),
    details: findColumn(header, [/details/i, /description/i, /^from$/i, /sender/i, /payer/i]),
    reference: findColumn(header, [/^reference$/i, /^note$/i, /^memo$/i, /message/i]),
  };
  if (col.id < 0 || col.credit < 0) {
    return { drafts: [], skipped: [{ line: 1, reason: 'header needs a transaction id column and an amount / credit column' }] };
  }

  const rows: StatementRow[] = [];
  const lineOf: number[] = [];
  table.slice(1).forEach((cells, i) => {
    const line = i + 2;
    const get = (index: number): string => (index >= 0 ? (cells[index] ?? '').trim() : '');
    const credit = get(col.credit).replace(/[^\d.,-]/g, '');
    const status = get(col.status).toLowerCase();
    const type = get(col.type).toLowerCase();
    if (!credit || credit === '0' || credit.startsWith('-')) return void skipped.push({ line, reason: 'no money received on this line' });
    if (col.debit >= 0 && get(col.debit).replace(/[^\d.]/g, '') !== '' && Number(get(col.debit).replace(/[^\d.]/g, '')) > 0) {
      return void skipped.push({ line, reason: 'outgoing line' });
    }
    if (status && !/^(processed|completed|complete|success|successful|settled|paid)$/.test(status)) {
      return void skipped.push({ line, reason: `status is "${status}", not completed` });
    }
    if (type && /(withdraw|send|sent|fee|purchase|pay(ment)? out|refund)/.test(type) && !/receive/.test(type)) {
      return void skipped.push({ line, reason: `type "${type}" is not money received` });
    }
    rows.push({ trxId: get(col.id), amount: credit, sender: get(col.details), date: get(col.when), reference: get(col.reference) });
    lineOf.push(line);
  });

  const result = draftsFromRows(method, currency, rows, fileName);
  for (const s of result.skipped) skipped.push({ line: lineOf[s.line - 1] ?? s.line, reason: s.reason });
  return { drafts: result.drafts, skipped: skipped.sort((a, b) => a.line - b.line) };
}
