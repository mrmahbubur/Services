/**
 * mrs-core — payment claims and settlement.
 *
 * The one rule: an invoice is credited only inside settle(), and settle() only runs
 * with a ledger record of money that actually arrived. One record settles one claim,
 * once - enforced in a single database transaction.
 */
import { PAYMENT_METHODS, USD_METHODS, methodDef, resolveMethod } from '../config.ts';
import type { Core } from '../core.ts';
import { bridgeStatuses, getSettings } from '../core.ts';
import { readAuditHead, writeAudit } from '../audit.ts';
import { C } from '../store/store.ts';
import type { CheckResult, Currency, EvidenceFile, Invoice, LedgerEntry, Method, Order, Payment } from '../types.ts';
import { HttpError, clampText, formatMoney, fromMinor, hoursBetween, nowIso, sha256Hex, toMinor, toUsdMinor } from '../util.ts';
import { applyCredit, dueMinor, fullyPaid, refreshInvoice } from './invoice.ts';
import { confusableKey, extractPayReferences, ingestManual, normalizeTrxId, trustBalanceFromEntry, trxKeyOf } from './ledger.ts';
import { BALANCE_FLAGS } from './balance.ts';
import { compareTrxIds, evaluateMatch, pendingChecks } from './matcher.ts';

const GENERIC_TRX = /^[A-Z0-9]{5,40}$/;

function paymentIdFor(invoiceId: string, normalizedTrxId: string): string {
  return 'PMT-' + sha256Hex(`${invoiceId}|${normalizedTrxId}`).slice(0, 16).toUpperCase();
}

/**
 * Which ledgers to search for a claim. bKash and Nagad are received on the SAME
 * number, so customers pick the wrong one; the claim is looked up in both and the
 * payment takes the method of the record that is found.
 */
function candidatesOf(method: Payment['method']): Method[] {
  if (method === 'usd_unspecified') return [...USD_METHODS];
  if (method === 'bkash') return ['bkash', 'nagad'];
  if (method === 'nagad') return ['nagad', 'bkash'];
  return [method];
}

function trxPatternOk(method: Payment['method'], rawTrx: string): boolean {
  if (method === 'usd_unspecified') return GENERIC_TRX.test(normalizeTrxId(method, rawTrx));
  return candidatesOf(method).some((m) => methodDef(m).trxIdPattern.test(normalizeTrxId(m, rawTrx)));
}

async function loadInvoice(core: Core, invoiceOrOrderId: string): Promise<Invoice | null> {
  const direct = await core.store.get<Invoice>(C.invoices, invoiceOrOrderId);
  if (direct) return direct;
  const order = await core.store.get<Order>(C.orders, invoiceOrOrderId);
  return order?.invoiceId ? core.store.get<Invoice>(C.invoices, order.invoiceId) : null;
}

/** What a client is allowed to see of their own payment. */
export function clientView(p: Payment): Record<string, unknown> {
  return {
    id: p.id,
    paymentId: p.id,
    invoiceId: p.invoiceId,
    orderId: p.orderId,
    method: p.method,
    trxId: p.trxId,
    normalizedTrxId: p.normalizedTrxId,
    amount: fromMinor(p.amountMinor),
    currency: p.currency,
    status: p.status,
    verified: p.status === 'verified',
    creditedUSD: p.creditedMinor !== undefined ? fromMinor(p.creditedMinor) : undefined,
    ownerConfirmationStatus: p.ownerConfirmationStatus,
    decidedBy: p.decidedBy,
    decisionReason: p.status === 'rejected' ? p.decisionReason : undefined,
    evidenceCount: p.evidence.length,
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
  };
}

// ---------------------------------------------------------------- submit a claim

export interface ClaimInput {
  invoiceId?: unknown;
  method?: unknown;
  methodId?: unknown;
  transactionId?: unknown;
  amount?: unknown;
  currency?: unknown;
  paidAt?: unknown;
  senderMask?: unknown;
  note?: unknown;
  idempotencyKey?: unknown;
}

export interface ClaimResult {
  payment: Payment;
  created: boolean;
}

/**
 * Records "I paid, here is the transaction id". This never credits anything by
 * itself; it only tells the matcher which ledger record to look for.
 * `actingClientId` is the signed-in client, or null when the owner submits for a client.
 */
export async function submitClaim(core: Core, input: ClaimInput, actingClientId: string | null): Promise<ClaimResult> {
  const settings = await getSettings(core.store);
  const invoice = await loadInvoice(core, clampText(input.invoiceId, 60));
  if (!invoice) throw new HttpError(404, 'invoice_not_found', 'No invoice with that number.');
  if (actingClientId !== null && invoice.clientId !== actingClientId) throw new HttpError(404, 'invoice_not_found', 'No invoice with that number.');
  if (invoice.status === 'void') throw new HttpError(409, 'invoice_void', 'This invoice was cancelled.');
  if (fullyPaid(invoice)) throw new HttpError(409, 'already_paid', 'This invoice is already paid in full.');

  const resolved = resolveMethod({ methodId: input.methodId, method: input.method });
  const currencyIn = clampText(input.currency, 5).toUpperCase();
  let method: Payment['method'];
  if (resolved) method = resolved;
  else if (currencyIn === 'USD') method = 'usd_unspecified'; // older page sends "bank_transfer" for all USD methods
  else throw new HttpError(400, 'unknown_method', 'Choose one of the listed payment methods.');
  const currency: Currency = method === 'usd_unspecified' ? 'USD' : methodDef(method).currency;

  const rawTrx = clampText(input.transactionId, 64);
  const normalized = normalizeTrxId(method, rawTrx);
  if (!trxPatternOk(method, rawTrx)) {
    const hint = method === 'usd_unspecified' ? 'letters and digits only' : methodDef(method).trxIdHint;
    throw new HttpError(400, 'bad_transaction_id', `That does not look like a transaction ID for this method (${hint}).`);
  }

  const amountMinor = typeof input.amount === 'number' ? toMinor(input.amount) : toMinor(String(input.amount ?? ''));
  if (!Number.isFinite(amountMinor) || amountMinor <= 0 || amountMinor > 100_000_000) throw new HttpError(400, 'bad_amount', 'Enter the amount you sent.');

  const paidAtMs = Date.parse(clampText(input.paidAt, 40));
  const paidAt = Number.isFinite(paidAtMs) && paidAtMs <= Date.now() + 3600_000 ? new Date(paidAtMs).toISOString() : nowIso();

  const id = paymentIdFor(invoice.invoiceId, normalized);
  const existing = await core.store.get<Payment>(C.payments, id);
  if (existing) {
    if (existing.status === 'rejected') throw new HttpError(409, 'previously_rejected', 'This transaction ID was already reviewed and rejected for this invoice. Please contact us.');
    return { payment: existing, created: false };
  }

  const onInvoice = await core.store.list<Payment>(C.payments, [['invoiceId', invoice.invoiceId]], 100);
  if (onInvoice.length >= settings.maxSubmissionsPerInvoice) {
    throw new HttpError(429, 'too_many_submissions', 'Too many payment submissions for this invoice. Please contact us so we can check it by hand.');
  }

  const sameTrx = (await core.store.list<Payment>(C.payments, [['normalizedTrxId', normalized]], 50)).filter((p) => p.invoiceId !== invoice.invoiceId && p.status !== 'rejected');
  if (sameTrx.some((p) => p.status === 'verified')) {
    throw new HttpError(409, 'trx_already_used', 'This transaction ID has already been used for another payment.');
  }

  const now = nowIso();
  const payment: Payment = {
    id,
    invoiceId: invoice.invoiceId,
    orderId: invoice.orderId,
    clientId: invoice.clientId,
    clientName: invoice.clientName,
    method,
    methodCandidates: candidatesOf(method),
    trxId: rawTrx,
    normalizedTrxId: normalized,
    trxKey: method === 'usd_unspecified' ? `usd:${normalized}` : trxKeyOf(method, normalized),
    claimKey: `${invoice.invoiceId}|${normalized}`,
    amountMinor,
    currency,
    paidAt,
    ...(clampText(input.senderMask, 60) ? { senderMask: clampText(input.senderMask, 60) } : {}),
    ...(clampText(input.note, 300) ? { note: clampText(input.note, 300) } : {}),
    status: 'awaiting_ledger',
    riskScore: 0,
    flags: sameTrx.length > 0 ? ['contested_transaction'] : [],
    checkResults: [],
    evidence: [],
    submittedBy: actingClientId === null ? 'owner' : 'client',
    ...(clampText(input.idempotencyKey, 120) ? { idempotencyKey: clampText(input.idempotencyKey, 120) } : {}),
    createdAt: now,
    updatedAt: now,
  };

  const created = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    if (await t.get<Payment>(C.payments, id)) return false;
    t.put(C.payments, id, payment);
    writeAudit(t, head, [{ actor: actingClientId ? `client:${actingClientId}` : 'owner', action: 'payment.claimed', target: id, detail: `${invoice.invoiceId} ${method} ${normalized} claims ${formatMoney(amountMinor, currency)}` }]);
    return true;
  });
  if (!created) return { payment: (await core.store.get<Payment>(C.payments, id)) ?? payment, created: false };

  const after = await tryMatch(core, id);
  return { payment: after ?? payment, created: true };
}

// ---------------------------------------------------------------- matching

async function findLedgerFor(core: Core, payment: Payment): Promise<LedgerEntry | null> {
  for (const m of payment.methodCandidates) {
    const exact = await core.store.get<LedgerEntry>(C.ledger, trxKeyOf(m, normalizeTrxId(m, payment.trxId)));
    if (exact) return exact;
  }
  // Mistyped look-alike characters: accept only when exactly one free record fits.
  const hits: LedgerEntry[] = [];
  for (const m of payment.methodCandidates) {
    const wanted = confusableKey(normalizeTrxId(m, payment.trxId));
    const free = await core.store.list<LedgerEntry>(C.ledger, [['method', m], ['status', 'unmatched']], 500);
    for (const e of free) if (!e.syntheticId && confusableKey(normalizeTrxId(m, e.trxId)) === wanted) hits.push(e);
  }
  return hits.length === 1 ? (hits[0] ?? null) : null;
}

async function competingClaims(core: Core, payment: Payment): Promise<number> {
  const same = await core.store.list<Payment>(C.payments, [['normalizedTrxId', payment.normalizedTrxId]], 50);
  return same.filter((p) => p.id !== payment.id && p.invoiceId !== payment.invoiceId && p.status !== 'rejected').length;
}

function methodHealthy(statuses: Awaited<ReturnType<typeof bridgeStatuses>>, payment: Payment): boolean {
  return payment.methodCandidates.some((m) => {
    const evidence = methodDef(m).evidence;
    return (evidence.includes('sms') && statuses.sms.health === 'healthy') || (evidence.includes('api') && statuses.api.health === 'healthy') || (evidence.includes('email') && statuses.email.health === 'healthy');
  });
}

/**
 * Looks for the ledger record behind a claim and settles it when every check passes.
 * Safe to call repeatedly; does nothing once the claim is decided.
 */
export async function tryMatch(core: Core, paymentId: string): Promise<Payment | null> {
  const payment = await core.store.get<Payment>(C.payments, paymentId);
  if (!payment) return null;
  if (payment.status !== 'awaiting_ledger' && payment.status !== 'needs_review') return payment;

  const settings = await getSettings(core.store);
  const invoice = await core.store.get<Invoice>(C.invoices, payment.invoiceId);
  if (!invoice) return payment;

  const entry = await findLedgerFor(core, payment);
  if (!entry) {
    if (payment.status === 'awaiting_ledger') {
      const statuses = await bridgeStatuses(core.store, settings.smsStaleHours);
      const next: Payment = { ...payment, checkResults: pendingChecks(payment, methodHealthy(statuses, payment)), updatedAt: nowIso() };
      await core.store.put(C.payments, payment.id, next);
      return next;
    }
    return payment;
  }

  const rejected = (await core.store.list<Payment>(C.payments, [['invoiceId', payment.invoiceId]], 100)).filter((p) => p.status === 'rejected').length;
  const verdict = evaluateMatch({ payment, entry, invoice, settings, competingClaims: await competingClaims(core, payment), priorRejections: rejected });

  if (verdict.decision === 'auto') {
    try {
      return await settle(core, payment.id, entry.id, 'auto', 'All automatic checks passed.', verdict.checks, verdict.flags, verdict.riskScore);
    } catch (err) {
      if (!(err instanceof HttpError)) throw err; // lost a race for the record: fall through to review
    }
  }

  const fresh = await core.store.get<Payment>(C.payments, payment.id);
  if (!fresh || (fresh.status !== 'awaiting_ledger' && fresh.status !== 'needs_review')) return fresh;
  const wasWaiting = fresh.status === 'awaiting_ledger' || fresh.candidateLedgerId !== entry.id;
  const next: Payment = { ...fresh, status: 'needs_review', candidateLedgerId: entry.id, flags: verdict.flags, riskScore: verdict.riskScore, checkResults: verdict.checks, updatedAt: nowIso() };
  await core.store.put(C.payments, next.id, next);
  if (wasWaiting) {
    await core.notifier.owner('action', `payment-review:${next.id}`, 'A payment needs your confirmation', `${invoice.invoiceId} (${invoice.clientName}): ${formatMoney(entry.amountMinor, entry.currency)} via ${entry.method}, transaction ${entry.trxId}.\nReason: ${verdict.flags.join(', ') || 'policy'}.`, '/admin');
  }
  return next;
}

// ---------------------------------------------------------------- settlement

/**
 * Credits an invoice from a ledger record. Atomic: the record is consumed, the claim
 * verified and the invoice credited together, or nothing changes.
 * mode 'owner' may use a record that carries warnings; nobody may reuse a consumed one.
 */
export async function settle(core: Core, paymentId: string, ledgerId: string, mode: 'auto' | 'owner', reason: string, checks?: CheckResult[], flags?: string[], riskScore?: number): Promise<Payment> {
  const settings = await getSettings(core.store);
  const outcome = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const payment = await t.get<Payment>(C.payments, paymentId);
    const entry = await t.get<LedgerEntry>(C.ledger, ledgerId);
    if (!payment) throw new HttpError(404, 'payment_not_found', 'Payment not found.');
    if (!entry) throw new HttpError(404, 'ledger_not_found', 'Ledger record not found.');
    const invoice = await t.get<Invoice>(C.invoices, payment.invoiceId);
    if (!invoice) throw new HttpError(404, 'invoice_not_found', 'Invoice not found.');

    if (payment.status === 'verified') throw new HttpError(409, 'already_verified', 'This payment is already verified.');
    if (payment.status === 'rejected') throw new HttpError(409, 'payment_rejected', 'This payment was rejected.');
    if (entry.status === 'consumed') throw new HttpError(409, 'ledger_consumed', 'That ledger record already settled another payment.');
    if (mode === 'auto' && (entry.status !== 'unmatched' || entry.integrityFlags.length > 0)) throw new HttpError(409, 'ledger_not_clean', 'Ledger record is not eligible for automatic settlement.');
    if (invoice.status === 'void') throw new HttpError(409, 'invoice_void', 'Invoice was cancelled.');
    if (!payment.methodCandidates.includes(entry.method)) {
      if (mode === 'auto') throw new HttpError(409, 'method_mismatch', 'Ledger record is for a different payment method.');
    }

    const creditMinor = toUsdMinor(entry.amountMinor, entry.currency, invoice.rateSnapshot);
    const credit = applyCredit(invoice, creditMinor, settings);
    const now = nowIso();

    const nextEntry: LedgerEntry = { ...entry, status: 'consumed', consumedBy: payment.id, consumedAt: now };
    const nextPayment: Payment = {
      ...payment,
      method: entry.method,
      methodCandidates: [entry.method],
      trxKey: entry.trxKey,
      status: 'verified',
      source: entry.source,
      ledgerEntryId: entry.id,
      creditedMinor: credit.appliedMinor + credit.surplusMinor,
      settlement: { appliedMinor: credit.appliedMinor, surplusMinor: credit.surplusMinor, forgivenMinor: credit.forgivenMinor },
      decidedBy: mode,
      decidedAt: now,
      decisionReason: reason.slice(0, 300),
      ...(mode === 'owner' ? { ownerConfirmationStatus: 'RECEIVED' as const } : {}),
      ...(checks ? { checkResults: checks } : {}),
      ...(flags ? { flags } : {}),
      ...(riskScore !== undefined ? { riskScore } : {}),
      updatedAt: now,
    };
    delete nextPayment.candidateLedgerId;

    t.put(C.ledger, entry.id, nextEntry);
    t.put(C.payments, payment.id, nextPayment);
    t.put(C.invoices, invoice.invoiceId, credit.invoice);
    writeAudit(t, head, [
      {
        actor: mode,
        action: 'payment.verified',
        target: payment.id,
        detail: `${invoice.invoiceId} credited ${formatMoney(credit.appliedMinor, 'USD')} from ${entry.id} (${entry.source}); due now ${formatMoney(dueMinor(credit.invoice), 'USD')}${credit.surplusMinor ? `; surplus ${formatMoney(credit.surplusMinor, 'USD')}` : ''}${credit.forgivenMinor ? `; written off ${formatMoney(credit.forgivenMinor, 'USD')}` : ''}. ${reason}`,
      },
    ]);
    return { payment: nextPayment, invoice: credit.invoice, entry: nextEntry, credit };
  });

  // Everything below is repeatable and is re-driven by the cron tick if the process stops here.
  const { payment, invoice, entry, credit } = outcome;
  if (mode === 'owner' && entry.integrityFlags.some((f) => (BALANCE_FLAGS as readonly string[]).includes(f))) {
    await trustBalanceFromEntry(core, entry); // the owner has just looked at the wallet
  }
  try {
    await core.hooks.invoiceChanged?.(invoice.invoiceId);
    const dueText = credit.nowFullyPaid ? 'Your invoice is paid in full.' : `${formatMoney(dueMinor(invoice), 'USD')} is still due.`;
    await core.hooks.orderMessage?.(payment.orderId, `Payment confirmed: ${formatMoney(entry.amountMinor, entry.currency)} received (transaction ${entry.trxId}). ${dueText}${invoice.receiptNumber && credit.nowFullyPaid ? ` Receipt ${invoice.receiptNumber}.` : ''}`);
  } catch (err) {
    core.log('error', 'post-settlement follow-up failed; the cron tick will retry', { paymentId: payment.id, error: String(err) });
  }
  if (credit.surplusMinor > 0) {
    await core.notifier.owner('action', `overpaid:${invoice.invoiceId}`, 'A client paid more than the invoice', `${invoice.invoiceId} (${invoice.clientName}) was overpaid by ${formatMoney(credit.surplusMinor, 'USD')}. Refund or credit it.`, '/admin');
  }
  if (mode === 'auto') {
    await core.notifier.owner('info', `payment-auto:${payment.id}`, 'Payment verified automatically', `${invoice.invoiceId}: ${formatMoney(entry.amountMinor, entry.currency)} via ${entry.method}.`);
  }
  return payment;
}

// ---------------------------------------------------------------- a new ledger record arrived

/** Called after every new ledger record: settles waiting claims and reference-only payments. */
export async function afterIngest(core: Core, entry: LedgerEntry): Promise<void> {
  if (entry.status !== 'unmatched') return;

  const waiting = [
    ...(await core.store.list<Payment>(C.payments, [['status', 'awaiting_ledger']], 500)),
    ...(await core.store.list<Payment>(C.payments, [['status', 'needs_review']], 500)).filter((p) => !p.candidateLedgerId),
  ];
  let claimed = false;
  for (const p of waiting) {
    if (!p.methodCandidates.includes(entry.method)) continue;
    if (compareTrxIds(p, entry) === 'different') continue;
    claimed = true;
    await tryMatch(core, p.id);
  }
  if (claimed) return;

  // No claim names this transfer. If the payer wrote an invoice's reference on it,
  // that is enough to know which invoice it pays - nobody has to type anything.
  const settings = await getSettings(core.store);
  if (!settings.autoMatchByReference || entry.syntheticId) return;
  const refs = extractPayReferences(entry.reference);
  if (refs.length !== 1) return;
  const invoices = (await core.store.list<Invoice>(C.invoices, [['paymentReferenceCode', refs[0] ?? '']], 5)).filter((i) => i.status !== 'void' && !fullyPaid(i));
  const invoice = invoices.length === 1 ? invoices[0] : undefined;
  if (!invoice) return;

  const normalized = normalizeTrxId(entry.method, entry.trxId);
  const id = paymentIdFor(invoice.invoiceId, normalized);
  const now = nowIso();
  const payment: Payment = {
    id,
    invoiceId: invoice.invoiceId,
    orderId: invoice.orderId,
    clientId: invoice.clientId,
    clientName: invoice.clientName,
    method: entry.method,
    methodCandidates: [entry.method],
    trxId: entry.trxId,
    normalizedTrxId: normalized,
    trxKey: entry.trxKey,
    claimKey: `${invoice.invoiceId}|${normalized}`,
    amountMinor: entry.amountMinor,
    currency: entry.currency,
    paidAt: entry.receivedAt,
    note: `Matched by the payment reference ${refs[0]} written on the transfer.`,
    status: 'awaiting_ledger',
    riskScore: 0,
    flags: [],
    checkResults: [],
    evidence: [],
    submittedBy: 'reference_auto',
    createdAt: now,
    updatedAt: now,
  };
  const created = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    if (await t.get(C.payments, id)) return false;
    t.put(C.payments, id, payment);
    writeAudit(t, head, [{ actor: 'auto', action: 'payment.claimed', target: id, detail: `${invoice.invoiceId} found by reference ${refs[0]} on ${entry.id}` }]);
    return true;
  });
  if (created) await tryMatch(core, id);
}

// ---------------------------------------------------------------- owner actions

export async function rejectPayment(core: Core, paymentId: string, reason: string, ownerStatus?: 'NOT_RECEIVED'): Promise<Payment> {
  const next = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const payment = await t.get<Payment>(C.payments, paymentId);
    if (!payment) throw new HttpError(404, 'payment_not_found', 'Payment not found.');
    if (payment.status === 'verified') throw new HttpError(409, 'already_verified', 'This payment is already verified. To undo it, use Reverse.');
    const updated: Payment = { ...payment, status: 'rejected', decidedBy: 'owner', decidedAt: nowIso(), decisionReason: reason.slice(0, 300), ...(ownerStatus ? { ownerConfirmationStatus: ownerStatus } : {}), updatedAt: nowIso() };
    delete updated.candidateLedgerId;
    t.put(C.payments, paymentId, updated);
    writeAudit(t, head, [{ actor: 'owner', action: 'payment.rejected', target: paymentId, detail: reason.slice(0, 300) }]);
    return updated;
  });
  await core.hooks.orderMessage?.(next.orderId, `We could not confirm the payment with transaction ID ${next.trxId}: ${next.decisionReason}. If you did pay, please check the ID and submit it again, or contact us.`);
  return next;
}

/**
 * Undoes a verified payment: a wrong tap on "Received", or money that was sent back.
 *
 *  - The invoice loses exactly what this payment gave it; the order is re-evaluated
 *    (files lock again if they should).
 *  - The payment returns to the owner's queue to be decided again (Received with the
 *    right amount, or Not received). It can never verify itself automatically again.
 *  - A provider's record (SMS, API, e-mail, statement) is set aside: after a refund it
 *    must not pay for anything else, so only the owner can use it again, explicitly.
 *  - A line the owner typed by hand is removed, so a corrected line can be entered.
 */
export async function reversePayment(core: Core, paymentId: string, reasonRaw: unknown): Promise<Payment> {
  const reason = clampText(reasonRaw, 300);
  if (reason.length < 5) throw new HttpError(400, 'reason_required', 'Say why this payment is being reversed.');
  const out = await core.store.tx(async (t) => {
    const head = await readAuditHead(t);
    const payment = await t.get<Payment>(C.payments, paymentId);
    if (!payment) throw new HttpError(404, 'payment_not_found', 'Payment not found.');
    if (payment.status !== 'verified') throw new HttpError(409, 'not_verified', 'Only a verified payment can be reversed.');
    const entry = payment.ledgerEntryId ? await t.get<LedgerEntry>(C.ledger, payment.ledgerEntryId) : null;
    const invoice = await t.get<Invoice>(C.invoices, payment.invoiceId);
    if (!invoice) throw new HttpError(404, 'invoice_not_found', 'Invoice not found.');

    const did = payment.settlement ?? { appliedMinor: Math.min(payment.creditedMinor ?? 0, invoice.paidMinor), surplusMinor: 0, forgivenMinor: 0 };
    const nextInvoice: Invoice = refreshInvoice({
      ...invoice,
      paidMinor: Math.max(0, invoice.paidMinor - did.appliedMinor),
      overpaidMinor: Math.max(0, invoice.overpaidMinor - did.surplusMinor),
      writtenOffMinor: Math.max(0, invoice.writtenOffMinor - did.forgivenMinor),
    });
    if (nextInvoice.status !== 'paid_verified') delete nextInvoice.paidAt;

    const now = nowIso();
    const ownerLine = entry?.source === 'manual';
    const nextPayment: Payment = { ...payment, status: 'needs_review', flags: [...new Set([...payment.flags, 'reversed'])], decidedBy: 'owner', decidedAt: now, decisionReason: `Reversed: ${reason}`, updatedAt: now };
    delete nextPayment.ownerConfirmationStatus;
    delete nextPayment.ledgerEntryId;
    delete nextPayment.source;
    delete nextPayment.creditedMinor;
    delete nextPayment.settlement;
    if (entry && !ownerLine) nextPayment.candidateLedgerId = entry.id;
    else delete nextPayment.candidateLedgerId;

    t.put(C.payments, paymentId, nextPayment);
    t.put(C.invoices, invoice.invoiceId, nextInvoice);
    if (entry && ownerLine) t.delete(C.ledger, entry.id);
    else if (entry) {
      const setAside: LedgerEntry = { ...entry, status: 'quarantined', integrityFlags: [...new Set([...entry.integrityFlags, 'reversed'])] };
      delete setAside.consumedBy;
      delete setAside.consumedAt;
      t.put(C.ledger, entry.id, setAside);
    }
    writeAudit(t, head, [{ actor: 'owner', action: 'payment.reversed', target: paymentId, detail: `${invoice.invoiceId} lost ${formatMoney(did.appliedMinor, 'USD')}; due now ${formatMoney(dueMinor(nextInvoice), 'USD')}; ledger ${entry ? (ownerLine ? `${entry.id} (owner's line) removed` : `${entry.id} set aside`) : 'none'}. ${reason}` }]);
    return { payment: nextPayment, invoice: nextInvoice };
  });
  await core.hooks.invoiceChanged?.(out.invoice.invoiceId);
  await core.hooks.orderMessage?.(out.payment.orderId, `A payment recorded earlier (transaction ${out.payment.trxId}) was reversed: ${reason}. ${formatMoney(dueMinor(out.invoice), 'USD')} is now due on this order.`);
  return out.payment;
}

export interface OwnerConfirmInput {
  action?: unknown;
  note?: unknown;
  /** Which account received it - needed only when the claim did not say. */
  method?: unknown;
  /** Amount the owner sees in the provider app, when it differs from the claim. */
  amount?: unknown;
}

/** The owner looked at the provider app. RECEIVED settles; NOT_RECEIVED rejects; CHECK parks it. */
export async function ownerConfirm(core: Core, paymentId: string, input: OwnerConfirmInput): Promise<Payment> {
  const payment = await core.store.get<Payment>(C.payments, paymentId);
  if (!payment) throw new HttpError(404, 'payment_not_found', 'Payment not found.');
  const action = clampText(input.action, 20).toUpperCase();
  const note = clampText(input.note, 300) || 'Owner checked the provider app.';

  if (action === 'NOT_RECEIVED') return rejectPayment(core, paymentId, note, 'NOT_RECEIVED');

  if (action === 'CHECK') {
    if (payment.status === 'verified' || payment.status === 'rejected') return payment;
    const next: Payment = { ...payment, status: 'needs_review', ownerConfirmationStatus: 'CHECK', flags: [...new Set([...payment.flags, 'owner_check'])], updatedAt: nowIso() };
    await core.store.put(C.payments, paymentId, next);
    return next;
  }

  if (action !== 'RECEIVED') throw new HttpError(400, 'bad_action', 'action must be RECEIVED, NOT_RECEIVED or CHECK.');
  if (payment.status === 'verified') return payment;

  const known = payment.candidateLedgerId ? await core.store.get<LedgerEntry>(C.ledger, payment.candidateLedgerId) : null;
  if (known && known.status !== 'consumed') return settle(core, paymentId, known.id, 'owner', note);

  // No provider record reached the system: the owner's word becomes the record.
  let method: Method | null = payment.method === 'usd_unspecified' ? resolveMethod({ method: input.method }) : payment.method;
  if (!method || !PAYMENT_METHODS.some((m) => m.method === method)) {
    throw new HttpError(400, 'method_required', 'Say which account received this payment (binance_pay, payoneer or skrill).');
  }
  if (!payment.methodCandidates.includes(method)) method = payment.methodCandidates[0] ?? method;
  const def = methodDef(method);
  const seenMinor = input.amount !== undefined ? toMinor(typeof input.amount === 'number' ? input.amount : String(input.amount)) : payment.currency === def.currency ? payment.amountMinor : NaN;
  if (!Number.isFinite(seenMinor) || seenMinor <= 0) throw new HttpError(400, 'amount_required', `Enter the amount you see in ${def.label}.`);

  const ingested = await ingestManual(core, method, payment.trxId, seenMinor, note);
  const entry = ingested.entry;
  if (!entry) throw new HttpError(500, 'ledger_write_failed', 'Could not record the ledger entry.');
  if (entry.status === 'consumed') throw new HttpError(409, 'ledger_consumed', 'That transaction already settled another payment.');
  return settle(core, paymentId, entry.id, 'owner', note);
}

/** Claims that waited too long for a provider record go to the owner. Run from the cron tick. */
export async function escalateStale(core: Core): Promise<number> {
  const settings = await getSettings(core.store);
  const waiting = await core.store.list<Payment>(C.payments, [['status', 'awaiting_ledger']], 500);
  let moved = 0;
  for (const p of waiting) {
    if (hoursBetween(p.createdAt, Date.now()) < settings.ledgerWaitWindowHours) continue;
    const next: Payment = { ...p, status: 'needs_review', flags: [...new Set([...p.flags, 'no_ledger_record'])], updatedAt: nowIso() };
    await core.store.put(C.payments, p.id, next);
    await core.notifier.owner('action', `payment-stale:${p.id}`, 'A client says they paid, but no record arrived', `${p.invoiceId} (${p.clientName ?? p.clientId}) claims ${formatMoney(p.amountMinor, p.currency)} via ${p.method}, transaction ${p.trxId}. Nothing matching has been reported after ${settings.ledgerWaitWindowHours} hours. Check the provider app and answer Received / Not received.`, '/admin');
    moved += 1;
  }
  return moved;
}

/** Re-runs matching for every undecided claim. */
export async function reconcileAll(core: Core): Promise<{ checked: number; verifiedCount: number }> {
  const open = [...(await core.store.list<Payment>(C.payments, [['status', 'awaiting_ledger']], 500)), ...(await core.store.list<Payment>(C.payments, [['status', 'needs_review']], 500))];
  let verifiedCount = 0;
  for (const p of open) {
    const after = await tryMatch(core, p.id);
    if (after?.status === 'verified') verifiedCount += 1;
  }
  return { checked: open.length, verifiedCount };
}

// ---------------------------------------------------------------- evidence (context for the owner; never proof)

const MAGIC: { mime: string; test: (b: Buffer) => boolean }[] = [
  { mime: 'image/png', test: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { mime: 'image/jpeg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/webp', test: (b) => b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP' },
  { mime: 'application/pdf', test: (b) => b.subarray(0, 5).toString('latin1') === '%PDF-' },
];

export function sniffMime(bytes: Buffer): string | null {
  return MAGIC.find((m) => m.test(bytes))?.mime ?? null;
}

export function decodeBase64Upload(base64Data: unknown, maxBytes: number): Buffer {
  if (typeof base64Data !== 'string' || base64Data.length < 16) throw new HttpError(400, 'bad_file', 'No file data.');
  const comma = base64Data.startsWith('data:') ? base64Data.indexOf(',') : -1;
  const b64 = comma >= 0 ? base64Data.slice(comma + 1) : base64Data;
  if (b64.length > Math.ceil((maxBytes * 4) / 3) + 8) throw new HttpError(413, 'file_too_large', `File is larger than ${Math.round(maxBytes / 1024 / 1024)} MB.`);
  if (!/^[A-Za-z0-9+/=\s_-]+$/.test(b64)) throw new HttpError(400, 'bad_file', 'File data is not valid base64.');
  const bytes = Buffer.from(b64, 'base64');
  if (bytes.length === 0) throw new HttpError(400, 'bad_file', 'File is empty.');
  if (bytes.length > maxBytes) throw new HttpError(413, 'file_too_large', `File is larger than ${Math.round(maxBytes / 1024 / 1024)} MB.`);
  return bytes;
}

export async function attachEvidence(core: Core, paymentId: string, fileName: unknown, base64Data: unknown, actingClientId: string | null): Promise<Payment> {
  const payment = await core.store.get<Payment>(C.payments, paymentId);
  if (!payment || (actingClientId !== null && payment.clientId !== actingClientId)) throw new HttpError(404, 'payment_not_found', 'Payment not found.');
  if (payment.evidence.length >= 3) throw new HttpError(409, 'too_many_files', 'At most 3 files per payment.');
  const bytes = decodeBase64Upload(base64Data, 5 * 1024 * 1024);
  if (!sniffMime(bytes)) throw new HttpError(415, 'bad_file_type', 'Upload a PNG, JPG, WebP or PDF receipt.');
  const sha256 = sha256Hex(bytes);

  const marker = await core.store.get<{ paymentId: string }>(C.meta, `evidence:${sha256}`);
  const reusedFrom = marker && marker.paymentId !== paymentId ? marker.paymentId : undefined;
  if (!marker) await core.store.put(C.meta, `evidence:${sha256}`, { paymentId });
  await core.store.putBlob(`evidence_${paymentId}_${sha256.slice(0, 16)}`, bytes);

  const file: EvidenceFile = { fileName: clampText(fileName, 80).replace(/[^\w.\- ]/g, '_') || 'receipt', sha256, size: bytes.length, uploadedAt: nowIso(), ...(reusedFrom ? { reusedFromPaymentId: reusedFrom } : {}) };
  const next: Payment = { ...payment, evidence: [...payment.evidence.filter((e) => e.sha256 !== sha256), file], flags: reusedFrom ? [...new Set([...payment.flags, 'evidence_reused'])] : payment.flags, updatedAt: nowIso() };
  await core.store.put(C.payments, paymentId, next);
  if (reusedFrom) {
    await core.notifier.owner('action', `evidence-reused:${paymentId}`, 'The same receipt image was used twice', `Payment ${paymentId} carries a screenshot already attached to ${reusedFrom}.`, '/admin');
  }
  return next;
}

// ---------------------------------------------------------------- views

export type Queue = 'needs_action' | 'awaiting_ledger' | 'auto_verified' | 'rejected' | 'all';

export async function listPayments(core: Core, queue: Queue): Promise<{ payments: Payment[]; counts: Record<string, number> }> {
  const all = (await core.store.list<Payment>(C.payments, [], 5000)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const is = {
    needs_action: (p: Payment) => p.status === 'needs_review',
    awaiting_ledger: (p: Payment) => p.status === 'awaiting_ledger',
    auto_verified: (p: Payment) => p.status === 'verified' && p.decidedBy === 'auto',
    rejected: (p: Payment) => p.status === 'rejected',
  };
  const counts = {
    needsAction: all.filter(is.needs_action).length,
    awaitingLedger: all.filter(is.awaiting_ledger).length,
    autoVerified: all.filter(is.auto_verified).length,
    rejected: all.filter(is.rejected).length,
    total: all.length,
  };
  const payments = queue === 'all' ? all : all.filter(is[queue]);
  return { payments: payments.slice(0, 500), counts };
}

/** Looks a payment up by its id, an invoice / order number, or a transaction id. */
export async function findPaymentByAnyId(core: Core, anyId: string): Promise<{ payment: Payment | null; invoice: Invoice | null }> {
  const byId = await core.store.get<Payment>(C.payments, anyId);
  if (byId) return { payment: byId, invoice: await core.store.get<Invoice>(C.invoices, byId.invoiceId) };
  const invoice = await loadInvoice(core, anyId);
  if (invoice) {
    const list = (await core.store.list<Payment>(C.payments, [['invoiceId', invoice.invoiceId]], 100)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { payment: list[0] ?? null, invoice };
  }
  const normalized = anyId.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  const byTrx = normalized.length >= 5 ? (await core.store.list<Payment>(C.payments, [['normalizedTrxId', normalized]], 5)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)) : [];
  const p = byTrx[0] ?? null;
  return { payment: p, invoice: p ? await core.store.get<Invoice>(C.invoices, p.invoiceId) : null };
}

function csvCell(v: string | number): string {
  const s = String(v);
  const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s; // stop spreadsheet formula injection
  return /[",\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
}

/** Income export for the accountant: one line per verified payment. */
export async function accountantPack(core: Core): Promise<{ csvContent: string; summary: { totalRecords: number; totalForeignIncomeUSD: number; totalLocalIncomeBDT: number } }> {
  const verified = (await core.store.list<Payment>(C.payments, [['status', 'verified']], 5000)).sort((a, b) => (a.decidedAt ?? '').localeCompare(b.decidedAt ?? ''));
  const lines = [['verified_at', 'invoice', 'client_id', 'method', 'transaction_id', 'received_amount', 'received_currency', 'credited_usd', 'evidence', 'decided_by'].join(',')];
  let foreignMinor = 0;
  let localMinor = 0;
  for (const p of verified) {
    const entry = p.ledgerEntryId ? await core.store.get<LedgerEntry>(C.ledger, p.ledgerEntryId) : null;
    const amountMinor = entry?.amountMinor ?? p.amountMinor;
    const currency = entry?.currency ?? p.currency;
    if (currency === 'USD') foreignMinor += amountMinor;
    else localMinor += amountMinor;
    lines.push([p.decidedAt ?? '', p.invoiceId, p.clientId, p.method, p.trxId, fromMinor(amountMinor).toFixed(2), currency, fromMinor(p.creditedMinor ?? 0).toFixed(2), p.source ?? '', p.decidedBy ?? ''].map(csvCell).join(','));
  }
  return { csvContent: lines.join('\n') + '\n', summary: { totalRecords: verified.length, totalForeignIncomeUSD: fromMinor(foreignMinor), totalLocalIncomeBDT: fromMinor(localMinor) } };
}
