/**
 * mrs-core — every HTTP route, in one place.
 *
 * WHO MAY CALL WHAT
 *   public     health, catalogue, payment methods, the pre-sale chat, placing an order
 *   collector  /api/ingest/*, /api/cron/tick   (signed with a shared secret)
 *   client     /api/portal/*, /api/orders/*, /api/payments/*   (Client ID + PIN session)
 *   owner      /api/admin/*                                    (admin session)
 *
 * mrs-core OWNS these prefixes: anything under them that is not defined here
 * answers 404, and nothing under /api/admin is reachable without an admin session.
 * Older handlers left in the host app for the same paths are therefore dead.
 */
import express from 'express';
import type { Request, RequestHandler, Response, Router } from 'express';
import { listAudit, verifyAuditChain, audit } from './audit.ts';
import { conciergeReply, orderFacts, threadReply } from './camellia.ts';
import { PAYMENT_METHODS, checkSecrets, publicRegistry, resolveMethod } from './config.ts';
import type { Core } from './core.ts';
import { bridgeStatuses, getSettings, saveSettings, touchBridge } from './core.ts';
import { clientReplied, getFulfilmentSettings, listDeliverables, ownerDone, ownerUpload, release, requestRevision, requeue, runJob, saveFulfilmentSettings, sendBack } from './fulfilment/engine.ts';
import { modelCallsToday } from './fulfilment/gemini.ts';
import { apiHeaders, body, errorHandler, jsonSmall, jsonUpload, param, query, rawBody, sendDownload, wrap } from './httpkit.ts';
import { alertOnce, listAlerts, markAlertRead } from './notify.ts';
import { publicCatalog } from './orders/catalog.ts';
import { addIntakeFile, addMessage, advance, cancelOrder, clientDeliverable, createOrder, factsFor, getOwnOrder, intakeBlobId, listMessages, loginClient, portalView, publicClient, setQuote, submitIntake } from './orders/service.ts';
import { getBalanceAnchor, ingestDraft, ingestEmail, ingestManual, ingestSms, listLedger, publicLedgerEntry, trustBalance } from './payments/ledger.ts';
import type { IngestResult } from './payments/ledger.ts';
import { mapBinancePayRow } from './payments/parsers/binance.ts';
import type { BinancePayRow } from './payments/parsers/binance.ts';
import { parseProviderEmail, verifyEmailAuth } from './payments/parsers/email.ts';
import { parseWalletSms, walletForSender } from './payments/parsers/sms.ts';
import { draftsFromCsv, draftsFromRows } from './payments/parsers/statement.ts';
import type { StatementRow } from './payments/parsers/statement.ts';
import { accountantPack, afterIngest, attachEvidence, clientView, decodeBase64Upload, findPaymentByAnyId, listPayments, ownerConfirm, reconcileAll, rejectPayment, reversePayment, settle, submitClaim } from './payments/service.ts';
import type { Queue } from './payments/service.ts';
import { ADMIN_COOKIE, ADMIN_TTL, CLIENT_COOKIE, CLIENT_TTL, adminConfigured, checkAdminPassword, clearSessionCookie, clientIp, forwardedChain, getTrustedProxyHops, issueToken, optionalClient, requireAdmin, requireClient, setSessionCookie } from './security/auth.ts';
import type { AuthDeps, AuthedRequest } from './security/auth.ts';
import { verifyBearerJson, verifySignedJson } from './security/hmac.ts';
import type { SignedBody } from './security/hmac.ts';
import { RateLimiter, rateLimit } from './security/ratelimit.ts';
import { C } from './store/store.ts';
import type { Client, Deliverable, Invoice, Job, Method, Order, Payment } from './types.ts';
import { HttpError, clampText, maskProviderText, nowIso, safeEqual, toMinor } from './util.ts';
import { runTick } from './tick.ts';

export const OWNED_PREFIXES = ['/api/admin', '/api/payments', '/api/ingest', '/api/orders', '/api/portal', '/api/catalog', '/api/payment-methods', '/api/concierge', '/api/cron', '/api/health', '/api/deliverables'];

const MINUTE = 60_000;
const startedAt = Date.now();

export function buildRouter(core: Core): Router {
  const router = express.Router();
  const { store, secrets } = core;

  // ---- admin "sign out everywhere" counter, cached briefly
  let epochCache: { at: number; value: number } | null = null;
  const adminEpoch = async (): Promise<number> => {
    if (epochCache && Date.now() - epochCache.at < 5000) return epochCache.value;
    const value = (await store.get<{ value: number }>(C.meta, 'adminEpoch'))?.value ?? 1;
    epochCache = { at: Date.now(), value };
    return value;
  };
  const auth: AuthDeps = { secrets, adminEpoch };
  const admin = requireAdmin(auth);
  const client = requireClient(auth);
  const clientId = (req: Request): string => (req as AuthedRequest).mrsSession?.sub ?? '';

  router.use(OWNED_PREFIXES, apiHeaders);

  // ============================================================ collectors (signed; raw body)

  const collectorLimit = rateLimit('collector', 600, MINUTE);

  function signed(req: Request, key: string, bearer?: string): SignedBody {
    const bySignature = key ? verifySignedJson(req, key) : { ok: false, reason: 'not configured' };
    if (bySignature.ok || !bearer) return bySignature;
    const byBearer = verifyBearerJson(req, bearer);
    return byBearer.ok ? byBearer : bySignature;
  }

  interface SmsItem {
    senderId: string;
    text: string;
    eventId?: string;
  }

  /** Accepts "SMS Gateway for Android" webhooks and a plain { sender, message } shape. */
  function smsItems(json: unknown): { ping: boolean; items: SmsItem[] } {
    const root = (json && typeof json === 'object' ? json : {}) as Record<string, unknown>;
    if (root.event === 'system:ping' || root.ping === true || root.heartbeat === true) return { ping: true, items: [] };
    if (typeof root.event === 'string' && root.event !== 'sms:received') return { ping: false, items: [] };
    const list = Array.isArray(root.messages) ? (root.messages as unknown[]) : [root];
    const items: SmsItem[] = [];
    for (const entry of list.slice(0, 50)) {
      const e = (entry && typeof entry === 'object' ? entry : {}) as Record<string, unknown>;
      const p = (e.payload && typeof e.payload === 'object' ? e.payload : e) as Record<string, unknown>;
      const pick = (...keys: string[]): string => {
        for (const k of keys) if (typeof p[k] === 'string' && (p[k] as string).trim()) return (p[k] as string).slice(0, 1200);
        return '';
      };
      const senderId = pick('sender', 'phoneNumber', 'from', 'address', 'senderId');
      const text = pick('message', 'text', 'body', 'raw_sms', 'content');
      const eventId = typeof e.id === 'string' ? e.id : pick('messageId', 'id', 'client_msg_id');
      if (senderId && text) items.push({ senderId, text, ...(eventId ? { eventId: eventId.slice(0, 80) } : {}) });
    }
    return { ping: false, items };
  }

  const smsIngest: RequestHandler = wrap(async (req, res) => {
    if (secrets.smsSigningKey.length < 16 && secrets.smsBearerToken.length < 24) throw new HttpError(503, 'sms_bridge_not_configured', 'SMS bridge is switched off: set MRS_SMS_SIGNING_KEY.');
    const v = signed(req, secrets.smsSigningKey, secrets.smsBearerToken);
    if (!v.ok) throw new HttpError(401, 'bad_signature', `SMS bridge request refused: ${v.reason}.`);
    const { ping, items } = smsItems(v.json);
    const results: string[] = [];
    let error: string | undefined;
    for (const item of items) {
      try {
        const r = await ingestSms(core, item);
        results.push(r.status);
        if (r.entry && (r.status === 'new' || r.status === 'quarantined')) await afterIngest(core, r.entry);
      } catch (err) {
        error = String((err as Error)?.message ?? err);
        core.log('error', 'sms ingest failed', { error });
        results.push('error');
      }
    }
    await touchBridge(store, 'sms', items.length, error);
    if (error) throw new HttpError(500, 'ingest_failed', 'Temporary failure; send again.'); // the phone app retries
    res.json({ ok: true, ping, results });
  });
  router.post('/api/ingest/sms', collectorLimit, rawBody, smsIngest);
  router.post('/api/payments/sms', collectorLimit, rawBody, smsIngest); // the path the earlier bridge used

  router.post(
    '/api/ingest/email',
    collectorLimit,
    rawBody,
    wrap(async (req, res) => {
      if (secrets.ingestSecret.length < 24) throw new HttpError(503, 'ingest_not_configured', 'Collectors are switched off: set MRS_INGEST_SECRET.');
      const v = verifySignedJson(req, secrets.ingestSecret);
      if (!v.ok) throw new HttpError(401, 'bad_signature', `Collector request refused: ${v.reason}.`);
      const root = (v.json && typeof v.json === 'object' ? v.json : {}) as Record<string, unknown>;
      const messages = Array.isArray(root.messages) ? (root.messages as Record<string, unknown>[]).slice(0, 25) : [];
      const results: { id: string; status: string; reason?: string }[] = [];
      for (const m of messages) {
        const id = clampText(m.id, 120);
        if (!id) continue;
        const r: IngestResult = await ingestEmail(core, { messageId: id, authResults: clampText(m.authResults, 4000), from: clampText(m.from, 300), subject: clampText(m.subject, 400), body: clampText(m.body, 12_000), date: clampText(m.date, 40) });
        if (r.entry && r.status === 'new') await afterIngest(core, r.entry);
        results.push({ id, status: r.status, ...(r.reason ? { reason: r.reason } : {}) });
      }
      await touchBridge(store, 'email', messages.length);
      res.json({ ok: true, results });
    }),
  );

  router.post(
    '/api/ingest/provider',
    collectorLimit,
    rawBody,
    wrap(async (req, res) => {
      if (secrets.ingestSecret.length < 24) throw new HttpError(503, 'ingest_not_configured', 'Collectors are switched off: set MRS_INGEST_SECRET.');
      const v = verifySignedJson(req, secrets.ingestSecret);
      if (!v.ok) throw new HttpError(401, 'bad_signature', `Collector request refused: ${v.reason}.`);
      const root = (v.json && typeof v.json === 'object' ? v.json : {}) as Record<string, unknown>;
      const provider = clampText(root.provider, 20);
      const counts: Record<string, number> = {};
      const bump = (k: string): void => void (counts[k] = (counts[k] ?? 0) + 1);
      const take = async (r: IngestResult): Promise<void> => {
        bump(r.status);
        if (r.entry && r.status === 'new') await afterIngest(core, r.entry);
      };
      if (typeof root.error === 'string') {
        await touchBridge(store, 'api', 0, `${provider}: ${root.error}`);
        res.json({ ok: true, noted: true });
        return;
      }
      if (provider === 'binance' && Array.isArray(root.rows)) {
        const own = PAYMENT_METHODS.find((m) => m.method === 'binance_pay')?.accountId ?? '';
        for (const row of (root.rows as BinancePayRow[]).slice(0, 200)) {
          const draft = mapBinancePayRow(row, own);
          if (draft) await take(await ingestDraft(core, draft, 'collector:api'));
          else bump('not_incoming');
        }
      } else if (provider === 'skrill' && typeof root.csv === 'string') {
        const parsed = draftsFromCsv('skrill', 'USD', root.csv.slice(0, 1_500_000), 'skrill-mqi');
        for (const d of parsed.drafts) await take(await ingestDraft(core, { ...d, source: 'api' }, 'collector:api'));
        counts.skipped = parsed.skipped.length;
      } else if (root.heartbeat !== true) {
        throw new HttpError(400, 'bad_payload', 'Expected { provider: "binance", rows } or { provider: "skrill", csv } or { heartbeat: true }.');
      }
      await touchBridge(store, 'api', Object.values(counts).reduce((a, b) => a + b, 0));
      res.json({ ok: true, counts });
    }),
  );

  router.post(
    '/api/cron/tick',
    rateLimit('cron', 30, MINUTE),
    rawBody,
    wrap(async (req, res) => {
      if (secrets.cronSecret.length < 24) throw new HttpError(503, 'cron_not_configured', 'Scheduler is switched off: set MRS_CRON_SECRET (or MRS_INGEST_SECRET).');
      const header = String(req.headers.authorization ?? '');
      const bearerOk = /^Bearer\s+/i.test(header) && safeEqual(header.replace(/^Bearer\s+/i, '').trim(), secrets.cronSecret);
      if (!bearerOk && !verifySignedJson(req, secrets.cronSecret).ok) throw new HttpError(401, 'bad_signature', 'Scheduler request refused.');
      const budget = Math.min(240_000, Math.max(5000, Number(query(req, 'budget')) || 40_000));
      // ?jobs=0 does only the quick housekeeping (for callers that must not wait on Camellia's work)
      res.json({ ok: true, ...(await runTick(core, budget, query(req, 'jobs') !== '0')) });
    }),
  );

  // ============================================================ public

  router.get('/api/health/liveness', (_req, res) => {
    res.json({ status: 'live', uptime: Math.round((Date.now() - startedAt) / 1000), timestamp: nowIso() });
  });

  router.get(
    '/api/health/readiness',
    wrap(async (_req, res) => {
      let storage = false;
      try {
        await store.put(C.meta, 'readiness', { at: nowIso() });
        storage = (await store.get(C.meta, 'readiness')) !== null;
      } catch {
        storage = false;
      }
      const problems = checkSecrets(secrets);
      const ready = storage && store.durable && adminConfigured(secrets);
      res.status(storage ? 200 : 503).json({
        status: !storage ? 'down' : ready ? 'ready' : 'degraded',
        database: !storage ? 'unreachable' : store.durable ? 'connected' : 'in-memory (NOT durable: data is lost on restart)',
        aiQuota: core.model.available ? 'normal' : 'not configured',
        uptime: Math.round((Date.now() - startedAt) / 1000),
        memoryUsageMb: Math.round((process.memoryUsage().rss / 1024 / 1024) * 10) / 10,
        checks: { storage, durableStorage: store.durable, auth: adminConfigured(secrets), paymentRegistry: PAYMENT_METHODS.length === 5, aiModel: core.model.available, configProblems: problems.length },
        timestamp: nowIso(),
      });
    }),
  );

  router.get('/api/catalog', (_req, res) => {
    res.json({ success: true, services: publicCatalog() });
  });

  router.get(
    '/api/payment-methods',
    wrap(async (_req, res) => {
      const settings = await getSettings(store);
      res.json({ success: true, registry: publicRegistry(), usdToBdt: settings.usdToBdt });
    }),
  );

  router.post(
    '/api/concierge/chat',
    rateLimit('chat', 20, MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      res.json(await conciergeReply(core, body(req), clientIp(req)));
    }),
  );

  // ============================================================ sign-in

  // Password guessing is slowed per caller and, in case the guesses come from many
  // addresses at once, for everyone together.
  const adminLoginIp = rateLimit('admin-login', 8, 15 * MINUTE);
  const adminLoginAll = new RateLimiter(60, 15 * MINUTE);
  router.post(
    '/api/admin/login',
    adminLoginIp,
    jsonSmall,
    wrap(async (req, res) => {
      if (!adminConfigured(secrets)) throw new HttpError(503, 'admin_not_configured', 'Admin access is switched off until MRS_SESSION_SECRET and MRS_ADMIN_PASSWORD are set.');
      if (!adminLoginAll.hit('all')) throw new HttpError(429, 'rate_limited', 'Too many sign-in attempts. Try again in 15 minutes.');
      const typed = body(req).password;
      // compared exactly as typed: no trimming, no case folding
      const ok = typeof typed === 'string' && typed.length <= 200 && checkAdminPassword(secrets, typed);
      if (!ok) {
        await alertOnce(core, 'admin-login-failed', 1 / 6, 'action', 'Failed admin sign-in', `A wrong admin password was entered from ${clientIp(req)}. If this was not you, someone is trying to get in. (Further attempts in the next 10 minutes are not reported separately.)`);
        throw new HttpError(401, 'bad_login', 'Wrong password.');
      }
      const epoch = await adminEpoch();
      const token = issueToken(secrets.sessionSecret, { role: 'admin', sub: 'owner', epoch }, ADMIN_TTL);
      setSessionCookie(req, res, ADMIN_COOKIE, token, ADMIN_TTL);
      await audit(store, { actor: 'owner', action: 'admin.login', target: 'session', detail: `from ${clientIp(req)}` });
      res.json({ success: true, token, expiresInSeconds: ADMIN_TTL });
    }),
  );

  router.post(
    '/api/portal/login',
    rateLimit('portal-login', 20, 15 * MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      if (secrets.sessionSecret.length < 32) throw new HttpError(503, 'portal_not_configured', 'Client sign-in is switched off until MRS_SESSION_SECRET is set.');
      const b = body(req);
      const c = await loginClient(core, b.clientId, b.pin);
      const token = issueToken(secrets.sessionSecret, { role: 'client', sub: c.clientId, epoch: 0 }, CLIENT_TTL);
      setSessionCookie(req, res, CLIENT_COOKIE, token, CLIENT_TTL);
      res.json({ success: true, token, client: publicClient(c) });
    }),
  );

  router.post('/api/portal/logout', (req, res) => {
    clearSessionCookie(req, res, CLIENT_COOKIE);
    res.json({ success: true });
  });

  // ============================================================ orders (client)

  router.post(
    '/api/orders',
    rateLimit('orders', 10, 60 * MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      if (secrets.sessionSecret.length < 32) throw new HttpError(503, 'portal_not_configured', 'Ordering is switched off until MRS_SESSION_SECRET is set.');
      const session = optionalClient(auth, req);
      const created = await createOrder(core, body(req), session?.sub ?? null, clientIp(req));
      let token: string | undefined;
      if (!session) {
        token = issueToken(secrets.sessionSecret, { role: 'client', sub: created.client.clientId, epoch: 0 }, CLIENT_TTL);
        setSessionCookie(req, res, CLIENT_COOKIE, token, CLIENT_TTL);
      }
      res.status(201).json({ success: true, order: created.order, invoice: created.invoice, client: publicClient(created.client), isNewClient: created.isNewClient, ...(created.plainPin ? { plainPin: created.plainPin } : {}), ...(token ? { token } : {}) });
    }),
  );

  router.get(
    '/api/portal/me',
    client,
    wrap(async (req, res) => {
      res.json({ success: true, ...(await portalView(core, clientId(req), clientView)) });
    }),
  );

  async function orderBundle(order: Order, forAdmin: boolean): Promise<Record<string, unknown>> {
    const facts = await factsFor(core, order);
    const deliverables = await listDeliverables(core, order.orderId);
    const payments = await store.list<Payment>(C.payments, [['orderId', order.orderId]], 100);
    return {
      order,
      invoice: facts.invoice,
      missing: facts.missing,
      messages: await listMessages(core, order.orderId, forAdmin),
      payments: forAdmin ? payments : payments.map(clientView),
      deliverables: forAdmin ? deliverables : deliverables.filter((d) => d.released).map((d) => clientDeliverable(d, order)),
      ...(forAdmin ? { job: facts.job } : { work: facts.job ? { state: facts.job.state, questionsForClient: facts.job.questionsForClient } : null }),
    };
  }

  router.get(
    '/api/orders/:id',
    client,
    wrap(async (req, res) => {
      const order = await getOwnOrder(core, param(req, 'id'), clientId(req));
      res.json({ success: true, ...(await orderBundle(order, false)) });
    }),
  );

  router.post(
    '/api/orders/:id/intake',
    client,
    rateLimit('intake', 60, 60 * MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      const order = await submitIntake(core, param(req, 'id'), clientId(req), b.intake ?? b);
      res.json({ success: true, ...(await orderBundle(order, false)) });
    }),
  );

  const uploadLimit = rateLimit('upload', 40, 60 * MINUTE);
  router.post(
    '/api/orders/:id/files',
    client,
    uploadLimit,
    jsonUpload,
    wrap(async (req, res) => {
      const b = body(req);
      const bytes = decodeBase64Upload(b.base64Data, 5 * 1024 * 1024);
      const file = await addIntakeFile(core, param(req, 'id'), clientId(req), b.field, b.fileName, bytes);
      res.status(201).json({ success: true, file });
    }),
  );

  router.post(
    '/api/orders/:id/messages',
    client,
    rateLimit('messages', 20, 10 * MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      const order = await getOwnOrder(core, param(req, 'id'), clientId(req));
      const text = clampText(body(req).text, 2000);
      if (text.length < 1) throw new HttpError(400, 'empty_message', 'Type a message.');
      await addMessage(core, order, 'client', order.clientName, text);
      if (await clientReplied(core, order.orderId, text)) {
        await addMessage(core, order, 'camellia', 'Camellia', 'Thank you. I have what I asked for and am continuing with your order.');
      } else {
        const facts = await factsFor(core, order);
        const reply = await threadReply(core, order, orderFacts(order, facts, facts.job, await listDeliverables(core, order.orderId)), text);
        if (reply) {
          await addMessage(core, order, 'camellia', 'Camellia', reply.reply);
          if (reply.needsOwner) await core.notifier.owner('action', `message:${order.orderId}`, 'A client message needs you', `${order.orderId} (${order.clientName}): ${text.slice(0, 400)}`, '/admin');
        }
      }
      res.status(201).json({ success: true, messages: await listMessages(core, order.orderId, false) });
    }),
  );

  router.post(
    '/api/orders/:id/revision',
    client,
    rateLimit('revision', 10, 60 * MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      const order = await requestRevision(core, param(req, 'id'), clientId(req), body(req).text);
      res.json({ success: true, order });
    }),
  );

  async function sendDeliverable(res: Response, d: Deliverable): Promise<void> {
    if (d.kind === 'link') {
      res.json({ success: true, url: d.externalUrl });
      return;
    }
    const bytes = await store.getBlob(`deliv_${d.id}`);
    if (!bytes) throw new HttpError(404, 'file_missing', 'The file is no longer stored.');
    sendDownload(res, d.fileName, d.mime, bytes);
  }

  router.get(
    '/api/deliverables/:id/download',
    client,
    wrap(async (req, res) => {
      const d = await store.get<Deliverable>(C.deliverables, param(req, 'id'));
      if (!d || d.clientId !== clientId(req) || !d.released) throw new HttpError(404, 'not_found', 'File not found.');
      const order = await store.get<Order>(C.orders, d.orderId);
      if (!order) throw new HttpError(404, 'not_found', 'File not found.');
      // Decided here, on the server, from the order's real state - never from a flag the browser holds.
      if (order.deliverablesLocked && d.kind !== 'preview') {
        throw new HttpError(402, 'locked', 'This file unlocks when the payment for this order is confirmed.');
      }
      await sendDeliverable(res, d);
    }),
  );

  // ============================================================ payments (client)

  router.post(
    '/api/payments',
    client,
    rateLimit('payments', 20, 60 * MINUTE),
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      const result = await submitClaim(core, { ...b, idempotencyKey: b.idempotencyKey ?? req.headers['idempotency-key'] }, clientId(req));
      res.status(result.created ? 201 : 200).json({ success: true, submission: clientView(result.payment), checkResults: result.payment.checkResults });
    }),
  );

  router.post(
    '/api/payments/:id/evidence',
    client,
    uploadLimit,
    jsonUpload,
    wrap(async (req, res) => {
      const b = body(req);
      const p = await attachEvidence(core, param(req, 'id'), b.fileName, b.base64Data, clientId(req));
      res.status(201).json({ success: true, submission: clientView(p) });
    }),
  );

  router.get(
    '/api/payments/:id/status',
    client,
    wrap(async (req, res) => {
      const found = await findPaymentByAnyId(core, param(req, 'id'));
      const mine = clientId(req);
      if ((found.payment && found.payment.clientId !== mine) || (found.invoice && found.invoice.clientId !== mine) || (!found.payment && !found.invoice)) {
        throw new HttpError(404, 'not_found', 'Nothing found for that reference.');
      }
      const inv = found.invoice;
      res.json({
        success: true,
        submission: found.payment ? clientView(found.payment) : null,
        checkResults: found.payment?.checkResults ?? [],
        invoice: inv ? { invoiceId: inv.invoiceId, status: inv.status, total: inv.total, amountDue: inv.amountDue, amountBDT: inv.amountBDT, depositCredited: inv.depositCredited, paymentReferenceCode: inv.paymentReferenceCode, receiptNumber: inv.receiptNumber } : null,
      });
    }),
  );

  // ============================================================ owner (everything below needs an admin session)

  router.use('/api/admin', admin);

  router.get('/api/admin/session', (_req, res) => {
    res.json({ success: true, authenticated: true });
  });

  router.post('/api/admin/logout', (req, res) => {
    clearSessionCookie(req, res, ADMIN_COOKIE);
    res.json({ success: true });
  });

  router.post(
    '/api/admin/logout-everywhere',
    wrap(async (req, res) => {
      const next = (await adminEpoch()) + 1;
      await store.put(C.meta, 'adminEpoch', { value: next });
      epochCache = { at: Date.now(), value: next };
      clearSessionCookie(req, res, ADMIN_COOKIE);
      await audit(store, { actor: 'owner', action: 'admin.logout_everywhere', target: 'session', detail: `epoch ${next}` });
      res.json({ success: true });
    }),
  );

  // ---- payments
  router.get(
    '/api/admin/payments',
    wrap(async (req, res) => {
      const q = query(req, 'queue');
      const queue: Queue = (['needs_action', 'awaiting_ledger', 'auto_verified', 'rejected', 'all'] as Queue[]).includes(q as Queue) ? (q as Queue) : 'all';
      const settings = await getSettings(store);
      const { payments, counts } = await listPayments(core, queue);
      res.json({ success: true, counts, payments, ledgerEntries: (await listLedger(core, 300)).map(publicLedgerEntry), settings, bridgeStatuses: await bridgeStatuses(store, settings.smsStaleHours) });
    }),
  );

  router.post(
    '/api/admin/payments/:id/verify',
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      const ledgerId = clampText(b.ledgerEntryId, 120);
      if (!ledgerId) throw new HttpError(400, 'ledger_required', 'Choose the ledger record this payment matches.');
      const payment = await settle(core, param(req, 'id'), ledgerId, 'owner', clampText(b.reason, 300) || 'Owner matched the payment to a ledger record.');
      res.json({ success: true, payment });
    }),
  );

  router.post(
    '/api/admin/payments/:id/owner-confirm',
    jsonSmall,
    wrap(async (req, res) => {
      res.json({ success: true, payment: await ownerConfirm(core, param(req, 'id'), body(req)) });
    }),
  );

  router.post(
    '/api/admin/payments/:id/reject',
    jsonSmall,
    wrap(async (req, res) => {
      const reason = clampText(body(req).reason, 300);
      if (reason.length < 3) throw new HttpError(400, 'reason_required', 'Give the client a reason.');
      res.json({ success: true, payment: await rejectPayment(core, param(req, 'id'), reason) });
    }),
  );

  router.post(
    '/api/admin/payments/:id/reverse',
    jsonSmall,
    wrap(async (req, res) => {
      res.json({ success: true, payment: await reversePayment(core, param(req, 'id'), body(req).reason) });
    }),
  );

  router.get(
    '/api/admin/payments/:id/evidence/:n',
    wrap(async (req, res) => {
      const p = await store.get<Payment>(C.payments, param(req, 'id'));
      const file = p?.evidence[Number(param(req, 'n'))];
      const bytes = p && file ? await store.getBlob(`evidence_${p.id}_${file.sha256.slice(0, 16)}`) : null;
      if (!file || !bytes) throw new HttpError(404, 'not_found', 'File not found.');
      sendDownload(res, file.fileName, 'application/octet-stream', bytes);
    }),
  );

  router.put(
    '/api/admin/payment-settings',
    jsonSmall,
    wrap(async (req, res) => {
      const settings = await saveSettings(store, body(req));
      await audit(store, { actor: 'owner', action: 'settings.payments', target: 'paymentSettings', detail: `killSwitch=${settings.killSwitch} limits=${JSON.stringify(settings.autoVerifyLimitsUsd)}` });
      res.json({ success: true, settings });
    }),
  );

  router.get('/api/admin/payment-registry', (_req, res) => {
    res.json({ success: true, registry: publicRegistry() });
  });

  router.post(
    '/api/admin/ledger',
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      const method = resolveMethod({ method: b.method, methodId: b.methodId });
      if (!method) throw new HttpError(400, 'unknown_method', 'Choose the account that received the money.');
      const amountMinor = toMinor(typeof b.amount === 'number' ? b.amount : String(b.amount ?? ''));
      const trxId = clampText(b.trxId, 48);
      if (!/^[A-Za-z0-9_-]{5,48}$/.test(trxId)) throw new HttpError(400, 'bad_transaction_id', 'Enter the transaction ID as the provider shows it.');
      if (!Number.isFinite(amountMinor) || amountMinor <= 0) throw new HttpError(400, 'bad_amount', 'Enter the amount received.');
      const r = await ingestManual(core, method, trxId, amountMinor, clampText(b.reason, 200) || 'Owner saw it in the provider app.');
      if (r.status === 'duplicate') throw new HttpError(409, 'duplicate', 'That transaction is already in the ledger.');
      if (r.entry) await afterIngest(core, r.entry);
      res.status(201).json({ success: true, entry: r.entry ? publicLedgerEntry(r.entry) : null });
    }),
  );

  router.post(
    '/api/admin/ledger/import',
    jsonUpload,
    wrap(async (req, res) => {
      const b = body(req);
      const method = resolveMethod({ method: b.method, methodId: b.methodId });
      if (!method) throw new HttpError(400, 'unknown_method', 'Choose which account this statement is from.');
      const currency = PAYMENT_METHODS.find((m) => m.method === method)?.currency ?? 'USD';
      const fileName = clampText(b.fileName, 80).replace(/[^\w.\-]/g, '_') || 'statement';
      const parsed = typeof b.csv === 'string' ? draftsFromCsv(method, currency, b.csv.slice(0, 1_500_000), fileName) : draftsFromRows(method, currency, Array.isArray(b.rows) ? (b.rows as StatementRow[]) : [], fileName);
      let imported = 0;
      let duplicates = 0;
      for (const d of parsed.drafts) {
        const r = await ingestDraft(core, d, 'owner');
        if (r.status === 'duplicate') duplicates += 1;
        else {
          imported += 1;
          if (r.entry) await afterIngest(core, r.entry);
        }
      }
      res.json({ success: true, importRecord: { fileName, method, importedCount: imported, duplicateCount: duplicates, skippedCount: parsed.skipped.length, skipped: parsed.skipped.slice(0, 50), importedAt: nowIso() } });
    }),
  );

  /** Shows how a message would be read, without recording anything. For checking real samples before go-live. */
  router.post(
    '/api/admin/ledger/parse-test',
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      if (b.kind === 'email') {
        const verdict = verifyEmailAuth(clampText(b.authResults, 4000), clampText(b.from, 300));
        const parsed = verdict.method ? parseProviderEmail(verdict.method, clampText(b.subject, 400), clampText(b.body, 12_000), 'parse-test') : null;
        res.json({ success: true, kind: 'email', authentication: verdict, parsed, recorded: false });
        return;
      }
      const sender = clampText(b.sender, 40);
      const text = clampText(b.text, 1200);
      const wallet = walletForSender(sender, core.senderRules);
      res.json({ success: true, kind: 'sms', sender, wallet, senderAccepted: wallet !== null, parsed: wallet ? parseWalletSms(wallet, text) : null, masked: maskProviderText(text), recorded: false });
    }),
  );

  router.get(
    '/api/admin/balance',
    wrap(async (_req, res) => {
      res.json({ success: true, bkash: await getBalanceAnchor(core, 'bkash'), nagad: await getBalanceAnchor(core, 'nagad'), note: 'Amounts are in paisa (1/100 Taka). trustedMinor is the last balance confirmed; suspectMinor is the latest balance reported by an SMS that does not follow from it.' });
    }),
  );

  router.post(
    '/api/admin/balance',
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      const method = resolveMethod({ method: b.method });
      if (method !== 'bkash' && method !== 'nagad') throw new HttpError(400, 'unknown_method', 'method must be bkash or nagad.');
      const balanceMinor = toMinor(typeof b.balance === 'number' ? b.balance : String(b.balance ?? ''));
      if (!Number.isFinite(balanceMinor) || balanceMinor < 0) throw new HttpError(400, 'bad_amount', 'Enter the balance your wallet app shows, in Taka.');
      res.json({ success: true, anchor: await trustBalance(core, method as Method, balanceMinor, 'owner entered the balance shown in the wallet app') });
    }),
  );

  router.post(
    '/api/admin/reconcile-bulk',
    wrap(async (_req, res) => {
      res.json({ success: true, ...(await reconcileAll(core)) });
    }),
  );

  router.get(
    '/api/admin/accountant-pack',
    wrap(async (_req, res) => {
      res.json({ success: true, ...(await accountantPack(core)) });
    }),
  );

  router.get(
    '/api/admin/quarantine',
    wrap(async (_req, res) => {
      const items = await store.list<{ at: string }>(C.quarantine, [], 500);
      res.json({ success: true, items: items.sort((a, b) => b.at.localeCompare(a.at)).slice(0, 200) });
    }),
  );

  // There is no simulator in production: a "simulated" payment would be a fake ledger record.
  router.use('/api/admin/simulator', (_req, res) => {
    res.status(410).json({ success: false, error: 'The payment simulator was removed. Test with a real small payment, or with the parse-test tool.', code: 'gone' });
  });

  // ---- orders and work
  router.get(
    '/api/admin/orders',
    wrap(async (req, res) => {
      const state = query(req, 'state');
      const orders = (await store.list<Order>(C.orders, state ? [['state', state]] : [], 2000)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 500);
      res.json({ success: true, orders });
    }),
  );

  router.get(
    '/api/admin/orders/:id',
    wrap(async (req, res) => {
      const order = await getOwnOrder(core, param(req, 'id'), null);
      const c = await store.get<Client>(C.clients, order.clientId);
      res.json({ success: true, ...(await orderBundle(order, true)), client: c ? publicClient(c) : null });
    }),
  );

  router.post(
    '/api/admin/orders/:id/quote',
    jsonSmall,
    wrap(async (req, res) => {
      const b = body(req);
      res.json({ success: true, ...(await setQuote(core, param(req, 'id'), b.amountUSD ?? b.amount, b.note)) });
    }),
  );

  router.post(
    '/api/admin/orders/:id/cancel',
    jsonSmall,
    wrap(async (req, res) => {
      res.json({ success: true, order: await cancelOrder(core, param(req, 'id'), clampText(body(req).reason, 300)) });
    }),
  );

  router.post(
    '/api/admin/orders/:id/messages',
    jsonSmall,
    wrap(async (req, res) => {
      const order = await getOwnOrder(core, param(req, 'id'), null);
      const b = body(req);
      const text = clampText(b.text, 4000);
      if (!text) throw new HttpError(400, 'empty_message', 'Type a message.');
      await addMessage(core, order, 'owner', 'M R S', text, b.internal === true);
      res.status(201).json({ success: true, messages: await listMessages(core, order.orderId, true) });
    }),
  );

  router.get(
    '/api/admin/orders/:id/files/:fileId',
    wrap(async (req, res) => {
      const order = await getOwnOrder(core, param(req, 'id'), null);
      const file = order.intakeFiles.find((f) => f.id === param(req, 'fileId'));
      const bytes = file ? await store.getBlob(intakeBlobId(order.orderId, file)) : null;
      if (!file || !bytes) throw new HttpError(404, 'not_found', 'File not found.');
      sendDownload(res, file.fileName, 'application/octet-stream', bytes); // client uploads are never rendered in the admin's browser
    }),
  );

  router.post(
    '/api/admin/orders/:id/deliverables',
    jsonUpload,
    wrap(async (req, res) => {
      const b = body(req);
      const url = clampText(b.externalUrl, 500);
      if (url && !/^https:\/\/[^\s]+$/.test(url)) throw new HttpError(400, 'bad_url', 'The link must start with https://');
      const bytes = url ? Buffer.alloc(0) : decodeBase64Upload(b.base64Data, 7.5 * 1024 * 1024);
      const d = await ownerUpload(core, param(req, 'id'), b.fileName, b.title, bytes, url || undefined);
      res.status(201).json({ success: true, deliverable: d });
    }),
  );

  router.get(
    '/api/admin/deliverables/:id/download',
    wrap(async (req, res) => {
      const d = await store.get<Deliverable>(C.deliverables, param(req, 'id'));
      if (!d) throw new HttpError(404, 'not_found', 'File not found.');
      await sendDeliverable(res, d);
    }),
  );

  router.get(
    '/api/admin/jobs',
    wrap(async (req, res) => {
      const state = query(req, 'state');
      const jobs = (await store.list<Job>(C.jobs, state ? [['state', state]] : [], 2000)).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 500);
      res.json({ success: true, jobs });
    }),
  );

  const jobAction = (fn: (id: string, b: Record<string, unknown>) => Promise<Job | null>): RequestHandler =>
    wrap(async (req, res) => {
      const job = await fn(param(req, 'id'), body(req));
      if (!job) throw new HttpError(404, 'job_not_found', 'Job not found.');
      const order = await advance(core, job.orderId);
      res.json({ success: true, job, order });
    });
  router.post('/api/admin/jobs/:id/run', jsonSmall, jobAction(async (id) => { await requeue(core, id); return runJob(core, id); }));
  router.post('/api/admin/jobs/:id/release', jsonSmall, jobAction((id, b) => release(core, id, 'owner', b.force === true)));
  router.post('/api/admin/jobs/:id/send-back', jsonSmall, jobAction((id, b) => sendBack(core, id, b.notes)));
  router.post('/api/admin/jobs/:id/owner-done', jsonSmall, jobAction((id, b) => ownerDone(core, id, b.notes)));

  router.get(
    '/api/admin/fulfilment-settings',
    wrap(async (_req, res) => {
      res.json({ success: true, settings: await getFulfilmentSettings(core), modelCallsToday: await modelCallsToday(core), model: core.model.name, modelAvailable: core.model.available });
    }),
  );
  router.put(
    '/api/admin/fulfilment-settings',
    jsonSmall,
    wrap(async (req, res) => {
      const settings = await saveFulfilmentSettings(core, body(req));
      await audit(store, { actor: 'owner', action: 'settings.fulfilment', target: 'fulfilmentSettings', detail: `autoRelease=${Object.keys(settings.autoRelease).join(',') || 'none'}` });
      res.json({ success: true, settings });
    }),
  );

  // ---- oversight
  router.get(
    '/api/admin/alerts',
    wrap(async (_req, res) => {
      res.json({ success: true, alerts: await listAlerts(store, 150) });
    }),
  );
  router.post(
    '/api/admin/alerts/:id/read',
    wrap(async (req, res) => {
      await markAlertRead(store, param(req, 'id'));
      res.json({ success: true });
    }),
  );
  router.get(
    '/api/admin/audit',
    wrap(async (_req, res) => {
      res.json({ success: true, chain: await verifyAuditChain(store), entries: await listAudit(store, 300) });
    }),
  );

  router.get(
    '/api/admin/overview',
    wrap(async (_req, res) => {
      const settings = await getSettings(store);
      const orders = await store.list<Order>(C.orders, [], 5000);
      const jobs = await store.list<Job>(C.jobs, [], 5000);
      const { counts } = await listPayments(core, 'all');
      const byState = (xs: { state: string }[]): Record<string, number> => xs.reduce<Record<string, number>>((acc, x) => ({ ...acc, [x.state]: (acc[x.state] ?? 0) + 1 }), {});
      const unpaid = (await store.list<Invoice>(C.invoices, [], 5000)).filter((i) => i.status === 'issued' || i.status === 'partially_paid');
      res.json({
        success: true,
        needsYou: { quotes: orders.filter((o) => o.state === 'quote_pending').length, payments: counts.needsAction, drafts: jobs.filter((j) => j.state === 'owner_review').length, handsOn: jobs.filter((j) => j.state === 'owner_task').length, failed: jobs.filter((j) => j.state === 'failed').length, unreadAlerts: (await listAlerts(store, 500)).filter((a) => !a.read && a.level !== 'info').length },
        orders: byState(orders),
        jobs: byState(jobs),
        payments: counts,
        receivableUSD: unpaid.reduce((s, i) => s + i.amountDue, 0),
        bridges: await bridgeStatuses(store, settings.smsStaleHours),
        configProblems: checkSecrets(secrets),
        storage: { kind: store.kind, durable: store.durable },
      });
    }),
  );

  /** Go-live check. `?live=1` also makes one tiny real call to the AI model. */
  router.get(
    '/api/admin/selftest',
    wrap(async (req, res) => {
      const settings = await getSettings(store);
      const checks: { id: string; ok: boolean; detail: string }[] = [];
      const add = (id: string, ok: boolean, detail: string): void => void checks.push({ id, ok, detail });
      try {
        const id = `selftest:${Date.now()}`;
        await store.put(C.meta, id, { v: 1 });
        const inTx = await store.tx(async (t) => {
          const got = await t.get<{ v: number }>(C.meta, id);
          t.put(C.meta, id, { v: (got?.v ?? 0) + 1 });
          return got?.v;
        });
        const after = await store.get<{ v: number }>(C.meta, id);
        const dup = await store.create(C.meta, id, { v: 9 });
        await store.putBlob(id, Buffer.from('blob-check'));
        const blob = await store.getBlob(id);
        await store.deleteBlob(id);
        await store.delete(C.meta, id);
        add('storage', inTx === 1 && after?.v === 2 && dup === false && blob?.toString() === 'blob-check', `${store.kind}: write, transaction, unique-create and file storage ${inTx === 1 && after?.v === 2 && dup === false && blob?.toString() === 'blob-check' ? 'work' : 'FAILED'}.`);
      } catch (err) {
        add('storage', false, `${store.kind}: ${String((err as Error)?.message ?? err).slice(0, 200)}`);
      }
      add('storage_durable', store.durable, store.durable ? 'Data survives restarts.' : 'IN-MEMORY storage: every order, payment and file is lost when the server restarts. Configure FirestoreStore before going live.');
      for (const p of checkSecrets(secrets)) add(`config:${p.key}`, false, p.message);
      const auditChain = await verifyAuditChain(store);
      add('audit_chain', auditChain.ok, auditChain.ok ? `${auditChain.entries} entries, chain intact.` : `Broken at entry ${auditChain.brokenAt}: ${auditChain.reason}.`);
      const bridges = await bridgeStatuses(store, settings.smsStaleHours);
      add('bridge_sms', bridges.sms.health === 'healthy', bridges.sms.health === 'never_seen' ? 'The phone has never reported. bKash and Nagad payments wait for you until it does.' : `Last seen ${bridges.sms.lastSeenAt} (${bridges.sms.health}).`);
      add('bridge_email', bridges.email.health === 'healthy', bridges.email.health === 'never_seen' ? 'The Gmail collector has never reported. Payoneer and Skrill payments wait for you until it does.' : `Last seen ${bridges.email.lastSeenAt} (${bridges.email.health}).`);
      add('bridge_api', bridges.api.health === 'healthy', bridges.api.health === 'never_seen' ? 'The Binance poller has never reported. Binance payments wait for you until it does.' : `Last seen ${bridges.api.lastSeenAt} (${bridges.api.health})${bridges.api.lastError ? `; last error: ${bridges.api.lastError}` : ''}.`);
      for (const w of ['bkash', 'nagad'] as Method[]) {
        const a = await getBalanceAnchor(core, w);
        add(`balance_${w}`, a.trustedMinor !== null && a.suspectMinor === null, a.trustedMinor === null ? 'No confirmed balance yet: enter the balance your app shows (once).' : a.suspectMinor !== null ? 'An SMS reported a balance that does not follow from the last confirmed one. Compare with your app and confirm.' : 'Running balance is confirmed.');
      }
      const chain = forwardedChain(req);
      add('your_address', true, `The server sees your address as ${clientIp(req)} (${chain.length} forwarded hop(s), trusting ${getTrustedProxyHops()}). Compare with your public IP address (search "what is my IP"). If they differ, every visitor is sharing one rate limit: set MRS_TRUSTED_PROXY_HOPS=${getTrustedProxyHops() + 1} and check again.`);
      if (!core.model.available) add('ai_model', false, 'GEMINI_API_KEY is not set.');
      else if (query(req, 'live') === '1') {
        try {
          const answer = await core.model.generate({ system: 'Reply with the single word READY.', parts: [{ text: 'Say READY.' }], maxOutputTokens: 256, temperature: 0 });
          add('ai_model', /ready/i.test(answer), `${core.model.name} answered: "${answer.trim().slice(0, 40)}"`);
        } catch (err) {
          add('ai_model', false, `${core.model.name}: ${String((err as Error)?.message ?? err).slice(0, 200)}`);
        }
      } else add('ai_model', true, `${core.model.name} is configured (add ?live=1 to make one real test call).`);
      res.json({ success: true, ok: checks.every((c) => c.ok), checks });
    }),
  );

  // ============================================================ nothing else lives under these prefixes
  router.use(OWNED_PREFIXES, (_req, res) => {
    res.status(404).json({ success: false, error: 'Not found.', code: 'not_found' });
  });
  router.use(errorHandler(core));
  return router;
}

