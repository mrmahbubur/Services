/**
 * mrs-core — sign-in for the owner (admin) and for clients (portal).
 *
 * The password / PIN is checked on the SERVER. The browser only ever holds a signed
 * session token; a flag in localStorage means nothing here.
 *
 *  - Passwords and PINs are stored as scrypt hashes with a per-record salt.
 *  - Sessions are HMAC-signed tokens, sent as an HttpOnly cookie and also accepted
 *    as `Authorization: Bearer` (for the AI Studio preview iframe).
 *  - Cookie-authenticated requests that change anything must come from this site
 *    (Origin check), which stops cross-site request forgery.
 *  - With no session secret / admin password configured, admin routes answer 503.
 *    They never fall back to "open".
 */
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { Secrets } from '../config.ts';
import { HttpError, safeEqual } from '../util.ts';

// ---------------------------------------------------------------- hashing

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 32 };

export function hashSecret(plain: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(plain, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64url'), hash.toString('base64url')].join('$');
}

export function verifySecret(plain: string, stored: string): boolean {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [N, r, p] = [Number(parts[1]), Number(parts[2]), Number(parts[3])];
  if (![N, r, p].every((n) => Number.isInteger(n) && n > 0) || N > 1 << 17) return false;
  try {
    const salt = Buffer.from(parts[4] ?? '', 'base64url');
    const expected = Buffer.from(parts[5] ?? '', 'base64url');
    const actual = scryptSync(plain, salt, expected.length, { N, r, p });
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------- tokens

export interface Session {
  role: 'admin' | 'client';
  /** 'owner' for admin, the Client ID for clients. */
  sub: string;
  iat: number;
  exp: number;
  /** Admin sessions carry the epoch; "sign out everywhere" bumps it. */
  epoch: number;
}

function sign(secret: string, body: string): string {
  return createHmac('sha256', secret).update('mrs-session-v1:' + body).digest('base64url');
}

export function issueToken(secret: string, session: Omit<Session, 'iat' | 'exp'>, ttlSeconds: number): string {
  const iat = Math.floor(Date.now() / 1000);
  const body = Buffer.from(JSON.stringify({ ...session, iat, exp: iat + ttlSeconds })).toString('base64url');
  return `v1.${body}.${sign(secret, body)}`;
}

export function readToken(secret: string, token: string | undefined): Session | null {
  if (!secret || !token) return null;
  const parts = token.split('.');
  if (parts.length !== 3 || parts[0] !== 'v1') return null;
  const body = parts[1] ?? '';
  if (!safeEqual(sign(secret, body), parts[2] ?? '')) return null;
  try {
    const s = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as Session;
    if ((s.role !== 'admin' && s.role !== 'client') || typeof s.sub !== 'string') return null;
    if (typeof s.exp !== 'number' || s.exp < Math.floor(Date.now() / 1000)) return null;
    return s;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------- http helpers

export const ADMIN_COOKIE = 'mrs_admin';
export const CLIENT_COOKIE = 'mrs_client';
export const ADMIN_TTL = 12 * 3600;
export const CLIENT_TTL = 14 * 24 * 3600;

function header(req: Request, name: string): string {
  const v = req.headers[name];
  return Array.isArray(v) ? (v[0] ?? '') : (v ?? '');
}

export function isHttps(req: Request): boolean {
  return req.secure || header(req, 'x-forwarded-proto').split(',')[0]?.trim() === 'https';
}

/**
 * How many proxies sit between the internet and this server. Each one appends the
 * address it received the request from to X-Forwarded-For, so the caller's real
 * address is that many entries from the END of the list. Entries before it are
 * whatever the caller typed and are never trusted.
 *
 * Cloud Run alone = 1. If the platform adds another hop, every visitor would appear
 * to come from that hop's address and would share one rate-limit bucket; the admin
 * self-test shows the address the server sees so this can be noticed and set.
 */
let trustedProxyHops = 1;
export function setTrustedProxyHops(hops: number): void {
  trustedProxyHops = Number.isInteger(hops) && hops >= 1 && hops <= 5 ? hops : 1;
}
export function getTrustedProxyHops(): number {
  return trustedProxyHops;
}

export function forwardedChain(req: Request): string[] {
  return header(req, 'x-forwarded-for')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

/** Caller address, for rate limiting and for the record. */
export function clientIp(req: Request): string {
  const xff = forwardedChain(req);
  return xff[xff.length - trustedProxyHops] ?? xff[0] ?? req.socket?.remoteAddress ?? 'unknown';
}

export function readCookie(req: Request, name: string): string | undefined {
  const raw = header(req, 'cookie');
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return undefined;
}

export function setSessionCookie(req: Request, res: Response, name: string, token: string, ttlSeconds: number): void {
  // Over HTTPS the cookie is partitioned + SameSite=None so it also works inside the
  // AI Studio preview iframe. CSRF is handled by the Origin check below.
  const attrs = isHttps(req) ? 'Secure; SameSite=None; Partitioned' : 'SameSite=Lax';
  res.append('Set-Cookie', `${name}=${encodeURIComponent(token)}; Path=/; HttpOnly; Max-Age=${ttlSeconds}; ${attrs}`);
}

export function clearSessionCookie(req: Request, res: Response, name: string): void {
  const attrs = isHttps(req) ? 'Secure; SameSite=None; Partitioned' : 'SameSite=Lax';
  res.append('Set-Cookie', `${name}=; Path=/; HttpOnly; Max-Age=0; ${attrs}`);
}

function bearer(req: Request): string | undefined {
  const h = header(req, 'authorization');
  return /^Bearer\s+\S+$/i.test(h) ? h.replace(/^Bearer\s+/i, '').trim() : undefined;
}

/** Extra origins the owner has allowed (for example the AI Studio preview address). */
let extraOrigins = new Set<string>();
export function setAllowedOrigins(list: string[]): void {
  extraOrigins = new Set();
  for (const item of list) {
    try {
      extraOrigins.add(new URL(item.trim()).host.toLowerCase());
    } catch {
      /* ignore entries that are not URLs */
    }
  }
}

/**
 * True when a state-changing, cookie-authenticated request really comes from this
 * site. Two independent signals, both set by the browser and not by page script:
 *  - Sec-Fetch-Site (modern browsers): a request started by another website says so
 *  - Origin / Referer: must name this site
 */
export function sameOrigin(req: Request, publicBaseUrl: string): boolean {
  const fetchSite = header(req, 'sec-fetch-site').toLowerCase();
  if (fetchSite === 'cross-site') return false;

  const origin = header(req, 'origin') || header(req, 'referer');
  if (!origin) return false;
  let host: string;
  try {
    host = new URL(origin).host.toLowerCase();
  } catch {
    return false;
  }
  const allowed = new Set<string>(extraOrigins);
  for (const h of [header(req, 'host'), header(req, 'x-forwarded-host').split(',')[0] ?? '']) {
    if (h.trim()) allowed.add(h.trim().toLowerCase());
  }
  try {
    allowed.add(new URL(publicBaseUrl).host.toLowerCase());
  } catch {
    /* ignore a malformed base url */
  }
  return allowed.has(host);
}

const BAD_ORIGIN = 'This request did not come from the site itself. If you are using the site at a different address (for example the AI Studio preview), add that address to MRS_ALLOWED_ORIGINS.';

// ---------------------------------------------------------------- guards

export interface AuthDeps {
  secrets: Secrets;
  /** Current admin epoch (cached read from the store). */
  adminEpoch: () => Promise<number>;
}

export interface AuthedRequest extends Request {
  mrsSession?: Session;
}

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

function resolveSession(req: Request, deps: AuthDeps, cookieName: string): { session: Session | null; viaCookie: boolean } {
  const viaBearer = readToken(deps.secrets.sessionSecret, bearer(req));
  if (viaBearer) return { session: viaBearer, viaCookie: false };
  return { session: readToken(deps.secrets.sessionSecret, readCookie(req, cookieName)), viaCookie: true };
}

export function adminConfigured(s: Secrets): boolean {
  return s.sessionSecret.length >= 32 && (s.adminPasswordHash.length > 0 || s.adminPassword.length >= 12);
}

export function checkAdminPassword(s: Secrets, candidate: string): boolean {
  if (!adminConfigured(s) || typeof candidate !== 'string' || candidate.length === 0) return false;
  if (s.adminPasswordHash) return verifySecret(candidate, s.adminPasswordHash);
  // Compare HMACs so the comparison is constant-time whatever the lengths.
  const mac = (v: string): string => createHmac('sha256', s.sessionSecret).update('admin-pw:' + v).digest('hex');
  return safeEqual(mac(candidate), mac(s.adminPassword));
}

export function requireAdmin(deps: AuthDeps) {
  return async (req: AuthedRequest, _res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!adminConfigured(deps.secrets)) {
        throw new HttpError(503, 'admin_not_configured', 'Admin access is switched off until MRS_SESSION_SECRET and MRS_ADMIN_PASSWORD are set.');
      }
      const { session, viaCookie } = resolveSession(req, deps, ADMIN_COOKIE);
      if (!session || session.role !== 'admin') throw new HttpError(401, 'admin_required', 'Sign in as the owner.');
      if (session.epoch !== (await deps.adminEpoch())) throw new HttpError(401, 'session_revoked', 'Session ended. Sign in again.');
      if (viaCookie && !SAFE_METHODS.has(req.method) && !sameOrigin(req, deps.secrets.publicBaseUrl)) {
        throw new HttpError(403, 'bad_origin', BAD_ORIGIN);
      }
      req.mrsSession = session;
      next();
    } catch (err) {
      next(err);
    }
  };
}

export function requireClient(deps: AuthDeps) {
  return (req: AuthedRequest, _res: Response, next: NextFunction): void => {
    try {
      if (deps.secrets.sessionSecret.length < 32) {
        throw new HttpError(503, 'portal_not_configured', 'Client sign-in is switched off until MRS_SESSION_SECRET is set.');
      }
      const { session, viaCookie } = resolveSession(req, deps, CLIENT_COOKIE);
      if (!session || session.role !== 'client') throw new HttpError(401, 'client_required', 'Sign in with your Client ID and PIN.');
      if (viaCookie && !SAFE_METHODS.has(req.method) && !sameOrigin(req, deps.secrets.publicBaseUrl)) {
        throw new HttpError(403, 'bad_origin', BAD_ORIGIN);
      }
      req.mrsSession = session;
      next();
    } catch (err) {
      next(err);
    }
  };
}

/** Reads a client session if one is present; never rejects. */
export function optionalClient(deps: AuthDeps, req: Request): Session | null {
  const { session } = resolveSession(req, deps, CLIENT_COOKIE);
  return session && session.role === 'client' ? session : null;
}
