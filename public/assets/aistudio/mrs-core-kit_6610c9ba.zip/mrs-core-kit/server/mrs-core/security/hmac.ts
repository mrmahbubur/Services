/**
 * mrs-core — authenticating the collectors (phone SMS bridge, Gmail script, API poller).
 *
 * Scheme (identical to "SMS Gateway for Android", so the phone app works unmodified):
 *
 *   X-Timestamp: <unix seconds>
 *   X-Signature: hex( HMAC-SHA256( key, <raw request body> + <X-Timestamp> ) )
 *
 * A request is accepted only if the signature matches AND the timestamp is recent
 * AND its event id has not been seen before (replay protection lives in the caller).
 */
import { createHmac, timingSafeEqual } from 'node:crypto';
import type { Request } from 'express';
import { safeEqual } from '../util.ts';

export const MAX_SKEW_SECONDS = 300;

export function signBody(key: string, body: string | Buffer, timestamp: string): string {
  return createHmac('sha256', key).update(body).update(timestamp).digest('hex');
}

function hexEqual(a: string, b: string): boolean {
  if (!/^[0-9a-f]+$/.test(a) || a.length !== b.length || a.length % 2 !== 0) return false;
  return timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
}

export interface SignedBody {
  ok: boolean;
  reason?: string;
  /** Parsed JSON body (only when ok). */
  json?: unknown;
}

function header(req: Request, name: string): string {
  const v = req.headers[name];
  return (Array.isArray(v) ? v[0] : v) ?? '';
}

/**
 * Verifies a signed JSON request.
 *
 * `req.body` is a Buffer when our own raw parser ran first (the normal case). If the
 * host app's express.json() got there first, the exact bytes are gone; we then try
 * the canonical re-serialisation. That is still safe - a request is only accepted
 * when an HMAC over the candidate bytes matches - it just may fail for payloads the
 * sender formatted differently, in which case the reason says how to fix the setup.
 */
export function verifySignedJson(req: Request, key: string, nowMs = Date.now()): SignedBody {
  if (!key || key.length < 16) return { ok: false, reason: 'signing key not configured on the server' };

  const tsHeader = header(req, 'x-timestamp').trim();
  const signature = header(req, 'x-signature').trim().toLowerCase().replace(/^sha256=/, '');
  if (!tsHeader || !signature) return { ok: false, reason: 'missing X-Timestamp or X-Signature' };
  if (!/^\d{9,13}$/.test(tsHeader)) return { ok: false, reason: 'X-Timestamp must be unix time' };

  const tsSeconds = tsHeader.length >= 12 ? Math.floor(Number(tsHeader) / 1000) : Number(tsHeader);
  if (Math.abs(nowMs / 1000 - tsSeconds) > MAX_SKEW_SECONDS) {
    return { ok: false, reason: 'timestamp outside the allowed 5 minute window (check the sender clock)' };
  }

  const body: unknown = req.body;
  const candidates: (Buffer | string)[] = [];
  if (Buffer.isBuffer(body)) candidates.push(body);
  else if (typeof body === 'string') candidates.push(body);
  else if (body && typeof body === 'object') candidates.push(JSON.stringify(body));
  if (candidates.length === 0) return { ok: false, reason: 'empty body' };

  const matched = candidates.find((c) => hexEqual(signature, signBody(key, c, tsHeader)));
  if (matched === undefined) {
    const hint = Buffer.isBuffer(body) ? '' : ' (body was parsed before mrs-core saw it: call installMrsCore(app) before app.use(express.json()))';
    return { ok: false, reason: 'signature mismatch' + hint };
  }

  try {
    const json: unknown = Buffer.isBuffer(matched) ? JSON.parse(matched.toString('utf8')) : typeof matched === 'string' && typeof body === 'string' ? JSON.parse(matched) : body;
    return { ok: true, json };
  } catch {
    return { ok: false, reason: 'body is not valid JSON' };
  }
}

/** Static bearer token, for SMS forwarder apps that can add a header but cannot sign. */
export function verifyBearerJson(req: Request, token: string): SignedBody {
  if (!token || token.length < 24) return { ok: false, reason: 'bearer token not configured on the server' };
  const h = header(req, 'authorization');
  const presented = /^Bearer\s+/i.test(h) ? h.replace(/^Bearer\s+/i, '').trim() : header(req, 'x-mrs-token').trim();
  if (!presented || !safeEqual(presented, token)) return { ok: false, reason: 'bad bearer token' };
  const body: unknown = req.body;
  try {
    if (Buffer.isBuffer(body)) return { ok: true, json: JSON.parse(body.toString('utf8')) };
    if (typeof body === 'string') return { ok: true, json: JSON.parse(body) };
    if (body && typeof body === 'object') return { ok: true, json: body };
  } catch {
    return { ok: false, reason: 'body is not valid JSON' };
  }
  return { ok: false, reason: 'empty body' };
}
