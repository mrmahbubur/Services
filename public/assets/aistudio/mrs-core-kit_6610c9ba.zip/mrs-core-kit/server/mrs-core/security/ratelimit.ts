/**
 * mrs-core — in-memory rate limiting.
 *
 * Per-instance only (Cloud Run may run several instances), which is enough to blunt
 * guessing and flooding. PIN lock-out, which must be exact, is stored on the client
 * record instead - see orders/service.ts.
 */
import type { NextFunction, Request, Response } from 'express';
import { clientIp } from './auth.ts';
import { HttpError } from '../util.ts';

interface Bucket {
  count: number;
  resetAt: number;
}

export class RateLimiter {
  private buckets = new Map<string, Bucket>();
  private limit: number;
  private windowMs: number;

  constructor(limit: number, windowMs: number) {
    this.limit = limit;
    this.windowMs = windowMs;
  }

  /** Counts one hit. Returns false when the caller is over the limit. */
  hit(key: string, now = Date.now()): boolean {
    if (this.buckets.size > 20_000) this.sweep(now);
    const b = this.buckets.get(key);
    if (!b || b.resetAt <= now) {
      this.buckets.set(key, { count: 1, resetAt: now + this.windowMs });
      return true;
    }
    b.count += 1;
    return b.count <= this.limit;
  }

  /** Seconds until the caller may try again. */
  retryAfter(key: string, now = Date.now()): number {
    const b = this.buckets.get(key);
    return b ? Math.max(1, Math.ceil((b.resetAt - now) / 1000)) : 1;
  }

  reset(key: string): void {
    this.buckets.delete(key);
  }

  private sweep(now: number): void {
    for (const [k, b] of this.buckets) if (b.resetAt <= now) this.buckets.delete(k);
  }
}

/** Express middleware: `limit` requests per `windowMs` per caller IP, per route group. */
export function rateLimit(name: string, limit: number, windowMs: number) {
  const limiter = new RateLimiter(limit, windowMs);
  return (req: Request, res: Response, next: NextFunction): void => {
    const key = `${name}:${clientIp(req)}`;
    if (limiter.hit(key)) {
      next();
      return;
    }
    res.setHeader('Retry-After', String(limiter.retryAfter(key)));
    next(new HttpError(429, 'rate_limited', 'Too many requests. Please wait a moment and try again.'));
  };
}
