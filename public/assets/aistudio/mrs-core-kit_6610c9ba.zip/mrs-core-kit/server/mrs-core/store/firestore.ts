/**
 * mrs-core — Firestore adapter (use this on Cloud Run / AI Studio).
 *
 * It takes a Firestore handle from the Admin SDK and never imports firebase-admin
 * itself, so this package adds no dependency. In the host app:
 *
 *   import { initializeApp } from 'firebase-admin/app';
 *   import { getFirestore } from 'firebase-admin/firestore';
 *   const db = getFirestore(initializeApp());            // or getFirestore(app, '<databaseId>')
 *   installMrsCore(app, { store: new FirestoreStore(db) });
 *
 * Collections are prefixed (default "mrs_") so they cannot collide with anything
 * the app already stores. Only equality filters are used, so no composite index
 * has to be created.
 *
 * Security rules: these collections are read and written by the SERVER only (the
 * Admin SDK bypasses rules). Browsers must have no access to any collection whose
 * name starts with "mrs_" - see docs/INTEGRATION.md for the rule to add.
 */
import type { Store, Tx, Where } from './store.ts';
import { MAX_BLOB_BYTES, plain } from './store.ts';

// The slice of the Admin SDK surface this adapter relies on.
interface DocSnap {
  exists: boolean;
  data(): unknown;
}
interface DocRef {
  get(): Promise<DocSnap>;
  set(data: object): Promise<unknown>;
  create(data: object): Promise<unknown>;
  delete(): Promise<unknown>;
}
interface QuerySnap {
  docs: { data(): unknown }[];
}
interface Query {
  where(field: string, op: '==', value: unknown): Query;
  limit(n: number): Query;
  get(): Promise<QuerySnap>;
}
interface CollectionRef extends Query {
  doc(id: string): DocRef;
}
interface Transaction {
  get(ref: DocRef): Promise<DocSnap>;
  set(ref: DocRef, data: object): unknown;
  delete(ref: DocRef): unknown;
}
export interface FirestoreLike {
  collection(path: string): CollectionRef;
  runTransaction<R>(fn: (t: Transaction) => Promise<R>): Promise<R>;
}

const CHUNK = 600 * 1024; // raw bytes per blob chunk; base64 keeps each doc under Firestore's 1 MiB cap

function isAlreadyExists(err: unknown): boolean {
  const e = err as { code?: unknown; message?: unknown };
  return e?.code === 6 || e?.code === 'already-exists' || /ALREADY_EXISTS|already exists/i.test(String(e?.message));
}

/** Firestore document ids may not contain '/', nor be '.' or '..', nor match __.*__ */
function docId(id: string): string {
  const safe = id.replace(/\//g, '_');
  return /^(\.{1,2}|__.*__)$/.test(safe) ? `id_${safe}` : safe;
}

export class FirestoreStore implements Store {
  readonly kind = 'firestore';
  readonly durable = true;
  private db: FirestoreLike;
  private prefix: string;

  constructor(db: unknown, prefix = 'mrs_') {
    const candidate = db as Partial<FirestoreLike> | null;
    if (!candidate || typeof candidate.collection !== 'function' || typeof candidate.runTransaction !== 'function') {
      throw new Error('FirestoreStore needs a Firestore handle from firebase-admin (getFirestore())');
    }
    this.db = candidate as FirestoreLike;
    this.prefix = prefix;
  }

  private ref(collection: string, id: string): DocRef {
    return this.db.collection(this.prefix + collection).doc(docId(id));
  }

  async get<T>(collection: string, id: string): Promise<T | null> {
    const snap = await this.ref(collection, id).get();
    return snap.exists ? (snap.data() as T) : null;
  }

  async put(collection: string, id: string, doc: object): Promise<void> {
    await this.ref(collection, id).set(plain(doc));
  }

  async create(collection: string, id: string, doc: object): Promise<boolean> {
    try {
      await this.ref(collection, id).create(plain(doc));
      return true;
    } catch (err) {
      if (isAlreadyExists(err)) return false;
      throw err;
    }
  }

  async delete(collection: string, id: string): Promise<void> {
    await this.ref(collection, id).delete();
  }

  async list<T>(collection: string, where: Where[] = [], limit = 2000): Promise<T[]> {
    let q: Query = this.db.collection(this.prefix + collection);
    for (const [field, value] of where) q = q.where(field, '==', value);
    const snap = await q.limit(limit).get();
    return snap.docs.map((d) => d.data() as T);
  }

  tx<R>(fn: (t: Tx) => Promise<R>): Promise<R> {
    return this.db.runTransaction(async (ft) => {
      const t: Tx = {
        get: async <T>(collection: string, id: string): Promise<T | null> => {
          const snap = await ft.get(this.ref(collection, id));
          return snap.exists ? (snap.data() as T) : null;
        },
        put: (collection, id, doc) => {
          ft.set(this.ref(collection, id), plain(doc));
        },
        delete: (collection, id) => {
          ft.delete(this.ref(collection, id));
        },
      };
      return fn(t);
    });
  }

  async putBlob(id: string, bytes: Buffer): Promise<void> {
    if (bytes.length > MAX_BLOB_BYTES) throw new Error('blob too large');
    const total = Math.max(1, Math.ceil(bytes.length / CHUNK));
    const previous = await this.get<{ chunks: number }>('blobIndex', id);
    for (let i = 0; i < total; i++) {
      const part = bytes.subarray(i * CHUNK, (i + 1) * CHUNK);
      await this.put('blobs', `${id}__${i}`, { id, index: i, data: part.toString('base64') });
    }
    await this.put('blobIndex', id, { id, chunks: total, size: bytes.length });
    for (let i = total; i < (previous?.chunks ?? 0); i++) await this.delete('blobs', `${id}__${i}`);
  }

  async getBlob(id: string): Promise<Buffer | null> {
    const index = await this.get<{ chunks: number }>('blobIndex', id);
    if (!index) return null;
    const parts: Buffer[] = [];
    for (let i = 0; i < index.chunks; i++) {
      const chunk = await this.get<{ data: string }>('blobs', `${id}__${i}`);
      if (!chunk) return null;
      parts.push(Buffer.from(chunk.data, 'base64'));
    }
    return Buffer.concat(parts);
  }

  async deleteBlob(id: string): Promise<void> {
    const index = await this.get<{ chunks: number }>('blobIndex', id);
    if (!index) return;
    for (let i = 0; i < index.chunks; i++) await this.delete('blobs', `${id}__${i}`);
    await this.delete('blobIndex', id);
  }
}
