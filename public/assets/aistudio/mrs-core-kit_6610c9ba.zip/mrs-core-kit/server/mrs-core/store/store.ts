/**
 * mrs-core — storage.
 *
 * Everything the business depends on (ledger, payments, invoices, orders, jobs,
 * deliverables) lives behind this one small interface, so the server - not the
 * browser - is the source of truth.
 *
 *   MemoryStore    tests and local experiments. Lost on restart.
 *   FileStore      one JSON file + a blobs folder. Fine on a VPS or a laptop.
 *                  NOT for Cloud Run: its disk is wiped on every cold start.
 *   FirestoreStore (firestore.ts) the one to use on Cloud Run / AI Studio.
 *
 * Transaction rule (same as Firestore): do every read before the first write.
 * MemoryStore enforces it, so a mistake shows up in tests rather than in production.
 */
import { existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

/** Equality filter: [field, value]. Only equality is used so Firestore needs no composite indexes. */
export type Where = [field: string, value: string | number | boolean];

export interface Tx {
  get<T>(collection: string, id: string): Promise<T | null>;
  put(collection: string, id: string, doc: object): void;
  delete(collection: string, id: string): void;
}

export interface Store {
  /** 'memory' | 'file' | 'firestore' - reported by the readiness endpoint. */
  readonly kind: string;
  /** False when data does not survive a restart. */
  readonly durable: boolean;
  get<T>(collection: string, id: string): Promise<T | null>;
  put(collection: string, id: string, doc: object): Promise<void>;
  /** Insert only if absent. Resolves false (and writes nothing) when the id exists. */
  create(collection: string, id: string, doc: object): Promise<boolean>;
  delete(collection: string, id: string): Promise<void>;
  list<T>(collection: string, where?: Where[], limit?: number): Promise<T[]>;
  /** Atomic read-then-write. `fn` may be retried, so it must only touch `t`. */
  tx<R>(fn: (t: Tx) => Promise<R>): Promise<R>;
  putBlob(id: string, bytes: Buffer): Promise<void>;
  getBlob(id: string): Promise<Buffer | null>;
  deleteBlob(id: string): Promise<void>;
}

/** Deep copy that also drops `undefined`, exactly as the Firestore adapter does. */
export function plain<T>(doc: T): T {
  return JSON.parse(JSON.stringify(doc)) as T;
}

export const MAX_BLOB_BYTES = 8 * 1024 * 1024;

export class MemoryStore implements Store {
  readonly kind: string = 'memory';
  readonly durable: boolean = false;
  protected data = new Map<string, Map<string, unknown>>();
  protected blobs = new Map<string, Buffer>();
  private queue: Promise<unknown> = Promise.resolve();

  protected col(name: string): Map<string, unknown> {
    let c = this.data.get(name);
    if (!c) {
      c = new Map();
      this.data.set(name, c);
    }
    return c;
  }

  /** Hook for FileStore. */
  protected persist(): void {}

  /** Every operation runs through one queue, which makes them atomic relative to each other. */
  private serial<R>(fn: () => Promise<R> | R): Promise<R> {
    const run = this.queue.then(fn, fn);
    this.queue = run.catch(() => undefined);
    return run;
  }

  get<T>(collection: string, id: string): Promise<T | null> {
    return this.serial(() => {
      const v = this.col(collection).get(id);
      return v === undefined ? null : (plain(v) as T);
    });
  }

  put(collection: string, id: string, doc: object): Promise<void> {
    return this.serial(() => {
      this.col(collection).set(id, plain(doc));
      this.persist();
    });
  }

  create(collection: string, id: string, doc: object): Promise<boolean> {
    return this.serial(() => {
      const c = this.col(collection);
      if (c.has(id)) return false;
      c.set(id, plain(doc));
      this.persist();
      return true;
    });
  }

  delete(collection: string, id: string): Promise<void> {
    return this.serial(() => {
      this.col(collection).delete(id);
      this.persist();
    });
  }

  list<T>(collection: string, where: Where[] = [], limit = 2000): Promise<T[]> {
    return this.serial(() => {
      const out: T[] = [];
      for (const v of this.col(collection).values()) {
        const rec = v as Record<string, unknown>;
        if (where.every(([field, value]) => rec[field] === value)) {
          out.push(plain(v) as T);
          if (out.length >= limit) break;
        }
      }
      return out;
    });
  }

  tx<R>(fn: (t: Tx) => Promise<R>): Promise<R> {
    return this.serial(async () => {
      const writes: { op: 'put' | 'delete'; collection: string; id: string; doc?: unknown }[] = [];
      const t: Tx = {
        get: async <T>(collection: string, id: string): Promise<T | null> => {
          if (writes.length > 0) {
            throw new Error('mrs-core store: transaction read after write (Firestore forbids this)');
          }
          const v = this.col(collection).get(id);
          return v === undefined ? null : (plain(v) as T);
        },
        put: (collection, id, doc) => {
          writes.push({ op: 'put', collection, id, doc: plain(doc) });
        },
        delete: (collection, id) => {
          writes.push({ op: 'delete', collection, id });
        },
      };
      const result = await fn(t); // a throw here discards every buffered write
      for (const w of writes) {
        if (w.op === 'put') this.col(w.collection).set(w.id, w.doc);
        else this.col(w.collection).delete(w.id);
      }
      if (writes.length > 0) this.persist();
      return result;
    });
  }

  async putBlob(id: string, bytes: Buffer): Promise<void> {
    if (bytes.length > MAX_BLOB_BYTES) throw new Error('blob too large');
    this.blobs.set(id, Buffer.from(bytes));
  }

  async getBlob(id: string): Promise<Buffer | null> {
    const b = this.blobs.get(id);
    return b ? Buffer.from(b) : null;
  }

  async deleteBlob(id: string): Promise<void> {
    this.blobs.delete(id);
  }
}

/** MemoryStore that survives restarts by writing one JSON file (atomically) plus blob files. */
export class FileStore extends MemoryStore {
  override readonly kind: string = 'file';
  override readonly durable: boolean = true;
  private file: string;
  private blobDir: string;

  constructor(dir: string) {
    super();
    mkdirSync(dir, { recursive: true });
    this.file = join(dir, 'mrs-core.json');
    this.blobDir = join(dir, 'blobs');
    mkdirSync(this.blobDir, { recursive: true });
    if (existsSync(this.file)) {
      const raw = JSON.parse(readFileSync(this.file, 'utf8')) as Record<string, Record<string, unknown>>;
      for (const [name, docs] of Object.entries(raw)) {
        this.data.set(name, new Map(Object.entries(docs)));
      }
    }
  }

  protected override persist(): void {
    const out: Record<string, Record<string, unknown>> = {};
    for (const [name, docs] of this.data) out[name] = Object.fromEntries(docs);
    const tmp = this.file + '.tmp';
    writeFileSync(tmp, JSON.stringify(out));
    renameSync(tmp, this.file); // rename is atomic: a crash never leaves a half-written file
  }

  private blobPath(id: string): string {
    return join(this.blobDir, id.replace(/[^A-Za-z0-9_.-]/g, '_'));
  }

  override async putBlob(id: string, bytes: Buffer): Promise<void> {
    if (bytes.length > MAX_BLOB_BYTES) throw new Error('blob too large');
    writeFileSync(this.blobPath(id), bytes);
  }

  override async getBlob(id: string): Promise<Buffer | null> {
    const p = this.blobPath(id);
    return existsSync(p) ? readFileSync(p) : null;
  }

  override async deleteBlob(id: string): Promise<void> {
    const p = this.blobPath(id);
    if (existsSync(p)) unlinkSync(p);
  }
}

/** Collection names, in one place. */
export const C = {
  ledger: 'ledger',
  payments: 'payments',
  claims: 'claims', // claimKey -> paymentId (uniqueness index)
  invoices: 'invoices',
  orders: 'orders',
  clients: 'clients',
  clientEmails: 'clientEmails', // email hash -> clientId (uniqueness index)
  messages: 'messages',
  jobs: 'jobs',
  deliverables: 'deliverables',
  intakeFiles: 'intakeFiles',
  audit: 'audit',
  meta: 'meta', // settings, audit head, balance anchors, bridge heartbeats, counters
  quarantine: 'quarantine', // provider messages that could not be parsed
  replay: 'replay', // webhook event ids already processed
  notifications: 'notifications',
  coupons: 'coupons',
} as const;
