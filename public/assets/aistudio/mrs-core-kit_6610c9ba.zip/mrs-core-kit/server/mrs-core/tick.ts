/**
 * mrs-core — the periodic tick.
 *
 * Cloud Run only gives the server CPU while it is answering a request, so nothing
 * can be left "running in the background". Instead, something calls
 * POST /api/cron/tick every minute (the Gmail collector does this; Cloud Scheduler
 * can too) and the work is done inside that request:
 *
 *   - move queued jobs forward (Camellia's work)
 *   - re-check waiting payments against the ledger
 *   - hand payments that waited too long to the owner
 *   - bring orders in line with their invoices
 *   - warn when a payment bridge has gone quiet
 *   - read Binance history directly, if this server is allowed to
 *
 * Every step is safe to repeat and safe to interrupt.
 */
import { methodDef } from './config.ts';
import type { Core } from './core.ts';
import { bridgeStatuses, getSettings, touchBridge } from './core.ts';
import { runDueJobs } from './fulfilment/engine.ts';
import { alertOnce } from './notify.ts';
import { advanceAllOpen } from './orders/service.ts';
import { ingestDraft } from './payments/ledger.ts';
import { BinanceError, fetchBinancePayHistory, mapBinancePayRow } from './payments/parsers/binance.ts';
import { afterIngest, escalateStale, reconcileAll } from './payments/service.ts';
import { C } from './store/store.ts';
import type { Payment } from './types.ts';

export interface TickResult {
  jobsRun: number;
  paymentsChecked: number;
  paymentsVerified: number;
  paymentsEscalated: number;
  ordersAdvanced: number;
  binance: string;
  tookMs: number;
}

interface BinanceState {
  cursor: number;
  lastRunAt: number;
  blockedUntil: number;
  clockOffsetMs: number;
}

/** Reads Binance Pay history from this server. Returns a short status word. */
async function pollBinance(core: Core): Promise<string> {
  const { binanceApiKey: apiKey, binanceApiSecret: apiSecret } = core.secrets;
  if (!apiKey || !apiSecret) return 'not configured';
  const state = (await core.store.get<BinanceState>(C.meta, 'binancePoll')) ?? { cursor: Date.now() - 24 * 3600_000, lastRunAt: 0, blockedUntil: 0, clockOffsetMs: 0 };
  const now = Date.now();
  if (state.blockedUntil > now) return 'blocked from this server (use the poller)';
  if (now - state.lastRunAt < 55_000) return 'skipped (ran less than a minute ago)';
  try {
    const rows = await fetchBinancePayHistory({ apiKey, apiSecret, fetchFn: core.fetchFn, clockOffsetMs: state.clockOffsetMs }, state.cursor - 15 * 60_000);
    const own = methodDef('binance_pay').accountId;
    let fresh = 0;
    for (const row of rows) {
      const draft = mapBinancePayRow(row, own);
      if (!draft) continue;
      const r = await ingestDraft(core, draft, 'collector:api');
      if (r.status === 'new' && r.entry) {
        fresh += 1;
        await afterIngest(core, r.entry);
      }
    }
    await core.store.put(C.meta, 'binancePoll', { ...state, cursor: now, lastRunAt: now });
    await touchBridge(core.store, 'api', rows.length);
    return `ok (${rows.length} rows, ${fresh} new)`;
  } catch (err) {
    const code = err instanceof BinanceError ? err.code : 'error';
    const message = String((err as Error)?.message ?? err);
    const next: BinanceState = { ...state, lastRunAt: now };
    if (code === 'restricted_location') next.blockedUntil = now + 6 * 3600_000;
    if (code === 'bad_key') next.blockedUntil = now + 3600_000;
    if (code === 'clock_skew') {
      try {
        const res = await core.fetchFn('https://api.binance.com/api/v3/time', { signal: AbortSignal.timeout(8000) });
        const t = (await res.json()) as { serverTime?: number };
        if (typeof t.serverTime === 'number') next.clockOffsetMs = t.serverTime - Date.now();
      } catch {
        /* try again on the next tick */
      }
    }
    await core.store.put(C.meta, 'binancePoll', next);
    await touchBridge(core.store, 'api', 0, message);
    if (code === 'restricted_location' || code === 'bad_key') await alertOnce(core, `binance:${code}`, 24, 'action', 'Binance cannot be read from the server', message);
    return code;
  }
}

async function bridgeWarnings(core: Core): Promise<void> {
  const settings = await getSettings(core.store);
  const bridges = await bridgeStatuses(core.store, settings.smsStaleHours);
  const waiting = [...(await core.store.list<Payment>(C.payments, [['status', 'awaiting_ledger']], 200))];
  const waitingOn = (methods: string[]): number => waiting.filter((p) => p.methodCandidates.some((m) => methods.includes(m))).length;
  const sms = waitingOn(['bkash', 'nagad']);
  if (sms > 0 && bridges.sms.health !== 'healthy') {
    await alertOnce(core, 'bridge:sms', 6, 'action', 'The SMS phone is not reporting', `${sms} bKash / Nagad payment(s) are waiting, and the phone that forwards bank SMS has ${bridges.sms.lastSeenAt ? `been silent since ${bridges.sms.lastSeenAt}` : 'never reported'}. Check that the phone is on, online, and the forwarder app is running. Until then, confirm those payments by hand.`);
  }
  const usd = waitingOn(['payoneer', 'skrill', 'binance_pay']);
  if (usd > 0 && bridges.email.health !== 'healthy' && bridges.api.health !== 'healthy') {
    await alertOnce(core, 'bridge:usd', 6, 'action', 'The Gmail / Binance collectors are not reporting', `${usd} Binance / Payoneer / Skrill payment(s) are waiting and no collector has reported recently. Check the Gmail script's trigger and the poller. Until then, confirm those payments by hand.`);
  }
}

/**
 * The two sweeps below read many documents and are only a safety net (orders and
 * bridges are normally updated the moment something happens), so they run every
 * ten minutes rather than on every tick. That keeps an idle site at about twelve
 * thousand Firestore reads a day, well inside the free allowance of fifty thousand.
 */
const SWEEP_EVERY_MS = 10 * 60_000;
const lastSweep = new WeakMap<object, number>();

export async function runTick(core: Core, budgetMs: number, withJobs = true): Promise<TickResult> {
  const started = Date.now();
  const sweep = started - (lastSweep.get(core.store) ?? 0) >= SWEEP_EVERY_MS;
  if (sweep) lastSweep.set(core.store, started);
  const guard = async <T>(name: string, fallback: T, fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (err) {
      core.log('error', `tick step failed: ${name}`, { error: String((err as Error)?.message ?? err).slice(0, 300) });
      return fallback;
    }
  };
  const binance = await guard('binance', 'error', () => pollBinance(core));
  const recon = await guard('reconcile', { checked: 0, verifiedCount: 0 }, () => reconcileAll(core));
  const escalated = await guard('escalate', 0, () => escalateStale(core));
  const advanced = sweep ? await guard('advance', 0, () => advanceAllOpen(core)) : 0;
  if (sweep) await guard('bridges', undefined, () => bridgeWarnings(core));
  const remaining = Math.max(2000, budgetMs - (Date.now() - started));
  const jobs = withJobs ? await guard('jobs', { ran: 0 }, () => runDueJobs(core, remaining)) : { ran: 0 };
  return { jobsRun: jobs.ran, paymentsChecked: recon.checked, paymentsVerified: recon.verifiedCount, paymentsEscalated: escalated, ordersAdvanced: advanced, binance, tookMs: Date.now() - started };
}
