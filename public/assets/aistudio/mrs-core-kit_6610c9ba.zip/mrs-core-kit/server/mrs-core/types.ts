/**
 * mrs-core — shared types.
 *
 * Field names deliberately mirror the shapes the existing M R S frontend already
 * reads (LedgerEntry, settings, bridgeStatuses, submission, order, invoice), so the
 * current admin and portal screens keep working once they talk to this server.
 *
 * Only erasable TypeScript syntax is used in this package (no enums, namespaces or
 * parameter properties), so it runs under tsx, esbuild and Node's type stripping.
 */

export type Currency = 'BDT' | 'USD';

/** The five payment rails of the official registry. */
export type Method = 'bkash' | 'nagad' | 'binance_pay' | 'payoneer' | 'skrill';

/**
 * Where an incoming-funds record came from. Every source is a channel only the
 * owner controls; a client can never write to the ledger.
 *  sms       - provider SMS forwarded by the owner's phone (bKash / Nagad)
 *  api       - provider API read with the owner's read-only key (Binance, Skrill MQI)
 *  email     - provider notification e-mail, DKIM/DMARC-authenticated by Gmail
 *  statement - statement lines imported by the owner
 *  manual    - a line the owner typed in after looking at the provider app
 */
export type EvidenceSource = 'sms' | 'api' | 'email' | 'statement' | 'manual';

export type LedgerKind = 'received' | 'cash_in' | 'other_credit';

export interface LedgerEntry {
  id: string;
  source: EvidenceSource;
  method: Method;
  /** Receiving account in the registry (wallet number / UID / customer id). */
  accountId: string;
  /** `${method}:${normalised transaction id}` - unique across the ledger. */
  trxKey: string;
  /** Transaction id exactly as the provider wrote it. */
  trxId: string;
  kind: LedgerKind;
  amountMinor: number;
  currency: Currency;
  /** Original asset for crypto rails, e.g. USDT. */
  asset?: string;
  /** Masked sender, safe to show in the admin UI. */
  senderMask: string;
  /** Full sender (number or name). Never sent to a browser. */
  senderRaw?: string;
  /** Free-text reference / note the payer typed, if the provider reports it. */
  reference?: string;
  balanceAfterMinor?: number;
  /** When the provider says the money arrived (ISO-8601, UTC). */
  receivedAt: string;
  ingestedAt: string;
  /** Provider text with numbers masked. */
  rawMasked: string;
  rawHash: string;
  status: 'unmatched' | 'consumed' | 'quarantined';
  /** Non-empty means the record needs the owner's eyes before it can settle anything. */
  integrityFlags: string[];
  consumedBy?: string;
  consumedAt?: string;
  /** Provider message id / e-mail id, for tracing. */
  sourceRef?: string;
  /** True when the id was synthesised because the provider gave none (some e-mails). */
  syntheticId?: boolean;
}

export type CheckStatus = 'pass' | 'fail' | 'warn' | 'pending' | 'skip';

export interface CheckResult {
  id: string;
  label: string;
  status: CheckStatus;
  detail: string;
}

export type PaymentStatus =
  | 'awaiting_ledger' // claim received; no matching incoming-funds record yet
  | 'needs_review' // owner decision required
  | 'verified' // settled against a ledger record
  | 'rejected';

export interface EvidenceFile {
  fileName: string;
  sha256: string;
  size: number;
  uploadedAt: string;
  /** Set when the same screenshot was already attached to a different payment. */
  reusedFromPaymentId?: string;
}

export interface Payment {
  id: string;
  invoiceId: string;
  orderId: string;
  clientId: string;
  clientName?: string;
  /** 'usd_unspecified' = legacy frontend sent `bank_transfer`; resolved from the ledger. */
  method: Method | 'usd_unspecified';
  methodCandidates: Method[];
  trxId: string;
  normalizedTrxId: string;
  trxKey: string;
  /** Uniqueness key for the claim (one live claim per transaction id). */
  claimKey: string;
  /** Amount the client says they sent, in `currency`. Informational only. */
  amountMinor: number;
  currency: Currency;
  paidAt: string;
  senderMask?: string;
  note?: string;
  status: PaymentStatus;
  /** Evidence source of the ledger record that settled this payment. */
  source?: EvidenceSource;
  ledgerEntryId?: string;
  /** Ledger record found for this claim but not settled automatically (owner decides). */
  candidateLedgerId?: string;
  /** What was credited to the invoice, in USD cents. */
  creditedMinor?: number;
  /** Exactly what the settlement did to the invoice (so a reversal can undo it exactly). */
  settlement?: { appliedMinor: number; surplusMinor: number; forgivenMinor: number };
  riskScore: number;
  flags: string[];
  checkResults: CheckResult[];
  /** Kept for the existing status widget, which keys off this field. */
  ownerConfirmationStatus?: 'RECEIVED' | 'NOT_RECEIVED' | 'CHECK';
  decidedBy?: 'auto' | 'owner';
  decidedAt?: string;
  decisionReason?: string;
  evidence: EvidenceFile[];
  submittedBy: 'client' | 'reference_auto' | 'owner';
  idempotencyKey?: string;
  createdAt: string;
  updatedAt: string;
}

export type InvoiceStatus = 'issued' | 'partially_paid' | 'paid_verified' | 'void';

export interface Invoice {
  invoiceId: string;
  invoiceNumber: string;
  orderId: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  serviceId: string;
  items: { description: string; amountUSD: number; amountBDT: number }[];
  /** Authoritative amounts, USD cents. */
  totalMinor: number;
  paidMinor: number;
  /** USD cents that must be in before work starts (0 = none). */
  depositMinor: number;
  /** BDT per 1 USD, frozen when the invoice was issued. */
  rateSnapshot: number;
  status: InvoiceStatus;
  paymentReferenceCode: string;
  reference: string;
  dueDate: string;
  issuedAt: string;
  issuedDate: string;
  paidAt?: string;
  receiptNumber?: string;
  /** USD cents received beyond the total (to refund or credit; never spent automatically). */
  overpaidMinor: number;
  /** USD cents forgiven because the shortfall was inside the configured tolerance. */
  writtenOffMinor: number;
  // Derived, legacy-shaped fields the existing UI reads.
  total: number;
  amountUSD: number;
  amountBDT: number;
  depositCredited: number;
  amountDue: number;
  currency: 'USD';
}

export type PaymentTiming = 'A' | 'B' | 'C'; // A pay after delivery, B deposit, C prepay

export type OrderState =
  | 'quote_pending'
  | 'awaiting_payment'
  | 'intake_pending'
  | 'in_progress'
  | 'owner_review'
  | 'delivered'
  | 'revision'
  | 'closed'
  | 'cancelled';

export interface IntakeFile {
  id: string;
  fileName: string;
  mime: string;
  size: number;
  sha256: string;
  uploadedAt: string;
}

export interface Order {
  orderId: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  clientWhatsapp?: string;
  clientCountry?: string;
  serviceId: string;
  serviceSlug: string;
  category: string;
  serviceName: string;
  details: string;
  quoteAmount: number;
  currency: 'USD';
  /** Machine state. `status` is the human label the existing UI shows. */
  state: OrderState;
  status: string;
  paymentTiming: PaymentTiming;
  invoiceId?: string;
  /** True when deliverables exist but stay locked until the invoice is settled. */
  deliverablesLocked: boolean;
  dueDays: number;
  dueDate: string;
  ref: string;
  agreementAcceptedAt: string;
  agreementVersion: string;
  agreementIp: string;
  isRush: boolean;
  rushDelivery: boolean;
  rushSurchargePercent: number;
  couponCode?: string;
  couponDiscount: number;
  revisionsUsed: number;
  revisionsTotal: number;
  noAiRequested: boolean;
  /** Answers to the service's intake questions, keyed by intake field. */
  intake: Record<string, string>;
  intakeFiles: IntakeFile[];
  kickoffChecklist: { id: string; title: string; required: boolean; completed: boolean }[];
  jobId?: string;
  test?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Client {
  clientId: string;
  name: string;
  email: string;
  whatsapp?: string;
  country?: string;
  /** scrypt hash - see security/auth.ts */
  pinHash: string;
  status: 'active' | 'suspended';
  trustTier: 'new' | 'trusted';
  completedPaidOrders: number;
  failedPinAttempts: number;
  pinLockedUntil?: string;
  createdAt: string;
}

export interface Message {
  id: string;
  clientId: string;
  orderId: string;
  sender: 'client' | 'camellia' | 'owner' | 'system';
  senderName: string;
  text: string;
  isInternalNote: boolean;
  timestamp: string;
}

export type FulfilmentMode =
  | 'auto' // Camellia produces the deliverable end to end; owner approves release
  | 'assisted' // Camellia does the automatable part; owner does the hands-on part
  | 'human' // live / access-based work; Camellia prepares, owner performs
  | 'manual'; // not handled by the pipeline at all; owner only

export type JobState =
  | 'waiting_inputs'
  | 'queued'
  | 'running'
  | 'owner_review'
  | 'owner_task'
  | 'released'
  | 'failed';

export interface JobStep {
  name: string;
  status: 'ok' | 'failed' | 'skipped';
  startedAt: string;
  finishedAt: string;
  detail?: string;
}

export interface QaCheck {
  id: string;
  label: string;
  passed: boolean;
  severity: 'block' | 'warn';
  detail: string;
}

export interface Job {
  id: string;
  orderId: string;
  serviceId: string;
  mode: FulfilmentMode;
  state: JobState;
  attempts: number;
  /** 'prepare' = Camellia's own pass. 'finish' = after the owner did the hands-on part. */
  phase: 'prepare' | 'finish';
  /** Lease so two instances never run the same job. */
  lockedUntil?: string;
  /** Do not run before this time (back-off after a temporary failure). */
  notBefore?: string;
  lastError?: string;
  /** Client revision requests and owner send-backs, oldest first. */
  feedback: string[];
  /** What the owner reported after doing the hands-on part. */
  ownerNotes?: string;
  /** Short account of the last run, for the owner. */
  summary?: string;
  steps: JobStep[];
  qa: QaCheck[];
  /** What the owner still has to do by hand, in plain words. */
  ownerTasks: string[];
  /** Things Camellia could not establish from what the client supplied. */
  questionsForClient: string[];
  deliverableIds: string[];
  /** Files of an earlier delivery that the next release replaces (revisions). */
  retireIds?: string[];
  model?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Deliverable {
  id: string;
  orderId: string;
  clientId: string;
  jobId?: string;
  title: string;
  description: string;
  fileName: string;
  mime: string;
  size: number;
  sha256: string;
  kind: 'final' | 'preview' | 'report' | 'link';
  /** For kind 'link' (large owner uploads kept elsewhere). */
  externalUrl?: string;
  /** Not visible to the client until the owner releases the job. */
  released: boolean;
  producedBy: 'camellia' | 'owner';
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  seq: number;
  at: string;
  actor: string;
  action: string;
  target: string;
  detail: string;
  prevHash: string;
  hash: string;
}

export interface BridgeStatus {
  source: string;
  lastSeenAt: string | null;
  health: 'healthy' | 'stale' | 'never_seen' | 'error';
  messageCount: number;
  errorCount: number;
  lastError?: string;
}

/** Verification policy. Same shape and defaults as the existing admin "settings" tab. */
export interface PaymentSettings {
  ledgerWaitWindowHours: number;
  reviewWindowDays: number;
  intentExpiryHours: number;
  slaHours: number;
  amountToleranceBps: number;
  amountToleranceFixedMinor: number;
  timeToleranceMinutes: number;
  autoVerifyLimitsUsd: Record<EvidenceSource | 'chain', number>;
  riskThresholdAuto: number;
  riskThresholdReview: number;
  minConfirmations: Record<string, number>;
  stepUpAmountUsd: number;
  smsStaleHours: number;
  maxSubmissionsPerInvoice: number;
  autoVerifySources: Record<EvidenceSource | 'chain', boolean>;
  killSwitch: boolean;
  /** Settle from the payer's reference alone (no claim typed by the client). */
  autoMatchByReference: boolean;
  /** BDT per 1 USD used for new invoices. */
  usdToBdt: number;
}
