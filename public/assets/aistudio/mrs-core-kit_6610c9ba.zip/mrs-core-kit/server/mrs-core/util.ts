/**
 * mrs-core — small, dependency-free helpers (ids, money, time, masking, errors).
 */
import { createHash, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import type { Currency } from './types.ts';

// ---------------------------------------------------------------- errors

/** An error that is safe to show to the caller. Anything else becomes a generic 500. */
export class HttpError extends Error {
  status: number;
  code: string;
  extra?: Record<string, unknown>;
  constructor(status: number, code: string, message?: string, extra?: Record<string, unknown>) {
    super(message ?? code);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

// ---------------------------------------------------------------- hashing

export function sha256Hex(input: string | Buffer | Uint8Array): string {
  return createHash('sha256').update(input).digest('hex');
}

/** Constant-time string comparison (length leak only). */
export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a, 'utf8');
  const bb = Buffer.from(b, 'utf8');
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

/** Stable JSON: object keys sorted, so the same data always hashes the same. */
export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value ?? null);
  if (Array.isArray(value)) return '[' + value.map(canonicalJson).join(',') + ']';
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj)
    .filter((k) => obj[k] !== undefined)
    .sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ':' + canonicalJson(obj[k])).join(',') + '}';
}

// ---------------------------------------------------------------- ids

const UNAMBIGUOUS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // same alphabet the site already uses

export function randomCode(length: number, alphabet = UNAMBIGUOUS): string {
  let out = '';
  for (let i = 0; i < length; i++) out += alphabet.charAt(randomInt(alphabet.length));
  return out;
}

export function randomDigits(length: number): string {
  let out = '';
  for (let i = 0; i < length; i++) out += String(randomInt(10));
  return out;
}

export function randomToken(bytes = 24): string {
  return randomBytes(bytes).toString('base64url');
}

/** Sortable unique id: PREFIX-<time base36><random>. */
export function newId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}${randomCode(6)}`;
}

/** `2611` for November 2026 - the YYMM stamp used in ORD-/INV-/RCP-/MRS- ids. */
export function yymm(d = new Date()): string {
  const dhaka = new Date(d.getTime() + 6 * 3600_000);
  return String(dhaka.getUTCFullYear()).slice(-2) + String(dhaka.getUTCMonth() + 1).padStart(2, '0');
}

// ---------------------------------------------------------------- money

/**
 * Decimal amount -> integer minor units (2 decimal places).
 * Strings are parsed digit by digit (no float error) and extra decimals are
 * truncated, so "14.999" USDT counts as 14.99, never rounded up to 15.00.
 */
export function toMinor(amount: string | number): number {
  if (typeof amount === 'number') {
    if (!Number.isFinite(amount)) return NaN;
    return Math.round(amount * 100);
  }
  const cleaned = amount.replace(/,/g, '').trim();
  const m = /^(-)?(\d+)(?:\.(\d+))?$/.exec(cleaned);
  if (!m) return NaN;
  const whole = Number(m[2]);
  const frac = Number(((m[3] ?? '') + '00').slice(0, 2));
  const value = whole * 100 + frac;
  return m[1] ? -value : value;
}

export function fromMinor(minor: number): number {
  return Math.round(minor) / 100;
}

export function formatMoney(minor: number, currency: Currency): string {
  const n = fromMinor(minor).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return currency === 'USD' ? `$${n}` : `Tk ${n}`;
}

/** USD cents -> BDT paisa at `rate` BDT per USD. */
export function usdToBdtMinor(usdMinor: number, rate: number): number {
  return Math.round(usdMinor * rate);
}

/** Amount in any supported currency -> USD cents at `rate` BDT per USD. */
export function toUsdMinor(amountMinor: number, currency: Currency, rate: number): number {
  return currency === 'USD' ? amountMinor : Math.round(amountMinor / rate);
}

/** Allowed shortfall, in minor units, for a given amount due. */
export function toleranceMinor(dueMinor: number, bps: number, fixedMinor: number): number {
  return Math.max(0, Math.floor((dueMinor * bps) / 10_000)) + Math.max(0, fixedMinor);
}

// ---------------------------------------------------------------- time

export function nowIso(): string {
  return new Date().toISOString();
}

export function hoursBetween(a: string | number | Date, b: string | number | Date): number {
  return Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 3600_000;
}

/**
 * bKash / Nagad print local Bangladesh time as DD/MM/YYYY HH:MM (UTC+6, no DST).
 * Returns ISO-8601 UTC, or null when the text is not a real date.
 */
export function parseDhakaDateTime(text: string): string | null {
  const m = /(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ ,]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/.exec(text);
  if (!m) return null;
  const [day, month, year] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const [hh, mm, ss] = [Number(m[4] ?? 0), Number(m[5] ?? 0), Number(m[6] ?? 0)];
  if (month < 1 || month > 12 || day < 1 || day > 31 || hh > 23 || mm > 59 || ss > 59) return null;
  const utc = Date.UTC(year, month - 1, day, hh - 6, mm, ss);
  const check = new Date(utc + 6 * 3600_000);
  if (check.getUTCDate() !== day || check.getUTCMonth() !== month - 1) return null; // e.g. 31/02
  return new Date(utc).toISOString();
}

// ---------------------------------------------------------------- masking

/** 01712345678 -> 017••••5678 ; short values are fully masked. */
export function maskNumber(value: string): string {
  const digits = value.replace(/[^\d+]/g, '');
  if (digits.length < 8) return '•'.repeat(Math.max(4, digits.length));
  return digits.slice(0, 3) + '••••' + digits.slice(-4);
}

export function maskName(value: string): string {
  const v = value.trim();
  if (!v) return '';
  if (v.includes('@')) {
    const [user, domain] = v.split('@');
    return (user ?? '').slice(0, 2) + '•••@' + (domain ?? '');
  }
  return v
    .split(/\s+/)
    .map((part) => part.charAt(0) + '•'.repeat(Math.min(4, Math.max(1, part.length - 1))))
    .join(' ');
}

export function maskSender(value: string): string {
  return /^[+\d][\d\s-]{6,}$/.test(value.trim()) ? maskNumber(value) : maskName(value);
}

/** Mask every long digit run and any balance figure in a provider message. */
export function maskProviderText(text: string): string {
  return text
    .replace(/(Balance:?\s*(?:Tk|BDT)?\.?\s*)[\d,]+(?:\.\d+)?/gi, '$1•••')
    .replace(/\b(\+?\d{3})\d{4,}(\d{4})\b/g, '$1••••$2')
    .slice(0, 400);
}

export function lastDigits(value: string, n = 4): string {
  return value.replace(/\D/g, '').slice(-n);
}

// ---------------------------------------------------------------- text

export function clampText(value: unknown, max: number): string {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

export function isEmail(value: string): boolean {
  return /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(value);
}

/** Lower-case, strip accents and punctuation - for loose "does this appear in that" tests. */
export function normaliseForMatch(text: string): string {
  return text
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9%$.+#]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
