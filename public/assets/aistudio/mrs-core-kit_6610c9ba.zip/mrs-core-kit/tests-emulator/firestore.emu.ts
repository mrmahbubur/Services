/**
 * Runs the storage adapter and the money-critical scenarios against Google's real
 * Firestore emulator (not a mock). Not part of `npm test` because it needs Java and
 * the emulator:
 *
 *   npx firebase-tools emulators:exec --only firestore --project demo-mrs \
 *     "node --import tsx --test tests-emulator/firestore.emu.ts"
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { randomBytes } from 'node:crypto';
import { buildCore } from '../server/mrs-core/compose.ts';
import { verifyAuditChain } from '../server/mrs-core/audit.ts';
import { createOrder } from '../server/mrs-core/orders/service.ts';
import { ingestDraft, ingestSms, trustBalance, getBalanceAnchor } from '../server/mrs-core/payments/ledger.ts';
import { afterIngest, settle, submitClaim } from '../server/mrs-core/payments/service.ts';
import { FirestoreStore } from '../server/mrs-core/store/firestore.ts';
import { C } from '../server/mrs-core/store/store.ts';
import type { Invoice, LedgerEntry, Payment } from '../server/mrs-core/types.ts';
import { TEST_SECRETS, bkashSms } from '../tests/helpers.ts';

assert.ok(process.env.FIRESTORE_EMULATOR_HOST, 'run this under the Firestore emulator (see the header of this file)');
const require = createRequire(process.env.FIREBASE_ADMIN_DIR ? `${process.env.FIREBASE_ADMIN_DIR}/` : import.meta.url);
const { initializeApp } = require('firebase-admin/app') as { initializeApp: (o: object, name?: string) => object };
const { getFirestore } = require('firebase-admin/firestore') as { getFirestore: (app: object) => { settings: (s: object) => void } };

const app = initializeApp({ projectId: 'demo-mrs' }, `t${Date.now()}`);
const db = getFirestore(app);

function freshStore(): FirestoreStore {
  return new FirestoreStore(db, `t${randomBytes(4).toString('hex')}_`); // own collections per test
}

function rig(): { store: FirestoreStore; core: ReturnType<typeof buildCore>; alerts: string[] } {
  const store = freshStore();
  const alerts: string[] = [];
  const core = buildCore({ store, secrets: TEST_SECRETS, env: {}, notifier: { owner: async (_l, topic) => void alerts.push(topic) }, log: () => undefined });
  return { store, core, alerts };
}

test('firestore: basic reads and writes behave like the in-memory store', async () => {
  const s = freshStore();
  assert.equal(s.kind, 'firestore');
  assert.equal(s.durable, true);
  assert.equal(await s.get('things', 'nope'), null);
  await s.put('things', 'bkash:DK593YKJET', { a: 1, nested: { b: [1, 2, { c: 'x' }] }, gone: undefined, nil: null });
  assert.deepEqual(await s.get('things', 'bkash:DK593YKJET'), { a: 1, nested: { b: [1, 2, { c: 'x' }] }, nil: null });
  // ids with characters our keys use
  for (const id of ['INV-2611-1044|DK593YKJET', 'evidence:abc', 'a/b', '..', 'balance:bkash', 'sms:deadbeef']) {
    await s.put('ids', id, { id });
    assert.deepEqual(await s.get('ids', id), { id }, id);
  }
  assert.equal(await s.create('things', 'once', { v: 1 }), true);
  assert.equal(await s.create('things', 'once', { v: 2 }), false, 'create never overwrites');
  assert.deepEqual(await s.get('things', 'once'), { v: 1 });
  await s.delete('things', 'once');
  assert.equal(await s.get('things', 'once'), null);
});

test('firestore: equality filters (one and two fields) and limits', async () => {
  const s = freshStore();
  for (let i = 0; i < 12; i++) await s.put('pay', `p${i}`, { id: `p${i}`, status: i % 3 === 0 ? 'verified' : 'awaiting_ledger', method: i % 2 === 0 ? 'bkash' : 'nagad', n: i, flag: i < 6 });
  assert.equal((await s.list('pay')).length, 12);
  assert.equal((await s.list('pay', [['status', 'verified']])).length, 4);
  assert.deepEqual((await s.list<{ id: string }>('pay', [['status', 'verified'], ['method', 'bkash']])).map((d) => d.id).sort(), ['p0', 'p6']);
  assert.equal((await s.list('pay', [['flag', true]])).length, 6);
  assert.equal((await s.list('pay', [['n', 7]])).length, 1);
  assert.equal((await s.list('pay', [], 5)).length, 5);
  assert.equal((await s.list('pay', [['status', 'nothing']])).length, 0);
});

test('firestore: transactions are atomic, and a thrown error writes nothing', async () => {
  const s = freshStore();
  await s.put('acct', 'a', { balance: 100 });
  await assert.rejects(() => s.tx(async (t) => {
    const a = await t.get<{ balance: number }>('acct', 'a');
    t.put('acct', 'a', { balance: (a?.balance ?? 0) - 100 });
    t.put('acct', 'b', { balance: 100 });
    throw new Error('abort');
  }));
  assert.deepEqual(await s.get('acct', 'a'), { balance: 100 });
  assert.equal(await s.get('acct', 'b'), null);

  // 20 concurrent increments must not lose an update
  await s.put('ctr', 'c', { n: 0 });
  await Promise.all(Array.from({ length: 20 }, () => s.tx(async (t) => {
    const c = await t.get<{ n: number }>('ctr', 'c');
    t.put('ctr', 'c', { n: (c?.n ?? 0) + 1 });
  })));
  assert.deepEqual(await s.get('ctr', 'c'), { n: 20 });
});

test('firestore: files are stored in chunks and come back byte-identical', async () => {
  const s = freshStore();
  const big = randomBytes(3 * 1024 * 1024 + 123);
  await s.putBlob('deliv_big', big);
  assert.ok((await s.getBlob('deliv_big'))?.equals(big));
  const small = Buffer.from('replaced with a short file');
  await s.putBlob('deliv_big', small); // fewer chunks than before: the old tail must go
  assert.ok((await s.getBlob('deliv_big'))?.equals(small));
  await s.putBlob('empty', Buffer.alloc(0));
  assert.equal((await s.getBlob('empty'))?.length, 0);
  await s.deleteBlob('deliv_big');
  assert.equal(await s.getBlob('deliv_big'), null);
  assert.equal(await s.getBlob('never'), null);
  await assert.rejects(() => s.putBlob('too_big', Buffer.alloc(9 * 1024 * 1024)));
});

test('firestore: bKash payment end to end, with replay, on the real database', async () => {
  const { core, store } = rig();
  await trustBalance(core, 'bkash', 0, 'test');
  const o = await createOrder(core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Fire Store', clientEmail: 'fs@example.org' }, null, '203.0.113.1');
  const invoice = o.invoice as Invoice;
  const claim = await submitClaim(core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'FSPAY00001', amount: 1500, currency: 'BDT' }, o.client.clientId);
  assert.equal(claim.payment.status, 'awaiting_ledger');

  const text = bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'FSPAY00001' });
  const first = await ingestSms(core, { senderId: 'bKash', text });
  assert.equal(first.status, 'new');
  if (first.entry) await afterIngest(core, first.entry);
  const [r2, r3] = await Promise.all([ingestSms(core, { senderId: 'bKash', text }), ingestSms(core, { senderId: 'bKash', text })]);
  assert.equal(r2.status, 'duplicate');
  assert.equal(r3.status, 'duplicate');

  assert.equal((await store.get<Payment>(C.payments, claim.payment.id))?.status, 'verified');
  const inv = await store.get<Invoice>(C.invoices, invoice.invoiceId);
  assert.equal(inv?.status, 'paid_verified');
  assert.equal(inv?.paidMinor, 1500);
  assert.equal((await store.get<LedgerEntry>(C.ledger, 'bkash:FSPAY00001'))?.status, 'consumed');
  assert.equal((await store.list(C.ledger)).length, 1);
  assert.equal((await getBalanceAnchor(core, 'bkash')).trustedMinor, 150_000);
  const chain = await verifyAuditChain(store);
  assert.equal(chain.ok, true, JSON.stringify(chain));
  assert.ok(chain.entries >= 4);
});

test('firestore: DOUBLE SPEND under real concurrency - one ledger record, many settlements, one winner', async () => {
  const { core, store } = rig();
  const claims: string[] = [];
  const invoices: string[] = [];
  for (let i = 0; i < 6; i++) {
    const o = await createOrder(core, { serviceId: 'ats-cv-resume', details: 'x', clientName: `Racer ${i}`, clientEmail: `racer${i}@example.org` }, null, '203.0.113.1');
    const c = await submitClaim(core, { invoiceId: (o.invoice as Invoice).invoiceId, methodId: 'bkash-personal', transactionId: `RACEFS000${i}`, amount: 1500, currency: 'BDT' }, o.client.clientId);
    claims.push(c.payment.id);
    invoices.push((o.invoice as Invoice).invoiceId);
  }
  const entry = (await ingestDraft(core, { source: 'statement', method: 'bkash', trxId: 'THEONLYONE', kind: 'received', amountMinor: 150_000, currency: 'BDT', receivedAt: new Date().toISOString(), rawText: 'race', flags: [] }, 'owner')).entry as LedgerEntry;

  const results = await Promise.allSettled(claims.map((id) => settle(core, id, entry.id, 'owner', 'race')));
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1, 'exactly one settlement succeeds');
  let paid = 0;
  for (const id of invoices) paid += (await store.get<Invoice>(C.invoices, id))?.paidMinor ?? 0;
  assert.equal(paid, 1500, 'the money was credited once across all invoices');
  assert.equal((await store.list<Payment>(C.payments, [['status', 'verified']])).length, 1);
  assert.equal((await verifyAuditChain(store)).ok, true, 'audit chain is intact after contended writes');
});

test('firestore: the same claim submitted 8 times at once creates one payment', async () => {
  const { core, store } = rig();
  const o = await createOrder(core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Dup', clientEmail: 'dup@example.org' }, null, '203.0.113.1');
  const body = { invoiceId: (o.invoice as Invoice).invoiceId, methodId: 'bkash-personal', transactionId: 'SAMECLAIM1', amount: 1500, currency: 'BDT' };
  const all = await Promise.all(Array.from({ length: 8 }, () => submitClaim(core, body, o.client.clientId)));
  assert.equal(new Set(all.map((r) => r.payment.id)).size, 1);
  assert.equal(all.filter((r) => r.created).length, 1);
  assert.equal((await store.list(C.payments)).length, 1);
});
