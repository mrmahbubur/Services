import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync, spawn } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { createHmac } from 'node:crypto';
import { readFileSync } from 'node:fs';
import type { AddressInfo } from 'node:net';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import express from 'express';
import { hashSecret, verifySecret } from '../server/mrs-core/security/auth.ts';
import { C } from '../server/mrs-core/store/store.ts';
import type { LedgerEntry } from '../server/mrs-core/types.ts';
import { TEST_SECRETS } from './helpers.ts';
import { adminToken, call, start } from './http-helpers.ts';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

// ================================================================ Gmail collector (Apps Script), run against a real server over real HTTP

interface FakeMessage {
  id: string;
  from: string;
  subject: string;
  body: string;
  date: Date;
  raw: string;
}

const gmailOk = (domain: string): string => `Authentication-Results: mx.google.com;\r\n       dkim=pass header.i=@${domain} header.s=s1 header.b=abc;\r\n       spf=pass (google.com: domain of bounce@${domain} designates 203.0.113.10 as permitted sender) smtp.mailfrom=bounce@${domain};\r\n       dmarc=pass (p=REJECT sp=REJECT dis=NONE) header.from=${domain}`;

function rawMessage(authHeader: string, from: string, subject: string, extraHeaders = ''): string {
  return `Delivered-To: owner@gmail.com\r\nReceived: by 2002:a05:6a10 with SMTP id x;\r\nARC-Authentication-Results: i=1; mx.google.com; dkim=fail; dmarc=fail header.from=wrong.example\r\nReturn-Path: <bounce@x>\r\n${authHeader}\r\n${extraHeaders}From: ${from}\r\nSubject: ${subject}\r\nMIME-Version: 1.0\r\n\r\nBody text\r\nAuthentication-Results: mx.google.com; dmarc=pass header.from=in-the-body.example\r\n`;
}

/** Starts the stand-alone dev server as a separate process (Apps Script calls are synchronous, so the server cannot share our event loop). */
async function startChildServer(): Promise<{ base: string; child: ChildProcess; stop: () => void }> {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--import', 'tsx', 'tools/dev-server.ts'], {
    cwd: ROOT,
    env: { PATH: process.env.PATH ?? '', HOME: process.env.HOME ?? '', PORT: String(port), MRS_DATA_DIR: 'memory', MRS_SESSION_SECRET: TEST_SECRETS.sessionSecret, MRS_ADMIN_PASSWORD: TEST_SECRETS.adminPassword, MRS_INGEST_SECRET: TEST_SECRETS.ingestSecret, MRS_PUBLIC_BASE_URL: `http://127.0.0.1:${port}` },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('dev server did not start')), 20_000);
    child.stdout?.on('data', (d: Buffer) => {
      if (d.toString().includes(`listening on ${port}`)) {
        clearTimeout(timer);
        resolve();
      }
    });
    child.once('exit', (code) => reject(new Error(`dev server exited with ${code}`)));
  });
  return { base: `http://127.0.0.1:${port}`, child, stop: () => void child.kill('SIGTERM') };
}

/** A model of the Apps Script services the collector uses. HTTP goes out for real, through curl. */
function appsScriptSandbox(messages: FakeMessage[], props: Map<string, string>, log: string[], requests: { url: string; status: number }[]): vm.Context {
  const thread = (list: FakeMessage[]) => ({
    getMessages: () => list.map((m) => ({ getId: () => m.id, getRawContent: () => m.raw, getFrom: () => m.from, getSubject: () => m.subject, getPlainBody: () => m.body, getDate: () => m.date })),
  });
  const sandbox = {
    Logger: { log: (s: unknown) => void log.push(String(s)) },
    ScriptApp: { getProjectTriggers: () => [], deleteTrigger: () => undefined, newTrigger: () => ({ timeBased: () => ({ everyMinutes: () => ({ create: () => undefined }) }) }) },
    PropertiesService: { getScriptProperties: () => ({ getProperty: (k: string) => props.get(k) ?? null, setProperty: (k: string, v: string) => void props.set(k, v) }) },
    GmailApp: {
      search: (q: string) => {
        const after = Number(/after:(\d+)/.exec(q)?.[1] ?? 0);
        const hits = messages.filter((m) => m.date.getTime() / 1000 >= after);
        return hits.length > 0 ? [thread(hits)] : [];
      },
    },
    Utilities: {
      Charset: { UTF_8: 'UTF_8' },
      // Apps Script returns SIGNED bytes (-128..127)
      computeHmacSha256Signature: (value: string, key: string) => Array.from(new Int8Array(createHmac('sha256', Buffer.from(key, 'utf8')).update(Buffer.from(value, 'utf8')).digest())),
    },
    UrlFetchApp: {
      fetch: (url: string, o: { method: string; payload: string; headers: Record<string, string>; contentType: string }) => {
        const args = ['-s', '-o', '-', '-w', '\n%{http_code}', '-X', 'POST', '-H', `Content-Type: ${o.contentType}`, '--data-binary', '@-', '--max-time', '20'];
        for (const [k, v] of Object.entries(o.headers ?? {})) args.push('-H', `${k}: ${v}`);
        const out = execFileSync('curl', [...args, url], { input: o.payload, encoding: 'utf8' });
        const cut = out.lastIndexOf('\n');
        const status = Number(out.slice(cut + 1));
        requests.push({ url, status });
        return { getResponseCode: () => status, getContentText: () => out.slice(0, cut) };
      },
    },
  };
  const context = vm.createContext(sandbox);
  vm.runInContext(readFileSync(join(ROOT, 'collectors/gmail-collector.gs'), 'utf8'), context, { filename: 'gmail-collector.gs' });
  return context;
}

test('Gmail collector: signs with Apps Script\'s own primitives, the real server accepts it, forgeries are filtered, nothing is sent twice', async () => {
  const server = await startChildServer();
  try {
    const now = new Date();
    const messages: FakeMessage[] = [
      { id: '18f0000000000001', from: 'Skrill <no-reply@email.skrill.com>', subject: "You've received USD 15.00", body: 'Hello,\nAmount: USD 15.00\nTransaction ID: 5566778899\nSender: Zoë Müller — "ünïcödé" ✓', date: now, raw: rawMessage(gmailOk('skrill.com'), 'Skrill <no-reply@email.skrill.com>', 'x') },
      // a scam: display name says Skrill, Gmail's verdict says gmail.com; and it smuggles its own look-alike header underneath Gmail's
      { id: '18f0000000000002', from: 'Skrill Payments <skrill.payments@gmail.com>', subject: "You've received USD 900.00", body: 'Transaction ID: 9999999999', date: now, raw: rawMessage(gmailOk('gmail.com'), 'Skrill Payments <skrill.payments@gmail.com>', 'x', 'Authentication-Results: mx.google.com; dkim=pass; dmarc=pass header.from=skrill.com\r\n') },
      { id: '18f0000000000003', from: 'Payoneer <no-reply@payoneer.com>', subject: 'Your monthly statement is ready', body: 'See your statement.', date: now, raw: rawMessage(gmailOk('payoneer.com'), 'Payoneer <no-reply@payoneer.com>', 'x') },
      { id: '18f0000000000000', from: 'Skrill <no-reply@email.skrill.com>', subject: "You've received USD 77.00", body: 'Transaction ID: 1111111111', date: new Date(now.getTime() - 5 * 86_400_000), raw: rawMessage(gmailOk('skrill.com'), 'Skrill <no-reply@email.skrill.com>', 'x') },
    ];
    const props = new Map<string, string>([['MRS_SITE', server.base.replace('http://', 'https://')], ['MRS_INGEST_SECRET', TEST_SECRETS.ingestSecret]]);
    const log: string[] = [];
    const requests: { url: string; status: number }[] = [];
    let ctx = appsScriptSandbox(messages, props, log, requests);

    // the script insists on https; the test server speaks http, so point it there after the check
    assert.doesNotThrow(() => vm.runInContext('config_(PropertiesService.getScriptProperties())', ctx));
    props.set('MRS_SITE', 'http://insecure.example');
    assert.throws(() => vm.runInContext('run()', ctx), /Set MRS_SITE \(https:\/\/\.\.\.\)/);
    const script = readFileSync(join(ROOT, 'collectors/gmail-collector.gs'), 'utf8').replace("if (!/^https:\\/\\//.test(site))", "if (!/^https?:\\/\\//.test(site))");
    ctx = appsScriptSandbox(messages, props, log, requests);
    vm.runInContext(script, ctx, { filename: 'gmail-collector.gs' });
    props.set('MRS_SITE', server.base);

    // header extraction: the first real header, unfolded; not the ARC one, not a later look-alike, not text in the body
    const extracted = vm.runInContext('firstAuthenticationResults_', ctx)(messages[1]?.raw) as string;
    assert.match(extracted, /^mx\.google\.com; dkim=pass header\.i=@gmail\.com/);
    assert.match(extracted, /header\.from=gmail\.com$/);
    assert.equal(vm.runInContext('firstAuthenticationResults_', ctx)('From: a@b\r\n\r\nAuthentication-Results: mx.google.com; dmarc=pass header.from=skrill.com'), '', 'a header-looking line in the BODY is not a header');
    assert.equal(vm.runInContext('asciiJson_', ctx)({ s: 'Zoë ✓' }), '{"s":"Zo\\u00eb \\u2713"}');
    assert.equal(vm.runInContext('hex_', ctx)([-1, 0, 127, -128, 16]), 'ff007f8010');

    vm.runInContext('selfTest()', ctx);
    assert.equal(log[log.length - 1], 'site answered 200');

    vm.runInContext('run()', ctx);
    assert.deepEqual(requests.map((r) => [r.url.replace(server.base, ''), r.status]), [['/api/ingest/email', 200], ['/api/ingest/email', 200], ['/api/cron/tick?jobs=0&budget=8000', 200]]);
    const handed = log.find((l) => l.startsWith('Handed over')) ?? '';
    assert.match(handed, /Handed over 3 message\(s\)/, 'the 5-day-old message is outside the window');
    assert.match(handed, /"id":"18f0000000000001","status":"new"/);
    assert.match(handed, /"id":"18f0000000000002","status":"rejected"/);
    assert.match(handed, /"id":"18f0000000000003","status":"ignored"/);
    assert.equal(props.get('DONE'), '18f0000000000001,18f0000000000002,18f0000000000003');

    // second run: nothing new is sent
    const before = requests.length;
    vm.runInContext('run()', ctx);
    assert.equal(log.filter((l) => l.startsWith('Handed over')).length, 1);
    assert.equal(requests.length, before + 2, 'one heartbeat post and one tick');

    // what the server recorded
    const login = await fetch(`${server.base}/api/admin/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: TEST_SECRETS.adminPassword }) });
    const token = ((await login.json()) as { token: string }).token;
    const view = (await (await fetch(`${server.base}/api/admin/payments?queue=all`, { headers: { Authorization: `Bearer ${token}` } })).json()) as { ledgerEntries: LedgerEntry[]; bridgeStatuses: { email: { health: string } } };
    assert.equal(view.ledgerEntries.length, 1, 'only the genuine Skrill notice became a ledger record');
    assert.equal(view.ledgerEntries[0]?.id, 'skrill:5566778899');
    assert.equal(view.ledgerEntries[0]?.amountMinor, 1500);
    assert.equal(view.bridgeStatuses.email.health, 'healthy');

    // a wrong secret is refused, and the script then marks nothing as done
    props.set('MRS_INGEST_SECRET', 'a-different-secret-0123456789abcd');
    props.set('DONE', '');
    props.set('SINCE', '0');
    vm.runInContext('run()', ctx);
    assert.match(log[log.length - 1] ?? '', /Site refused the batch \(401\)/);
    assert.equal(props.get('DONE'), '');
  } finally {
    server.stop();
  }
});

// ================================================================ poller (Binance / Skrill) against stand-in providers and the real server

interface Poller {
  readConfig: (env: Record<string, string>) => { cfg: Record<string, unknown>; problems: string[] };
  pollOnce: (cfg: Record<string, unknown>, state: Record<string, unknown>) => Promise<string[]>;
  signedHeaders: (secret: string, body: string, nowMs?: number) => Record<string, string>;
  loadEnv: (file: string, base?: Record<string, string>) => Record<string, string>;
}

test('poller: reads Binance with a signed request, reports to the site, and says why when it cannot', async () => {
  const poller = (await import(join(ROOT, 'collectors/poller.mjs'))) as Poller;
  const KEY = 'binance-read-only-key';
  const SECRET = 'binance-secret-0123456789';
  let mode: 'ok' | 'restricted' | 'skew' | 'badkey' = 'ok';
  const seen: { path: string; key: string; valid: boolean }[] = [];
  const provider = express();
  provider.get('/api/v3/time', (_req, res) => void res.json({ serverTime: Date.now() + 4000 }));
  provider.get('/sapi/v1/pay/transactions', (req, res) => {
    const qs = req.originalUrl.split('?')[1] ?? '';
    const [unsigned, sig] = qs.split('&signature=');
    const valid = createHmac('sha256', SECRET).update(unsigned ?? '').digest('hex') === sig;
    seen.push({ path: req.path, key: String(req.headers['x-mbx-apikey']), valid });
    if (mode === 'restricted') return void res.status(451).json({ code: 0, msg: "Service unavailable from a restricted location according to 'b. Eligibility'" });
    if (mode === 'badkey') return void res.status(401).json({ code: -2015, msg: 'Invalid API-key, IP, or permissions for action.' });
    if (mode === 'skew' && seen.length % 2 === 1) return void res.status(400).json({ code: -1021, msg: 'Timestamp for this request is outside of the recvWindow.' });
    if (!valid || req.headers['x-mbx-apikey'] !== KEY) return void res.status(401).json({ code: -2014, msg: 'bad' });
    res.json({ code: '000000', message: 'success', success: true, data: [{ orderType: 'C2C', transactionId: 'M_P_880011223344', transactionTime: Date.now(), amount: '25.00000000', currency: 'USDT', payerInfo: { name: 'Jack' }, receiverInfo: { binanceId: '38927942' } }, { orderType: 'C2C', transactionId: 'M_P_880011223345', transactionTime: Date.now(), amount: '-9.5', currency: 'USDT' }] });
  });
  provider.get('/app/query.pl', (req, res) => {
    if (req.query.password !== '5f4dcc3b5aa765d61d8327deb882cf99') return void res.send('401\t\tCannot log in'); // md5("password")
    res.type('text/csv').send('ID,Time (CET),Type,Transaction Details,[-] USD,[+] USD,Status,Balance,Reference\n3344556677,2026-11-10 10:00,Receive Money,from a@b.com,,40.00,processed,140.00,\n');
  });
  const providerServer = provider.listen(0, '127.0.0.1');
  await new Promise<void>((r) => providerServer.once('listening', () => r()));
  const providerBase = `http://127.0.0.1:${(providerServer.address() as AddressInfo).port}`;

  const app = await start();
  try {
    const bad = poller.readConfig({ MRS_SITE: 'mrs', MRS_INGEST_SECRET: 'short', BINANCE_API_KEY: 'k' });
    assert.equal(bad.problems.length, 3);
    const { cfg, problems } = poller.readConfig({ MRS_SITE: app.base, MRS_INGEST_SECRET: TEST_SECRETS.ingestSecret, BINANCE_API_KEY: KEY, BINANCE_API_SECRET: SECRET, BINANCE_BASE_URL: providerBase, SKRILL_EMAIL: 'me@example.org', SKRILL_MQI_PASSWORD: 'password', SKRILL_BASE_URL: providerBase });
    assert.deepEqual(problems, []);

    const state: Record<string, unknown> = {};
    const lines = await poller.pollOnce(cfg, state);
    assert.deepEqual(lines, ['binance: 2 row(s) read, 1 incoming, site recorded 1 new', 'skrill: history read, site recorded 1 new']);
    assert.ok(seen.every((s) => s.valid && s.key === KEY), 'requests to Binance carried a valid signature and the key header');
    const ledger = await app.store.list<LedgerEntry>(C.ledger);
    assert.deepEqual(ledger.map((e) => `${e.id}=${e.amountMinor}:${e.source}`).sort(), ['binance_pay:880011223344=2500:api', 'skrill:3344556677=4000:api']);
    assert.equal(typeof state.binanceCursor, 'number');

    // again: the site has them already
    state.skrillLastRun = 0;
    assert.deepEqual(await poller.pollOnce(cfg, state), ['binance: 2 row(s) read, 1 incoming, site recorded 0 new', 'skrill: history read, site recorded 0 new']);
    assert.equal((await app.store.list(C.ledger)).length, 2);

    // clock skew: the poller asks Binance for the time and retries by itself
    mode = 'skew';
    seen.length = 0;
    const skew = await poller.pollOnce(cfg, state);
    assert.match(skew[0] ?? '', /^binance: 2 row\(s\) read/);
    assert.ok(Math.abs(Number(state.clockOffsetMs) - 4000) < 1500, 'clock offset learned from Binance');

    // blocked location / bad key: said plainly, and shown to the owner in the admin screen
    mode = 'restricted';
    assert.match((await poller.pollOnce(cfg, state))[0] ?? '', /Binance refuses requests from this network location/);
    const token = await adminToken(app);
    let view = await call(app, 'GET', '/api/admin/payments?queue=all', { token });
    assert.match((view.json.bridgeStatuses as { api: { lastError: string } }).api.lastError, /binance: Binance refuses requests from this network location/);
    mode = 'badkey';
    assert.match((await poller.pollOnce(cfg, state))[0] ?? '', /"Enable Reading" not ticked/);
    view = await call(app, 'GET', '/api/admin/payments?queue=all', { token });
    assert.equal((view.json.bridgeStatuses as { api: { errorCount: number } }).api.errorCount, 2);

    // a poller with the wrong site secret gets a clear answer and records nothing
    const wrong = poller.readConfig({ MRS_SITE: app.base, MRS_INGEST_SECRET: 'not-the-right-secret-0123456789', BINANCE_API_KEY: KEY, BINANCE_API_SECRET: SECRET, BINANCE_BASE_URL: providerBase });
    mode = 'ok';
    assert.match((await poller.pollOnce(wrong.cfg, {}))[0] ?? '', /the site refused the signature/);

    // secrets never appear in what the poller prints
    const everything = [...lines, ...skew].join('\n');
    assert.ok(!everything.includes(SECRET) && !everything.includes(TEST_SECRETS.ingestSecret) && !everything.includes(KEY));
  } finally {
    await app.close();
    await new Promise<void>((r) => providerServer.close(() => r()));
  }
});

test('password hashing tool output is accepted by the server', () => {
  const out = execFileSync(process.execPath, [join(ROOT, 'tools/hash-password.mjs'), 'a long private passphrase'], { encoding: 'utf8' }).trim();
  assert.match(out, /^scrypt\$16384\$8\$1\$[\w-]+\$[\w-]+$/);
  assert.equal(verifySecret('a long private passphrase', out), true);
  assert.equal(verifySecret('a long private passphrasE', out), false);
  assert.equal(verifySecret('x', 'scrypt$999999999$8$1$AAAA$AAAA'), false, 'absurd cost parameters are refused, not computed');
  assert.equal(verifySecret('x', 'plain'), false);
  assert.notEqual(hashSecret('same'), hashSecret('same'), 'every hash has its own salt');
});
