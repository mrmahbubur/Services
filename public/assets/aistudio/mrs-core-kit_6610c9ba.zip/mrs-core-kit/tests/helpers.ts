import { buildCore } from '../server/mrs-core/compose.ts';
import type { Secrets } from '../server/mrs-core/config.ts';
import type { Core, ModelClient, ModelRequest } from '../server/mrs-core/core.ts';
import type { AlertLevel } from '../server/mrs-core/notify.ts';
import { MemoryStore } from '../server/mrs-core/store/store.ts';
import type { Store } from '../server/mrs-core/store/store.ts';

export const TEST_SECRETS: Secrets = {
  sessionSecret: 'test-session-secret-0123456789abcdef-XYZ',
  adminPassword: 'correct horse battery staple',
  adminPasswordHash: '',
  smsSigningKey: 'sms-signing-key-0123456789',
  smsBearerToken: 'sms-bearer-token-0123456789abcdef',
  ingestSecret: 'ingest-secret-0123456789abcdefgh',
  cronSecret: 'cron-secret-0123456789abcdefghij',
  geminiApiKey: '',
  geminiModel: 'test-model',
  pagespeedApiKey: '',
  binanceApiKey: '',
  binanceApiSecret: '',
  telegramBotToken: '',
  telegramChatId: '',
  publicBaseUrl: 'http://127.0.0.1',
  production: false,
};

export interface Alert {
  level: AlertLevel;
  topic: string;
  title: string;
  body: string;
}

/** A model that answers from a script, so the pipeline can be tested without a real AI. */
export class ScriptedModel implements ModelClient {
  readonly name = 'scripted';
  available = true;
  calls: ModelRequest[] = [];
  private handler: (req: ModelRequest, n: number) => string | Promise<string>;
  constructor(handler: (req: ModelRequest, n: number) => string | Promise<string>) {
    this.handler = handler;
  }
  async generate(req: ModelRequest): Promise<string> {
    this.calls.push(req);
    return this.handler(req, this.calls.length);
  }
}

export interface TestRig {
  core: Core;
  store: Store;
  alerts: Alert[];
}

export function makeRig(opts: { store?: Store; model?: ModelClient; balanceAutoHeal?: number; secrets?: Partial<Secrets>; fetchFn?: Core['fetchFn'] } = {}): TestRig {
  const alerts: Alert[] = [];
  const store = opts.store ?? new MemoryStore();
  const core = buildCore({
    store,
    secrets: { ...TEST_SECRETS, ...(opts.secrets ?? {}) },
    env: {},
    notifier: { owner: async (level, topic, title, body) => void alerts.push({ level, topic, title, body }) },
    ...(opts.model ? { model: opts.model } : {}),
    ...(opts.fetchFn ? { fetchFn: opts.fetchFn } : {}),
    balanceAutoHeal: opts.balanceAutoHeal ?? 0,
    log: () => undefined,
  });
  return { core, store, alerts };
}

/** dd/mm/yyyy hh:mm in Bangladesh time, `minutesAgo` before now - the format operators print. */
export function dhakaStamp(minutesAgo = 0): string {
  const d = new Date(Date.now() - minutesAgo * 60_000 + 6 * 3600_000);
  const p = (n: number): string => String(n).padStart(2, '0');
  return `${p(d.getUTCDate())}/${p(d.getUTCMonth() + 1)}/${d.getUTCFullYear()} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`;
}

export function bkashSms(o: { amount: string; from?: string; ref?: string; balance: string; trx: string; minutesAgo?: number }): string {
  return `You have received Tk ${o.amount} from ${o.from ?? '01712345678'}.${o.ref ? ` Ref ${o.ref}.` : ''} Fee Tk 0.00. Balance Tk ${o.balance}. TrxID ${o.trx} at ${dhakaStamp(o.minutesAgo ?? 0)}`;
}

export function nagadSms(o: { amount: string; from?: string; ref?: string; balance: string; trx: string; minutesAgo?: number }): string {
  return `Money Received.\nAmount: Tk ${o.amount}\nSender: ${o.from ?? '01712345678'}\nRef: ${o.ref ?? 'N/A'}\nTxnID: ${o.trx}\nBalance: Tk ${o.balance}\n${dhakaStamp(o.minutesAgo ?? 0)}`;
}
