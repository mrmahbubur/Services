/** Starts the real Express app on a free port and talks to it over real HTTP. */
import { createHmac } from 'node:crypto';
import type { AddressInfo } from 'node:net';
import assert from 'node:assert/strict';
import express from 'express';
import type { Express } from 'express';
import type { Secrets } from '../server/mrs-core/config.ts';
import type { ModelClient } from '../server/mrs-core/core.ts';
import { installMrsCore } from '../server/mrs-core/index.ts';
import type { Installed } from '../server/mrs-core/index.ts';
import type { AlertLevel } from '../server/mrs-core/notify.ts';
import { MemoryStore } from '../server/mrs-core/store/store.ts';
import type { Store } from '../server/mrs-core/store/store.ts';
import { TEST_SECRETS } from './helpers.ts';

export interface App {
  base: string;
  port: number;
  store: Store;
  installed: Installed;
  alerts: { level: AlertLevel; topic: string; title: string }[];
  close: () => Promise<void>;
}

export async function start(opts: { secrets?: Partial<Secrets>; before?: (app: Express) => void; after?: (app: Express) => void; store?: Store; model?: ModelClient; env?: Record<string, string> } = {}): Promise<App> {
  const app = express();
  const alerts: App['alerts'] = [];
  const store = opts.store ?? new MemoryStore();
  opts.before?.(app);
  // publicBaseUrl is filled in once the port is known
  const secrets: Secrets = { ...TEST_SECRETS, ...(opts.secrets ?? {}) };
  const installed = installMrsCore(app, { store, secrets, env: opts.env ?? {}, notifier: { owner: async (level, topic, title) => void alerts.push({ level, topic, title }) }, log: () => undefined, ...(opts.model ? { model: opts.model } : {}) });
  opts.after?.(app);
  const server = app.listen(0, '127.0.0.1');
  await new Promise<void>((resolve) => server.once('listening', () => resolve()));
  const port = (server.address() as AddressInfo).port;
  secrets.publicBaseUrl = `http://127.0.0.1:${port}`;
  return { base: `http://127.0.0.1:${port}`, port, store, installed, alerts, close: () => new Promise((resolve) => server.close(() => resolve())) };
}

export interface Reply {
  status: number;
  json: Record<string, unknown>;
  text: string;
  headers: Headers;
  cookies: string[];
}

export async function call(app: App, method: string, path: string, opts: { body?: unknown; raw?: string; headers?: Record<string, string>; cookie?: string; token?: string; origin?: string } = {}): Promise<Reply> {
  const headers: Record<string, string> = { ...(opts.headers ?? {}) };
  let payload: string | undefined;
  if (opts.raw !== undefined) payload = opts.raw;
  else if (opts.body !== undefined) payload = JSON.stringify(opts.body);
  if (payload !== undefined && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  if (opts.cookie) headers.Cookie = opts.cookie;
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  if (opts.origin) headers.Origin = opts.origin;
  const res = await fetch(app.base + path, { method, headers, ...(payload !== undefined ? { body: payload } : {}), redirect: 'manual' });
  const text = await res.text();
  let json: Record<string, unknown> = {};
  try {
    json = JSON.parse(text) as Record<string, unknown>;
  } catch {
    /* not JSON */
  }
  return { status: res.status, json, text, headers: res.headers, cookies: res.headers.getSetCookie().map((c) => c.split(';')[0] ?? '') };
}

export function sign(key: string, raw: string, ts = String(Math.floor(Date.now() / 1000))): Record<string, string> {
  return { 'X-Timestamp': ts, 'X-Signature': createHmac('sha256', key).update(raw).update(ts).digest('hex') };
}

export async function adminToken(app: App): Promise<string> {
  const r = await call(app, 'POST', '/api/admin/login', { body: { password: TEST_SECRETS.adminPassword } });
  assert.equal(r.status, 200);
  return r.json.token as string;
}
