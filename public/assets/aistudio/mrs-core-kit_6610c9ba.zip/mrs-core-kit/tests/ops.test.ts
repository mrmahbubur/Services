import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { saveSettings, touchBridge } from '../server/mrs-core/core.ts';
import { verifyAuditChain } from '../server/mrs-core/audit.ts';
import { createOrder } from '../server/mrs-core/orders/service.ts';
import { ingestSms, trustBalance } from '../server/mrs-core/payments/ledger.ts';
import { afterIngest, submitClaim } from '../server/mrs-core/payments/service.ts';
import { C, FileStore } from '../server/mrs-core/store/store.ts';
import type { Invoice, Job, LedgerEntry, Order, Payment } from '../server/mrs-core/types.ts';
import { runTick } from '../server/mrs-core/tick.ts';
import { ScriptedModel, TEST_SECRETS, bkashSms, makeRig } from './helpers.ts';
import { call, start } from './http-helpers.ts';

const CV = 'Rahim Uddin. Software Engineer at Shapla Tech since 2021. Built REST APIs in Node.js. '.repeat(6);
const POSTING = 'Backend engineer with Node.js and PostgreSQL experience needed for a product team. '.repeat(2);

function cvModel(): ScriptedModel {
  return new ScriptedModel((req) => {
    const text = req.parts.map((p) => p.text ?? '').join('\n');
    if (text.includes('<<<CV>>>')) return JSON.stringify({ name: 'Rahim Uddin', headline: 'Software Engineer', contact: { email: null, phone: null, location: null, links: [] }, summary: null, experience: [{ title: 'Software Engineer', employer: 'Shapla Tech', location: null, start: '2021', end: null, bullets: ['Built REST APIs in Node.js'] }], education: [], skills: ['Node.js'], certifications: [], projects: [], languages: [], unclear: [] });
    if (text.includes('<<<JOB_POSTINGS>>>')) return JSON.stringify({ roleTitles: ['Backend engineer'], keywords: [{ term: 'Node.js', importance: 'must' }, { term: 'PostgreSQL', importance: 'must' }] });
    return JSON.stringify({ headline: 'Software Engineer', summary: 'Software Engineer at Shapla Tech since 2021.', skillGroups: [{ group: 'Backend', items: ['Node.js'] }], experience: [{ index: 0, bullets: ['Built REST APIs in Node.js.'] }], projects: [], questionsForClient: [] });
  });
}

test('the scheduler tick drives Camellia\'s queued work, over HTTP, with nobody pressing anything', async () => {
  const app = await start({ model: cvModel() });
  try {
    const order = await call(app, 'POST', '/api/orders', { body: { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Tick Client', clientEmail: 'tick@example.org', intake: { cv_text: CV, job_postings: POSTING } } });
    const orderId = (order.json.order as Order).orderId;
    assert.equal((order.json.order as Order).state, 'in_progress');
    assert.equal((await app.store.get<Job>(C.jobs, `JOB-${orderId.replace('ORD-', '')}`))?.state, 'queued');

    // the quick housekeeping tick (what the Gmail script calls every minute) must NOT start the job
    const light = await call(app, 'POST', '/api/cron/tick?jobs=0', { raw: '{}', token: TEST_SECRETS.cronSecret });
    assert.equal(light.json.jobsRun, 0);
    assert.equal((await app.store.get<Job>(C.jobs, `JOB-${orderId.replace('ORD-', '')}`))?.state, 'queued');

    const full = await call(app, 'POST', '/api/cron/tick', { raw: '{}', token: TEST_SECRETS.cronSecret });
    assert.equal(full.status, 200);
    assert.equal(full.json.jobsRun, 1);
    const job = (await app.store.get<Job>(C.jobs, `JOB-${orderId.replace('ORD-', '')}`)) as Job;
    assert.equal(job.state, 'owner_review');
    assert.equal((await app.store.get<Order>(C.orders, orderId))?.state, 'owner_review');
    assert.ok(app.alerts.some((a) => a.title === 'A draft is ready for your review'));
    assert.equal((await call(app, 'POST', '/api/cron/tick', { raw: '{}', token: TEST_SECRETS.cronSecret })).json.jobsRun, 0, 'nothing left to do');

    // the client sees progress but not the unreleased files
    const me = await call(app, 'GET', '/api/portal/me', { token: order.json.token as string });
    assert.equal((me.json.deliverables as unknown[]).length, 0);
  } finally {
    await app.close();
  }
});

test('tick: a claim that arrived before its SMS is settled on the next tick even if the first match was missed', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const o = await createOrder(rig.core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Late Match', clientEmail: 'late@example.org' }, null, '203.0.113.2');
  const invoice = o.invoice as Invoice;
  const claim = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'LATEMATCH1', amount: 1500, currency: 'BDT' }, o.client.clientId);
  // the SMS is recorded, but the process stops before the follow-up runs
  const res = await ingestSms(rig.core, { senderId: 'bKash', text: bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'LATEMATCH1' }) });
  assert.equal(res.status, 'new');
  assert.equal((await rig.store.get<Payment>(C.payments, claim.payment.id))?.status, 'awaiting_ledger');

  const t = await runTick(rig.core, 2000);
  assert.equal(t.paymentsVerified, 1);
  assert.equal((await rig.store.get<Payment>(C.payments, claim.payment.id))?.status, 'verified');
  assert.equal((await rig.store.get<Invoice>(C.invoices, invoice.invoiceId))?.status, 'paid_verified');
});

test('tick: an invoice paid while the order was not updated (crash in between) is put right by the sweep', async () => {
  const rig = makeRig({ model: cvModel() });
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const o = await createOrder(rig.core, { serviceId: 'gravatar-identity-consultation', details: 'x', clientName: 'Sweep', clientEmail: 'sweep@example.org', intake: { emails: 'a@example.org', role: 'Designer' } }, null, '203.0.113.2');
  assert.equal(o.order.state, 'awaiting_payment');
  // simulate "payment settled, then the process died before the order was advanced"
  rig.core.hooks.invoiceChanged = async () => {
    throw new Error('process died here');
  };
  const res = await ingestSms(rig.core, { senderId: 'bKash', text: bkashSms({ amount: '2,500.00', balance: '2,500.00', trx: 'SWEEPPAY01', ref: (o.invoice as Invoice).paymentReferenceCode }) });
  if (res.entry) await afterIngest(rig.core, res.entry);
  assert.equal((await rig.store.get<Invoice>(C.invoices, (o.invoice as Invoice).invoiceId))?.status, 'paid_verified', 'the money is recorded');
  assert.equal((await rig.store.get<Order>(C.orders, o.order.orderId))?.state, 'awaiting_payment', 'the order was left behind');

  const t = await runTick(rig.core, 1000, false);
  assert.ok(t.ordersAdvanced >= 1);
  const fixed = (await rig.store.get<Order>(C.orders, o.order.orderId)) as Order;
  assert.equal(fixed.state, 'in_progress');
  assert.ok(fixed.jobId, 'and its work was queued');
});

test('tick: reading Binance from the server; a refused location is reported once and then left alone', async () => {
  const KEY = 'server-side-binance-key';
  const SECRET = 'server-side-binance-secret';
  let mode: 'ok' | 'restricted' = 'ok';
  let calls = 0;
  const fetchFn = async (url: string, init?: RequestInit): Promise<Response> => {
    const u = new URL(url);
    assert.equal(u.host, 'api.binance.com');
    calls += 1;
    if (mode === 'restricted') return new Response(JSON.stringify({ code: 0, msg: "Service unavailable from a restricted location according to 'b. Eligibility'" }), { status: 451 });
    const [unsigned, sig] = u.search.slice(1).split('&signature=');
    assert.equal(createHmac('sha256', SECRET).update(unsigned ?? '').digest('hex'), sig, 'the server signs its Binance request correctly');
    assert.equal((init?.headers as Record<string, string>)['X-MBX-APIKEY'], KEY);
    return new Response(JSON.stringify({ code: '000000', success: true, data: [{ orderType: 'C2C', transactionId: 'M_P_700800900100', transactionTime: Date.now(), amount: '15', currency: 'USDT', receiverInfo: { binanceId: '38927942' } }] }), { status: 200 });
  };
  const rig = makeRig({ fetchFn, secrets: { binanceApiKey: KEY, binanceApiSecret: SECRET } });
  const o = await createOrder(rig.core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Bin', clientEmail: 'bin@example.org' }, null, '203.0.113.2');
  const claim = await submitClaim(rig.core, { invoiceId: (o.invoice as Invoice).invoiceId, methodId: 'binance-pay', transactionId: '700800900100', amount: 15, currency: 'USD' }, o.client.clientId);
  assert.equal(claim.payment.status, 'awaiting_ledger');

  const t = await runTick(rig.core, 1000, false);
  assert.equal(t.binance, 'ok (1 rows, 1 new)');
  assert.equal((await rig.store.get<Payment>(C.payments, claim.payment.id))?.status, 'verified');
  assert.equal((await rig.store.get<LedgerEntry>(C.ledger, 'binance_pay:700800900100'))?.source, 'api');
  assert.match((await runTick(rig.core, 1000, false)).binance, /^skipped/, 'not polled more than once a minute');
  assert.equal(calls, 1);

  // now on a network Binance refuses
  const blocked = makeRig({ fetchFn, secrets: { binanceApiKey: KEY, binanceApiSecret: SECRET } });
  mode = 'restricted';
  assert.equal((await runTick(blocked.core, 1000, false)).binance, 'restricted_location');
  assert.match((await runTick(blocked.core, 1000, false)).binance, /blocked from this server/);
  assert.match((await runTick(blocked.core, 1000, false)).binance, /blocked from this server/);
  assert.equal(calls, 2, 'after a refusal the server stops knocking');
  assert.equal(blocked.alerts.filter((a) => a.topic === 'binance:restricted_location').length, 1);
  assert.match(blocked.alerts.find((a) => a.topic === 'binance:restricted_location')?.body ?? '', /Run collectors\/poller\.mjs on your own computer/);
});

test('tick: when payments wait and the phone is silent, the owner is told - once', async () => {
  const rig = makeRig();
  const o = await createOrder(rig.core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Quiet', clientEmail: 'quiet@example.org' }, null, '203.0.113.2');
  await submitClaim(rig.core, { invoiceId: (o.invoice as Invoice).invoiceId, methodId: 'bkash-personal', transactionId: 'QUIETPHONE', amount: 1500, currency: 'BDT' }, o.client.clientId);
  await runTick(rig.core, 500, false);
  const first = rig.alerts.filter((a) => a.topic === 'bridge:sms');
  assert.equal(first.length, 1);
  assert.match(first[0]?.body ?? '', /has never reported/);

  // the client was told the truth on the status page: this method is not connected right now
  const p = (await rig.store.list<Payment>(C.payments))[0] as Payment;
  assert.match(p.checkResults.find((c) => c.id === 'ledger_record')?.detail ?? '', /not connected right now; the owner will confirm it by hand/);

  // once the phone reports, the wording for new claims changes
  await touchBridge(rig.store, 'sms', 1);
  const o2 = await createOrder(rig.core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Quiet 2', clientEmail: 'quiet2@example.org' }, null, '203.0.113.2');
  const c2 = await submitClaim(rig.core, { invoiceId: (o2.invoice as Invoice).invoiceId, methodId: 'bkash-personal', transactionId: 'QUIETPHON2', amount: 1500, currency: 'BDT' }, o2.client.clientId);
  assert.match(c2.payment.checkResults.find((c) => c.id === 'ledger_record')?.detail ?? '', /usually takes a few minutes/);
});

test('FileStore: everything, including files and the audit chain, survives a restart', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'mrs-filestore-'));
  try {
    const first = makeRig({ store: new FileStore(dir) });
    assert.equal(first.store.durable, true);
    await trustBalance(first.core, 'bkash', 0, 'test');
    await saveSettings(first.store, { usdToBdt: 110 });
    const o = await createOrder(first.core, { serviceId: 'ats-cv-resume', details: 'x', clientName: 'Persist', clientEmail: 'persist@example.org' }, null, '203.0.113.2');
    const res = await ingestSms(first.core, { senderId: 'bKash', text: bkashSms({ amount: '1,650.00', balance: '1,650.00', trx: 'PERSIST001', ref: (o.invoice as Invoice).paymentReferenceCode }) });
    if (res.entry) await afterIngest(first.core, res.entry);
    await first.store.putBlob('deliv_test', Buffer.from('file contents that must survive'));

    // "restart": a brand-new store object reading the same folder
    const second = makeRig({ store: new FileStore(dir) });
    const inv = await second.store.get<Invoice>(C.invoices, (o.invoice as Invoice).invoiceId);
    assert.equal(inv?.status, 'paid_verified');
    assert.equal(inv?.rateSnapshot, 110);
    assert.equal((await second.store.get<LedgerEntry>(C.ledger, 'bkash:PERSIST001'))?.status, 'consumed');
    assert.equal((await second.store.getBlob('deliv_test'))?.toString(), 'file contents that must survive');
    assert.equal((await verifyAuditChain(second.store)).ok, true);
    // and the replay protection survived too: the same SMS again is still a duplicate
    assert.equal((await ingestSms(second.core, { senderId: 'bKash', text: bkashSms({ amount: '1,650.00', balance: '1,650.00', trx: 'PERSIST001', ref: (o.invoice as Invoice).paymentReferenceCode }) })).status, 'duplicate');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
