import { test } from 'node:test';
import assert from 'node:assert/strict';
import { saveSettings } from '../server/mrs-core/core.ts';
import { verifyAuditChain } from '../server/mrs-core/audit.ts';
import { createOrder } from '../server/mrs-core/orders/service.ts';
import { ingestDraft, ingestEmail, ingestSms, trustBalance, getBalanceAnchor } from '../server/mrs-core/payments/ledger.ts';
import { mapBinancePayRow } from '../server/mrs-core/payments/parsers/binance.ts';
import { afterIngest, attachEvidence, escalateStale, ownerConfirm, reconcileAll, rejectPayment, reversePayment, settle, submitClaim } from '../server/mrs-core/payments/service.ts';
import { C } from '../server/mrs-core/store/store.ts';
import type { AuditEntry, Invoice, LedgerEntry, Order, Payment } from '../server/mrs-core/types.ts';
import { HttpError } from '../server/mrs-core/util.ts';
import { bkashSms, makeRig, nagadSms } from './helpers.ts';
import type { TestRig } from './helpers.ts';

let seq = 0;
async function newOrder(rig: TestRig, serviceId = 'ats-cv-resume', extra: Record<string, unknown> = {}): Promise<{ order: Order; invoice: Invoice; clientId: string }> {
  seq += 1;
  const r = await createOrder(rig.core, { serviceId, details: 'test order', clientName: `Client ${seq}`, clientEmail: `client${seq}@example.org`, ...extra }, null, '203.0.113.9');
  assert.ok(r.invoice, 'fixed-price order must have an invoice');
  return { order: r.order, invoice: r.invoice, clientId: r.client.clientId };
}

async function sms(rig: TestRig, senderId: string, text: string): Promise<LedgerEntry | undefined> {
  const res = await ingestSms(rig.core, { senderId, text });
  if (res.entry && res.status !== 'duplicate') await afterIngest(rig.core, res.entry);
  return res.entry;
}

const inv = (rig: TestRig, id: string): Promise<Invoice | null> => rig.store.get<Invoice>(C.invoices, id);
const pay = (rig: TestRig, id: string): Promise<Payment | null> => rig.store.get<Payment>(C.payments, id);
const led = (rig: TestRig, id: string): Promise<LedgerEntry | null> => rig.store.get<LedgerEntry>(C.ledger, id);

async function rejects(fn: () => Promise<unknown>, code: string): Promise<void> {
  await assert.rejects(fn, (err: unknown) => {
    assert.ok(err instanceof HttpError, `expected HttpError, got ${String(err)}`);
    assert.equal(err.code, code);
    return true;
  });
}

test('bKash: claim first, SMS second -> verified automatically, exactly once', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 1_000_000, 'test'); // Tk 10,000.00
  const { invoice, clientId } = await newOrder(rig);
  assert.equal(invoice.totalMinor, 1500);

  const claim = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'DK593YKJET', amount: 1500, currency: 'BDT', senderMask: '01712345678' }, clientId);
  assert.equal(claim.payment.status, 'awaiting_ledger');
  assert.equal((await inv(rig, invoice.invoiceId))?.paidMinor, 0, 'a claim alone must never credit an invoice');

  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '11,500.00', trx: 'DK593YKJET' }));

  const p = await pay(rig, claim.payment.id);
  assert.equal(p?.status, 'verified');
  assert.equal(p?.decidedBy, 'auto');
  assert.equal(p?.source, 'sms');
  const paid = await inv(rig, invoice.invoiceId);
  assert.equal(paid?.status, 'paid_verified');
  assert.equal(paid?.paidMinor, 1500);
  assert.equal(paid?.amountDue, 0);
  assert.equal(paid?.receiptNumber, invoice.invoiceId.replace('INV-', 'RCP-'));
  assert.equal((await led(rig, 'bkash:DK593YKJET'))?.status, 'consumed');

  // the same transaction cannot pay a second invoice
  const other = await newOrder(rig);
  await rejects(() => submitClaim(rig.core, { invoiceId: other.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'dk593ykjet', amount: 1500, currency: 'BDT' }, other.clientId), 'trx_already_used');
  assert.equal((await inv(rig, other.invoice.invoiceId))?.paidMinor, 0);
});

test('bKash: SMS first, claim second -> verified at submission', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 500_000, 'test');
  const { invoice, clientId } = await newOrder(rig);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '6,500.00', trx: 'AB12CD34EF' }));
  assert.equal((await led(rig, 'bkash:AB12CD34EF'))?.status, 'unmatched');
  const claim = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, method: 'bkash', transactionId: 'AB12CD34EF', amount: 1500, currency: 'BDT', senderMask: '5678' }, clientId);
  assert.equal(claim.payment.status, 'verified');
  assert.equal((await inv(rig, invoice.invoiceId))?.status, 'paid_verified');
});

test('a made-up transaction id is never verified; it escalates to the owner', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  const claim = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'FAKE123456', amount: 1500, currency: 'BDT' }, clientId);
  assert.equal(claim.payment.status, 'awaiting_ledger');
  await reconcileAll(rig.core);
  assert.equal((await pay(rig, claim.payment.id))?.status, 'awaiting_ledger');
  assert.equal(await escalateStale(rig.core), 0, 'not stale yet');

  await rig.store.put(C.payments, claim.payment.id, { ...claim.payment, createdAt: new Date(Date.now() - 7 * 3600_000).toISOString() });
  assert.equal(await escalateStale(rig.core), 1);
  const p = await pay(rig, claim.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok(p?.flags.includes('no_ledger_record'));
  assert.equal((await inv(rig, invoice.invoiceId))?.paidMinor, 0);
  assert.ok(rig.alerts.some((a) => a.topic.startsWith('payment-stale:')));
});

test('a replayed SMS creates one ledger record and does not disturb the balance chain', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 100_000, 'test');
  const text = bkashSms({ amount: '500.00', balance: '1,500.00', trx: 'REPLAY0001' });
  const first = await ingestSms(rig.core, { senderId: 'bKash', text });
  const second = await ingestSms(rig.core, { senderId: 'bKash', text });
  const third = await ingestSms(rig.core, { senderId: '16247', text: text + ' ' }); // trailing space, other operator id
  assert.equal(first.status, 'new');
  assert.equal(second.status, 'duplicate');
  assert.equal(third.status, 'duplicate');
  assert.equal((await rig.store.list(C.ledger)).length, 1);
  const anchor = await getBalanceAnchor(rig.core, 'bkash');
  assert.equal(anchor.trustedMinor, 150_000);
  assert.equal(anchor.suspectMinor, null);
  // the next genuine message is still clean
  const next = await ingestSms(rig.core, { senderId: 'bKash', text: bkashSms({ amount: '100.00', balance: '1,600.00', trx: 'REPLAY0002' }) });
  assert.deepEqual(next.entry?.integrityFlags, []);
});

test('messages from anyone but the operator ids are dropped, and OTPs are never stored', async () => {
  const rig = makeRig();
  const forged = await ingestSms(rig.core, { senderId: '+8801712345678', text: bkashSms({ amount: '5,000.00', balance: '9,000.00', trx: 'FROMPHONE1' }) });
  assert.equal(forged.status, 'ignored');
  const otp = await ingestSms(rig.core, { senderId: 'bKash', text: 'Your bKash verification code is 482913. Never share your PIN or OTP.' });
  assert.equal(otp.status, 'ignored');
  assert.equal((await rig.store.list(C.ledger)).length, 0);
  assert.equal((await rig.store.list(C.quarantine)).length, 0);
  assert.equal((await rig.store.list(C.replay)).length, 0, 'nothing about an ignored message is kept');
});

test('underpayment is credited as partial; a second payment completes the invoice', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  const c1 = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'PART000001', amount: 1500, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,000.00', balance: '1,000.00', trx: 'PART000001' }));
  assert.equal((await pay(rig, c1.payment.id))?.status, 'verified');
  let i = await inv(rig, invoice.invoiceId);
  assert.equal(i?.status, 'partially_paid');
  assert.equal(i?.paidMinor, 1000);
  assert.equal(i?.amountDue, 5);

  const c2 = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'PART000002', amount: 500, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '500.00', balance: '1,500.00', trx: 'PART000002' }));
  assert.equal((await pay(rig, c2.payment.id))?.status, 'verified');
  i = await inv(rig, invoice.invoiceId);
  assert.equal(i?.status, 'paid_verified');
  assert.equal(i?.paidMinor, 1500);
});

test('a shortfall inside the 1% tolerance is written off, not left owing', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'TOLER00001', amount: 1490, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,490.00', balance: '1,490.00', trx: 'TOLER00001' }));
  const i = await inv(rig, invoice.invoiceId);
  assert.equal(i?.status, 'paid_verified');
  assert.equal(i?.paidMinor, 1490);
  assert.equal(i?.writtenOffMinor, 10);
});

test('overpayment settles the invoice and reports the surplus to the owner', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'OVER000001', amount: 2000, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '2,000.00', balance: '2,000.00', trx: 'OVER000001' }));
  const i = await inv(rig, invoice.invoiceId);
  assert.equal(i?.status, 'paid_verified');
  assert.equal(i?.paidMinor, 1500);
  assert.equal(i?.overpaidMinor, 500);
  assert.ok(rig.alerts.some((a) => a.topic === `overpaid:${invoice.invoiceId}`));
});

test('an amount above the automatic limit waits for the owner, who can approve it', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig, 'iptv-vip-pass', { planMonths: '12' });
  assert.equal(invoice.totalMinor, 9900);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'LIMIT00001', amount: 9900, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '9,900.00', balance: '9,900.00', trx: 'LIMIT00001' }));
  let p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok(p?.flags.includes('over_auto_limit'));
  assert.equal(p?.candidateLedgerId, 'bkash:LIMIT00001');
  assert.equal((await inv(rig, invoice.invoiceId))?.paidMinor, 0);

  p = await ownerConfirm(rig.core, c.payment.id, { action: 'RECEIVED', note: 'seen in app' });
  assert.equal(p.status, 'verified');
  assert.equal(p.decidedBy, 'owner');
  assert.equal(p.ownerConfirmationStatus, 'RECEIVED');
  assert.equal((await inv(rig, invoice.invoiceId))?.status, 'paid_verified');
});

test('FORGED SMS: a balance that does not add up is never settled automatically', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 250_000, 'test'); // real balance Tk 2,500.00
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'FORGED0001', amount: 1500, currency: 'BDT' }, clientId);
  // forger does not know the balance and invents one
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '18,340.00', trx: 'FORGED0001' }));
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok(p?.flags.includes('ledger_flagged'));
  assert.equal((await inv(rig, invoice.invoiceId))?.paidMinor, 0);
  assert.ok((await led(rig, 'bkash:FORGED0001'))?.integrityFlags.includes('balance_gap'));
  assert.ok(rig.alerts.some((a) => a.level === 'urgent' && a.topic === 'balance:bkash'));

  // a genuine payment for someone else, right after, is unaffected
  const honest = await newOrder(rig);
  const hc = await submitClaim(rig.core, { invoiceId: honest.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'HONEST0001', amount: 1500, currency: 'BDT' }, honest.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '4,000.00', trx: 'HONEST0001' }));
  assert.equal((await pay(rig, hc.payment.id))?.status, 'verified');

  // a second forged message that continues the forger's own fake balance is still flagged
  const again = await newOrder(rig);
  const ac = await submitClaim(rig.core, { invoiceId: again.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'FORGED0002', amount: 1500, currency: 'BDT' }, again.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '19,840.00', trx: 'FORGED0002' }));
  assert.equal((await pay(rig, ac.payment.id))?.status, 'needs_review');
});

test('first SMS from a new phone needs the owner once; approving it trusts the chain', async () => {
  const rig = makeRig();
  const a = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'nagad-personal', transactionId: '71ABCD01', amount: 1500, currency: 'BDT' }, a.clientId);
  await sms(rig, 'NAGAD', nagadSms({ amount: '1,500.00', balance: '3,200.00', trx: '71ABCD01' }));
  let p = await pay(rig, ca.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok((await led(rig, 'nagad:71ABCD01'))?.integrityFlags.includes('balance_unanchored'));

  p = await ownerConfirm(rig.core, ca.payment.id, { action: 'RECEIVED' });
  assert.equal(p.status, 'verified');
  assert.equal((await getBalanceAnchor(rig.core, 'nagad')).trustedMinor, 320_000);

  const b = await newOrder(rig);
  const cb = await submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'nagad-personal', transactionId: '71ABCD02', amount: 1500, currency: 'BDT' }, b.clientId);
  await sms(rig, '16167', nagadSms({ amount: '1,500.00', balance: '4,700.00', trx: '71ABCD02' }));
  assert.equal((await pay(rig, cb.payment.id))?.status, 'verified');
  assert.equal((await pay(rig, cb.payment.id))?.decidedBy, 'auto');
});

test('approving an OLD flagged record does not bless a later forged one', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 100_000, 'test');
  const a = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'GAPREAL001', amount: 1500, currency: 'BDT' }, a.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '7,000.00', trx: 'GAPREAL001' })); // gap (an SMS was lost)
  await sms(rig, 'bKash', bkashSms({ amount: '9,999.00', balance: '99,999.00', trx: 'GAPFORGE01' })); // forged, newest
  await ownerConfirm(rig.core, ca.payment.id, { action: 'RECEIVED' });
  const anchor = await getBalanceAnchor(rig.core, 'bkash');
  assert.equal(anchor.trustedMinor, 100_000, 'trusted balance must not jump to the forged figure');
});

test('reference on the transfer pays the invoice with no claim typed by anyone', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice } = await newOrder(rig);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'REFAUTO001', ref: invoice.paymentReferenceCode }));
  const i = await inv(rig, invoice.invoiceId);
  assert.equal(i?.status, 'paid_verified');
  const payments = await rig.store.list<Payment>(C.payments, [['invoiceId', invoice.invoiceId]]);
  assert.equal(payments.length, 1);
  assert.equal(payments[0]?.submittedBy, 'reference_auto');
  assert.equal(payments[0]?.status, 'verified');
});

test('a transfer carrying ANOTHER invoice\'s reference is not auto-settled for the claimant', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const victim = await newOrder(rig);
  const squatter = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: squatter.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'SQUAT00001', amount: 1500, currency: 'BDT' }, squatter.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'SQUAT00001', ref: victim.invoice.paymentReferenceCode }));
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok(p?.flags.includes('reference_names_other_invoice'));
  assert.equal((await inv(rig, squatter.invoice.invoiceId))?.paidMinor, 0);
});

test('payer number that differs from the record sends the claim to review', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'SENDER0001', amount: 1500, currency: 'BDT', senderMask: '01999990000' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'SENDER0001', from: '01712345678' }));
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok(p?.flags.includes('sender_mismatch'));
});

test('a mistyped O/0 in the transaction id still matches, and says so', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'DKO93YKJET', amount: 1500, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'DK093YKJET' }));
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'verified');
  assert.ok(p?.flags.includes('trx_id_typo_corrected'));
});

test('two orders claiming one transaction: neither is settled automatically', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const a = await newOrder(rig);
  const b = await newOrder(rig);
  const [ca, cb] = await Promise.all([
    submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'CONTEST001', amount: 1500, currency: 'BDT' }, a.clientId),
    submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'CONTEST001', amount: 1500, currency: 'BDT' }, b.clientId),
  ]);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'CONTEST001' }));
  const pa = await pay(rig, ca.payment.id);
  const pb = await pay(rig, cb.payment.id);
  assert.equal(pa?.status, 'needs_review');
  assert.equal(pb?.status, 'needs_review');
  assert.ok(pa?.flags.includes('contested_transaction') && pb?.flags.includes('contested_transaction'));
  assert.equal(((await inv(rig, a.invoice.invoiceId))?.paidMinor ?? 0) + ((await inv(rig, b.invoice.invoiceId))?.paidMinor ?? 0), 0);
});

test('DOUBLE SPEND: one ledger record settled for two payments at once -> exactly one wins', async () => {
  const rig = makeRig();
  const a = await newOrder(rig);
  const b = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'RACE000001', amount: 1500, currency: 'BDT' }, a.clientId);
  const cb = await submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'RACE000002', amount: 1500, currency: 'BDT' }, b.clientId);
  const entry = (await ingestDraft(rig.core, { source: 'statement', method: 'bkash', trxId: 'RACE000001', kind: 'received', amountMinor: 150_000, currency: 'BDT', receivedAt: new Date().toISOString(), rawText: 'race', flags: [] }, 'owner')).entry;
  assert.ok(entry);
  const results = await Promise.allSettled([settle(rig.core, ca.payment.id, entry.id, 'owner', 'x'), settle(rig.core, cb.payment.id, entry.id, 'owner', 'x'), settle(rig.core, ca.payment.id, entry.id, 'owner', 'x')]);
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
  const total = ((await inv(rig, a.invoice.invoiceId))?.paidMinor ?? 0) + ((await inv(rig, b.invoice.invoiceId))?.paidMinor ?? 0);
  assert.equal(total, 1500, 'the money was counted once');
});

test('submitting the same claim twice returns the same payment', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  const body = { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'IDEMP00001', amount: 1500, currency: 'BDT' };
  const [x, y] = await Promise.all([submitClaim(rig.core, body, clientId), submitClaim(rig.core, body, clientId)]);
  const z = await submitClaim(rig.core, { ...body, transactionId: ' idemp-00001 ' }, clientId);
  assert.equal(x.payment.id, y.payment.id);
  assert.equal(x.payment.id, z.payment.id);
  assert.equal(z.created, false);
  assert.equal((await rig.store.list(C.payments)).length, 1);
});

test('a client cannot submit against someone else\'s invoice, nor learn that it exists', async () => {
  const rig = makeRig();
  const a = await newOrder(rig);
  const b = await newOrder(rig);
  await rejects(() => submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'OTHER00001', amount: 1500, currency: 'BDT' }, b.clientId), 'invoice_not_found');
  await rejects(() => submitClaim(rig.core, { invoiceId: 'INV-0000-0000', methodId: 'bkash-personal', transactionId: 'OTHER00001', amount: 1500, currency: 'BDT' }, b.clientId), 'invoice_not_found');
});

test('input validation: bad ids, bad amounts, too many submissions', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  const base = { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', amount: 1500, currency: 'BDT' };
  await rejects(() => submitClaim(rig.core, { ...base, transactionId: 'abc' }, clientId), 'bad_transaction_id');
  await rejects(() => submitClaim(rig.core, { ...base, transactionId: '<script>alert(1)</script>' }, clientId), 'bad_transaction_id');
  await rejects(() => submitClaim(rig.core, { ...base, transactionId: 'GOODID0001', amount: -5 }, clientId), 'bad_amount');
  await rejects(() => submitClaim(rig.core, { ...base, transactionId: 'GOODID0001', amount: 'lots' }, clientId), 'bad_amount');
  await rejects(() => submitClaim(rig.core, { invoiceId: invoice.invoiceId, method: 'western_union', transactionId: 'GOODID0001', amount: 15, currency: 'EUR' }, clientId), 'unknown_method');
  for (let i = 0; i < 5; i++) await submitClaim(rig.core, { ...base, transactionId: `SPAM00000${i}` }, clientId);
  await rejects(() => submitClaim(rig.core, { ...base, transactionId: 'SPAM000009' }, clientId), 'too_many_submissions');
});

test('kill switch stops all automatic settlement', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  await saveSettings(rig.store, { killSwitch: true });
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'KILL000001', amount: 1500, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'KILL000001' }));
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'needs_review');
  assert.ok(p?.flags.includes('kill_switch'));
  await saveSettings(rig.store, { killSwitch: false });
  await reconcileAll(rig.core);
  assert.equal((await pay(rig, c.payment.id))?.status, 'verified');
});

test('Cash In (not Send Money) and transfers older than the invoice need the owner', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const a = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'CASHIN0001', amount: 1500, currency: 'BDT' }, a.clientId);
  const res = await ingestSms(rig.core, { senderId: 'bKash', text: `Cash In Tk 1,500.00 from 01812345678 successful. Fee Tk 0.00. Balance Tk 1,500.00. TrxID CASHIN0001 at 01/01/2026 10:00` });
  if (res.entry) await afterIngest(rig.core, res.entry);
  const pa = await pay(rig, ca.payment.id);
  assert.equal(pa?.status, 'needs_review');
  assert.ok(pa?.flags.includes('not_a_direct_transfer'));

  const b = await newOrder(rig);
  const cb = await submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'OLDPAY0001', amount: 1500, currency: 'BDT' }, b.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '3,000.00', trx: 'OLDPAY0001', minutesAgo: 3 * 24 * 60 }));
  const pb = await pay(rig, cb.payment.id);
  assert.equal(pb?.status, 'needs_review');
  assert.ok(pb?.flags.includes('paid_before_invoice'));
});

test('Binance: API history row settles a claim; id prefixes are ignored; outgoing rows are not money in', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  assert.equal(mapBinancePayRow({ orderType: 'C2C', transactionId: 'M_P_1', transactionTime: Date.now(), amount: '-15', currency: 'USDT' }, '38927942'), null);

  const draft = mapBinancePayRow({ orderType: 'C2C', transactionId: 'M_P_71505104267788288', transactionTime: Date.now(), amount: '15.00000000', currency: 'USDT', payerInfo: { name: 'Jack' }, receiverInfo: { binanceId: '38927942' } }, '38927942');
  assert.ok(draft);
  assert.deepEqual(draft.flags, []);
  const res = await ingestDraft(rig.core, draft, 'collector:api');
  assert.equal(res.entry?.id, 'binance_pay:71505104267788288');
  if (res.entry) await afterIngest(rig.core, res.entry);

  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'binance-pay', transactionId: '71505104267788288', amount: 15, currency: 'USD' }, clientId);
  assert.equal(c.payment.status, 'verified');
  assert.equal(c.payment.source, 'api');
  assert.equal((await inv(rig, invoice.invoiceId))?.status, 'paid_verified');
});

test('Binance: wrong receiver, non-stable asset and fractional dust are handled safely', async () => {
  const wrong = mapBinancePayRow({ orderType: 'C2C', transactionId: 'P_1234567890', transactionTime: Date.now(), amount: '15', currency: 'USDT', receiverInfo: { binanceId: '11111111' } }, '38927942');
  assert.ok(wrong?.flags.includes('wrong_receiver'));
  const bnb = mapBinancePayRow({ orderType: 'C2C', transactionId: 'P_1234567891', transactionTime: Date.now(), amount: '0.05', currency: 'BNB' }, '38927942');
  assert.ok(bnb?.flags.includes('currency_not_accepted'));
  const box = mapBinancePayRow({ orderType: 'CRYPTO_BOX', transactionId: 'P_1234567892', transactionTime: Date.now(), amount: '15', currency: 'USDT' }, '38927942');
  assert.ok(box?.flags.includes('unexpected_order_type'));
  const dust = mapBinancePayRow({ orderType: 'C2C', transactionId: 'P_1234567893', transactionTime: Date.now(), amount: '14.99999999', currency: 'USDT' }, '38927942');
  assert.equal(dust?.amountMinor, 1499, 'never rounded up');
});

test('older page sends method "bank_transfer" for every USD method: resolved from the ledger', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, method: 'bank_transfer', transactionId: 'SK-998-877-66', amount: 15, currency: 'USD' }, clientId);
  assert.equal(c.payment.method, 'usd_unspecified');
  assert.equal(c.payment.status, 'awaiting_ledger');
  const res = await ingestDraft(rig.core, { source: 'statement', method: 'skrill', trxId: 'SK99887766', kind: 'received', amountMinor: 1500, currency: 'USD', receivedAt: new Date().toISOString(), rawText: 'skrill stmt', flags: [] }, 'owner');
  if (res.entry) await afterIngest(rig.core, res.entry);
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'verified');
  assert.equal(p?.method, 'skrill');
});

const GMAIL_OK = (domain: string): string => `mx.google.com; dkim=pass header.i=@${domain} header.s=s1 header.b=abc; spf=pass (google.com: domain of bounce@${domain} designates 203.0.113.10 as permitted sender) smtp.mailfrom=bounce@${domain}; dmarc=pass (p=REJECT sp=REJECT dis=NONE) header.from=${domain}`;

test('e-mail: an authenticated Skrill notice with a transaction id settles a small claim', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'skrill', transactionId: '4455667788', amount: 15, currency: 'USD' }, clientId);
  const res = await ingestEmail(rig.core, { messageId: 'gm-1', authResults: GMAIL_OK('skrill.com'), from: 'Skrill <no-reply@email.skrill.com>', subject: "You've received USD 15.00", body: 'Hello,\nYou have received a payment.\nAmount: USD 15.00\nTransaction ID: 4455667788\nThank you.', date: new Date().toISOString() });
  assert.equal(res.status, 'new');
  if (res.entry) await afterIngest(rig.core, res.entry);
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'verified');
  assert.equal(p?.source, 'email');
  // same e-mail again
  assert.equal((await ingestEmail(rig.core, { messageId: 'gm-1', authResults: GMAIL_OK('skrill.com'), from: 'Skrill <no-reply@email.skrill.com>', subject: "You've received USD 15.00", body: 'x', date: new Date().toISOString() })).status, 'duplicate');
});

test('e-mail: look-alike senders and failed authentication are refused and reported', async () => {
  const rig = makeRig();
  const common = { subject: "You've received USD 500.00", body: 'Transaction ID: 99887766', date: new Date().toISOString() };
  const cases: [string, string, string][] = [
    ['no dmarc', 'mx.google.com; dkim=pass header.i=@skrill.com; spf=pass smtp.mailfrom=x@skrill.com', 'Skrill <no-reply@skrill.com>'],
    ['dmarc fail', 'mx.google.com; dkim=fail; spf=fail; dmarc=fail (p=REJECT) header.from=skrill.com', 'Skrill <no-reply@skrill.com>'],
    ['look-alike domain', GMAIL_OK('skrill.com.payments-secure.net'), 'Skrill <no-reply@skrill.com.payments-secure.net>'],
    ['gmail address with a bank display name', GMAIL_OK('gmail.com'), 'Skrill Payments <skrill.payments@gmail.com>'],
    ['verdict not from Gmail', 'mail.attacker.net; dkim=pass; dmarc=pass header.from=skrill.com', 'Skrill <no-reply@skrill.com>'],
    ['visible From differs from authenticated domain', GMAIL_OK('skrill.com'), 'Skrill <no-reply@evil.example>'],
    ['suffix trick', GMAIL_OK('notskrill.com'), 'Skrill <no-reply@notskrill.com>'],
  ];
  let n = 0;
  for (const [name, auth, from] of cases) {
    n += 1;
    const res = await ingestEmail(rig.core, { messageId: `bad-${n}`, authResults: auth, from, ...common });
    assert.equal(res.status, 'rejected', name);
  }
  assert.equal((await rig.store.list(C.ledger)).length, 0);
  assert.ok(rig.alerts.some((a) => a.topic === 'email-unauthenticated'));
});

test('e-mail: no transaction id, "pending", payment requests and two amounts never settle automatically', async () => {
  const rig = makeRig();
  const { invoice, clientId } = await newOrder(rig);
  // Payoneer notice without any id -> synthetic id, flagged
  const res = await ingestEmail(rig.core, { messageId: 'p-1', authResults: GMAIL_OK('payoneer.com'), from: 'Payoneer <no-reply@payoneer.com>', subject: 'You received a payment of $15.00 USD from Acme Ltd', body: 'Your payment is now available in your balance.', date: new Date().toISOString() });
  assert.equal(res.status, 'new');
  assert.ok(res.entry?.syntheticId);
  assert.ok(res.entry?.integrityFlags.includes('no_provider_id'));
  if (res.entry) await afterIngest(rig.core, res.entry);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'payoneer', transactionId: 'PYN12345', amount: 15, currency: 'USD' }, clientId);
  assert.equal(c.payment.status, 'awaiting_ledger');

  const pending = await ingestEmail(rig.core, { messageId: 'p-2', authResults: GMAIL_OK('payoneer.com'), from: 'Payoneer <no-reply@payoneer.com>', subject: 'You received a payment of $20.00 USD', body: 'Payment ID: 88776655. This payment is pending review.', date: new Date().toISOString() });
  assert.ok(pending.entry?.integrityFlags.includes('pending_at_provider'));

  const request = await ingestEmail(rig.core, { messageId: 'p-3', authResults: GMAIL_OK('payoneer.com'), from: 'Payoneer <no-reply@payoneer.com>', subject: 'Acme Ltd requested a payment of $500.00', body: 'Pay now', date: new Date().toISOString() });
  assert.equal(request.status, 'ignored');

  const two = await ingestEmail(rig.core, { messageId: 's-9', authResults: GMAIL_OK('skrill.com'), from: 'Skrill <no-reply@skrill.com>', subject: "You've received USD 10.00 from $500.00 USD Trading", body: 'Transaction ID: 123454321', date: new Date().toISOString() });
  assert.ok(two.entry?.integrityFlags.includes('multiple_amounts'));
  assert.equal(two.entry?.amountMinor, 1000, 'the first amount in the provider-written subject is used');
});

test('the same Binance payment seen by API and by an id-less e-mail counts once', async () => {
  const rig = makeRig();
  const when = new Date().toISOString();
  const api = await ingestDraft(rig.core, mapBinancePayRow({ orderType: 'C2C', transactionId: 'P_555000111222', transactionTime: Date.parse(when), amount: '25', currency: 'USDT' }, '38927942') as never, 'collector:api');
  const mail = await ingestEmail(rig.core, { messageId: 'b-1', authResults: GMAIL_OK('binance.com'), from: 'Binance <do-not-reply@directmail.binance.com>', subject: 'Payment Receive Successful', body: 'You have received 25 USDT from Jack.', date: when });
  assert.equal(api.status, 'new');
  assert.equal(mail.status, 'quarantined');
  assert.ok(mail.entry?.integrityFlags.some((f) => f.startsWith('twin_of:')));
  const free = await rig.store.list<LedgerEntry>(C.ledger, [['status', 'unmatched']]);
  assert.equal(free.length, 1);
});

test('owner: RECEIVED with no provider record writes the ledger line; NOT_RECEIVED rejects', async () => {
  const rig = makeRig();
  const a = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'payoneer', transactionId: 'PYN000111', amount: 15, currency: 'USD' }, a.clientId);
  const pa = await ownerConfirm(rig.core, ca.payment.id, { action: 'RECEIVED', note: 'seen in Payoneer' });
  assert.equal(pa.status, 'verified');
  assert.equal(pa.source, 'manual');
  assert.equal((await led(rig, 'payoneer:PYN000111'))?.status, 'consumed');
  assert.equal((await inv(rig, a.invoice.invoiceId))?.status, 'paid_verified');

  const b = await newOrder(rig);
  const cb = await submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'payoneer', transactionId: 'PYN000222', amount: 15, currency: 'USD' }, b.clientId);
  const pb = await ownerConfirm(rig.core, cb.payment.id, { action: 'NOT_RECEIVED', note: 'nothing in the account' });
  assert.equal(pb.status, 'rejected');
  assert.equal((await inv(rig, b.invoice.invoiceId))?.paidMinor, 0);
  await rejects(() => submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'payoneer', transactionId: 'PYN000222', amount: 15, currency: 'USD' }, b.clientId), 'previously_rejected');
  await rejects(() => rejectPayment(rig.core, ca.payment.id, 'oops'), 'already_verified');

  // legacy USD claim: the owner must say which account received it
  const c = await newOrder(rig);
  const cc = await submitClaim(rig.core, { invoiceId: c.invoice.invoiceId, method: 'bank_transfer', transactionId: 'USD000333', amount: 15, currency: 'USD' }, c.clientId);
  await rejects(() => ownerConfirm(rig.core, cc.payment.id, { action: 'RECEIVED' }), 'method_required');
  assert.equal((await ownerConfirm(rig.core, cc.payment.id, { action: 'RECEIVED', method: 'skrill' })).method, 'skrill');
});

test('the same receipt image on two payments is flagged', async () => {
  const rig = makeRig();
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.from('fake image body')]).toString('base64');
  const a = await newOrder(rig);
  const b = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'EVID000001', amount: 1500, currency: 'BDT' }, a.clientId);
  const cb = await submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'EVID000002', amount: 1500, currency: 'BDT' }, b.clientId);
  await attachEvidence(rig.core, ca.payment.id, 'r.png', `data:image/png;base64,${png}`, a.clientId);
  const pb = await attachEvidence(rig.core, cb.payment.id, 'r.png', png, b.clientId);
  assert.ok(pb.flags.includes('evidence_reused'));
  await rejects(() => attachEvidence(rig.core, ca.payment.id, 'x.exe', Buffer.from('MZ this is not an image at all').toString('base64'), a.clientId), 'bad_file_type');
  await rejects(() => attachEvidence(rig.core, ca.payment.id, 'r.png', png, b.clientId), 'payment_not_found');
});

test('amounts in Taka are converted at the rate frozen on the invoice', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  await saveSettings(rig.store, { usdToBdt: 120 });
  const { invoice, clientId } = await newOrder(rig);
  assert.equal(invoice.rateSnapshot, 120);
  assert.equal(invoice.amountBDT, 1800);
  await saveSettings(rig.store, { usdToBdt: 200 }); // a later rate change must not affect this invoice
  await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'RATE000001', amount: 1800, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,800.00', balance: '1,800.00', trx: 'RATE000001' }));
  assert.equal((await inv(rig, invoice.invoiceId))?.status, 'paid_verified');
});

test('audit log is a verifiable chain, and tampering is detected', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'AUDIT00001', amount: 1500, currency: 'BDT' }, clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'AUDIT00001' }));
  const ok = await verifyAuditChain(rig.store);
  assert.equal(ok.ok, true);
  assert.ok(ok.entries >= 4);
  const entries = await rig.store.list<AuditEntry>(C.audit);
  assert.ok(entries.some((e) => e.action === 'payment.verified'));

  const victim = entries.find((e) => e.action === 'payment.verified') as AuditEntry;
  await rig.store.put(C.audit, victim.id, { ...victim, detail: 'credited $9,999.00' });
  const broken = await verifyAuditChain(rig.store);
  assert.equal(broken.ok, false);
  assert.equal(broken.brokenAt, victim.seq);

  await rig.store.put(C.audit, victim.id, victim);
  const last = entries.sort((a, b) => b.seq - a.seq)[0] as AuditEntry;
  await rig.store.delete(C.audit, last.id);
  assert.equal((await verifyAuditChain(rig.store)).ok, false, 'removing the newest entry is detected');
});

test('bKash and Nagad share one number: a claim filed under the wrong wallet still finds its money', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'nagad', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  // the customer chose "bKash" on the pay page but actually paid with Nagad (8-character id)
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: '71WRONGW', amount: 1500, currency: 'BDT' }, clientId);
  assert.equal(c.payment.status, 'awaiting_ledger');
  assert.deepEqual(c.payment.methodCandidates, ['bkash', 'nagad']);
  await sms(rig, 'NAGAD', nagadSms({ amount: '1,500.00', balance: '1,500.00', trx: '71WRONGW' }));
  const p = await pay(rig, c.payment.id);
  assert.equal(p?.status, 'verified');
  assert.equal(p?.method, 'nagad', 'the payment takes the method of the record that was found');
  assert.equal((await led(rig, 'nagad:71WRONGW'))?.status, 'consumed');
  assert.equal(await led(rig, 'bkash:71WRONGW'), null);
  // a dollar method is NOT searched in the wallets, and the other way round
  const other = await newOrder(rig);
  const usd = await submitClaim(rig.core, { invoiceId: other.invoice.invoiceId, methodId: 'skrill', transactionId: '71WRONGW9', amount: 15, currency: 'USD' }, other.clientId);
  assert.deepEqual(usd.payment.methodCandidates, ['skrill']);
});

test('owner can REVERSE a verified payment; it can then only be decided again by the owner', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');

  // (a) a real SMS-backed payment, verified automatically, then reversed because the money was sent back
  const a = await newOrder(rig);
  const ca = await submitClaim(rig.core, { invoiceId: a.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'REVERSE001', amount: 1490, currency: 'BDT' }, a.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,490.00', balance: '1,490.00', trx: 'REVERSE001' }));
  let inv1 = (await inv(rig, a.invoice.invoiceId)) as Invoice;
  assert.equal(inv1.status, 'paid_verified');
  assert.equal(inv1.writtenOffMinor, 10);
  await rejects(() => rejectPayment(rig.core, ca.payment.id, 'changed my mind'), 'already_verified');
  await rejects(() => reversePayment(rig.core, ca.payment.id, 'no'), 'reason_required');

  const reversed = await reversePayment(rig.core, ca.payment.id, 'Refunded to the customer in bKash');
  assert.equal(reversed.status, 'needs_review', 'back in the owner\'s queue');
  assert.ok(reversed.flags.includes('reversed'));
  assert.match(reversed.decisionReason ?? '', /^Reversed: Refunded/);
  inv1 = (await inv(rig, a.invoice.invoiceId)) as Invoice;
  assert.equal(inv1.status, 'issued');
  assert.equal(inv1.paidMinor, 0);
  assert.equal(inv1.writtenOffMinor, 0, 'the tolerance write-off is undone too');
  assert.equal(inv1.amountDue, 15);
  assert.equal(inv1.paidAt, undefined);
  const aside = await led(rig, 'bkash:REVERSE001');
  assert.equal(aside?.status, 'quarantined', 'after a refund the provider record must not pay for anything else');
  assert.ok(aside?.integrityFlags.includes('reversed'));
  await rejects(() => reversePayment(rig.core, ca.payment.id, 'again please'), 'not_verified');
  const msgs = await rig.store.list<{ text: string }>(C.messages, [['orderId', a.order.orderId]]);
  assert.ok(msgs.some((m) => /was reversed: Refunded to the customer/.test(m.text)));

  // nothing brings it back by itself: not the tick, not a new claim for the same transaction
  await reconcileAll(rig.core);
  await reconcileAll(rig.core);
  assert.equal((await pay(rig, ca.payment.id))?.status, 'needs_review');
  assert.equal((await inv(rig, a.invoice.invoiceId))?.paidMinor, 0);
  const again = await newOrder(rig);
  const retry = await submitClaim(rig.core, { invoiceId: again.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'REVERSE001', amount: 1490, currency: 'BDT' }, again.clientId);
  assert.equal(retry.payment.status, 'needs_review', 'the refunded transaction cannot buy a new order');
  assert.equal((await inv(rig, again.invoice.invoiceId))?.paidMinor, 0);
  // the owner closes the reversed one for good
  const closed = await ownerConfirm(rig.core, ca.payment.id, { action: 'NOT_RECEIVED', note: 'refunded' });
  assert.equal(closed.status, 'rejected');
  await reconcileAll(rig.core);
  assert.equal((await inv(rig, again.invoice.invoiceId))?.paidMinor, 0, 'still not reusable after the first claim is closed');

  // ... but the owner CAN deliberately confirm a reversed payment again
  const b0 = await newOrder(rig);
  const cb0 = await submitClaim(rig.core, { invoiceId: b0.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'REVERSE002', amount: 1500, currency: 'BDT' }, b0.clientId);
  await sms(rig, 'bKash', bkashSms({ amount: '1,500.00', balance: '2,990.00', trx: 'REVERSE002' }));
  await reversePayment(rig.core, cb0.payment.id, 'Reversed by mistake, will confirm again');
  const back = await ownerConfirm(rig.core, cb0.payment.id, { action: 'RECEIVED', note: 'it was right after all' });
  assert.equal(back.status, 'verified');
  assert.equal(back.decidedBy, 'owner');
  assert.equal((await inv(rig, b0.invoice.invoiceId))?.status, 'paid_verified');

  // (b) a wrong tap on "Received" with no provider record, for the wrong amount
  const b = await newOrder(rig);
  const cb = await submitClaim(rig.core, { invoiceId: b.invoice.invoiceId, methodId: 'payoneer', transactionId: 'WRONGTAP1', amount: 15, currency: 'USD' }, b.clientId);
  await ownerConfirm(rig.core, cb.payment.id, { action: 'RECEIVED' });
  assert.equal((await inv(rig, b.invoice.invoiceId))?.status, 'paid_verified');
  await reversePayment(rig.core, cb.payment.id, 'Tapped Received for the wrong amount');
  assert.equal((await inv(rig, b.invoice.invoiceId))?.paidMinor, 0);
  assert.equal(await led(rig, 'payoneer:WRONGTAP1'), null, 'the owner\'s own line is removed');
  await reconcileAll(rig.core);
  assert.equal((await inv(rig, b.invoice.invoiceId))?.paidMinor, 0);
  // confirm again with the amount actually seen in Payoneer
  const fixed = await ownerConfirm(rig.core, cb.payment.id, { action: 'RECEIVED', amount: 10, note: 'only $10 arrived' });
  assert.equal(fixed.status, 'verified');
  const partial = (await inv(rig, b.invoice.invoiceId)) as Invoice;
  assert.equal(partial.status, 'partially_paid');
  assert.equal(partial.paidMinor, 1000);
  assert.equal((await led(rig, 'payoneer:WRONGTAP1'))?.amountMinor, 1000);

  const chain = await verifyAuditChain(rig.store);
  assert.equal(chain.ok, true);
  assert.equal((await rig.store.list<AuditEntry>(C.audit)).filter((e) => e.action === 'payment.reversed').length, 3);
});

test('owner confirmed by hand, then the bank SMS shows a different amount: the owner is told at once', async () => {
  const rig = makeRig();
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { invoice, clientId } = await newOrder(rig);
  const c = await submitClaim(rig.core, { invoiceId: invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'SHORTPAY01', amount: 1500, currency: 'BDT' }, clientId);
  await ownerConfirm(rig.core, c.payment.id, { action: 'RECEIVED', note: 'trusted the customer' }); // recorded as Tk 1,500
  assert.equal((await inv(rig, invoice.invoiceId))?.status, 'paid_verified');
  // the real SMS arrives: it was only Tk 500
  const res = await ingestSms(rig.core, { senderId: 'bKash', text: bkashSms({ amount: '500.00', balance: '500.00', trx: 'SHORTPAY01' }) });
  assert.equal(res.status, 'duplicate');
  const alert = rig.alerts.find((a) => a.topic === 'ledger-conflict:bkash:SHORTPAY01');
  assert.equal(alert?.level, 'urgent');
  assert.match(alert?.body ?? '', /recorded \(manual\) as Tk 1,500\.00, but the operator's SMS says Tk 500\.00/);
  assert.equal((await getBalanceAnchor(rig.core, 'bkash')).trustedMinor, 50_000, 'the running balance still follows the genuine SMS');
  // the path the alert recommends: reverse, then confirm with the right amount
  await reversePayment(rig.core, c.payment.id, 'SMS shows Tk 500, not 1,500');
  const fixed = await ownerConfirm(rig.core, c.payment.id, { action: 'RECEIVED', amount: 500, note: 'Tk 500 per the SMS' });
  assert.equal(fixed.status, 'verified');
  const corrected = (await inv(rig, invoice.invoiceId)) as Invoice;
  assert.equal(corrected.status, 'partially_paid');
  assert.equal(corrected.paidMinor, 500);
  assert.equal(corrected.amountDue, 10);
  // same amount -> no alert
  const rig2 = makeRig();
  await trustBalance(rig2.core, 'bkash', 0, 'test');
  const o2 = await newOrder(rig2);
  const c2 = await submitClaim(rig2.core, { invoiceId: o2.invoice.invoiceId, methodId: 'bkash-personal', transactionId: 'SAMEAMT001', amount: 1500, currency: 'BDT' }, o2.clientId);
  await ownerConfirm(rig2.core, c2.payment.id, { action: 'RECEIVED' });
  await ingestSms(rig2.core, { senderId: 'bKash', text: bkashSms({ amount: '1,500.00', balance: '1,500.00', trx: 'SAMEAMT001' }) });
  assert.equal(rig2.alerts.filter((a) => a.topic.startsWith('ledger-conflict')).length, 0);
});
