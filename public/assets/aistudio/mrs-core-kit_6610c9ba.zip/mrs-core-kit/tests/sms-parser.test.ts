import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseWalletSms, walletForSender, senderRulesFromEnv } from '../server/mrs-core/payments/parsers/sms.ts';
import { applyBalance, EMPTY_ANCHOR, trustLatest, setTrusted } from '../server/mrs-core/payments/balance.ts';

test('sender id decides the wallet; ordinary phone numbers are never operators', () => {
  assert.equal(walletForSender('bKash'), 'bkash');
  assert.equal(walletForSender('BKASH'), 'bkash');
  assert.equal(walletForSender('16247'), 'bkash');
  assert.equal(walletForSender('NAGAD'), 'nagad');
  assert.equal(walletForSender('16167'), 'nagad');
  assert.equal(walletForSender('01810853282'), null); // the owner's own number is not an operator
  assert.equal(walletForSender('+8801792322734'), null);
  assert.equal(walletForSender('bKash '), 'bkash');
  assert.equal(walletForSender(''), null);
  const custom = senderRulesFromEnv({ MRS_SMS_SENDERS_BKASH: 'bKash, 16247 ,bKashBD' });
  assert.equal(walletForSender('bkashbd', custom), 'bkash');
});

test('bKash: received with reference, fee and balance', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 2,500.00 from 01711098234. Ref PAY-2611-1044. Fee Tk 0.00. Balance Tk 14,250.00. TrxID 9K8X2M99 at 05/11/2026 14:15');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.kind, 'received');
  assert.equal(p.trxId, '9K8X2M99');
  assert.equal(p.amountMinor, 250000);
  assert.equal(p.sender, '01711098234');
  assert.equal(p.reference, 'PAY-2611-1044');
  assert.equal(p.balanceMinor, 1425000);
  assert.equal(p.deltaMinor, 250000);
  assert.equal(p.providerTime, '2026-11-05T08:15:00.000Z'); // 14:15 Dhaka = 08:15 UTC
  assert.deepEqual(p.flags, []);
});

test('bKash: received without reference or fee (short form)', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 200.00 from 01712345678. Balance Tk 212.74. TrxID DK593YKJET at 05/11/2026 22:56');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.amountMinor, 20000);
  assert.equal(p.sender, '01712345678');
  assert.equal(p.reference, undefined);
  assert.equal(p.balanceMinor, 21274);
  assert.equal(p.trxId, 'DK593YKJET');
  assert.deepEqual(p.flags, []);
});

test('bKash: "TrxID X and Ref Y at ..." ordering', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 1,200.00 from 01712750278. Fee Tk 0.00. Balance Tk 1,200.00. TrxID DJC9SZQV0J and Ref PAY-2611-7781 at 12/10/2026 15:24');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.trxId, 'DJC9SZQV0J');
  assert.equal(p.amountMinor, 120000);
  assert.equal(p.reference, 'PAY-2611-7781');
  assert.deepEqual(p.flags, []);
});

test('bKash: whole-taka balance followed by a sentence full stop', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 100.00 from 01712345678. Fee Tk 0.00. Balance Tk 100. TrxID DK563YZW8E at 05/11/2026 23:07.');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.balanceMinor, 10000);
  assert.equal(p.amountMinor, 10000);
});

test('bKash: Cash In is money in, but not a Send Money', () => {
  const p = parseWalletSms('bkash', 'Cash In Tk 1,000.00 from 01812345678 successful. Fee Tk 0.00. Balance Tk 2,000.00. TrxID AB12CD34EF at 01/11/2026 10:00');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.kind, 'cash_in');
  assert.equal(p.amountMinor, 100000);
});

test('bKash: outgoing movements only move the balance', () => {
  const out1 = parseWalletSms('bkash', 'Cash Out Tk 500.00 to 01712345678 successful. Fee Tk 9.25. Balance Tk 100.00. TrxID DK563YZW8E at 05/11/2026 23:07.');
  assert.equal(out1.outcome, 'balance_only');
  assert.equal(out1.deltaMinor, -50925);
  assert.equal(out1.balanceMinor, 10000);

  const out2 = parseWalletSms('bkash', 'Send Money Tk 200.00 to 01712345678 successful. Ref gift. Fee Tk 5.00. Balance Tk 3.72. TrxID DK593YKJEA at 05/11/2026 22:57');
  assert.equal(out2.outcome, 'balance_only');
  assert.equal(out2.deltaMinor, -20500);

  const out3 = parseWalletSms('bkash', 'Payment of Tk. 100 to Merchant is successful. Balance Tk 46.72. TrxID DJN9G0UH0V at 23/10/2026 22:14');
  assert.equal(out3.outcome, 'balance_only');
  assert.equal(out3.deltaMinor, -10000);
  assert.equal(out3.balanceMinor, 4672);
});

test('Nagad: labelled multi-line "Money Received"', () => {
  const p = parseWalletSms('nagad', 'Money Received.\nAmount: Tk 4,500.00\nSender: 01810992341\nRef: PAY-2611-1050\nTxnID: 71B89KX2\nBalance: Tk 28,450.00\n05/11/2026 16:30');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.kind, 'received');
  assert.equal(p.trxId, '71B89KX2');
  assert.equal(p.amountMinor, 450000);
  assert.equal(p.sender, '01810992341');
  assert.equal(p.reference, 'PAY-2611-1050');
  assert.equal(p.balanceMinor, 2845000);
  assert.equal(p.providerTime, '2026-11-05T10:30:00.000Z');
  assert.deepEqual(p.flags, []);
});

test('Nagad: single-line variant used by the existing site simulator', () => {
  const p = parseWalletSms('nagad', 'Money Received. Amount: Tk 4,500.00. Sender: 01810992341. TxnID: 71B89KX. Balance: Tk 28,450.00. Date: 05/11/2026 16:30');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.trxId, '71B89KX');
  assert.equal(p.amountMinor, 450000);
  assert.equal(p.sender, '01810992341');
  assert.equal(p.reference, undefined);
});

test('Nagad: "Ref: N/A" is no reference', () => {
  const p = parseWalletSms('nagad', 'Money Received.\nAmount: Tk 500.00\nSender: 01712345678\nRef: N/A\nTxnID: 72AB3890\nBalance: Tk 1,234.56\n17/08/2026 14:32');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.reference, undefined);
  assert.equal(p.amountMinor, 50000);
});

test('Nagad sender id with a bKash-shaped body still parses (format is not tied to the wallet)', () => {
  const p = parseWalletSms('nagad', 'You have received Tk 850.00 from 01811223344. Balance Tk 2,400.00. TrxID 72AB3890 at 12/10/2026 09:05');
  assert.equal(p.outcome, 'credit');
  assert.equal(p.wallet, 'nagad');
  assert.equal(p.amountMinor, 85000);
});

test('OTP and promotional messages are ignored (text must not be kept)', () => {
  assert.equal(parseWalletSms('bkash', 'Your bKash verification code is 482913. Do not share this OTP with anyone.').outcome, 'ignored');
  assert.equal(parseWalletSms('bkash', 'Get 10% cashback on mobile recharge this Friday! T&C apply.').outcome, 'ignored');
  assert.equal(parseWalletSms('nagad', 'Your Nagad security code is 9912. Tk 500 bonus waiting!').outcome, 'ignored');
});

test('money-shaped message with no transaction id is quarantined, not trusted', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 5,000.00 from 01711112222.');
  assert.equal(p.outcome, 'unparsed');
});

test('HOSTILE: payer puts a second TrxID in the reference -> ambiguous, never clean', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 10.00 from 01711112222. Ref TrxID AAAAAAAAAA. Fee Tk 0.00. Balance Tk 510.00. TrxID DK777REAL1 at 05/11/2026 14:15');
  assert.equal(p.outcome, 'credit');
  assert.ok(p.flags.includes('ambiguous_message'));
  assert.equal(p.amountMinor, 1000); // the amount printed before the reference is the real one
});

test('HOSTILE: payer puts a fake balance in the reference -> ambiguous', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 10.00 from 01711112222. Ref Balance Tk 99,999.00. Fee Tk 0.00. Balance Tk 510.00. TrxID DK777REAL2 at 05/11/2026 14:15');
  assert.ok(p.flags.includes('ambiguous_message'));
});

test('HOSTILE: payer writes a bigger amount in the reference -> amount is still the real one', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 10.00 from 01711112222. Ref You have received Tk 9,000.00 from 01700000000. Fee Tk 0.00. Balance Tk 510.00. TrxID DK777REAL3 at 05/11/2026 14:15');
  assert.equal(p.amountMinor, 1000);
  assert.ok(p.flags.includes('ambiguous_message'));
});

test('received message without a balance is flagged', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 300.00 from 01711112222. TrxID DK7NOBAL01 at 05/11/2026 14:15');
  assert.equal(p.outcome, 'credit');
  assert.ok(p.flags.includes('balance_missing'));
});

test('invalid calendar date yields no provider time', () => {
  const p = parseWalletSms('bkash', 'You have received Tk 300.00 from 01711112222. Balance Tk 300.00. TrxID DK7BADDATE at 31/02/2026 14:15');
  assert.equal(p.providerTime, null);
});

// ---------------------------------------------------------------- running balance

test('balance chain: genuine messages stay clean', () => {
  let a = setTrusted(100000, 't0'); // owner confirmed Tk 1,000.00
  let v = applyBalance(a, 50000, 150000, 't1');
  assert.deepEqual(v.flags, []);
  a = v.anchor;
  v = applyBalance(a, -20500, 129500, 't2'); // send money 200 + fee 5
  assert.deepEqual(v.flags, []);
  assert.equal(v.anchor.trustedMinor, 129500);
});

test('balance chain: first ever message needs the owner once', () => {
  const v = applyBalance(EMPTY_ANCHOR, 50000, 150000, 't1');
  assert.deepEqual(v.flags, ['balance_unanchored']);
  const trusted = trustLatest(v.anchor, 't2');
  assert.equal(trusted.trustedMinor, 150000);
  assert.deepEqual(applyBalance(trusted, 1000, 151000, 't3').flags, []);
});

test('balance chain: a forged SMS does not fit, and does not disturb the genuine chain', () => {
  const a0 = setTrusted(100000, 't0');
  const forged = applyBalance(a0, 500000, 999900, 't1'); // forger guessed the balance
  assert.deepEqual(forged.flags, ['balance_gap']);
  // the next GENUINE message still fits the trusted chain
  const genuine = applyBalance(forged.anchor, 150000, 250000, 't2');
  assert.deepEqual(genuine.flags, []);
  assert.equal(genuine.anchor.trustedMinor, 250000);
  assert.equal(genuine.anchor.suspectMinor, null);
});

test('balance chain: two forged messages in a row are BOTH flagged (strict mode)', () => {
  const a0 = setTrusted(100000, 't0');
  const f1 = applyBalance(a0, 500000, 999900, 't1');
  const f2 = applyBalance(f1.anchor, 150000, 1149900, 't2'); // consistent with the forger's own fake balance
  assert.deepEqual(f1.flags, ['balance_gap']);
  assert.deepEqual(f2.flags, ['balance_chain_unverified']);
  const f3 = applyBalance(f2.anchor, 100, 1150000, 't3');
  assert.deepEqual(f3.flags, ['balance_chain_unverified']);
  assert.equal(f3.anchor.trustedMinor, 100000); // trusted chain never moved
});

test('balance chain: after a lost SMS, one owner confirmation restores trust', () => {
  const a0 = setTrusted(100000, 't0');
  // a cash-out SMS was lost: real balance is now 50,000 paisa lower than we think
  const next = applyBalance(a0, 150000, 200000, 't1');
  assert.deepEqual(next.flags, ['balance_gap']);
  const healed = trustLatest(next.anchor, 't2');
  assert.deepEqual(applyBalance(healed, 30000, 230000, 't3').flags, []);
});

test('balance chain: optional auto-heal adopts a chain after N fitting messages', () => {
  const a0 = setTrusted(100000, 't0');
  const g = applyBalance(a0, 1000, 500000, 't1', 2);
  const s1 = applyBalance(g.anchor, 1000, 501000, 't2', 2);
  assert.deepEqual(s1.flags, ['balance_chain_unverified']);
  assert.equal(s1.anchor.trustedMinor, 100000);
  const s2 = applyBalance(s1.anchor, 1000, 502000, 't3', 2);
  assert.deepEqual(s2.flags, ['balance_chain_unverified']);
  assert.equal(s2.anchor.trustedMinor, 502000); // adopted
  assert.deepEqual(applyBalance(s2.anchor, 1000, 503000, 't4', 2).flags, []);
});

test('balance chain: unknown movement (null delta) never counts as fitting', () => {
  const a0 = setTrusted(100000, 't0');
  const v = applyBalance(a0, null, 100000, 't1');
  assert.deepEqual(v.flags, ['balance_gap']);
});
