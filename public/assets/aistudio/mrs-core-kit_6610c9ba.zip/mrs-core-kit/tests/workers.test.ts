import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { ModelRequest } from '../server/mrs-core/core.ts';
import { listDeliverables, ownerDone, ownerUpload, release, requeue, runDueJobs, runJob } from '../server/mrs-core/fulfilment/engine.ts';
import { ModelError } from '../server/mrs-core/fulfilment/gemini.ts';
import { docxToText } from '../server/mrs-core/fulfilment/render/docx.ts';
import { parseDelimited } from '../server/mrs-core/fulfilment/render/text.ts';
import { xlsxToRows } from '../server/mrs-core/fulfilment/render/xlsx.ts';
import { gravatarHash } from '../server/mrs-core/fulfilment/workers/lookups.ts';
import { listZip } from '../server/mrs-core/fulfilment/render/zip.ts';
import { addIntakeFile, createOrder, setQuote } from '../server/mrs-core/orders/service.ts';
import { ingestSms, trustBalance } from '../server/mrs-core/payments/ledger.ts';
import { afterIngest } from '../server/mrs-core/payments/service.ts';
import { C } from '../server/mrs-core/store/store.ts';
import type { Deliverable, Invoice, Job, Order } from '../server/mrs-core/types.ts';
import { HttpError } from '../server/mrs-core/util.ts';
import { ScriptedModel, bkashSms, makeRig } from './helpers.ts';
import type { TestRig } from './helpers.ts';

let n = 0;
async function place(rig: TestRig, serviceId: string, intake: Record<string, string>, extra: Record<string, unknown> = {}): Promise<{ order: Order; clientId: string; invoice: Invoice | null }> {
  n += 1;
  const r = await createOrder(rig.core, { serviceId, details: 'Please do this for me.', clientName: `Worker Client ${n}`, clientEmail: `wc${n}@example.org`, intake, ...extra }, null, '203.0.113.7');
  return { order: r.order, clientId: r.client.clientId, invoice: r.invoice };
}
const getOrder = async (rig: TestRig, id: string): Promise<Order> => (await rig.store.get<Order>(C.orders, id)) as Order;
const getJob = async (rig: TestRig, id: string): Promise<Job> => (await rig.store.get<Job>(C.jobs, id)) as Job;
const failedBlocks = (j: Job | null): string[] => (j?.qa ?? []).filter((q) => q.severity === 'block' && !q.passed).map((q) => q.id).sort();
const bytesOf = async (rig: TestRig, d: Deliverable): Promise<Buffer> => (await rig.store.getBlob(`deliv_${d.id}`)) as Buffer;
const promptOf = (req: ModelRequest): string => req.parts.map((p) => p.text ?? '').join('\n');

async function payBkash(rig: TestRig, invoice: Invoice, taka: string, balance: string, trx: string): Promise<void> {
  const res = await ingestSms(rig.core, { senderId: 'bKash', text: bkashSms({ amount: taka, balance, trx, ref: invoice.paymentReferenceCode }) });
  assert.equal(res.status, 'new');
  if (res.entry) await afterIngest(rig.core, res.entry);
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
}

// ================================================================ S-MRS-02 proofreading (quote service, pay after delivery)

const DOC = `# Install guide

The servr listens on port 8080 and handle 1,200 requests per second.

Run \`npm  install\` first, then start it:

\`\`\`bash
node server.js   --port 8080
\`\`\`

See https://example.com/docs for more informations.`;

test('proofreading: quote -> owner prices it -> language fixed, substance proven unchanged', async () => {
  const model = new ScriptedModel((req) => {
    const text = promptOf(req);
    assert.match(text, /\u27E6CODE1\u27E7/, 'code was replaced by tokens before the model saw it');
    assert.ok(!text.includes('node server.js'), 'the model never sees the code itself');
    const body = /<<<DOCUMENT>>>\n([\s\S]*)\n<<<\/DOCUMENT>>>/.exec(text)?.[1] ?? '';
    return `${body.replace('servr', 'server').replace('handle 1,200', 'handles 1,200').replace('informations', 'information')}\n=====CHANGES=====\n- servr -> server (spelling)\n- handle -> handles (agreement)`;
  });
  const rig = makeRig({ model });
  const { order } = await place(rig, 'technical-writing-proofreading', { task: 'Proofread my document', source_text: DOC, audience: 'developers' });
  assert.equal(order.state, 'quote_pending', 'a quote service has no price until the owner sets one');
  assert.equal(order.jobId, undefined);
  assert.ok(rig.alerts.some((a) => a.title === 'New order needs a price'));

  const quoted = await setQuote(rig.core, order.orderId, 80, 'Two hours at $40.');
  assert.equal(quoted.invoice.totalMinor, 8000);
  assert.equal(quoted.invoice.depositMinor, 0, 'new clients pay this service after delivery');
  assert.equal(quoted.order.state, 'in_progress');

  const j = await runJob(rig.core, quoted.order.jobId as string);
  assert.equal(j?.state, 'owner_review');
  assert.deepEqual(failedBlocks(j), []);
  const files = await listDeliverables(rig.core, order.orderId);
  const md = files.find((f) => f.fileName.endsWith('.md')) as Deliverable;
  const out = (await bytesOf(rig, md)).toString('utf8');
  assert.match(out, /The server listens on port 8080 and handles 1,200 requests/);
  assert.ok(out.includes('node server.js   --port 8080'), 'code block restored exactly, spacing included');
  assert.ok(out.includes('`npm  install`'));
  assert.match(docxToText(await bytesOf(rig, files.find((f) => f.fileName.endsWith('.docx')) as Deliverable)), /more information\./);
});

test('proofreading: a model that changes a figure or drops code is blocked', async () => {
  const model = new ScriptedModel((req) => {
    const body = /<<<DOCUMENT>>>\n([\s\S]*)\n<<<\/DOCUMENT>>>/.exec(promptOf(req))?.[1] ?? '';
    return body.replace('1,200', '12,000').replace('\u27E6CODE2\u27E7', '') + '\n=====CHANGES=====\n- tidied';
  });
  const rig = makeRig({ model });
  const { order } = await place(rig, 'technical-writing-proofreading', { task: 'Proofread my document', source_text: DOC, audience: 'developers' });
  const q = await setQuote(rig.core, order.orderId, 40, '');
  const j = await runJob(rig.core, q.order.jobId as string);
  assert.deepEqual(failedBlocks(j), ['proof_code', 'proof_numbers']);
  await assert.rejects(() => release(rig.core, j?.id as string, 'owner', false), (e: unknown) => e instanceof HttpError && e.code === 'checks_failed');
});

test('writing: outline then document; an invented link or a skipped section is blocked', async () => {
  const source = 'The Acme API has two endpoints. GET /v1/items lists items. POST /v1/items creates an item and needs an API key in the X-Api-Key header. Rate limit: 60 requests per minute. Documentation lives at https://acme.example.com/docs. '.repeat(2);
  let draft = '';
  const model = new ScriptedModel((req) => {
    if (req.schema) return JSON.stringify({ title: 'Acme API Quick Start', sections: [{ heading: 'Authentication', purpose: 'how to send the key' }, { heading: 'Endpoints', purpose: 'the two endpoints' }, { heading: 'Rate limits', purpose: 'the limit' }], questionsForClient: ['What does the API return on error?'] });
    return draft;
  });
  const good = `# Acme API Quick Start\n\n## Authentication\n\nSend your API key in the X-Api-Key header with every POST request. ${'Keep the key private. '.repeat(12)}\n\n## Endpoints\n\n1. GET /v1/items lists items.\n2. POST /v1/items creates an item.\n\n${'Each endpoint accepts and returns JSON. '.repeat(10)}\n\n## Rate limits\n\nThe limit is 60 requests per minute. ${'Space requests evenly. '.repeat(10)} See https://acme.example.com/docs.\n`;
  const rig = makeRig({ model });
  const { order } = await place(rig, 'technical-writing-proofreading', { task: 'Write a new document', source_text: source, audience: 'integrators' });
  const q = await setQuote(rig.core, order.orderId, 120, '');

  draft = good.replace('https://acme.example.com/docs', 'https://acme.example.com/docs and https://status.acme-api.io').replace('## Rate limits', '## Limits');
  let j = await runJob(rig.core, q.order.jobId as string);
  assert.deepEqual(failedBlocks(j), ['doc_links', 'doc_sections']);

  draft = good;
  await requeue(rig.core, j?.id as string);
  j = await runJob(rig.core, j?.id as string);
  assert.deepEqual(failedBlocks(j), []);
  assert.deepEqual(j?.questionsForClient, ['What does the API return on error?']);
  assert.equal((await listDeliverables(rig.core, order.orderId)).filter((f) => !f.released).length, 3, 'pdf + docx + md, the earlier draft\'s files were replaced');
});

// ================================================================ S-MRS-11 data entry

const CSV = 'Full Name,E-mail,Joined,Amount\n  alice   SMITH ,Alice@Example.COM,05/03/2024,"$1,200.50"\nbob jones,bob@example,31/02/2024,twelve\n,,,\nALICE smith,alice@example.com,2024-03-05,1200.50\n';
const PLAN = {
  headerRow: true,
  dateOrder: 'DMY',
  dedupeKey: ['Email'],
  notes: ['Names converted to title case.'],
  questionsForClient: [],
  columns: [
    { name: 'Name', from: ['Full Name'], join: null, transforms: ['collapse_spaces', 'title'], type: 'text', required: true },
    { name: 'Email', from: ['E-mail'], join: null, transforms: ['trim'], type: 'email', required: true },
    { name: 'Joined', from: ['Joined'], join: null, transforms: [], type: 'date', required: false },
    { name: 'Amount', from: ['Amount'], join: null, transforms: ['remove_currency'], type: 'number', required: false },
  ],
};

test('data entry: the model only proposes the plan; code transforms every row and accounts for each', async () => {
  const model = new ScriptedModel((req) => {
    const text = promptOf(req);
    assert.match(text, /<<<SAMPLE>>>/);
    assert.match(req.system, /You do not edit the data yourself/);
    return JSON.stringify(PLAN);
  });
  const rig = makeRig({ model });
  const { order, clientId } = await place(rig, 'data-entry', { target_columns: 'Name, Email, Joined, Amount', rules: 'Dates as ISO. Remove duplicate emails.' });
  assert.equal(order.state, 'quote_pending');
  await addIntakeFile(rig.core, order.orderId, clientId, 'source_file', 'people.csv', Buffer.from(CSV, 'utf8'));
  const q = await setQuote(rig.core, order.orderId, 10, '');
  assert.equal(q.order.state, 'in_progress');

  const j = await runJob(rig.core, q.order.jobId as string);
  assert.equal(j?.state, 'owner_review');
  assert.deepEqual(failedBlocks(j), []);
  assert.equal(model.calls.length, 1, 'one model call, whatever the number of rows');
  assert.match(j?.summary ?? '', /4 rows in, 2 out \(1 duplicates, 1 empty\); 3 cell\(s\) flagged/);

  const files = await listDeliverables(rig.core, order.orderId);
  const csvOut = parseDelimited((await bytesOf(rig, files.find((f) => f.fileName.endsWith('.csv')) as Deliverable)).toString('utf8'));
  assert.deepEqual(csvOut, [['Name', 'Email', 'Joined', 'Amount'], ['Alice Smith', 'alice@example.com', '2024-03-05', '1200.50'], ['Bob Jones', 'bob@example', '31/02/2024', 'twelve']]);
  const xlsx = xlsxToRows(await bytesOf(rig, files.find((f) => f.fileName.endsWith('.xlsx')) as Deliverable));
  assert.deepEqual(xlsx, csvOut, 'Excel and CSV carry identical data');
  const json = JSON.parse((await bytesOf(rig, files.find((f) => f.fileName.endsWith('.json')) as Deliverable)).toString('utf8')) as Record<string, string>[];
  assert.deepEqual(json[0], { Name: 'Alice Smith', Email: 'alice@example.com', Joined: '2024-03-05', Amount: '1200.50' });
  assert.ok((j?.qa ?? []).find((c) => c.id === 'data_dates' && !c.passed), 'the ambiguous 05/03 date is pointed out');
});

test('data entry: a plan naming a column that does not exist is blocked, not obeyed', async () => {
  const model = new ScriptedModel(() => JSON.stringify({ ...PLAN, columns: [{ name: 'Name', from: ['Customer'], join: null, transforms: [], type: 'text', required: true }] }));
  const rig = makeRig({ model });
  const { order, clientId } = await place(rig, 'data-entry', { target_columns: 'Name' });
  await addIntakeFile(rig.core, order.orderId, clientId, 'source_file', 'people.csv', Buffer.from(CSV, 'utf8'));
  const q = await setQuote(rig.core, order.orderId, 10, '');
  const j = await runJob(rig.core, q.order.jobId as string);
  assert.deepEqual(failedBlocks(j), ['data_plan']);
});

test('data entry: a scan is transcribed by the model and can never release without a person', async () => {
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.from('pretend image')]);
  const model = new ScriptedModel((req) => {
    if (req.parts.some((p) => p.inlineData)) return JSON.stringify({ header: ['Name', 'Qty'], rows: [['Rice', '5'], ['Dal', '2']], uncertain: [{ row: 2, column: 'Qty', note: 'smudged' }] });
    return JSON.stringify({ headerRow: true, dateOrder: 'DMY', dedupeKey: [], notes: [], questionsForClient: [], columns: [{ name: 'Name', from: ['Name'], join: null, transforms: ['trim'], type: 'text', required: true }, { name: 'Qty', from: ['Qty'], join: null, transforms: [], type: 'number', required: true }] });
  });
  const rig = makeRig({ model });
  const { saveFulfilmentSettings } = await import('../server/mrs-core/fulfilment/engine.ts');
  await saveFulfilmentSettings(rig.core, { autoRelease: { 'S-MRS-11': true } });
  const { order, clientId } = await place(rig, 'data-entry', { target_columns: 'Name, Qty' });
  await addIntakeFile(rig.core, order.orderId, clientId, 'source_file', 'receipt.png', png);
  const q = await setQuote(rig.core, order.orderId, 10, '');
  const j = await runJob(rig.core, q.order.jobId as string);
  assert.equal(j?.state, 'owner_review', 'auto-release is on, but a scan still waits for a person');
  assert.deepEqual(failedBlocks(j), ['data_scan']);
  const released = await release(rig.core, j?.id as string, 'owner', true); // the owner compared it and releases anyway
  assert.equal(released.state, 'released');
});

// ================================================================ S-MRS-12 learning

const SYLLABUS = { title: 'Git Basics', objectives: [{ id: 'O1', text: 'Create commits' }, { id: 'O2', text: 'Use branches' }], lessons: [{ n: 1, title: 'Commits', objectiveIds: ['O1'], minutes: 45, outline: ['a', 'b', 'c'] }, { n: 2, title: 'Branches', objectiveIds: ['O2'], minutes: 45, outline: ['a', 'b', 'c'] }] };
const lessonBody = (num: number, obj: string, answerIndex = 1): Record<string, unknown> => ({
  n: num,
  contentMarkdown: `A commit records a snapshot of your work. ${'It has an author, a message and a parent. '.repeat(8)}\n\n\`\`\`bash\ngit commit -m "message"\n\`\`\`\n`,
  exercises: [{ prompt: 'Make a commit with a message.', solution: 'Run git add . and then git commit -m "first".', objectiveIds: [obj] }],
  quiz: [{ question: 'Which command records a snapshot?', options: ['git push', 'git commit', 'git pull', 'git clone'], answerIndex, explanation: 'commit records it.', objectiveIds: [obj] }],
});

test('learning: every objective must be taught AND tested; malformed quizzes are blocked', async () => {
  let lessons: Record<string, unknown>[] = [lessonBody(1, 'O1'), lessonBody(2, 'O2')];
  const model = new ScriptedModel((req) => (/Design a course syllabus/.test(req.system) ? JSON.stringify(SYLLABUS) : JSON.stringify({ lessons })));
  const rig = makeRig({ model });
  const { order } = await place(rig, 'online-learning-resources', { topic: 'Git', level: 'Beginner', outcomes: 'Commit and branch', length: '2 lessons of 45 minutes' });
  const q = await setQuote(rig.core, order.orderId, 60, '');
  let j = await runJob(rig.core, q.order.jobId as string);
  assert.deepEqual(failedBlocks(j), []);
  const files = await listDeliverables(rig.core, order.orderId);
  assert.deepEqual(files.map((f) => f.fileName).sort(), ['Git-Basics-answer-key.docx', 'Git-Basics-answer-key.pdf', 'Git-Basics-markdown.zip', 'Git-Basics.docx', 'Git-Basics.pdf']);
  const zipNames = listZip(await bytesOf(rig, files.find((f) => f.fileName.endsWith('.zip')) as Deliverable)).map((e) => e.name);
  assert.deepEqual(zipNames, ['00-overview.md', 'lesson-01.md', 'lesson-02.md', 'answer-key.md']);
  const learner = docxToText(await bytesOf(rig, files.find((f) => f.fileName === 'Git-Basics.docx') as Deliverable));
  const key = docxToText(await bytesOf(rig, files.find((f) => f.fileName === 'Git-Basics-answer-key.docx') as Deliverable));
  assert.ok(!/Answer: B/.test(learner), 'the learner book has no answers');
  assert.match(key, /Answer: B/);

  // objective O2 is never assessed, and one quiz has an out-of-range answer
  lessons = [lessonBody(1, 'O1'), lessonBody(2, 'O1', 7)];
  await requeue(rig.core, j?.id as string);
  j = await runJob(rig.core, j?.id as string);
  assert.deepEqual(failedBlocks(j), ['course_objectives_assessed', 'course_quiz']);
});

// ================================================================ S-GRV-01 gravatar audit (prepaid: nothing starts before verified payment)

test('gravatar audit: PREPAID service starts only after the payment is verified; facts are looked up live', async () => {
  const seen: string[] = [];
  const karim = gravatarHash('karim@example.org'); // this address has a profile; the other does not
  const fetchFn = async (url: string): Promise<Response> => {
    seen.push(url);
    if (url.startsWith('https://api.gravatar.com/v3/profiles/')) {
      return url.endsWith(karim) ? jsonResponse({ display_name: 'Karim Ahmed', profile_url: 'https://gravatar.com/karimahmed', job_title: 'Designer', verified_accounts: [{ service_label: 'GitHub', url: 'https://github.com/karim' }] }) : jsonResponse({ error: 'Profile not found' }, 404);
    }
    if (url.startsWith('https://gravatar.com/avatar/')) return new Response('', { status: url.includes(karim) ? 200 : 404 });
    throw new Error('unexpected request to ' + url);
  };
  let advice = '### Findings\n\nOnly one of the two addresses has a profile and an avatar. The second address shows a default picture everywhere.\n\n### Recommended profile\n\nDisplay name: Karim Ahmed. Bio: Product designer focused on clear interfaces.\n\n### Step by step\n\n1. Add the second address to the same Gravatar account.\n2. Set the avatar for it.';
  const model = new ScriptedModel((req) => {
    assert.match(promptOf(req), /\| karim@example\.org \| yes \| yes \| Karim Ahmed \| GitHub \|/, 'the model is handed the measured table');
    assert.match(promptOf(req), /\| k\.ahmed@example\.net \| no \| no \| - \| - \|/);
    return advice;
  });
  const rig = makeRig({ model, fetchFn });
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { order, invoice } = await place(rig, 'gravatar-identity-consultation', { emails: 'Karim@Example.org\nk.ahmed@example.net\nnot-an-email', role: 'Product designer' });
  assert.equal(order.state, 'awaiting_payment', 'prepaid: no work before payment');
  assert.equal(order.jobId, undefined);
  assert.equal((await runDueJobs(rig.core, 1000)).ran, 0);
  assert.equal(seen.length, 0, 'nothing was looked up or generated for an unpaid order');

  await payBkash(rig, invoice as Invoice, '2,500.00', '2,500.00', 'GRVPAY0001');
  const paid = await getOrder(rig, order.orderId);
  assert.equal(paid.state, 'in_progress');
  assert.ok(paid.jobId);

  let j = await runJob(rig.core, paid.jobId as string);
  assert.equal(j?.state, 'owner_review');
  assert.deepEqual(failedBlocks(j), []);
  assert.equal(seen.filter((u) => u.startsWith('https://api.gravatar.com/v3/profiles/')).length, 2, 'two valid addresses, two lookups');
  assert.equal(j?.lastError, undefined);
  assert.ok(seen.every((u) => /^https:\/\/(api\.gravatar\.com|gravatar\.com)\//.test(u)), 'requests go only to Gravatar');
  assert.ok(seen.every((u) => !u.includes('example.org') && !u.includes('@')), 'addresses are sent as hashes, never in clear');

  // advice that invents a link is blocked
  advice += '\n\nVerify at https://gravatar-verify.example.io/now';
  await requeue(rig.core, j?.id as string);
  j = await runJob(rig.core, j?.id as string);
  assert.equal(j?.state, 'owner_review', 'the second run completed (this is not a stale result)');
  assert.deepEqual(failedBlocks(j), ['advice_links']);
});

// ================================================================ S-MRS-03 website (deposit, then owner's hands-on step, then re-measure)

function psi(perf: number, lcp: string): unknown {
  return { lighthouseResult: { categories: { performance: { score: perf }, seo: { score: 0.9 }, accessibility: { score: 0.8 }, 'best-practices': { score: 1 } }, audits: { 'largest-contentful-paint': { title: 'Largest Contentful Paint', displayValue: lcp, score: perf }, 'unused-javascript': { title: 'Reduce unused JavaScript', score: 0.2, scoreDisplayMode: 'metricSavings', displayValue: 'Est savings of 300 KiB', details: { overallSavingsMs: 1200 } }, 'meta-description': { title: 'Document does not have a meta description', score: 0 } } } };
}

test('website: 50% deposit starts the work; audit -> owner applies fixes -> measured again -> report', async () => {
  let perf = 0.38;
  let lcp = '5.4 s';
  const urls: string[] = [];
  const fetchFn = async (url: string): Promise<Response> => {
    urls.push(url);
    if (url.startsWith('https://www.googleapis.com/pagespeedonline/v5/runPagespeed?')) return jsonResponse(psi(perf, lcp));
    throw new Error('unexpected request to ' + url);
  };
  const model = new ScriptedModel((req) => (/completion report/.test(req.system) ? '### Work completed\n\n- Installed a caching plugin and deferred unused JavaScript.\n\n### Results\n\nMobile performance rose and Largest Contentful Paint fell.\n\n### Keeping it fast\n\n- Re-test after each plugin update and keep images compressed below the fold.' : '### Diagnosis\n\nThe page is slow mainly because of unused JavaScript.\n\n### Fix plan\n\n1. Defer unused JavaScript.\n2. Add a meta description.\n\n### Risks\n\nTake a full backup first so any change can be rolled back quickly and safely.'));
  const rig = makeRig({ model, fetchFn });
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { order } = await place(rig, 'website-management', { site_url: 'https://shop.example.com/', platform: 'WordPress', issues: 'Very slow on phones', backup_ok: 'Yes' });
  const q = await setQuote(rig.core, order.orderId, 60, '');
  assert.equal(q.invoice.depositMinor, 3000, '50% deposit');
  assert.equal(q.order.state, 'awaiting_payment');

  await payBkash(rig, q.invoice, '3,000.00', '3,000.00', 'WEBDEP0001');
  let o = await getOrder(rig, order.orderId);
  assert.equal(o.state, 'in_progress', 'deposit met, work starts');
  assert.equal(((await rig.store.get<Invoice>(C.invoices, q.invoice.invoiceId)) as Invoice).status, 'partially_paid');

  let j = (await runJob(rig.core, o.jobId as string)) as Job;
  assert.equal(j.state, 'owner_task', 'the fixes need a person with admin access');
  assert.match(j.ownerTasks.join('\n'), /Take a full backup/);
  assert.equal(urls.length, 2);
  const u = new URL(urls[0] as string);
  assert.equal(u.host, 'www.googleapis.com');
  assert.equal(u.searchParams.get('url'), 'https://shop.example.com/', 'the client\'s site is only ever named to Google\'s tester, never fetched by this server');

  await assert.rejects(() => ownerDone(rig.core, j.id, 'ok'), (e: unknown) => e instanceof HttpError && e.code === 'notes_required');
  perf = 0.91;
  lcp = '1.6 s';
  j = await ownerDone(rig.core, j.id, 'Installed a caching plugin and deferred unused JavaScript.');
  assert.equal(j.state, 'owner_review');
  assert.deepEqual(failedBlocks(j), []);
  assert.match(j.summary ?? '', /mobile 38 -> 91/);

  await release(rig.core, j.id, 'owner', false);
  o = await getOrder(rig, order.orderId);
  assert.equal(o.state, 'delivered');
  assert.equal(o.deliverablesLocked, false, 'this service is not lockable: the report is available, the balance is simply due');
  const report = (await listDeliverables(rig.core, order.orderId)).find((f) => f.fileName.endsWith('-report.docx')) as Deliverable;
  const text = docxToText(await bytesOf(rig, report));
  assert.match(text, /Performance\t38\t91\t\+53/);
  assert.match(text, /Largest Contentful Paint now: 1\.6 s \(was 5\.4 s\)/);
});

// ================================================================ S-MRS-07 DNS

function doh(records: Record<string, string[]>) {
  return async (url: string): Promise<Response> => {
    const u = new URL(url);
    assert.equal(u.host, 'dns.google');
    const key = `${u.searchParams.get('name')}|${u.searchParams.get('type')}`;
    const type = { A: 1, NS: 2, CNAME: 5, MX: 15, TXT: 16, AAAA: 28 }[u.searchParams.get('type') ?? 'A'];
    return jsonResponse({ Status: 0, Answer: (records[key] ?? []).map((data) => ({ type, data })) });
  };
}

test('DNS: faults are found in live records; "done" is only accepted when DNS actually changed', async () => {
  const records: Record<string, string[]> = { 'acme-shop.com|NS': ['ada.ns.cloudflare.com.', 'bob.ns.cloudflare.com.'], 'acme-shop.com|A': ['203.0.113.9'], 'acme-shop.com|MX': ['10 mx.zoho.com.'], 'acme-shop.com|TXT': ['v=spf1 include:zoho.com ~all', 'v=spf1 a mx ~all'] };
  const model = new ScriptedModel((req) => {
    assert.match(promptOf(req), /MEASURED FACTS/);
    return /completion report/.test(req.system) ? '### Work completed\n\n- Merged the two SPF records into one and added a DMARC record.\n\n### Verified\n\nPublic DNS now shows a single SPF record and a DMARC record for the domain.\n\n### What to expect\n\nChanges are usually visible everywhere within an hour.' : '### Current state\n\nThe domain publishes two SPF records and no DMARC record, so mail authentication fails.\n\n### Changes needed\n\n1. Merge the SPF records into one.\n2. Add a DMARC record.\n\n### How we will verify\n\nSPF and DMARC will be read again from public DNS.';
  });
  const rig = makeRig({ model, fetchFn: (url) => doh(records)(url) });
  const { order } = await place(rig, 'web-setup', { domain: 'acme-shop.com', goal: 'Business e-mail on my domain', email_provider: 'Zoho Mail' });
  const q = await setQuote(rig.core, order.orderId, 18, '');
  assert.equal(q.invoice.depositMinor, 900);
  // owner confirms the deposit by hand in this test
  const { submitClaim, ownerConfirm } = await import('../server/mrs-core/payments/service.ts');
  const claim = await submitClaim(rig.core, { invoiceId: q.invoice.invoiceId, methodId: 'payoneer', transactionId: 'PYNDNS001', amount: 9, currency: 'USD' }, order.clientId);
  await ownerConfirm(rig.core, claim.payment.id, { action: 'RECEIVED' });

  const o = await getOrder(rig, order.orderId);
  let j = (await runJob(rig.core, o.jobId as string)) as Job;
  assert.equal(j.state, 'owner_task');
  assert.match(j.summary ?? '', /DNS at Cloudflare; 2 fault\(s\) found/);
  const plan = docxToText(await bytesOf(rig, (await listDeliverables(rig.core, order.orderId)).find((f) => f.fileName.endsWith('.docx')) as Deliverable));
  assert.match(plan, /2 SPF records are published/);
  assert.match(plan, /No DMARC record/);

  // owner says it is done, but nothing changed in DNS
  j = await ownerDone(rig.core, j.id, 'Merged SPF into one record and added DMARC.');
  assert.deepEqual(failedBlocks(j), ['dns_changed']);
  await assert.rejects(() => release(rig.core, j.id, 'owner', false), (e: unknown) => e instanceof HttpError && e.code === 'checks_failed');

  // now the change is really live
  records['acme-shop.com|TXT'] = ['v=spf1 include:zoho.com ~all'];
  records['_dmarc.acme-shop.com|TXT'] = ['v=DMARC1; p=none; rua=mailto:dmarc@acme-shop.com'];
  await requeue(rig.core, j.id);
  j = (await runJob(rig.core, j.id)) as Job;
  assert.deepEqual(failedBlocks(j), []);
  assert.match(j.summary ?? '', /2 record set\(s\) changed; 0 fault\(s\) remain/);
});

// ================================================================ pack services

const section = (key: string, markdown: string): { key: string; markdown: string } => ({ key, markdown });
const filler = (s: string): string => `${s} ${'This part is written out in enough detail to be useful. '.repeat(2)}`;

test('app store listing: character limits and store rules are enforced by code', async () => {
  const listing = (title: string): unknown => ({
    sections: [section('listing', filler('Texts below.')), section('data_safety', filler('| Data | Purpose |\n|---|---|\n| Email | Account |')), section('rating', filler('Everyone.')), section('checklist', filler('Signed AAB, icon, screenshots.'))],
    fields: [{ name: 'play_title', value: title }, { name: 'play_short', value: 'Track your daily water intake with simple reminders.' }, { name: 'play_full', value: 'AquaLog helps you log water and reminds you to drink through the day.' }],
    questionsForClient: [],
  });
  let title = 'AquaLog - The Best Free Water Tracker App';
  const model = new ScriptedModel(() => JSON.stringify(listing(title)));
  const rig = makeRig({ model });
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { order, invoice } = await place(rig, 'app-store-publishing', { store: 'Google Play', app_name: 'AquaLog', what_it_does: 'Logs water intake and reminds you to drink.', category: 'Health', audience: 'Adults 18+', data_collected: 'Email for account', privacy_policy_url: 'https://aqualog.example.com/privacy' });
  assert.equal(order.state, 'awaiting_payment');
  await payBkash(rig, invoice as Invoice, '2,500.00', '2,500.00', 'APPPAY0001');
  const o = await getOrder(rig, order.orderId);
  let j = (await runJob(rig.core, o.jobId as string)) as Job;
  assert.equal(j.state, 'owner_task');
  assert.deepEqual(failedBlocks(j), ['play_title', 'store_claims'], '41 characters, and "Best" / "Free" in a title');

  title = 'AquaLog: Water Tracker';
  await requeue(rig.core, j.id);
  j = (await runJob(rig.core, j.id)) as Job;
  assert.deepEqual(failedBlocks(j), []);
  assert.match(j.ownerTasks.join('\n'), /never ask for their password/);
});

test('IT support: destructive instructions to the client are blocked; the report comes only from the technician\'s notes', async () => {
  let before = 'Save your work and close private windows.';
  let report = '## What was wrong\n\nA faulty display driver caused the freezes.\n\n## What was done\n\n- Rolled back the display driver.\n- Created a restore point.\n\n## Keeping it healthy\n\n- Install driver updates from the manufacturer only, and restart once a week.';
  const model = new ScriptedModel((req) => (/hand-over document/.test(req.system) ? JSON.stringify({ markdown: report }) : JSON.stringify({ sections: [section('understanding', filler('The PC freezes.')), section('causes', filler('Driver, disk, heat.')), section('before', filler(before)), section('plan', filler('Check event log, then drivers.')), section('safety', filler('You can end the session at any time.'))], fields: [], questionsForClient: [] })));
  const rig = makeRig({ model });
  const { order } = await place(rig, 'it-support-troubleshooting', { system: 'Windows 11', symptom: 'PC freezes after 10 minutes', remote_tool: 'AnyDesk', availability: 'Weekdays 6pm BST' });
  const q = await setQuote(rig.core, order.orderId, 25, '');
  const { submitClaim, ownerConfirm } = await import('../server/mrs-core/payments/service.ts');
  await ownerConfirm(rig.core, (await submitClaim(rig.core, { invoiceId: q.invoice.invoiceId, methodId: 'skrill', transactionId: 'SKITS00001', amount: 25, currency: 'USD' }, order.clientId)).payment.id, { action: 'RECEIVED' });
  const o = await getOrder(rig, order.orderId);

  before = 'Open a terminal and run format C: to start clean, and disable your antivirus.';
  let j = (await runJob(rig.core, o.jobId as string)) as Job;
  assert.deepEqual(failedBlocks(j), ['it_safe']);

  before = 'Save your work and close private windows.';
  await requeue(rig.core, j.id);
  j = (await runJob(rig.core, j.id)) as Job;
  assert.equal(j.state, 'owner_task');
  assert.deepEqual(failedBlocks(j), []);

  // after the session: a report that states a figure the technician never gave is blocked
  report += '\n\nFreezes dropped by 95% over 30 days.';
  j = await ownerDone(rig.core, j.id, 'Cause: faulty display driver. Rolled back the driver and created a restore point.');
  assert.deepEqual(failedBlocks(j), ['handover_figures']);
});

test('tutoring: graded work is flagged for the tutor; creative brief contrast is computed', async () => {
  const tutor = new ScriptedModel(() => JSON.stringify({ sections: ['goals', 'plan', 'examples', 'practice', 'prep'].map((k) => section(k, filler(k))), fields: [{ name: 'graded_work', value: 'no' }], questionsForClient: [] }));
  const rig = makeRig({ model: tutor });
  const t = await place(rig, 'tutoring', { topic: 'Recursion', level: 'Beginner', goals: 'Please solve my assignment due Friday', availability: 'Sat 10am' });
  const tq = await setQuote(rig.core, t.order.orderId, 16, '');
  const { submitClaim, ownerConfirm } = await import('../server/mrs-core/payments/service.ts');
  await ownerConfirm(rig.core, (await submitClaim(rig.core, { invoiceId: tq.invoice.invoiceId, methodId: 'skrill', transactionId: 'SKTUT00001', amount: 16, currency: 'USD' }, t.order.clientId)).payment.id, { action: 'RECEIVED' });
  const tj = (await runJob(rig.core, (await getOrder(rig, t.order.orderId)).jobId as string)) as Job;
  const integrity = tj.qa.find((c) => c.id === 'tutor_integrity');
  assert.equal(integrity?.passed, false, 'code notices "assignment" even though the model said "no"');
  assert.match(integrity?.detail ?? '', /do not hand over a solution to submit/);

  const brief = (bg: string, fg: string, copy: string): string => JSON.stringify({ sections: [section('objective', filler('A logo for Nodi Tea.')), section('directions', filler('Three directions.')), section('palette', filler('Greens.')), section('type', filler('Inter and Lora.')), section('copy', filler(copy)), section('exports', filler('SVG, PNG.'))], fields: [{ name: 'background_hex', value: bg }, { name: 'text_hex', value: fg }, { name: 'palette_hex', value: `${bg},${fg},#2E7D32` }], questionsForClient: [] });
  let answer = brief('#FFFFFF', '#9E9E9E', 'Nodi Tea — fresh from Sylhet');
  const rig2 = makeRig({ model: new ScriptedModel(() => answer) });
  const g = await place(rig2, 'graphics-design', { item: 'Logo', brand_name: 'Nodi Tea', description: 'A calm tea brand', text_on_design: 'Nodi Tea — Fresh from Sylhet' });
  const gq = await setQuote(rig2.core, g.order.orderId, 30, '');
  let gj = (await runJob(rig2.core, gq.order.jobId as string)) as Job;
  assert.deepEqual(failedBlocks(gj), ['brief_copy'], 'the client wrote "Fresh", the brief says "fresh"');
  assert.match(gj.qa.find((c) => c.id === 'brief_contrast')?.detail ?? '', /2\.68:1/);
  answer = brief('#FFFFFF', '#1B5E20', 'Nodi Tea — Fresh from Sylhet');
  await requeue(rig2.core, gj.id);
  gj = (await runJob(rig2.core, gj.id)) as Job;
  assert.deepEqual(failedBlocks(gj), []);
  assert.equal(gj.qa.find((c) => c.id === 'brief_contrast')?.passed, true);
});

// ================================================================ manual service and failure handling

test('manual service: payment is verified automatically, fulfilment is left to the owner', async () => {
  const rig = makeRig({ model: new ScriptedModel(() => { throw new Error('the model must not be called for a manual service'); }) });
  await trustBalance(rig.core, 'bkash', 0, 'test');
  const { order, invoice } = await place(rig, 'iptv-vip-pass', {}, { planMonths: '1' });
  assert.equal((invoice as Invoice).totalMinor, 1200);
  await payBkash(rig, invoice as Invoice, '1,200.00', '1,200.00', 'MANPAY0001');
  const o = await getOrder(rig, order.orderId);
  assert.equal(o.state, 'in_progress');
  assert.equal(o.jobId, undefined, 'no automatic job is created');
  assert.equal((await runDueJobs(rig.core, 1000)).ran, 0);
  assert.ok(rig.alerts.some((a) => a.title === 'An order is ready for you to fulfil'));

  await assert.rejects(() => ownerUpload(rig.core, order.orderId, 'run.html', 'x', Buffer.from('<script>')), (e: unknown) => e instanceof HttpError && e.code === 'bad_file_type');
  await ownerUpload(rig.core, order.orderId, 'details.txt', 'Your details', Buffer.from('delivered by hand'));
  const after = await getOrder(rig, order.orderId);
  await release(rig.core, after.jobId as string, 'owner', false);
  assert.equal((await getOrder(rig, order.orderId)).state, 'delivered');
});

test('model outage: temporary errors back off and retry; permanent ones tell the owner; nothing is faked', async () => {
  let mode: 'down' | 'blocked' = 'down';
  const model = new ScriptedModel(() => {
    throw mode === 'down' ? new ModelError('unavailable', 'service unavailable', true) : new ModelError('blocked', 'refused', false);
  });
  const rig = makeRig({ model });
  const { order } = await place(rig, 'ats-cv-resume', { cv_text: 'x'.repeat(300), job_postings: 'y'.repeat(100) });
  let j = (await runJob(rig.core, order.jobId as string)) as Job;
  assert.equal(j.state, 'queued');
  assert.ok(j.notBefore && Date.parse(j.notBefore) > Date.now(), 'a back-off time is set');
  assert.equal((await runDueJobs(rig.core, 1000)).ran, 0, 'not retried before the back-off ends');
  assert.equal((await listDeliverables(rig.core, order.orderId)).length, 0);

  mode = 'blocked';
  await requeue(rig.core, j.id);
  j = (await runJob(rig.core, j.id)) as Job;
  assert.equal(j.state, 'failed');
  assert.ok(rig.alerts.some((a) => a.title === 'Camellia could not finish an order'));
  assert.equal((await getJob(rig, j.id)).lastError, 'refused');
});

test('lookup outage: Gravatar briefly unreachable -> the job waits and retries; it does not fail or guess', async () => {
  let up = false;
  const karim = gravatarHash('karim@example.org');
  const fetchFn = async (url: string): Promise<Response> => {
    if (!up) throw new TypeError('fetch failed: ECONNRESET');
    if (url.startsWith('https://api.gravatar.com/')) return url.endsWith(karim) ? jsonResponse({ display_name: 'Karim Ahmed', profile_url: 'https://gravatar.com/karimahmed' }) : jsonResponse({}, 404);
    return new Response('', { status: 200 });
  };
  const model = new ScriptedModel(() => '### Findings\n\nThe address has a profile and an avatar. Nothing is inconsistent across the listed addresses.\n\n### Step by step\n\n1. Add a job title line to the profile.\n2. Connect one more verified account so the profile is easier to trust.');
  const rig = makeRig({ model, fetchFn });
  const { order, invoice } = await place(rig, 'gravatar-identity-consultation', { emails: 'karim@example.org', role: 'Designer' });
  const { submitClaim, ownerConfirm } = await import('../server/mrs-core/payments/service.ts');
  await ownerConfirm(rig.core, (await submitClaim(rig.core, { invoiceId: (invoice as Invoice).invoiceId, methodId: 'skrill', transactionId: 'SKGRV00009', amount: 25, currency: 'USD' }, order.clientId)).payment.id, { action: 'RECEIVED' });
  const jobId = (await getOrder(rig, order.orderId)).jobId as string;

  let j = (await runJob(rig.core, jobId)) as Job;
  assert.equal(j.state, 'queued', 'a temporary outage is not a failure');
  assert.match(j.lastError ?? '', /could not reach api\.gravatar\.com/);
  assert.ok(j.notBefore && Date.parse(j.notBefore) > Date.now());
  assert.equal(model.calls.length, 0, 'no advice was written without the facts');
  assert.equal((await listDeliverables(rig.core, order.orderId)).length, 0);
  assert.ok(!rig.alerts.some((a) => a.title === 'Camellia could not finish an order'));

  up = true;
  await requeue(rig.core, jobId);
  j = (await runJob(rig.core, jobId)) as Job;
  assert.equal(j.state, 'owner_review');
  assert.deepEqual(failedBlocks(j), []);
});
