/**
 * A small stand-alone server for trying mrs-core on your own computer.
 *
 *   MRS_SESSION_SECRET=... MRS_ADMIN_PASSWORD=... npm run demo
 *
 * Data is kept in ./.mrs-data (set MRS_DATA_DIR to change, or MRS_DATA_DIR=memory
 * to keep nothing). This is NOT how the live site runs: there, mrs-core is installed
 * into the existing Express app with a FirestoreStore.
 */
import express from 'express';
import { FileStore, MemoryStore, installMrsCore } from '../server/mrs-core/index.ts';

const dir = process.env.MRS_DATA_DIR ?? '.mrs-data';
const store = dir === 'memory' ? new MemoryStore() : new FileStore(dir);
const app = express();
installMrsCore(app, { store });
app.get('/', (_req, res) => void res.type('text/plain').send('mrs-core dev server. Try GET /api/health/readiness'));

const port = Number(process.env.PORT ?? 8080);
const server = app.listen(port, process.env.HOST ?? '127.0.0.1', () => {
  console.log(`listening on ${port}`);
});
process.on('SIGTERM', () => server.close(() => process.exit(0)));
