#!/usr/bin/env node
/**
 * Prints a hash of an admin password, for the MRS_ADMIN_PASSWORD_HASH secret.
 * With the hash stored instead of the password, the password itself is nowhere on
 * the server.
 *
 *   node tools/hash-password.mjs
 */
import { randomBytes, scryptSync } from 'node:crypto';
import { createInterface } from 'node:readline/promises';

const rl = createInterface({ input: process.stdin, output: process.stderr });
const password = process.argv[2] ?? (await rl.question('Admin password (12+ characters): '));
rl.close();
if (password.length < 12) {
  console.error('Use at least 12 characters.');
  process.exit(2);
}
const N = 16384;
const r = 8;
const p = 1;
const salt = randomBytes(16);
const hash = scryptSync(password, salt, 32, { N, r, p });
console.log(['scrypt', N, r, p, salt.toString('base64url'), hash.toString('base64url')].join('$'));
