#!/usr/bin/env node
/**
 * Do the tests actually protect anything?
 *
 * For each guarantee below, this script breaks the code on purpose (one small
 * edit), runs the tests that should notice, and expects them to FAIL. Then it
 * restores the file. A guarantee whose sabotage goes unnoticed is reported as
 * "SURVIVED", which means the test suite has a hole there.
 *
 *   node tools/mutation-check.mjs
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = (p) => join(root, 'server/mrs-core', p);

const MUTATIONS = [
  { name: 'a used ledger record can settle a second payment', file: 'payments/service.ts', find: "if (entry.status === 'consumed') throw new HttpError(409, 'ledger_consumed', 'That ledger record already settled another payment.');", replace: '', tests: ['payments'] },
  { name: 'matcher stops treating a flagged ledger record as a hard doubt', file: 'payments/matcher.ts', find: "  'ledger_flagged',\n", replace: '', tests: ['units'] },
  {
    name: 'a flagged ledger record is settled automatically (both guards removed)',
    edits: [
      { file: 'payments/matcher.ts', find: "  'ledger_flagged',\n", replace: '' },
      { file: 'payments/service.ts', find: "if (mode === 'auto' && (entry.status !== 'unmatched' || entry.integrityFlags.length > 0)) throw new HttpError(409, 'ledger_not_clean', 'Ledger record is not eligible for automatic settlement.');", replace: '' },
    ],
    tests: ['payments'],
  },
  { name: 'the invoice is credited with the amount the CLIENT typed', file: 'payments/service.ts', find: 'const creditMinor = toUsdMinor(entry.amountMinor, entry.currency, invoice.rateSnapshot);\n    const credit = applyCredit', replace: 'const creditMinor = toUsdMinor(payment.amountMinor, payment.currency, invoice.rateSnapshot);\n    const credit = applyCredit', tests: ['payments'] },
  { name: 'a claim alone (no ledger record) verifies the payment', file: 'payments/service.ts', find: "  const entry = await findLedgerFor(core, payment);\n  if (!entry) {", replace: "  const entry = (await findLedgerFor(core, payment)) ?? ({ id: 'x', source: 'manual', method: payment.methodCandidates[0], accountId: methodDef(payment.methodCandidates[0]).accountId, trxKey: 'x', trxId: payment.trxId, kind: 'received', amountMinor: payment.amountMinor, currency: payment.currency, senderMask: '', receivedAt: nowIso(), ingestedAt: nowIso(), rawMasked: '', rawHash: '', status: 'unmatched', integrityFlags: [] });\n  if (!entry) {", tests: ['payments'] },
  { name: 'a reversed payment verifies itself again on the next tick', edits: [{ file: 'payments/matcher.ts', find: "  'reversed',\n]);", replace: ']);' }, { file: 'payments/service.ts', find: "status: 'quarantined', integrityFlags: [...new Set([...entry.integrityFlags, 'reversed'])] };", replace: "status: 'unmatched', integrityFlags: entry.integrityFlags };" }], tests: ['payments'] },
  { name: 'a reversal leaves the invoice credited', file: 'payments/service.ts', find: '      paidMinor: Math.max(0, invoice.paidMinor - did.appliedMinor),\n', replace: '      paidMinor: invoice.paidMinor,\n', tests: ['payments'] },
  { name: 'a claim under the wrong wallet is not looked up in the other one', file: 'payments/service.ts', find: "  if (method === 'bkash') return ['bkash', 'nagad'];\n", replace: '', tests: ['payments'] },
  { name: 'an SMS that contradicts a recorded amount goes unreported', file: 'payments/ledger.ts', find: "typeof result.smsAmountMinor === 'number' && result.smsAmountMinor !== entry.amountMinor) {", replace: 'false) {', tests: ['payments'] },
  { name: 'SMS from any sender is treated as a bank message', file: 'payments/parsers/sms.ts', find: "  if (rules.nagad.includes(s)) return 'nagad';\n  return null;", replace: "  if (rules.nagad.includes(s)) return 'nagad';\n  return 'bkash';", tests: ['payments', 'sms-parser'] },
  { name: 'the running-balance check accepts anything', file: 'payments/balance.ts', find: 'const fits = (from: number | null): boolean => from !== null && deltaMinor !== null && from + deltaMinor === balanceMinor;', replace: 'const fits = (from: number | null): boolean => from !== null;', tests: ['payments', 'sms-parser'] },
  { name: 'a replayed SMS is processed again', file: 'payments/ledger.ts', find: "    if (await t.get(C.replay, contentKey)) return { status: 'duplicate' as const };\n", replace: '', tests: ['payments'] },
  { name: 'e-mail is trusted without Gmail\'s DMARC verdict', file: 'payments/parsers/email.ts', find: "if (dmarc !== 'pass') return { ok: false, reason: `dmarc=${dmarc ?? 'missing'}` };", replace: '', tests: ['payments'] },
  { name: 'a look-alike e-mail domain is accepted', file: 'payments/parsers/email.ts', find: "return h === domain || h.endsWith('.' + domain);", replace: 'return h.includes(domain);', tests: ['payments'] },
  { name: 'webhook signatures are not checked', file: 'security/hmac.ts', find: 'const matched = candidates.find((c) => hexEqual(signature, signBody(key, c, tsHeader)));', replace: 'const matched = candidates[0];', tests: ['http'] },
  { name: 'old signed webhooks are accepted forever', file: 'security/hmac.ts', find: 'if (Math.abs(nowMs / 1000 - tsSeconds) > MAX_SKEW_SECONDS) {', replace: 'if (false) {', tests: ['http'] },
  { name: 'admin routes do not require a session', file: 'security/auth.ts', find: "if (!session || session.role !== 'admin') throw new HttpError(401, 'admin_required', 'Sign in as the owner.');", replace: '', tests: ['http'] },
  { name: 'a client token is accepted as an admin token', file: 'security/auth.ts', find: "if (!session || session.role !== 'admin') throw new HttpError(401, 'admin_required', 'Sign in as the owner.');", replace: "if (!session) throw new HttpError(401, 'admin_required', 'Sign in as the owner.');", tests: ['http'] },
  { name: 'session tokens are not signature-checked', file: 'security/auth.ts', find: "if (!safeEqual(sign(secret, body), parts[2] ?? '')) return null;", replace: '', tests: ['http'] },
  { name: 'cross-site requests are accepted (no CSRF check)', file: 'security/auth.ts', find: '  return allowed.has(host);\n}', replace: '  return true || allowed.has(host);\n}', tests: ['http'] },
  { name: 'the browser\'s own "cross-site" signal is ignored', file: 'security/auth.ts', find: "  if (fetchSite === 'cross-site') return false;\n", replace: '', tests: ['http'] },
  { name: 'the caller\'s address is taken from the part of X-Forwarded-For anyone can forge', file: 'security/auth.ts', find: "return xff[xff.length - trustedProxyHops] ?? xff[0] ?? req.socket?.remoteAddress ?? 'unknown';", replace: "return xff[0] ?? req.socket?.remoteAddress ?? 'unknown';", tests: ['http'] },
  { name: 'every failed sign-in raises its own alert (alert flooding)', file: 'notify.ts', find: "  if (last && Date.now() - Date.parse(last.at) < hours * 3600_000) return false;\n", replace: '', tests: ['http'] },
  { name: 'an unconfigured admin password leaves admin open', file: 'security/auth.ts', find: "return s.sessionSecret.length >= 32 && (s.adminPasswordHash.length > 0 || s.adminPassword.length >= 12);", replace: 'return true;', tests: ['http'] },
  { name: 'one client can read another client\'s order', file: 'orders/service.ts', find: "if (!order || (clientId !== null && order.clientId !== clientId)) throw new HttpError(404, 'order_not_found', 'Order not found.');", replace: "if (!order) throw new HttpError(404, 'order_not_found', 'Order not found.');", tests: ['http'] },
  { name: 'one client can read another client\'s payment status', file: 'routes.ts', find: "if ((found.payment && found.payment.clientId !== mine) || (found.invoice && found.invoice.clientId !== mine) || (!found.payment && !found.invoice)) {", replace: 'if (!found.payment && !found.invoice) {', tests: ['http'] },
  { name: 'locked files can be downloaded before payment', file: 'routes.ts', find: "if (order.deliverablesLocked && d.kind !== 'preview') {", replace: 'if (false) {', tests: ['http'] },
  {
    name: 'a visitor can order under someone else\'s e-mail (both guards removed)',
    edits: [
      { file: 'orders/service.ts', find: "    if (await core.store.get(C.clientEmails, emailKey(email))) {\n      throw new HttpError(409, 'existing_client', 'This e-mail address already has a Client ID. Sign in with your Client ID and PIN to place the order.');\n    }\n", replace: '' },
      { file: 'orders/service.ts', find: "      if (await t.get(C.clientEmails, emailKey(newClient.email))) throw new HttpError(409, 'existing_client', 'This e-mail address already has a Client ID. Sign in to place the order.');\n", replace: '' },
    ],
    tests: ['http'],
  },
  { name: 'wrong PINs never lock the account', file: 'orders/service.ts', find: "  if (client.pinLockedUntil && Date.parse(client.pinLockedUntil) > Date.now()) {", replace: '  if (false) {', tests: ['http'] },
  { name: 'prepaid work starts before payment', file: 'orders/service.ts', find: "  if (!depositMet(invoice)) return { state: 'awaiting_payment', locked: false };\n", replace: '', tests: ['workers'] },
  { name: 'an order left behind by a crash is never repaired', file: 'tick.ts', find: "const advanced = sweep ? await guard('advance', 0, () => advanceAllOpen(core)) : 0;", replace: 'const advanced = 0;', tests: ['ops'] },
  { name: 'the scheduler never runs Camellia\'s queued work', file: 'tick.ts', find: "const jobs = withJobs ? await guard('jobs', { ran: 0 }, () => runDueJobs(core, remaining)) : { ran: 0 };", replace: 'const jobs = { ran: 0 };', tests: ['ops'] },
  { name: 'a silent SMS phone is never reported', file: 'tick.ts', find: "  if (sms > 0 && bridges.sms.health !== 'healthy') {", replace: '  if (false) {', tests: ['ops'] },
  { name: 'a brief outage of a lookup service fails the job outright', file: 'fulfilment/engine.ts', find: "const retryable = (err as { retryable?: unknown })?.retryable === true;", replace: 'const retryable = err instanceof ModelError && err.retryable;', tests: ['workers'] },
  { name: 'CV: invented figures are not checked', file: 'fulfilment/workers/cv.ts', find: 'const badNumbers = source.ungroundedNumbers(prose);', replace: 'const badNumbers: string[] = [];', tests: ['cv'] },
  { name: 'CV: skills not in the CV are allowed', file: 'fulfilment/workers/cv.ts', find: 'const badSkills = skills.filter((s) => !source.hasTerm(s));', replace: 'const badSkills: string[] = [];', tests: ['cv'] },
  { name: 'work with failed checks can be released without "force"', file: 'fulfilment/engine.ts', find: "if (blockers.length > 0 && !(actor === 'owner' && force)) {", replace: 'if (false) {', tests: ['cv', 'workers'] },
  { name: 'work with failed checks auto-releases', file: 'fulfilment/engine.ts', find: "if (job.mode === 'auto' && blockers.length === 0 && settings.autoRelease[service.serviceId] && result.files.length > 0) {", replace: "if (job.mode === 'auto' && settings.autoRelease[service.serviceId] && result.files.length > 0) {", tests: ['cv', 'workers'] },
  { name: 'two server instances run the same job', file: 'fulfilment/engine.ts', find: '    if (!runnable || leased) return null;\n', replace: '', tests: ['cv'] },
  { name: 'proofreading: changed numbers go unnoticed', file: 'fulfilment/workers/writing.ts', find: "check('proof_numbers', 'Every number is unchanged', nums.lost.length === 0 && nums.added.length === 0, 'block',", replace: "check('proof_numbers', 'Every number is unchanged', true, 'block',", tests: ['workers', 'units'] },
  { name: 'data entry: rows can vanish without the accounting noticing', file: 'fulfilment/workers/data.ts', find: "    if (out.every((v) => v === '')) return void emptyRows.push(rowNumber);", replace: "    if (out.every((v) => v === '')) return;", tests: ['workers', 'units'] },
  { name: 'client-supplied internal addresses are accepted (SSRF)', file: 'orders/catalog.ts', find: "  return !/(^|\\.)(localhost|local|internal|lan|home|corp|test|invalid|example)$/.test(v);", replace: '  return true;', tests: ['units'] },
  { name: 'client-supplied IP addresses are accepted as websites (SSRF)', file: 'orders/catalog.ts', find: '  return isPublicDomain(u.hostname);\n}', replace: '  return true;\n}', tests: ['units'] },
  { name: 'Camellia\'s replies are shown unchecked', file: 'camellia.ts', find: "    return '[shown on your invoice page]';\n  });", replace: '    return match;\n  });', tests: ['http'] },
  { name: 'the audit log can be edited without detection', file: 'audit.ts', find: "if (entryHash(rest) !== hash) return { ok: false, entries: all.length, brokenAt: e.seq, reason: 'entry was modified' };", replace: '', tests: ['payments'] },
  { name: 'zip bombs are inflated without a size cap', file: 'fulfilment/render/zip.ts', find: 'return inflateRawSync(raw, { maxOutputLength: maxBytes });', replace: 'return inflateRawSync(raw);', tests: ['units'] },
];

function runTests(names) {
  const files = names.map((n) => `tests/${n}.test.ts`);
  const r = spawnSync(process.execPath, ['--import', 'tsx', '--test', '--test-concurrency=1', ...files], { cwd: root, encoding: 'utf8', timeout: 180_000 });
  const fail = Number(/^# fail (\d+)/m.exec(r.stdout)?.[1] ?? (r.status === 0 ? 0 : 1));
  const firstFailure = /^not ok \d+ - (.+)$/m.exec(r.stdout)?.[1] ?? '';
  return { failed: fail > 0 || r.status !== 0, firstFailure };
}

let survived = 0;
let broken = 0;
const rows = [];
for (const m of MUTATIONS) {
  const edits = m.edits ?? [{ file: m.file, find: m.find, replace: m.replace }];
  const originals = new Map();
  let problem = '';
  for (const e of edits) {
    const path = src(e.file);
    if (!originals.has(path)) originals.set(path, readFileSync(path, 'utf8'));
    const count = originals.get(path).split(e.find).length - 1;
    if (count !== 1) problem = `edit point found ${count} times in ${e.file} (expected 1)`;
  }
  if (problem) {
    broken += 1;
    rows.push(['SKIPPED', m.name, problem]);
    continue;
  }
  let result;
  try {
    const current = new Map(originals);
    for (const e of edits) current.set(src(e.file), current.get(src(e.file)).replace(e.find, e.replace));
    for (const [path, text] of current) writeFileSync(path, text);
    result = runTests(m.tests);
  } finally {
    for (const [path, text] of originals) writeFileSync(path, text); // always put the real code back
  }
  if (result.failed) rows.push(['caught', m.name, result.firstFailure.slice(0, 70)]);
  else {
    survived += 1;
    rows.push(['SURVIVED', m.name, `no test in [${m.tests.join(', ')}] noticed`]);
  }
}

const w = Math.max(...rows.map((r) => r[1].length));
for (const [status, name, detail] of rows) console.log(`${status.padEnd(9)} ${name.padEnd(w)}  ${detail}`);
console.log(`\n${rows.length} sabotages: ${rows.length - survived - broken} caught, ${survived} survived, ${broken} skipped.`);
process.exit(survived + broken > 0 ? 1 : 0);
