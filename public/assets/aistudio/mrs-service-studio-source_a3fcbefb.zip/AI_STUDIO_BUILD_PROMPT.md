# Google AI Studio integration brief

Paste the block below into the existing MRS project in Google AI Studio **after adding/reviewing the source project**. A public URL alone is not enough to modify the original project. Keep a backup/branch before applying changes.

---

## Build brief

Redesign the existing M R S Services website as a premium, systematic, future-facing digital operations studio. Use the included MRS Service Studio project as the design and implementation reference. Preserve factual information from the current public service catalog; do not invent prices, guarantees, service counts, turnaround commitments, or payment policies.

### Brand and user experience

- Use a precise, editorial technology direction: deep ink/forest backgrounds, muted sage surfaces, high-contrast lime accents, subtle grid/orbit details, clean typography, strong spacing, and responsive layouts.
- Build a clear home page with: a direct hero, three service tracks, a searchable/filterable catalog, a transparent five-step process, a responsible-AI explanation, and a strong contact/brief CTA.
- Include the Camellia concierge as a useful service-routing assistant. Label whether Gemini is connected or the interface is in preview mode.
- Keep accessibility in scope: keyboard focus, semantic landmarks, form labels, contrast, reduced motion, and mobile navigation.

### AI and backend contract

- Call Gemini only from a trusted server/API route using `@google/genai` and a server-side `GEMINI_API_KEY` environment variable. Never expose an API key in browser code, `VITE_*` variables, HTML, or client-visible logs.
- Ground Camellia in the shared MRS catalog. It may explain guide prices, timing, and service fit; it must not invent details, guarantee availability, place orders, approve/collect payments, or replace a human scope/price confirmation.
- Do not ask users to submit passwords, card details, bKash/Nagad PINs, private keys, recovery codes, or remote-access credentials. Avoid persisting chat history unless a clear retention policy and consent are added.
- Expose same-origin endpoints: `GET /api/health`, `POST /api/assistant`, and `POST /api/quotes`. Validate input, cap message/body sizes, rate-limit public endpoints, and keep all secrets server-side.
- Persist quote requests in the existing production database or an approved managed PostgreSQL store. Do not use in-memory or local JSON storage for production.
- Protect any owner/admin inbox with server-side authentication and log no contact details or brief content unnecessarily.

### Preserve existing systems

- Keep the existing client portal sign-in, Client ID/PIN security, order records, payment verification, invoices, and deliverable isolation intact. Do not replace those with a mock form.
- Keep IPTV plan selection/activation on the existing dedicated IPTV portal unless its owner separately approves a backend integration.
- Preserve all existing working URLs, legal/privacy notices, and operational contact channels. Verify redirects and route behavior before publishing.
- Do not represent the starter quote form as a replacement for the existing paid-order flow. It is a service inquiry intake only.

### Release checklist

1. Compare the current AI Studio project source with this implementation and make a focused merge rather than blindly overwriting backend/auth/payment code.
2. Test all 16 catalog entries, category filters, search, mobile navigation, assistant responses, validation errors, and successful quote submission.
3. Test the production Gemini key, database connection, rate limits, admin authorization, HTTPS, and privacy/retention behavior using staging data.
4. Confirm links to the existing Client Portal and IPTV portal work in the deployed environment.
5. Build, run the project checks, review the diff, then publish only after the MRS owner approves the final result.

---

## Merge checklist for the project owner

- [ ] Add the source from this workspace to the existing project/repository (or export the AI Studio app source first).
- [ ] Reconcile routing, auth, portal, payment, and order APIs; retain existing behavior.
- [ ] Provide a backend-only Gemini key and production database through the deployment platform's secret manager.
- [ ] Verify privacy policy, data retention, consent, support contacts, and service pricing against the live operational policy.
- [ ] Test in staging, then publish from the existing AI Studio project.
