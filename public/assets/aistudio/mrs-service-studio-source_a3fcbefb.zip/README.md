# M R S Service Studio — production-ready redesign starter

A responsive, high-contrast service-studio website built from the public MRS catalog at `mrs-services.ai.studio`. It includes a redesigned home/catalog experience, an AI concierge API, and a validated service-brief intake flow.

> **Integration boundary:** this workspace is a deployable implementation, not a change made inside the live Google AI Studio project. A public URL does not provide source-code or account access. The existing Client Portal and IPTV checkout are linked rather than recreated; merge this project into the existing source after reviewing the current routes and backend.

## What is included

- Responsive MRS-branded home page, service tracks, searchable 16-service catalog, delivery process, and responsible-AI explanation.
- Camellia concierge backed by a server-side Google Gemini call (`@google/genai`). Its system instruction grounds answers in the shared public catalog and keeps quote/payment commitments under human review.
- A deterministic local preview assistant when no Gemini key is configured. The UI labels this as preview mode; it is not presented as a live model.
- Validated quote/brief intake with server-generated reference IDs, rate limits, consent, and a protected owner inbox endpoint.
- PostgreSQL storage for production; local JSONL storage only for development.
- Preserved external links to the current client portal, privacy notice, dedicated IPTV portal, scoping call, and existing fixed-price order routes where available.
- Responsive styles, keyboard-accessible controls, reduced-motion support, security headers, and environment-variable secrets.

## Run locally

Requirements: Node.js 20.19+ and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`). The Vite server proxies `/api/*` to the Express backend on port `8787`.

With no `GEMINI_API_KEY`, Camellia uses a small deterministic catalog matcher so the project can be previewed safely. Submitted briefs are written to `data/requests.jsonl` in local development; that file is ignored by Git. Do not use local-file storage for a multi-user or production deployment.

## Connect Google Gemini

1. Create or use a Gemini API key in Google AI Studio.
2. Set `GEMINI_API_KEY` in the **server's** environment (or in your local `.env`). Never put it in `VITE_*`, browser code, HTML, or a public repository.
3. Optionally set `GEMINI_MODEL` to a model enabled for the key/project. The starter defaults to `gemini-3.8-flash`; set the model ID to one enabled for your AI Studio project if needed.
4. Restart the API server. `GET /api/health` should report `"aiMode":"gemini"`.

The API retains no chat history in this starter: the browser sends the recent conversation with each request and the server passes it to Gemini. Do not send private credentials or sensitive payment information to the assistant.

## Production deployment

This is a Node/Express + Vite project. Build the frontend and run the Express server behind HTTPS on a trusted host that supports server-side environment variables and PostgreSQL.

Required production environment:

```env
NODE_ENV=production
PORT=8787
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DATABASE
PGSSLMODE=require
GEMINI_API_KEY=your_server_side_key
GEMINI_MODEL=gemini-3.8-flash
ADMIN_API_KEY=a-long-random-owner-only-secret
TRUST_PROXY=1
```

Then:

```bash
npm run build
npm start
```

The server applies `server/schema.sql` on startup. Use a managed Postgres database with backups and a retention policy appropriate to your privacy obligations. `TRUST_PROXY=1` is only for deployment behind a trusted reverse proxy; do not enable it when clients can reach the Node process directly.

### Endpoints

- `GET /api/health` — status only; returns Gemini/demo mode and storage mode.
- `POST /api/assistant` — catalog-grounded Camellia conversation.
- `POST /api/quotes` — validated service brief, returns a reference such as `Q-YYMM-ABC123`.
- `GET /api/admin/quotes?limit=50` — owner inbox; requires `Authorization: Bearer $ADMIN_API_KEY`.

Example owner inbox request:

```bash
curl -H "Authorization: Bearer $ADMIN_API_KEY" \
  "https://YOUR_HOST/api/admin/quotes?limit=50"
```

Treat the owner inbox as sensitive personal data. The starter does not send email notifications or automatically change request status; connect your preferred notification/CRM service on the server if needed, and document retention/deletion procedures before launch.

## Google AI Studio integration

Read [`AI_STUDIO_BUILD_PROMPT.md`](./AI_STUDIO_BUILD_PROMPT.md) for a ready-to-paste integration prompt and merge checklist. The important deployment rule is that Gemini calls and quote storage remain server-side. If the existing AI Studio project exposes only browser-side code, connect the UI to a trusted backend API; do not paste the Gemini key into the frontend.

Before replacing the current site, compare the existing project routes, client portal authentication, payment flow, privacy copy, and production data model. This starter keeps the portal and IPTV checkout as external links and does not claim to implement either system.
