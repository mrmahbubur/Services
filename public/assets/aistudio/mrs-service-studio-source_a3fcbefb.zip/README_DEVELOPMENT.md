# Engineering notes

## System shape

- `src/` — React UI and responsive visual system.
- `shared/services.js` — shared source of truth for the public service catalog (used by both UI and assistant prompt).
- `server/index.js` — Express API, Gemini proxy, validation, rate limits, admin inbox endpoint.
- `server/store.js` + `server/schema.sql` — PostgreSQL persistence in production; JSONL only in local development.

## Safety and release notes

- Quote form submissions include name, one or more contact methods, selected service, brief, and consent. The form warns visitors not to send secrets.
- Gemini receives recent chat messages and the public catalog, but this implementation does not save chat history.
- Quote requests contain personal data. Use a managed database, TLS, restricted access, backups, and a deletion/retention policy.
- `GET /api/admin/quotes` exposes request content only with a server-side bearer key. Keep that key out of browser clients.
- Add a production email/CRM alert and spam/bot protection only after choosing a trusted provider and updating consent/privacy text.
- Existing portal authentication and payment flows are intentionally out of scope; retain those systems and verify their URLs when merging.
