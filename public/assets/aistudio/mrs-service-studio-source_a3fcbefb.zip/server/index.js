import "dotenv/config";
import { createServer } from "node:http";
import { timingSafeEqual } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { GoogleGenAI } from "@google/genai";
import { z } from "zod";
import { SERVICES, getCategoryName } from "../shared/services.js";
import { closeStore, createQuoteRequest, getStorageMode, initializeStore, listQuoteRequests } from "./store.js";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const app = express();
const port = Number(process.env.PORT || 8787);
const isProduction = process.env.NODE_ENV === "production";
const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;

if (isProduction && !ai) throw new Error("GEMINI_API_KEY is required in production; refusing to launch in preview/demo mode.");
if (isProduction && !process.env.ADMIN_API_KEY) throw new Error("ADMIN_API_KEY is required in production to protect the owner inbox.");
if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      fontSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"],
      formAction: ["'self'"],
    },
  },
  referrerPolicy: { policy: "strict-origin-when-cross-origin" },
}));
app.use(express.json({ limit: "24kb", strict: true }));

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again shortly." },
});
const assistantLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 14,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Camellia is receiving many requests. Please wait a moment and try again." },
});
const quoteLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 6,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Please wait before sending another brief." },
});

app.use("/api", generalLimiter);

const chatSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string().trim().min(1).max(1200),
  }).strict()).min(1).max(12),
}).strict();

const quoteSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.union([z.string().trim().email().max(254), z.literal("")]).optional(),
  whatsapp: z.string().trim().max(32).optional().default(""),
  serviceSlug: z.string().trim().min(2).max(80),
  brief: z.string().trim().min(20).max(3000),
  consent: z.literal(true),
}).strict().refine((data) => Boolean(data.email || data.whatsapp), {
  message: "Add either an email address or a WhatsApp / phone number so the team can reply.",
  path: ["email"],
});

function catalogForPrompt() {
  return SERVICES.map((service) => ({
    name: service.name,
    category: getCategoryName(service.category),
    summary: service.summary,
    USD: service.rateUSD,
    BDT: service.rateBDT,
    typicalTiming: service.turnaround,
    route: service.kind === "external" ? "Dedicated external IPTV portal" : service.kind === "existing-order" ? "Existing order flow" : "Request a human-reviewed quote",
  }));
}

const systemInstruction = `You are Camellia, the warm, concise service-coordination assistant for M R S Services. You help a visitor understand the public catalog and shape a useful brief.\n\nUse ONLY the catalog below for service availability, guide prices, and timing. Do not invent discounts, guarantees, payment rules, service capabilities, legal or technical assurances, or delivery dates. If a detail is missing or may have changed, say that the operations team must confirm it. Guide prices are not binding quotes.\n\nAsk at most one or two relevant follow-up questions at a time. Keep answers short, clear, and practical. Recommend the most relevant service, not every service. Never approve, collect, or process a payment; never claim an order has been placed; a human must confirm scope, price, availability, and delivery. For catalog entries marked Existing order flow, direct visitors to the existing order route instead of suggesting a new quote flow. For M R S IPTV VIP Pass, direct plan and activation questions to the dedicated portal listed in the public site; do not invent channel, licensing, or uptime guarantees beyond the catalog.\n\nDo not ask for passwords, payment card details, bKash/Nagad PINs, private keys, recovery codes, remote-access credentials, or government identity numbers. If a visitor shares secrets, do not repeat them; tell them to remove the message and rotate the credential if it was exposed. Do not present yourself as a human.\n\nPUBLIC SERVICE CATALOG:\n${JSON.stringify(catalogForPrompt())}`;

function localCatalogReply(text) {
  const query = text.toLowerCase();
  const keywords = {
    "ai-digital-productivity": ["ai", "automation", "automate", "agent", "prompt", "workflow", "gemini", "openai"],
    "technical-writing-proofreading": ["write", "writing", "proofread", "documentation", "manual", "api doc", "technical doc"],
    "website-management": ["website", "wordpress", "blogger", "seo", "speed", "core web", "cms", "site"],
    "it-support-troubleshooting": ["computer", "laptop", "it support", "troubleshoot", "malware", "driver", "network", "wifi", "virus"],
    "app-store-publishing": ["app store", "play store", "google play", "publishing", "publish app", "apple app"],
    "ats-cv-resume": ["cv", "resume", "résumé", "ats", "job application", "job"],
    "web-setup": ["domain", "dns", "hosting", "ssl", "cloudflare", "business email"],
    tutoring: ["tutor", "tutoring", "learn", "learning", "class", "course", "programming lesson"],
    "graphics-design": ["design", "logo", "banner", "graphic", "branding", "visual"],
    "virtual-assistance": ["assistant", "admin", "inbox", "calendar", "virtual assistance", "spreadsheet support"],
    "data-entry": ["data entry", "spreadsheet", "csv", "deduplicate", "data cleanup", "excel"],
    "online-learning-resources": ["curriculum", "study guide", "quiz", "learning resources", "lesson plan"],
    "gravatar-identity-consultation": ["gravatar", "identity", "avatar", "profile identity", "pgp"],
    "gravatar-profile-personalization": ["bio", "profile personalization", "gravatar profile", "social links"],
    "gravatar-custom-domain-mapping": ["cname", "custom domain", "map domain", "domain mapping"],
    "iptv-vip-pass": ["iptv", "streaming", "firestick", "smart tv", "tv pass"],
  };
  const scored = SERVICES.map((service) => ({
    service,
    score: (keywords[service.slug] || []).reduce((total, keyword) => total + (query.includes(keyword) ? (keyword.length > 5 ? 2 : 1) : 0), 0),
  })).sort((a, b) => b.score - a.score);
  const match = scored[0]?.score > 0 ? scored[0].service : null;

  if (!match) {
    return "I can help route a brief across AI and digital operations, website or IT support, app publishing, CV and learning support, Gravatar identity, or IPTV. What outcome are you trying to achieve, and what tools or platform are involved?";
  }
  if (match.kind === "external") {
    return `For ${match.name}, the public catalog lists ${match.rateUSD} (${match.rateBDT}); the dedicated IPTV portal handles plan selection and activation. Please use the existing IPTV portal for current plan details. What device are you setting up?`;
  }
  if (match.kind === "existing-order") {
    return `For ${match.name}, the public guide price is ${match.rateUSD} (${match.rateBDT}), with typical timing of ${match.turnaround}. Use the existing order link on its service card for the current order flow; this assistant does not take payment or place orders.`;
  }
  return `A relevant route is ${match.name}. The public guide price is ${match.rateUSD} (${match.rateBDT}), with typical timing of ${match.turnaround}. The final scope and quote need human confirmation. What result do you need, and what platform or deadline should the team know about?`;
}

app.get("/api/health", (_request, response) => {
  response.json({
    ok: true,
    aiMode: ai ? "gemini" : "demo",
    storageMode: getStorageMode(),
  });
});

app.post("/api/assistant", assistantLimiter, async (request, response) => {
  const parsed = chatSchema.safeParse(request.body);
  if (!parsed.success) return response.status(400).json({ error: "Please send a short message (up to 1,200 characters)." });
  const messages = parsed.data.messages.slice(-12);
  if (messages[messages.length - 1]?.role !== "user") {
    return response.status(400).json({ error: "The conversation must end with a visitor message." });
  }

  const fallback = localCatalogReply(messages[messages.length - 1].content);
  if (!ai) return response.json({ reply: fallback, mode: "demo" });

  try {
    const result = await ai.models.generateContent({
      model,
      contents: messages.map((message) => ({
        role: message.role === "assistant" ? "model" : "user",
        parts: [{ text: message.content }],
      })),
      config: {
        systemInstruction,
        temperature: 0.35,
        maxOutputTokens: 450,
      },
    });
    const reply = result.text?.trim();
    if (!reply) return response.json({ reply: fallback, mode: "fallback" });
    return response.json({ reply, mode: "gemini" });
  } catch (error) {
    console.error("Gemini request failed:", error?.name || "unknown provider error");
    return response.json({ reply: fallback, mode: "fallback" });
  }
});

app.post("/api/quotes", quoteLimiter, async (request, response, next) => {
  const parsed = quoteSchema.safeParse(request.body);
  if (!parsed.success) {
    const firstIssue = parsed.error.issues[0];
    return response.status(400).json({ error: firstIssue?.message || "Check the brief and contact details, then try again." });
  }
  const input = parsed.data;
  if (!SERVICES.some((service) => service.slug === input.serviceSlug && service.kind !== "external")) {
    return response.status(400).json({ error: "Choose one of the available services." });
  }

  try {
    const saved = await createQuoteRequest(input);
    return response.status(201).json({ id: saved.id, createdAt: saved.createdAt, message: "Your brief was received for human review." });
  } catch (error) {
    return next(error);
  }
});

function constantTimeEquals(expected, actual) {
  if (!expected || !actual) return false;
  const expectedBuffer = Buffer.from(expected);
  const actualBuffer = Buffer.from(actual);
  return expectedBuffer.length === actualBuffer.length && timingSafeEqual(expectedBuffer, actualBuffer);
}

app.get("/api/admin/quotes", async (request, response, next) => {
  const adminKey = process.env.ADMIN_API_KEY;
  if (!adminKey) return response.status(503).json({ error: "Owner inbox is not configured." });
  const bearer = request.get("authorization")?.match(/^Bearer\s+(.+)$/i)?.[1] || "";
  if (!constantTimeEquals(adminKey, bearer)) return response.status(401).json({ error: "Unauthorized." });

  try {
    const rows = await listQuoteRequests(request.query.limit);
    return response.json({ requests: rows });
  } catch (error) {
    return next(error);
  }
});

if (isProduction) {
  const distDir = path.join(rootDir, "dist");
  app.use(express.static(distDir, { index: false, maxAge: "1h", etag: true }));
  app.use(async (request, response, next) => {
    if (request.method !== "GET" || request.path.startsWith("/api/")) return next();
    try {
      await fs.access(path.join(distDir, "index.html"));
      return response.sendFile(path.join(distDir, "index.html"));
    } catch (error) {
      return next(error);
    }
  });
}

app.use("/api", (_request, response) => response.status(404).json({ error: "API route not found." }));
app.use((error, _request, response, _next) => {
  if (error?.type === "entity.too.large") return response.status(413).json({ error: "Request is too large." });
  if (error?.type === "entity.parse.failed") return response.status(400).json({ error: "Request body must be valid JSON." });
  console.error("Request failed:", error?.message || "unknown server error");
  return response.status(500).json({ error: "Something went wrong. Please try again or contact the operations desk." });
});

await initializeStore();
const server = createServer(app);
server.listen(port, "0.0.0.0", () => {
  console.log(`MRS API listening on 0.0.0.0:${port} · storage=${getStorageMode()} · ai=${ai ? model : "preview/demo"}`);
});

async function shutdown(signal) {
  console.log(`${signal} received; shutting down cleanly.`);
  server.close(async () => {
    await closeStore();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
