import { randomUUID } from "node:crypto";
import { appendFile, mkdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Pool } from "pg";

const serverDir = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(serverDir, "..");
const dataDir = path.join(rootDir, "data");
const requestsFile = path.join(dataDir, "requests.jsonl");
let pool = null;
let mode = "uninitialized";

export async function initializeStore() {
  if (process.env.DATABASE_URL) {
    const ssl = process.env.PGSSLMODE === "require" ? { rejectUnauthorized: false } : undefined;
    pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl, max: 10, idleTimeoutMillis: 30_000 });
    const schema = await readFile(path.join(serverDir, "schema.sql"), "utf8");
    await pool.query(schema);
    mode = "postgres";
    return mode;
  }

  if (process.env.NODE_ENV === "production") {
    throw new Error("DATABASE_URL is required in production. Local JSON storage is development-only.");
  }

  await mkdir(dataDir, { recursive: true, mode: 0o700 });
  mode = "local-dev";
  return mode;
}

export function getStorageMode() {
  return mode;
}

function newReference() {
  const date = new Date();
  const yearMonth = `${String(date.getUTCFullYear()).slice(-2)}${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
  return `Q-${yearMonth}-${randomUUID().slice(0, 6).toUpperCase()}`;
}

export async function createQuoteRequest(input) {
  const id = newReference();
  const createdAt = new Date().toISOString();
  const record = {
    id,
    name: input.name,
    email: input.email || null,
    whatsapp: input.whatsapp || null,
    serviceSlug: input.serviceSlug,
    brief: input.brief,
    consent: true,
    status: "new",
    createdAt,
  };

  if (pool) {
    const result = await pool.query(
      `INSERT INTO quote_requests (id, name, email, whatsapp, service_slug, brief, consent, status, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id, created_at`,
      [record.id, record.name, record.email, record.whatsapp, record.serviceSlug, record.brief, record.consent, record.status, record.createdAt],
    );
    return { id: result.rows[0].id, createdAt: result.rows[0].created_at };
  }

  if (mode !== "local-dev") throw new Error("Request storage is not initialized.");
  await appendFile(requestsFile, `${JSON.stringify(record)}\n`, { encoding: "utf8", mode: 0o600 });
  return { id, createdAt };
}

export async function listQuoteRequests(limit = 50) {
  const boundedLimit = Math.max(1, Math.min(Number(limit) || 50, 200));
  if (pool) {
    const result = await pool.query(
      `SELECT id, name, email, whatsapp, service_slug AS "serviceSlug", brief, consent, status, created_at AS "createdAt"
       FROM quote_requests ORDER BY created_at DESC LIMIT $1`,
      [boundedLimit],
    );
    return result.rows;
  }

  if (mode !== "local-dev") throw new Error("Request storage is not initialized.");
  try {
    const content = await readFile(requestsFile, "utf8");
    return content.trim().split("\n").filter(Boolean).slice(-boundedLimit).reverse().map((line) => JSON.parse(line));
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

export async function closeStore() {
  if (pool) await pool.end();
}
