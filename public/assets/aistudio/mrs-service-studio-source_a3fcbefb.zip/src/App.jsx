import { useEffect, useMemo, useRef, useState } from "react";
import { SERVICE_CATEGORIES, SERVICES, getCategoryName } from "../shared/services.js";

const PORTAL_URL = "https://mrs-services.ai.studio/portal";

function Icon({ name, size = 18, className = "" }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className,
    "aria-hidden": true,
  };
  const paths = {
    arrow: <><path d="M5 12h14" /><path d="m13 5 7 7-7 7" /></>,
    arrowUp: <><path d="M12 19V5" /><path d="m5 12 7-7 7 7" /></>,
    spark: <><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z" /><path d="m19 15 .9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15Z" /></>,
    shield: <><path d="M12 3 20 6v5.2c0 4.9-3.4 8.2-8 9.8-4.6-1.6-8-4.9-8-9.8V6l8-3Z" /><path d="m8.7 12.1 2.1 2.1 4.6-4.8" /></>,
    layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5" /><path d="m3 16 9 5 9-5" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.5 4.5" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    chat: <><path d="M20 11.2a7.2 7.2 0 0 1-7.2 7.2H7l-3.5 2v-5A7.2 7.2 0 0 1 10.7 8h2.1a7.2 7.2 0 0 1 7.2 3.2Z" /><path d="M8 12h.01M12 12h.01M16 12h.01" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    check: <><path d="m5 12 4 4L19 6" /></>,
    globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" /></>,
    bolt: <><path d="m13 2-9 12h7l-1 8 10-13h-7l1-7Z" /></>,
    shieldCheck: <><path d="M12 3 20 6v5.2c0 4.9-3.4 8.2-8 9.8-4.6-1.6-8-4.9-8-9.8V6l8-3Z" /><path d="m8.7 12.1 2.1 2.1 4.6-4.8" /></>,
    scan: <><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3" /><path d="M4 12h16" /></>,
    code: <><path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14" /></>,
    user: <><circle cx="12" cy="8" r="3.5" /><path d="M4.5 20a7.5 7.5 0 0 1 15 0" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5" /></>,
  };
  return <svg {...common}>{paths[name] || paths.spark}</svg>;
}

function Header({ onPortalClick }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="header-inner wrap">
        <a className="brand" href="#top" aria-label="M R S Services home" onClick={closeMenu}>
          <span className="brand-mark"><span>M</span><i>R</i><span>S</span></span>
          <span className="brand-copy"><strong>MRS</strong><small>SERVICE STUDIO</small></span>
        </a>
        <button className="menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          <Icon name={menuOpen ? "close" : "menu"} size={21} />
        </button>
        <nav className={`main-nav ${menuOpen ? "is-open" : ""}`} aria-label="Main navigation">
          <a href="#solutions" onClick={closeMenu}>Solutions</a>
          <a href="#catalog" onClick={closeMenu}>Service catalog</a>
          <a href="#approach" onClick={closeMenu}>How it works</a>
          <a href="#concierge" onClick={closeMenu}>AI concierge</a>
          <a className="nav-portal" href={PORTAL_URL} target="_blank" rel="noreferrer" onClick={(event) => { closeMenu(); onPortalClick?.(event); }}>
            Client portal <Icon name="external" size={13} />
          </a>
        </nav>
        <a className="button button-small button-lime header-cta" href="#concierge">
          Talk to Camellia <Icon name="arrow" size={15} />
        </a>
      </div>
    </header>
  );
}

function SectionTitle({ eyebrow, title, body, light = false, align = "left" }) {
  return (
    <div className={`section-title ${light ? "section-title-light" : ""} align-${align}`}>
      <span className="eyebrow"><span className="eyebrow-line" />{eyebrow}</span>
      <h2>{title}</h2>
      {body && <p>{body}</p>}
    </div>
  );
}

function AssistantPanel({ health }) {
  const initialMessage = {
    role: "assistant",
    content: "Hi, I’m Camellia. Tell me what you’re trying to get done and I’ll point you to a relevant service or help shape a clear brief.",
  };
  const [messages, setMessages] = useState([initialMessage]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const endRef = useRef(null);
  const inputRef = useRef(null);
  const mode = health?.aiMode === "gemini" ? "Gemini connected" : "Preview mode";

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [messages, busy]);

  async function sendMessage(text = input) {
    const content = text.trim();
    if (!content || busy) return;
    const next = [...messages, { role: "user", content }];
    setMessages(next);
    setInput("");
    setNotice("");
    setBusy(true);
    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next.slice(-12) }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Camellia is unavailable right now.");
      setMessages((current) => [...current, { role: "assistant", content: data.reply || "I couldn’t form a clear answer. Please try again." }]);
      if (data.mode === "demo") setNotice("Local preview assistant · add a Gemini API key for live AI responses.");
      if (data.mode === "fallback") setNotice("Gemini is temporarily unavailable; showing catalog-based guidance.");
    } catch (error) {
      setMessages((current) => [...current, { role: "assistant", content: "I couldn’t reach the assistant service just now. You can still browse the catalog or send a service brief below." }]);
      setNotice(error.message || "Connection issue");
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  }

  return (
    <section className="assistant-card" id="concierge" aria-labelledby="assistant-title">
      <div className="assistant-topline">
        <div className="assistant-agent">
          <span className="assistant-avatar"><Icon name="spark" size={17} /></span>
          <div><strong id="assistant-title">Camellia <span>AI concierge</span></strong><small>Service coordination · MRS Studio</small></div>
        </div>
        <span className={`ai-status ${health?.aiMode === "gemini" ? "is-live" : "is-preview"}`}><i />{mode}</span>
      </div>
      <div className="assistant-rule" />
      <div className="chat-window" aria-live="polite" aria-label="Conversation with Camellia">
        {messages.map((message, index) => (
          <div className={`chat-row ${message.role === "user" ? "chat-user" : "chat-agent"}`} key={`${index}-${message.role}`}>
            {message.role === "assistant" && <span className="chat-mark"><Icon name="spark" size={13} /></span>}
            <p>{message.content}</p>
          </div>
        ))}
        {busy && <div className="chat-row chat-agent"><span className="chat-mark"><Icon name="spark" size={13} /></span><p className="typing-dots"><i /><i /><i /><span className="sr-only">Camellia is thinking</span></p></div>}
        <div ref={endRef} />
      </div>
      {messages.length === 1 && (
        <div className="prompt-chips" aria-label="Suggested questions">
          <button type="button" onClick={() => sendMessage("I want to automate a repetitive business workflow.")}>Automate a workflow <Icon name="arrow" size={12} /></button>
          <button type="button" onClick={() => sendMessage("I need help improving my website performance.")}>Improve my website <Icon name="arrow" size={12} /></button>
          <button type="button" onClick={() => sendMessage("I need an ATS-friendly CV for a role I am applying to.")}>Optimize my CV <Icon name="arrow" size={12} /></button>
        </div>
      )}
      {notice && <p className="assistant-notice">{notice}</p>}
      <form className="assistant-compose" onSubmit={(event) => { event.preventDefault(); sendMessage(); }}>
        <label className="sr-only" htmlFor="camellia-input">Ask Camellia about a service</label>
        <input ref={inputRef} id="camellia-input" value={input} onChange={(event) => setInput(event.target.value)} placeholder="Describe what you need…" maxLength={1200} />
        <button type="submit" disabled={!input.trim() || busy} aria-label="Send message"><Icon name="arrowUp" size={17} /></button>
      </form>
      <p className="assistant-footnote"><Icon name="shield" size={13} /> No passwords, payment PINs, or private access keys. A person confirms every quote.</p>
    </section>
  );
}

function ServiceCard({ service, onQuote }) {
  const categoryName = getCategoryName(service.category);
  return (
    <article className={`service-card card-${service.category}`}>
      <div className="service-card-top">
        <span className="service-category"><i />{categoryName}</span>
        <span className="service-icon"><Icon name={service.category === "gravatar" ? "globe" : service.category === "iptv" ? "layers" : "spark"} size={17} /></span>
      </div>
      <h3>{service.name}</h3>
      <p className="service-summary">{service.summary}</p>
      <div className="service-meta">
        <div><span>Guide price</span><strong>{service.rateUSD}</strong><small>{service.rateBDT}</small></div>
        <div><span>Typical timing</span><strong className="timing"><Icon name="clock" size={14} />{service.turnaround}</strong></div>
      </div>
      <div className="service-card-actions">
        {service.kind === "external" ? (
          <a className="text-link" href={service.externalUrl} target="_blank" rel="noreferrer">Plans & activation <Icon name="external" size={14} /></a>
        ) : service.kind === "existing-order" ? (
          <a className="text-link" href={service.existingOrderUrl} target="_blank" rel="noreferrer">Continue to order <Icon name="external" size={14} /></a>
        ) : (
          <button type="button" className="text-link" onClick={() => onQuote(service)}>Scope this service <Icon name="arrow" size={14} /></button>
        )}
        <span className="service-arrow"><Icon name="arrow" size={16} /></span>
      </div>
    </article>
  );
}

function QuoteModal({ open, service, onClose }) {
  const [form, setForm] = useState({ name: "", email: "", whatsapp: "", brief: "", consent: false });
  const [serviceSlug, setServiceSlug] = useState(service?.slug ?? SERVICES[0].slug);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [confirmation, setConfirmation] = useState("");

  useEffect(() => {
    if (open) {
      setServiceSlug(service?.slug ?? SERVICES[0].slug);
      setError("");
      setConfirmation("");
    }
  }, [open, service]);

  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (event) => { if (event.key === "Escape" && !submitting) onClose(); };
    document.addEventListener("keydown", onKeyDown);
    document.body.classList.add("modal-open");
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.classList.remove("modal-open");
    };
  }, [open, submitting, onClose]);

  if (!open) return null;

  const selected = SERVICES.find((item) => item.slug === serviceSlug) || SERVICES[0];
  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  async function submit(event) {
    event.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const response = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, serviceSlug }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "We couldn’t send your request. Please try again.");
      setConfirmation(data.id);
      setForm({ name: "", email: "", whatsapp: "", brief: "", consent: false });
    } catch (submitError) {
      setError(submitError.message || "Could not submit your request. Please retry.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="modal-scrim" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !submitting) onClose(); }}>
      <section className="quote-modal" role="dialog" aria-modal="true" aria-labelledby={confirmation ? "success-title" : "quote-title"}>
        <button type="button" className="modal-close" onClick={onClose} aria-label="Close request form" disabled={submitting}><Icon name="close" size={20} /></button>
        {confirmation ? (
          <div className="quote-success">
            <span className="success-mark"><Icon name="check" size={25} /></span>
            <span className="eyebrow"><span className="eyebrow-line" />Brief received</span>
            <h2 id="success-title">Good work starts with a clear brief.</h2>
            <p>Your request is in the operations queue. A person will review the scope and contact you using the details you provided.</p>
            <div className="reference-number"><span>Reference</span><strong>{confirmation}</strong></div>
            <button type="button" className="button button-lime" onClick={onClose}>Done <Icon name="arrow" size={15} /></button>
          </div>
        ) : (
          <>
            <span className="eyebrow"><span className="eyebrow-line" />Start with the outcome</span>
            <h2 id="quote-title">Request a service brief</h2>
            <p className="modal-intro">Share the goal and constraints. Camellia can help you scope it; a human confirms the final quote before work begins.</p>
            <form className="quote-form" onSubmit={submit}>
              <label className="field-label">Service
                <select value={serviceSlug} onChange={(event) => setServiceSlug(event.target.value)}>
                  {SERVICES.filter((item) => item.kind !== "external").map((item) => <option key={item.slug} value={item.slug}>{item.name}</option>)}
                </select>
              </label>
              <div className="form-grid">
                <label className="field-label">Your name
                  <input autoComplete="name" required minLength={2} maxLength={80} value={form.name} onChange={(event) => update("name", event.target.value)} placeholder="Name" />
                </label>
                <label className="field-label">Email address
                  <input autoComplete="email" type="email" maxLength={254} value={form.email} onChange={(event) => update("email", event.target.value)} placeholder="you@example.com" />
                </label>
              </div>
              <label className="field-label">WhatsApp / phone <span className="optional-label">optional</span>
                <input autoComplete="tel" maxLength={32} value={form.whatsapp} onChange={(event) => update("whatsapp", event.target.value)} placeholder="Include country code if useful" />
              </label>
              <label className="field-label">What would a good result look like?
                <textarea required minLength={20} maxLength={3000} rows={4} value={form.brief} onChange={(event) => update("brief", event.target.value)} placeholder="Tell us the goal, tools or platform, any deadline, and what is already in place…" />
              </label>
              <label className="consent-row">
                <input type="checkbox" checked={form.consent} onChange={(event) => update("consent", event.target.checked)} required />
                <span>I agree to be contacted about this request. I will not include passwords, payment details, or private access keys.</span>
              </label>
              {error && <p className="form-error" role="alert">{error}</p>}
              <div className="quote-form-footer">
                <span><Icon name="shield" size={14} /> Sent securely to the MRS operations desk.</span>
                <button type="submit" className="button button-lime" disabled={submitting}>{submitting ? "Sending…" : "Send brief"}<Icon name="arrow" size={15} /></button>
              </div>
            </form>
          </>
        )}
      </section>
    </div>
  );
}

function App() {
  const [health, setHealth] = useState(null);
  const [activeFilter, setActiveFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [quoteService, setQuoteService] = useState(null);
  const catalogSearchRef = useRef(null);

  useEffect(() => {
    fetch("/api/health").then((response) => response.json()).then(setHealth).catch(() => setHealth({ aiMode: "offline" }));
  }, []);

  useEffect(() => {
    const handleSearchShortcut = (event) => {
      const target = event.target;
      if (event.key !== "/" || event.metaKey || event.ctrlKey || event.altKey || document.body.classList.contains("modal-open")) return;
      if (target instanceof HTMLElement && !target.isContentEditable && !["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) {
        event.preventDefault();
        catalogSearchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handleSearchShortcut);
    return () => window.removeEventListener("keydown", handleSearchShortcut);
  }, []);

  const filteredServices = useMemo(() => {
    const term = search.trim().toLowerCase();
    return SERVICES.filter((service) => {
      const matchesCategory = activeFilter === "all" || service.category === activeFilter;
      const haystack = `${service.name} ${service.summary} ${getCategoryName(service.category)} ${service.rateUSD}`.toLowerCase();
      return matchesCategory && (!term || haystack.includes(term));
    });
  }, [activeFilter, search]);

  const openQuote = (service = null) => {
    setQuoteService(service);
    setQuoteOpen(true);
  };

  const filterCategory = (key) => {
    setActiveFilter(key);
    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <Header />
      <main id="top">
        <section className="hero-section">
          <div className="hero-grid-lines" aria-hidden="true" />
          <div className="hero-glow hero-glow-one" aria-hidden="true" />
          <div className="hero-glow hero-glow-two" aria-hidden="true" />
          <div className="hero-content wrap">
            <div className="hero-copy">
              <div className="eyebrow hero-eyebrow"><span className="signal-dot" />Independent digital operations studio <span className="eyebrow-divider">/</span> Bangladesh · Worldwide</div>
              <h1>Make complex work <span>feel effortless.</span></h1>
              <p className="hero-lede">AI workflows, technical delivery, and digital support—brought together in one clear, human-led service studio.</p>
              <div className="hero-actions">
                <a className="button button-lime" href="#catalog">Explore the catalog <Icon name="arrow" size={16} /></a>
                <a className="button button-outline" href="#concierge"><span className="button-spark"><Icon name="spark" size={15} /></span>Ask Camellia</a>
              </div>
              <div className="hero-assurance">
                <div className="assurance-avatars" aria-hidden="true"><span>M</span><span>R</span><span>S</span></div>
                <p><strong>Built around real delivery.</strong><br />A human confirms scope, price, and next steps.</p>
              </div>
            </div>
            <div className="hero-side">
              <div className="console-label"><span className="console-label-left"><i className="signal-dot" />MRS / SERVICE DESK</span><span>01 — 03</span></div>
              <AssistantPanel health={health} />
              <div className="hero-side-note"><span className="mini-orbit"><i /><i /><i /></span><span>From first question to a clear next step.</span><Icon name="arrow" size={14} /></div>
            </div>
          </div>
          <div className="hero-bottom-line wrap"><span>Operational clarity for people who build</span><span>01 / SERVICE STUDIO</span></div>
        </section>

        <section className="metrics-band" aria-label="Studio highlights">
          <div className="wrap metrics-grid">
            <div className="metric-item"><span className="metric-icon"><Icon name="layers" size={17} /></span><div><strong>16</strong><span>focused services</span></div></div>
            <div className="metric-item"><span className="metric-icon"><Icon name="globe" size={17} /></span><div><strong>03</strong><span>solution tracks</span></div></div>
            <div className="metric-item"><span className="metric-icon"><Icon name="clock" size={17} /></span><div><strong>Clear</strong><span>service-specific timing</span></div></div>
            <div className="metric-item"><span className="metric-icon"><Icon name="shieldCheck" size={17} /></span><div><strong>Human</strong><span>review before delivery</span></div></div>
          </div>
        </section>

        <section className="solutions-section section-light" id="solutions">
          <div className="wrap">
            <div className="solutions-heading-row">
              <SectionTitle eyebrow="One studio · three focused tracks" title={<>The right kind of help, <em>without the runaround.</em></>} body="Choose a delivery lane. We’ll make the scope, cost, and hand-off clear before the work starts." light />
              <div className="section-index light-index"><span>02</span><i /></div>
            </div>
            <div className="solution-cards">
              {SERVICE_CATEGORIES.map((category, index) => (
                <article className={`solution-card solution-${category.key}`} key={category.key}>
                  <div className="solution-card-head"><span className="solution-number">0{index + 1} / TRACK</span><span className="solution-card-icon"><Icon name={category.key === "mrs" ? "code" : category.key === "gravatar" ? "globe" : "layers"} size={19} /></span></div>
                  <div className="solution-card-content">
                    <span className="solution-count">{String(category.count).padStart(2, "0")} SERVICES</span>
                    <h3>{category.name}</h3>
                    <p>{category.description}</p>
                    <button className="solution-link" type="button" onClick={() => filterCategory(category.key)}>Explore {category.shortName}<Icon name="arrow" size={15} /></button>
                  </div>
                  <span className="solution-card-art" aria-hidden="true"><i /><i /><i /></span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="catalog-section" id="catalog">
          <div className="wrap">
            <div className="catalog-top-row">
              <SectionTitle eyebrow="The service catalog / 16 routes" title={<>Small teams. <span className="text-ink-accent">Serious follow-through.</span></>} body="Transparent guide prices and typical delivery windows. Every custom scope is confirmed with you before work begins." />
              <div className="catalog-side-note"><span className="catalog-asterisk">✳</span><p>Can’t decide where to start?<br /><a href="#concierge">Ask Camellia for a recommendation <Icon name="arrow" size={13} /></a></p></div>
            </div>
            <div className="catalog-controls">
              <div className="filter-tabs" role="tablist" aria-label="Filter services by track">
                <button type="button" role="tab" aria-selected={activeFilter === "all"} className={activeFilter === "all" ? "active" : ""} onClick={() => setActiveFilter("all")}>All <span>16</span></button>
                <button type="button" role="tab" aria-selected={activeFilter === "mrs"} className={activeFilter === "mrs" ? "active" : ""} onClick={() => setActiveFilter("mrs")}>MRS Services</button>
                <button type="button" role="tab" aria-selected={activeFilter === "gravatar"} className={activeFilter === "gravatar" ? "active" : ""} onClick={() => setActiveFilter("gravatar")}>Identity</button>
                <button type="button" role="tab" aria-selected={activeFilter === "iptv"} className={activeFilter === "iptv" ? "active" : ""} onClick={() => setActiveFilter("iptv")}>IPTV</button>
              </div>
              <label className="catalog-search"><Icon name="search" size={17} /><span className="sr-only">Search services</span><input ref={catalogSearchRef} value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search a service…" /><kbd>/</kbd></label>
            </div>
            <div className="catalog-result-line"><span>Showing <strong>{filteredServices.length.toString().padStart(2, "0")}</strong> of 16 delivery routes</span><span className="catalog-listing-note"><i /> ESTIMATES SHOWN IN USD & BDT</span></div>
            {filteredServices.length ? (
              <div className="service-grid">
                {filteredServices.map((service) => <ServiceCard key={service.slug} service={service} onQuote={openQuote} />)}
              </div>
            ) : (
              <div className="empty-results"><Icon name="search" size={22} /><h3>No service matches that search.</h3><p>Try another term or reset the category filter.</p><button type="button" className="text-link" onClick={() => { setSearch(""); setActiveFilter("all"); }}>Show all services <Icon name="arrow" size={15} /></button></div>
            )}
            <p className="catalog-footnote"><Icon name="shield" size={14} /> Guide prices are based on the current public catalog and may change. Final scope, availability, and price are confirmed directly.</p>
          </div>
        </section>

        <section className="approach-section" id="approach">
          <div className="wrap approach-wrap">
            <div className="approach-intro">
              <SectionTitle eyebrow="Delivery, with a clear owner" title={<>A process that keeps <em>people in control.</em></>} body="Automation handles the busywork. A real person owns the scope, checks the details, and signs off on delivery." />
              <div className="approach-note"><span className="note-mark"><Icon name="shieldCheck" size={19} /></span><p><strong>No mystery hand-offs.</strong><br />You see the next step before we move to it.</p></div>
            </div>
            <div className="process-list">
              {[
                ["01", "Share the outcome", "Tell us what is stuck, what you need, and any useful deadline."],
                ["02", "Get a focused recommendation", "Camellia can route your brief to a relevant service and surface the published guide price."],
                ["03", "Confirm scope and price", "A human reviews your requirements and confirms what is included before work starts."],
                ["04", "Approve the next step", "Payment and order details stay in the existing, appropriate channel."],
                ["05", "Receive the hand-off", "Deliverables are shared through the agreed channel, with a clear completion note."],
              ].map(([number, title, description], index) => (
                <article className="process-step" key={number}>
                  <span className="process-number">{number}</span>
                  <div className="process-copy"><h3>{title}</h3><p>{description}</p></div>
                  <span className={`process-status ${index === 1 ? "status-ai" : ""}`}>{index === 1 ? "AI-ASSISTED" : index === 2 || index === 3 ? "HUMAN CHECK" : "MRS FLOW"}</span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="intelligence-section">
          <div className="wrap intelligence-wrap">
            <div className="intelligence-copy">
              <span className="eyebrow"><span className="eyebrow-line" />Designed for responsible automation</span>
              <h2>Smart enough to help.<br /><em>Grounded enough to trust.</em></h2>
              <p>Camellia uses the service catalog to help clarify needs and suggest a sensible route. It does not approve payment, promise availability, or replace a human scope review.</p>
              <a className="button button-outline" href="#concierge"><Icon name="spark" size={15} />Try the concierge</a>
            </div>
            <div className="intelligence-points">
              <article><span className="point-icon"><Icon name="scan" size={18} /></span><div><h3>Catalog-grounded answers</h3><p>Rates and service details come from the published catalog, not guesswork.</p></div></article>
              <article><span className="point-icon"><Icon name="user" size={18} /></span><div><h3>Human-approved commitments</h3><p>Camellia can recommend and organize. People confirm the quote and delivery.</p></div></article>
              <article><span className="point-icon"><Icon name="shield" size={18} /></span><div><h3>Secrets stay out of chat</h3><p>Never share passwords, payment PINs, private keys, or remote-access codes here.</p></div></article>
            </div>
            <div className="intelligence-orbit" aria-hidden="true"><span /><span /><span /><i /></div>
          </div>
        </section>

        <section className="closing-section">
          <div className="wrap closing-card">
            <div className="closing-backdrop" aria-hidden="true"><span /><span /><span /></div>
            <div className="closing-copy">
              <span className="eyebrow"><span className="eyebrow-line" />Ready when you are</span>
              <h2>Bring the messy brief.<br /><em>Leave with a system.</em></h2>
              <p>Start with a quick conversation or send a structured service brief to the operations desk.</p>
              <div className="closing-actions">
                <a className="button button-lime" href="#concierge">Start with Camellia <Icon name="arrow" size={16} /></a>
                <button className="button button-outline" type="button" onClick={() => openQuote()}>Send a service brief <Icon name="arrow" size={15} /></button>
              </div>
            </div>
            <div className="closing-side">
              <div className="closing-dial"><span>01</span><i /><span>05</span></div>
              <p>From first question<br />to final hand-off.</p>
              <a href={PORTAL_URL} target="_blank" rel="noreferrer">Already a client? Open your workspace <Icon name="external" size={14} /></a>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="wrap footer-main">
          <a className="brand footer-brand" href="#top" aria-label="M R S Services home">
            <span className="brand-mark"><span>M</span><i>R</i><span>S</span></span>
            <span className="brand-copy"><strong>MRS</strong><small>SERVICE STUDIO</small></span>
          </a>
          <p className="footer-tagline">Practical digital work.<br /><span>Delivered with intention.</span></p>
          <div className="footer-links"><span>Explore</span><a href="#catalog">Service catalog</a><a href="#approach">Our process</a><a href="#concierge">Camellia AI</a></div>
          <div className="footer-links"><span>Connect</span><a href="https://calendly.com/mrxshahin" target="_blank" rel="noreferrer">Book a scoping call <Icon name="external" size={12} /></a><a href="mailto:mr216873@gmail.com">Email operations <Icon name="external" size={12} /></a><a href={PORTAL_URL} target="_blank" rel="noreferrer">Client portal <Icon name="external" size={12} /></a><a href="https://wa.me/8801810853282" target="_blank" rel="noreferrer">WhatsApp support <Icon name="external" size={12} /></a><a href="https://mrs-services.ai.studio/privacy" target="_blank" rel="noreferrer">Privacy & isolation <Icon name="external" size={12} /></a></div>
        </div>
        <div className="wrap footer-bottom"><span>© {new Date().getFullYear()} M R S Services. Built for clear, human-led delivery.</span><span><Icon name="shield" size={13} /> Essential session state only · Never send secrets in chat</span><a href="#top" className="back-top">Back to top <Icon name="arrowUp" size={14} /></a></div>
      </footer>

      <QuoteModal open={quoteOpen} service={quoteService} onClose={() => setQuoteOpen(false)} />
    </>
  );
}

export default App;
